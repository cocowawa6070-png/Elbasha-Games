package com.mostafabek.elbashagames

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.util.Base64
import android.provider.OpenableColumns
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ElbashaApp(
    auth: FirebaseAuth,
    sound: SoundManager,
    databaseUrl: String,
    onGoogleSignIn: ((String?) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val settingsPrefs = remember { context.getSharedPreferences("elbasha_ui", android.content.Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(settingsPrefs.getBoolean("english", false)) }
    var darkTheme by remember { mutableStateOf(settingsPrefs.getBoolean("dark_theme", true)) }
    val settings = AppUiSettings(english = english, darkTheme = darkTheme)
    val palette = paletteFor(darkTheme)
    val database = remember(databaseUrl) {
        val candidate = databaseUrl.trim().trimEnd('/')
        val host = candidate.removePrefix("https://").substringBefore('/')
        val looksLikeRealtimeDatabaseUrl = candidate.startsWith("https://") &&
            (host.endsWith(".firebaseio.com") || host.endsWith(".firebasedatabase.app"))
        if (looksLikeRealtimeDatabaseUrl) runCatching { FirebaseDatabase.getInstance(candidate) }.getOrNull() else null
    }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var isDeveloper by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf<String?>(null) }

    val toggleLanguage = {
        english = !english
        settingsPrefs.edit().putBoolean("english", english).apply()
    }
    val toggleTheme = {
        darkTheme = !darkTheme
        settingsPrefs.edit().putBoolean("dark_theme", darkTheme).apply()
    }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(currentUser?.uid) {
        val user = currentUser
        if (user == null) {
            isDeveloper = false
        } else {
            saveUserProfile(database, user)
            // The developer panel is intentionally bound to the configured developer UID only.
            // A database-side boolean must never promote another account to developer access.
            isDeveloper = ElbashaAccess.isDeveloper(user.uid)
        }
    }

    val colorScheme = if (darkTheme) darkColorScheme(
        primary = palette.gold,
        onPrimary = palette.deepWine,
        secondary = Color(0xFFCF8A3C),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    ) else lightColorScheme(
        primary = palette.gold,
        onPrimary = Color.White,
        secondary = Color(0xFFB56A19),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    )

    CompositionLocalProvider(
        LocalAppUiSettings provides settings,
        LocalElbashaPalette provides palette,
        LocalLayoutDirection provides if (english) LayoutDirection.Ltr else LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = colorScheme) {
            Surface(modifier = Modifier.fillMaxSize(), color = DeepWine) {
                if (currentUser == null) {
                    AuthScreen(
                        auth = auth,
                        database = database,
                        message = authMessage,
                        onMessage = { authMessage = it },
                        onGoogleSignIn = {
                            onGoogleSignIn { error -> authMessage = error ?: if (english) "Signed in with Google" else "تم تسجيل الدخول بحساب Google" }
                        },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                } else {
                    MainHub(
                        user = currentUser!!,
                        database = database,
                        sound = sound,
                        isDeveloper = isDeveloper,
                        onSignOut = { auth.signOut() },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                }
            }
        }
    }
}

private fun saveUserProfile(database: FirebaseDatabase?, user: FirebaseUser) {
    if (database == null) return
    val displayName = (user.displayName?.takeIf { it.isNotBlank() }
        ?: user.email?.substringBefore("@")
        ?: "لاعب جديد").take(28)

    // Keep email in the private user node; only the public profile is readable by other players.
    val privateReference = database.reference.child("users").child(user.uid)
    privateReference.get().addOnSuccessListener { snapshot ->
        val privateUpdates = hashMapOf<String, Any>(
            "email" to (user.email ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) privateUpdates["createdAt"] = ServerValue.TIMESTAMP
        privateReference.updateChildren(privateUpdates)
    }

    val publicReference = database.reference.child("publicProfiles").child(user.uid)
    publicReference.get().addOnSuccessListener { snapshot ->
        val publicUpdates = hashMapOf<String, Any>(
            "displayName" to displayName,
            "photoUrl" to (user.photoUrl?.toString() ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) publicUpdates["createdAt"] = ServerValue.TIMESTAMP
        publicReference.updateChildren(publicUpdates)
    }
}

@Composable
private fun AuthScreen(
    auth: FirebaseAuth,
    database: FirebaseDatabase?,
    message: String?,
    onMessage: (String?) -> Unit,
    onGoogleSignIn: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    var registerMode by remember { mutableStateOf(true) }
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val english = LocalAppUiSettings.current.english
    val contextText = if (registerMode) uiText("إنشاء حساب جديد", "Create account") else uiText("تسجيل الدخول", "Sign in")

    Box(
        modifier = Modifier.fillMaxSize().elbashaAtmosphere(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.elbasha_logo),
                contentDescription = "Elbasha Games logo",
                modifier = Modifier.size(220.dp),
                contentScale = ContentScale.Fit
            )
            Text("ELBASHA GAMES", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("THE FOOTBALL PLAYGROUND", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onToggleLanguage) { Text(if (LocalAppUiSettings.current.english) "العربية" else "English", color = Gold) }
                TextButton(onClick = onToggleTheme) { Text(if (LocalAppUiSettings.current.darkTheme) uiText("☀️ الوضع النهاري", "☀️ Light mode") else uiText("🌙 الوضع الليلي", "🌙 Dark mode"), color = Gold) }
            }
            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = PanelColor)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(contextText, color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (registerMode) {
                        OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(uiText("اسم اللاعب", "Player name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(uiText("البريد الإلكتروني", "Email address")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(uiText("كلمة المرور", "Password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            onMessage(null)
                            if (!email.contains("@") || password.length < 6 || (registerMode && displayName.trim().length !in 2..28)) {
                                onMessage(if (english) "Check your email, password (6+ characters), and player name (2-28 characters)." else "راجع البريد وكلمة المرور (6 أحرف على الأقل) واسم اللاعب (من حرفين إلى 28)")
                            } else {
                                busy = true
                                val task = if (registerMode) auth.createUserWithEmailAndPassword(email.trim(), password)
                                    else auth.signInWithEmailAndPassword(email.trim(), password)
                                task.addOnCompleteListener { result ->
                                    busy = false
                                    if (result.isSuccessful) {
                                        val signedUser = auth.currentUser
                                        if (registerMode && signedUser != null) {
                                            val request = UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
                                            signedUser.updateProfile(request).addOnCompleteListener {
                                                saveUserProfile(database, signedUser)
                                                signedUser.sendEmailVerification()
                                                onMessage(if (english) "Account created. Check your inbox to verify your email." else "تم إنشاء الحساب. راجع بريدك لتأكيده.")
                                            }
                                        } else {
                                            onMessage(if (english) "Signed in successfully" else "تم تسجيل الدخول بنجاح")
                                        }
                                    } else {
                                        onMessage(result.exception?.localizedMessage ?: "تعذر إكمال العملية")
                                    }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = DeepWine, strokeWidth = 2.dp)
                        else Text(if (registerMode) uiText("إنشاء الحساب", "Create account") else uiText("دخول", "Sign in"), fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onGoogleSignIn,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
                    ) { Text(uiText("الدخول باستخدام Google", "Continue with Google")) }
                    TextButton(onClick = { registerMode = !registerMode; onMessage(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (registerMode) uiText("عندك حساب؟ سجّل دخول", "Already have an account? Sign in") else uiText("لسه جديد؟ أنشئ حساب", "New here? Create an account"), color = Gold)
                    }
                    if (!registerMode) {
                        TextButton(onClick = {
                            if (!email.contains("@")) onMessage(if (english) "Enter your email address first" else "اكتب بريدك الإلكتروني الأول")
                            else auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { task ->
                                onMessage(if (task.isSuccessful) {
                                    if (english) "Password reset link sent" else "تم إرسال رابط استعادة كلمة المرور"
                                } else task.exception?.localizedMessage ?: if (english) "Could not send the link" else "تعذر إرسال الرابط")
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(uiText("نسيت كلمة المرور؟", "Forgot password?"), color = Muted) }
                    }
                    message?.let { Text(it, color = if (it.contains("نجاح") || it.contains("تم إنشاء") || it.contains("تم إرسال") || it.contains("successfully") || it.contains("created") || it.contains("sent")) Gold else LocalElbashaPalette.current.bad, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("DEVELOPED BY MOSTAFA BEK", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class GameItem(val id: String, val titleAr: String, val titleEn: String, val subtitleAr: String, val subtitleEn: String, val emoji: String, val ready: Boolean = false)
private data class RankItem(val uid: String, val name: String, val points: Long)

@Composable
private fun MainHub(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    isDeveloper: Boolean,
    onSignOut: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val appContext = LocalContext.current
    val english = LocalAppUiSettings.current.english
    var page by remember { mutableStateOf("home") }
    var leaderboard by remember { mutableStateOf<List<RankItem>>(emptyList()) }
    var firebaseConnected by remember { mutableStateOf<Boolean?>(null) }
    var photoCacheRevision by remember { mutableIntStateOf(0) }
    var isLoadingAllPhotos by remember { mutableStateOf(false) }
    var photoLoadProgress by remember { mutableStateOf(0f) }
    var photoLoadStatus by remember { mutableStateOf("") }
    var photoLoadJob by remember { mutableStateOf<Job?>(null) }
    var sharedMusicName by remember { mutableStateOf("") }
    var musicUploadStatus by remember { mutableStateOf("") }
    var appliedMusicTimestamp by remember { mutableStateOf(0L) }
    val uiScope = rememberCoroutineScope()
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            musicUploadStatus = localizedText(english, "جاري قراءة الملف...", "Reading audio file...")
            uiScope.launch {
                try {
                    val (audioBytes, audioName) = withContext(Dispatchers.IO) {
                        val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف")
                        val displayName = appContext.contentResolver.query(
                            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                        val name = displayName?.take(100)?.ifBlank { "Elbasha Music" }
                            ?: uri.lastPathSegment?.substringAfterLast('/')?.take(100)?.ifBlank { "Elbasha Music" }
                            ?: "Elbasha Music"
                        bytes to name
                    }
                    if (audioBytes.isEmpty()) throw IllegalArgumentException("الملف فارغ")
                    val signedInUid = user.uid.takeIf { it.isNotBlank() }
                        ?: throw IllegalStateException(if (english) "Sign in again before uploading shared music." else "سجّل الدخول من جديد قبل رفع موسيقى الجروب.")
                    if (!ElbashaAccess.isDeveloper(signedInUid)) throw SecurityException(
                        if (english) "This account is not the developer account allowed to upload shared music." else "الحساب الحالي ليس حساب المطور المسموح له برفع موسيقى الجروب."
                    )
                    if (audioBytes.size > 5 * 1024 * 1024) throw IllegalArgumentException(
                        if (english) "Choose an audio file smaller than 5 MB." else "اختار ملف صوت أقل من 5 ميجابايت."
                    )
                    val encoded = withContext(Dispatchers.Default) {
                        Base64.encodeToString(audioBytes, Base64.NO_WRAP)
                    }
                    val reference = database?.reference?.child("sharedMusic")?.child("current")
                        ?: throw IllegalStateException(if (english) "Firebase is not configured." else "Firebase غير مهيأ.")
                    val payload = mapOf(
                        "name" to audioName,
                        "mimeType" to (appContext.contentResolver.getType(uri) ?: "audio/*"),
                        "data" to encoded,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    reference.setValue(payload).addOnCompleteListener { task ->
                        musicUploadStatus = if (task.isSuccessful) {
                            if (english) "Uploaded. The new track is syncing to everyone." else "تم الرفع. الأغنية الجديدة بتتزامن مع كل اللاعبين."
                        } else {
                            val detail = task.exception?.localizedMessage.orEmpty()
                            if (detail.contains("Permission denied", ignoreCase = true)) {
                                if (english) "Firebase denied this upload. Confirm the deployed Realtime Database rules allow sharedMusic/current for developer UID ${user.uid}." else "Firebase رفض الرفع. راجع قواعد Realtime Database المنشورة وتأكد أن sharedMusic/current مسموح لحساب المطور الحالي (${user.uid})."
                            } else detail.ifBlank { if (english) "Upload failed." else "فشل رفع الأغنية." }
                        }
                    }
                } catch (error: Exception) {
                    musicUploadStatus = error.localizedMessage ?: if (english) "Could not upload this audio file." else "تعذر رفع الملف الصوتي."
                }
            }
        }
    }
    val cachedPlayerPhotos = remember(page, photoCacheRevision) { PlayerImageRepository.cachedCount(appContext) }
    val bundledPlayerPhotos = remember(page, photoCacheRevision) { PlayerImageRepository.bundledCount(appContext) }
    val cachedPhotoBytes = remember(page, photoCacheRevision) { PlayerImageRepository.cachedBytes(appContext) }
    val games = listOf(
        GameItem("auction", "المزاد الكروي", "Football Auction", "زايد على النجوم وابنِ فريقك", "Bid for stars and build your squad", "🔨", ready = true),
        GameItem("deal", "صندوق الحظ", "Deal or No Deal", "افتح الصناديق واختبر حظك", "Open the boxes and test your luck", "🎁", ready = true),
        GameItem("build", "كون فريق", "Build Your Team", "كوّن فريقًا من 4 إلى 11 لاعبًا", "Build a squad of 4 to 11 players", "🧩", ready = true)
    )
DisposableEffect(database, isDeveloper) {
        val reference = if (isDeveloper) database?.reference?.child(".info/connected") else null
        if (reference == null) {
            firebaseConnected = null
            onDispose { }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    firebaseConnected = snapshot.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(error: DatabaseError) { firebaseConnected = false }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
            }
        }
    }

DisposableEffect(database) {
        val reference = database?.reference?.child("leaderboard")
        if (reference == null) {
            leaderboard = emptyList()
            onDispose { }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    leaderboard = snapshot.children
                        .filter { child -> child.key != ElbashaAccess.DeveloperUid }
                        .map { child ->
                        RankItem(
                            uid = child.key ?: "",
                            name = child.child("displayName").getValue(String::class.java) ?: "لاعب",
                            points = child.child("totalPoints").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedByDescending { it.points }.take(50)
                }
                override fun onCancelled(error: DatabaseError) { }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
            }
        }
    }

    DisposableEffect(database, sound) {
        val reference = database?.reference?.child("sharedMusic")?.child("current")
        if (reference == null) {
            sharedMusicName = ""
            onDispose { sound.clearSharedMusic() }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val encoded = snapshot.child("data").getValue(String::class.java)
                    val timestamp = snapshot.child("updatedAt").getValue(Long::class.java) ?: 0L
                    val trackName = snapshot.child("name").getValue(String::class.java).orEmpty()
                    if (encoded.isNullOrBlank() || timestamp <= 0L) {
                        sharedMusicName = ""
                        sound.clearSharedMusic()
                        return
                    }
                    sharedMusicName = trackName
                    if (timestamp != appliedMusicTimestamp) {
                        appliedMusicTimestamp = timestamp
                        uiScope.launch(Dispatchers.IO) {
                            val cachedFile = File(appContext.cacheDir, "elbasha_shared_music_$timestamp.bin")
                            val saved = runCatching {
                                val bytes = Base64.decode(encoded, Base64.DEFAULT)
                                require(bytes.isNotEmpty() && bytes.size <= 5 * 1024 * 1024)
                                cachedFile.writeBytes(bytes)
                                cachedFile
                            }.getOrNull()
                            withContext(Dispatchers.Main) {
                                if (saved != null) {
                                    sound.setSharedMusic(saved)
                                    appContext.cacheDir.listFiles()?.filter {
                                        it.name.startsWith("elbasha_shared_music_") && it != saved
                                    }?.forEach { it.delete() }
                                } else musicUploadStatus = if (english) "The shared track could not be decoded." else "تعذر قراءة الأغنية المشتركة."
                            }
                        }
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    musicUploadStatus = error.message
                }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
                sound.clearSharedMusic()
            }
        }
    }

    when (page) {
        "trivia" -> { TriviaScreen(user, database, sound) { page = "home" }; return }
        "guess" -> { GuessPlayerScreen(user, database, sound) { page = "home" }; return }
        "stats" -> { StatsChallengeScreen(user, database, sound) { page = "home" }; return }
        "build" -> { BuildTeamScreen(user, database, sound) { page = "home" }; return }
        "auction" -> { AuctionGameScreen(user, database, sound) { page = "home" }; return }
        "deal" -> { DealOrNoDealScreen(user, database, sound) { page = "home" }; return }
        "penalty" -> { PenaltyShootoutScreen(user, database, sound) { page = "home" }; return }
        "rooms" -> { OnlineRoomsScreen(user, database) { page = "home" }; return }
    }

    Column(
        modifier = Modifier.fillMaxSize().elbashaAtmosphere()
            .verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, Gold.copy(alpha = 0.45f), RoundedCornerShape(26.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(26.dp)
        ) {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Wine, PanelColor, DeepWine)))) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(82.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("ELBASHA GAMES", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(uiText("أهلاً يا ${user.displayName ?: user.email?.substringBefore("@") ?: "باشا"}", "Welcome, ${user.displayName ?: user.email?.substringBefore("@") ?: "Boss"}"), color = Cream, fontSize = 14.sp)
                            Text(uiText("ملعبك. قوانينك. بطولتك.", "Your pitch. Your rules. Your glory."), color = Muted, fontSize = 10.sp)
                        }
                        SoundToggles(sound)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(uiText("العرش مستني البطل", "The throne awaits"), color = Cream, fontSize = 23.sp, fontWeight = FontWeight.Black)
                            Text(uiText("اختار لعبتك وابدأ المنافسة ضد الذكاء الاصطناعي.", "Choose a game and start your challenge against AI."), color = Muted, fontSize = 12.sp)
                        }
                        Text("♛", color = Gold, fontSize = 42.sp, fontWeight = FontWeight.Black)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallStat(uiText("الألعاب الأساسية", "Core games"), "${games.size}", Modifier.weight(1f))
                        SmallStat(uiText("اللاعبون", "Players"), "${leaderboard.size}", Modifier.weight(1f))
                        SmallStat(uiText("ترتيبك", "Your rank"), if (leaderboard.any { it.uid == user.uid }) "${leaderboard.indexOfFirst { it.uid == user.uid } + 1}" else "—", Modifier.weight(1f))
                    }
                }
            }
        }
        if (database == null) {
            InfoCard(
                uiText("وضع اللعب الفردي", "Single-player mode"),
                uiText("الألعاب المدمجة شغالة. اربط Realtime Database لتفعيل لوحة المتصدرين وحفظ النقاط بين الأجهزة.", "Built-in games are ready. Connect Realtime Database to enable the leaderboard and cross-device score saving.")
            )
        }
        Card(
            onClick = { page = "rooms" },
            modifier = Modifier.fillMaxWidth().border(1.dp, Gold.copy(alpha = 0.5f), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(PanelAltColor, Wine))).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText("غرف أونلاين", "ONLINE ROOMS"), color = Gold, fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text(uiText("أنشئ غرفة خاصة أو ادخل بكود • حتى 10 لاعبين", "Create or join by code • up to 10 players"), color = Cream, fontSize = 11.sp)
                }
                Text("⌁", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            NavButton(uiText("🎮 العب", "🎮 Play"), page == "home" || page == "games", Modifier.weight(1f)) { page = "games" }
            NavButton(uiText("⚙️ الإعدادات", "⚙️ Settings"), page == "settings", Modifier.weight(1f)) { page = "settings" }
            NavButton(uiText("🏅 ضيوف الشرف", "🏅 Hall of Fame"), page == "honors", Modifier.weight(1f)) { page = "honors" }
        }

        when (page) {
            "rank" -> {
                SectionTitle(uiText("🏆 لوحة المتصدرين", "🏆 Leaderboard"))
                if (leaderboard.isEmpty()) InfoCard(uiText("لسه مفيش نتائج", "No results yet"), uiText("أول ما النقاط تتسجل، ترتيب الأبطال هيظهر هنا.", "Player rankings will appear here after the first scores are saved."))
                leaderboard.forEachIndexed { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = if (item.uid == user.uid) PanelAltColor else PanelColor)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(14.dp))
                            Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                            Text(uiText("${item.points} نقطة", "${item.points} pts"), color = Gold, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            "honors" -> {
                SectionTitle(uiText("🏅 ضيوف الشرف", "🏅 Hall of Fame"))
                InfoCard(
                    uiText("القسم قيد التجهيز", "Section is being prepared"),
                    uiText("هنبني تصميم ضيوف الشرف على الموقع المرجعي اللي هتحدده، من غير ما نخترع شكل مختلف عن طلبك.", "This section will follow the reference website you choose. Its design is intentionally pending that reference.")
                )
            }
            "profile" -> {
                SectionTitle(uiText("👤 حساب اللاعب", "👤 Player profile"))
                InfoCard(user.displayName ?: uiText("لاعب Elbasha", "Elbasha player"), user.email ?: "")
                InfoCard(uiText("معرّف الحساب", "Account ID"), user.uid)
                Button(onClick = onSignOut, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(uiText("تسجيل الخروج", "Sign out")) }
            }
            "developer" -> {
                SectionTitle("⚙️ Developer Panel")
                if (isDeveloper) {
                    InfoCard("Mostafa Bek", uiText("صلاحية المطور مفعّلة. دي لوحة تشخيص فعلية لحالة المحتوى الحالي.", "Developer access is enabled. This panel reports the current content state."))
                    InfoCard(uiText("قاعدة اللاعبين", "Player database"), "${PlayerDatabase.players.size} ${uiText("لاعبًا", "players")} • ${PlayerDatabase.players.map { it.nationalityEn }.distinct().size} ${uiText("جنسيات", "nationalities")}")
                    InfoCard(uiText("نطاق التقييمات", "Rating range"), "${PlayerDatabase.players.minOf { it.rating }} – ${PlayerDatabase.players.maxOf { it.rating }} OVR • ${PlayerDatabase.players.count { it.rating < 75 }} ${uiText("أقل من 75", "below 75")}")
                    InfoCard(uiText("المراكز المعتمدة", "Canonical positions"), ElbashaPositions.rosterOrder.joinToString("  ›  "))
                    InfoCard(uiText("الأسئلة", "Question bank"), "${QuestionRepository.sample.size} ${uiText("سؤالًا مدمجًا", "built-in questions")}")
                    InfoCard(
                        uiText("صور اللاعبين", "Player photos"),
                        uiText(
                            "$bundledPlayerPhotos صورة مرفقة داخل APK، و$cachedPlayerPhotos صورة في الكاش المحلي (${cachedPhotoBytes / 1024} KB). الصور المرفقة تعمل دون إنترنت، والكاش لا يُعد جزءًا من APK.",
                            "$bundledPlayerPhotos portraits bundled in the APK; $cachedPlayerPhotos cached locally (${cachedPhotoBytes / 1024} KB). Bundled portraits work offline; cache files are not part of the APK."
                        )
                    )
                    Button(
                        onClick = {
                            PlayerImageRepository.clearCache(appContext)
                            photoCacheRevision++
                            photoLoadStatus = localizedText(english, "تم مسح الكاش المحلي للصور.", "Local portrait cache cleared.")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
                    ) { Text(uiText("مسح الصور المخزنة مؤقتًا", "Clear cached player photos")) }
                    Button(
                        enabled = !isLoadingAllPhotos,
                        onClick = {
                            photoLoadJob = uiScope.launch {
                                isLoadingAllPhotos = true
                                photoLoadProgress = 0f
                                photoLoadStatus = localizedText(english, "بدأ تحميل الصور تدريجيًا...", "Portrait download started...")
                                var found = 0
                                try {
                                    PlayerDatabase.players.forEachIndexed { index, player ->
                                        val bitmap = runCatching { PlayerImageRepository.load(appContext, player.nameEn) }.getOrNull()
                                        if (bitmap != null) found++
                                        photoLoadProgress = (index + 1).toFloat() / PlayerDatabase.players.size.toFloat()
                                        photoLoadStatus = if (english) "${index + 1}/${PlayerDatabase.players.size} checked • $found photos found" else "تم فحص ${index + 1}/${PlayerDatabase.players.size} • تم العثور على $found صورة"
                                        if (index < PlayerDatabase.players.lastIndex) delay(220)
                                    }
                                    photoLoadStatus = if (english) "Finished: $found usable portraits cached." else "اكتمل الفحص: تم تخزين $found صورة متاحة."
                                } catch (cancelled: CancellationException) {
                                    photoLoadStatus = localizedText(english, "تم إيقاف تحميل الصور.", "Portrait download cancelled.")
                                } finally {
                                    photoCacheRevision++
                                    isLoadingAllPhotos = false
                                    photoLoadJob = null
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) { Text(if (isLoadingAllPhotos) uiText("جاري تحميل الصور...", "Loading portraits...") else uiText("تحميل صور اللاعبين (${PlayerDatabase.players.size})", "Download all ${PlayerDatabase.players.size} player portraits")) }
                    if (isLoadingAllPhotos) {
                        LinearProgressIndicator(progress = { photoLoadProgress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor)
                        TextButton(onClick = { photoLoadJob?.cancel() }, modifier = Modifier.fillMaxWidth()) {
                            Text(uiText("إيقاف التحميل", "Cancel photo download"), color = Gold)
                        }
                    }
                    if (photoLoadStatus.isNotBlank()) Text(photoLoadStatus, color = Gold, fontSize = 11.sp)
                    SectionTitle(uiText("🎵 موسيقى الجروب", "🎵 Group music"))
                    InfoCard(uiText("المقطع الحالي", "Current track"), sharedMusicName.ifBlank { localizedText(english, "لم يتم رفع موسيقى بعد", "No shared track uploaded yet") })
                    Button(
                        onClick = { musicPicker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) { Text(uiText("رفع أغنية من الهاتف للجميع", "Upload a track for everyone")) }
                    Text(uiText("MP3 أو OGG أو AAC • حتى 5 MB. الرفع متاح للمطور فقط، والأغنية تتزامن عبر Firebase مع كل الحسابات.", "MP3, OGG or AAC • up to 5 MB. Developer-only upload; the track syncs to every account through Firebase."), color = Muted, fontSize = 11.sp)
                    if (musicUploadStatus.isNotBlank()) Text(musicUploadStatus, color = Gold, fontSize = 11.sp)
                    InfoCard(uiText("اتصال Firebase", "Firebase connection"), when (firebaseConnected) {
                        true -> uiText("متصل", "Connected")
                        false -> uiText("غير متصل", "Disconnected")
                        null -> uiText("غير مهيأ أو جارٍ الفحص", "Not configured or checking")
                    })
                    InfoCard(uiText("نسخة التطبيق", "App build"), "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                    InfoCard(uiText("الصوت", "Audio"), uiText("موسيقى مشتركة من لوحة المطور + مؤثرا الفوز والخسارة.", "Shared developer-managed music + win/loss effects."))
                    InfoCard(uiText("حالة الألعاب", "Game modules"), uiText("المزاد • صندوق الحظ • كون فريق. الغرف الأونلاين مؤجلة لما بعد الإصدار الأول.", "Auction • Deal or No Deal • Build Your Team. Online rooms remain post-v1."))
                } else {
                    InfoCard(uiText("غير مصرح", "Access denied"), uiText("لوحة المطور متاحة لحساب المطور المعتمد فقط.", "The developer panel is restricted to the configured developer account."))
                }
            }
            "settings" -> {
                SectionTitle(uiText("⚙️ إعدادات التطبيق", "⚙️ App settings"))
                InfoCard(user.displayName ?: uiText("حساب اللاعب", "Player account"), user.email ?: "")
                InfoCard(uiText("المظهر", "Appearance"), uiText("اختار الشكل اللي يريح عينك.", "Choose the appearance you prefer."))
                Button(onClick = onToggleTheme, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (LocalAppUiSettings.current.darkTheme) uiText("☀️ تفعيل الوضع النهاري", "☀️ Switch to light mode") else uiText("🌙 تفعيل الوضع الليلي", "🌙 Switch to dark mode"))
                }
                InfoCard(uiText("اللغة", "Language"), uiText("تقدر تبدّل بين العربية والإنجليزية في أي وقت.", "Switch between Arabic and English at any time."))
                Button(onClick = onToggleLanguage, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (LocalAppUiSettings.current.english) "العربية" else "English")
                }
                InfoCard(uiText("الموسيقى المشتركة", "Shared music"), sharedMusicName.ifBlank { uiText("المطور لم يرفع أغنية بعد.", "The developer has not uploaded a track yet.") })
                Button(onClick = { sound.toggleMusic() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (sound.musicOn) uiText("🎵 كتم موسيقى الجروب", "🎵 Mute group music") else uiText("🎵 تشغيل موسيقى الجروب", "🎵 Play group music"))
                }
                InfoCard(uiText("مؤثرات الفوز والخسارة", "Win/loss effects"), uiText("المؤثرات منفصلة عن موسيقى الجروب.", "Effects are controlled separately from group music."))
                Button(onClick = { sound.toggleSound() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (sound.soundOn) uiText("🔊 كتم المؤثرات", "🔊 Mute effects") else uiText("🔊 تشغيل المؤثرات", "🔊 Enable effects"))
                }
                InfoCard("Firebase", uiText("رابط Realtime Database مضبوط في المشروع. تأكد فقط من تفعيل Email/Password وGoogle ونشر قواعد قاعدة البيانات من ملف firebase/database.rules.json.", "The Realtime Database URL is configured. Confirm Email/Password and Google providers are enabled, and publish the rules from firebase/database.rules.json."))
                InfoCard(uiText("تحديث التطبيق", "App updates"), uiText("افحص GitHub لتنزيل آخر إصدار مباشرة من داخل التطبيق. أندرويد سيطلب تأكيد التثبيت.", "Check GitHub and download the latest release from inside the app. Android will ask you to confirm installation."))
                AppUpdaterCard()
                Button(
                    onClick = onSignOut,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
                ) { Text(uiText("تسجيل الخروج من الحساب", "Sign out of account")) }
            }
            else -> {
                SectionTitle(if (page == "games") uiText("🎮 مكتبة الألعاب", "🎮 Game library") else uiText("🔥 اختار لعبتك", "🔥 Choose your game"))
                games.chunked(2).forEach { gameRow ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        gameRow.forEach { game ->
                            Box(Modifier.weight(1f)) {
                                GameCard(game) { if (game.ready) { sound.play(Sfx.Click); sound.vibrate(20); page = game.id } }
                            }
                        }
                        if (gameRow.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                SectionTitle(uiText("🏆 أفضل اللاعبين", "🏆 Top players"))
                if (leaderboard.isEmpty()) InfoCard(uiText("المنافسة لسه بتبدأ", "Competition starts here"), uiText("أول لاعب يسجل نقاط هيحجز مكانه هنا.", "The first player to score will appear here."))
                leaderboard.take(3).forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(listOf("🥇", "🥈", "🥉").getOrElse(index) { "🏅" }, fontSize = 21.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                        Text("${item.points}", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
                Text("DEVELOPED BY MOSTAFA BEK", color = Gold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (isDeveloper && page != "developer") {
            TextButton(onClick = { page = "developer" }, modifier = Modifier.fillMaxWidth()) { Text(uiText("⚙️ فتح لوحة المطور", "⚙️ Open developer panel"), color = Gold) }
        }
    }
}

@Composable
private fun SmallStat(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(PanelAltColor, RoundedCornerShape(14.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 11.sp)
        Text(value, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavButton(title: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected) Gold else PanelColor, contentColor = if (selected) DeepWine else Cream)) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun GameCard(game: GameItem, onClick: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        enabled = game.ready,
        modifier = Modifier.fillMaxWidth().height(188.dp).animateContentSize()
            .border(1.dp, palette.gold.copy(alpha = 0.42f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(22.dp)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(palette.panelAlt, palette.panel, palette.deepWine)))) {
            Column(
                Modifier.fillMaxSize().padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).background(palette.gold.copy(alpha = 0.15f), RoundedCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text(game.emoji, fontSize = 28.sp) }
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (game.ready) uiText("متاحة", "READY") else uiText("قريبًا", "SOON"),
                        color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.background(palette.gold.copy(alpha = 0.12f), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(uiText(game.titleAr, game.titleEn), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text(uiText(game.subtitleAr, game.subtitleEn), color = palette.muted, fontSize = 11.sp, maxLines = 2, minLines = 2)
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (game.ready) uiText("ابدأ اللعب", "PLAY NOW") else uiText("تحت التطوير", "IN DEVELOPMENT"), color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text("${if (LocalAppUiSettings.current.english) "OPEN" else "افتح"}  ›", color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(title, color = Cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SetupRequiredScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = DeepWine, surface = Wine)) {
        Surface(Modifier.fillMaxSize(), color = DeepWine) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(220.dp))
                Text("ELBASHA GAMES", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                Text(message, color = Cream, textAlign = TextAlign.Center)
            }
        }
    }
}
