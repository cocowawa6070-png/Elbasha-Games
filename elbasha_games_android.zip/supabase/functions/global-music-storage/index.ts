import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.2.0/index.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SECRET_KEYS = (() => {
  try { return JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") ?? "{}"); }
  catch { return {}; }
})();
const SERVICE_ROLE_KEY = SECRET_KEYS.default ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const FIREBASE_PROJECT_ID = "elbasha-games";
const FIREBASE_JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"),
);
const BUCKET = "music";
const DEVELOPER_UID = "8Rs2HFEKfYYTNT2Elzj90oVuZ4k1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

function validMusicPath(path: unknown): path is string {
  return typeof path === "string" &&
    path.startsWith("global-music/") &&
    path.length <= 220 &&
    !path.includes("..") &&
    !path.includes("\\");
}

async function firebaseUidFromRequest(request: Request): Promise<string> {
  const authorization = request.headers.get("Authorization") ?? "";
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  if (!match) throw new Error("تسجيل الدخول مطلوب.");

  // Validate Firebase ID-token signature, issuer, audience and expiry using Google's public keys.
  let payload;
  try {
    const verified = await jwtVerify(match[1], FIREBASE_JWKS, {
      issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
      audience: FIREBASE_PROJECT_ID,
    });
    payload = verified.payload;
  } catch {
    throw new Error("جلسة تسجيل الدخول غير صالحة أو انتهت.");
  }
  const uid = payload.sub;
  if (typeof uid !== "string" || !uid) throw new Error("تعذر التحقق من حساب المستخدم.");
  return uid;
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return jsonResponse({ error: "Method not allowed" }, 405);
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    return jsonResponse({ error: "إعدادات Supabase Storage غير مكتملة." }, 500);
  }

  try {
    const uid = await firebaseUidFromRequest(request);
    const body = await request.json();
    const action = body?.action;
    const path = body?.path;
    if (!validMusicPath(path)) return jsonResponse({ error: "مسار الأغنية غير صالح." }, 400);

    const isDeveloper = uid === DEVELOPER_UID;
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    if (action === "create_upload") {
      if (!isDeveloper) return jsonResponse({ error: "رفع الأغاني متاح للمطور فقط." }, 403);
      const contentType = typeof body?.contentType === "string" ? body.contentType : "";
      if (!contentType.startsWith("audio/")) {
        return jsonResponse({ error: "نوع الملف غير مدعوم. ارفع ملفًا صوتيًا فقط." }, 400);
      }
      const { data, error } = await supabase.storage.from(BUCKET).createSignedUploadUrl(path, { upsert: false });
      if (error || !data?.signedUrl) {
        return jsonResponse({ error: error?.message ?? "تعذر إنشاء رابط رفع آمن." }, 502);
      }
      const signedUrl = data.signedUrl.startsWith("http")
        ? data.signedUrl
        : `${SUPABASE_URL}/storage/v1${data.signedUrl.startsWith("/") ? data.signedUrl : `/${data.signedUrl}`}`;
      return jsonResponse({ signedUrl, path });
    }

    if (action === "signed_download") {
      const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 2 * 60 * 60);
      if (error || !data?.signedUrl) {
        return jsonResponse({ error: error?.message ?? "تعذر إنشاء رابط تنزيل آمن." }, 404);
      }
      return jsonResponse({ signedUrl: data.signedUrl, expiresIn: 2 * 60 * 60 });
    }

    if (action === "delete") {
      if (!isDeveloper) return jsonResponse({ error: "حذف الأغاني متاح للمطور فقط." }, 403);
      const { error } = await supabase.storage.from(BUCKET).remove([path]);
      if (error) return jsonResponse({ error: error.message }, 502);
      return jsonResponse({ deleted: true, path });
    }

    return jsonResponse({ error: "Action غير معروفة." }, 400);
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ غير متوقع.";
    const status = message.includes("مطلوب") || message.includes("غير صالحة") ? 401 : 500;
    return jsonResponse({ error: message }, status);
  }
});
