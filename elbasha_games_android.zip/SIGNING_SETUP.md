# Stable GitHub Actions signing key for ELBASHA GAMES

The GitHub-hosted runner is temporary. A temporary fallback key allows the CI workflow to build and test before signing secrets are configured, but its certificate is not stable. Google/Firebase Android OAuth must recognize the certificate that actually signs the APK, and future update APKs must use the same key as the installed app.

This project uses a stable debug keystore through GitHub Actions secrets. The private keystore and its Base64 copy are delivered separately from the project ZIP and must never be committed to the public repository. The workflow can still build a temporary debug APK before the secrets are configured, but Google Sign-In and consistent update signatures require the stable key.

## 1. Add the two GitHub Actions secrets

Download the two separate private files supplied with Session 14: `elbasha-keystore-base64.txt` and `ELBASHA_SIGNING_PRIVATE_INFO.txt`. Keep both private. The second file contains the generated password. The alias is `elbasha-debug`.

Open the repository:

`Settings` → `Secrets and variables` → `Actions` → `New repository secret`

Create these two repository secrets:

- `ANDROID_DEBUG_KEYSTORE_BASE64`: the complete one-line contents of the separate file `elbasha-keystore-base64.txt` supplied with this project update.
- `ANDROID_DEBUG_KEYSTORE_PASSWORD`: the password in the separate private file `ELBASHA_SIGNING_PRIVATE_INFO.txt` supplied with this project update.

Do not commit either private file to the repository. Do not paste the values into source code, workflow files, or public issues.

## 2. Register this key in Firebase

In Firebase Console → Project settings → Your apps → Android app `com.mostafabek.elbashagames` → SHA certificate fingerprints, add:

- SHA-1: `B2:15:81:85:72:E1:72:C3:81:5E:A9:FE:C4:54:66:EA:2A:20:18:2E`
- SHA-256: `4E:79:B0:7A:5D:39:23:3E:9B:EF:CC:40:87:D1:EC:8C:BB:16:D3:5B:56:E4:CB:B3:76:4C:35:D9:50:1E:16:AB`

Keep the old fingerprints for now; just add these two new ones.

## 3. Refresh google-services.json

After saving both fingerprints, download the updated `google-services.json` from the same Android app in Firebase Console. Replace `app/google-services.json` in this project with the newly downloaded file.

The Web OAuth client ID in `app/src/main/res/values/strings.xml` should remain the Web client ID for the `elbasha-games` Firebase project. Do not replace it with the Android OAuth client ID.

## 4. Build and install

Run the GitHub Actions workflow `Build Elbasha Games APK`. It will print the signing certificate fingerprints used by the APK. They should match the two fingerprints above.

Because this is a new signing key, Android will not install this APK as an update over an older APK signed with a different key. Uninstall the old test APK first, then install the new one. Firebase account data is stored remotely; local app preferences may reset.

## Security note

This is a stable **debug/testing** signing key, not a production Play Store release key. Keep the keystore and both GitHub secrets private. Never publish the keystore or its Base64 contents in the public repository.
