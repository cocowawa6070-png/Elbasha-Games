# إعداد موسيقى ELBASHA على Supabase

## ما الذي يستخدمه التطبيق؟

- ملفات الصوت تُحفظ في Bucket باسم `music` داخل Supabase، ويظل الـ Bucket **Private**.
- قائمة الأغاني وأمر التشغيل المشترك (الأغنية الحالية، تشغيل/إيقاف مؤقت، وموضع التشغيل) يظلان في Firebase Realtime Database لأن هذا هو مسار المزامنة اللحظية الموجود أصلًا في هذه النسخة.
- قواعد فرع `globalMusic` في Realtime Database ما زالت مطلوبة. إذا لم تكن منشورة بالفعل، ادمج محتوى `firebase/globalMusic_realtime_database_snippet.json` داخل كائن `rules` الحالي ثم اضغط Publish. لا تستبدل بقية قواعد قاعدة البيانات.
- Supabase Edge Function تتحقق من Firebase ID Token. حساب المطور وحده يستطيع إنشاء روابط الرفع والحذف. باقي الحسابات المسجّلة تستطيع طلب رابط تنزيل مؤقت فقط.
- لا يوجد `service_role` key داخل التطبيق أو APK.

## 1. إعداد الـ Bucket

في Supabase Dashboard افتح **Storage → music → Settings** وتأكد من الآتي:

- اسم الـ Bucket هو `music`.
- Public bucket = **OFF**.
- الحد الأقصى لحجم الملف لا يقل عن 60 MB ولا يزيد عليه إذا أردت نفس حد التطبيق.
- أنواع الملفات المسموحة: `audio/*` إذا كان الحقل يدعم wildcard، أو صيغ الصوت التي تستخدمها فعليًا مثل `audio/mpeg`, `audio/mp4`, `audio/ogg`, `audio/wav`.

لا تنشئ سياسة عامة للرفع أو التنزيل على `storage.objects`. الوظائف الموقّعة تستخدم مفتاح الخدمة من جهة الخادم، والـ Bucket يظل خاصًا.

## 2. نشر Edge Function

من مجلد المشروع الذي يحتوي `supabase/config.toml`:

```bash
supabase login
supabase link --project-ref <PROJECT_REF_FROM_SUPABASE_DASHBOARD>
supabase functions deploy global-music-storage --no-verify-jwt
```

التحقق من JWT معطّل على بوابة Supabase لهذه الوظيفة فقط لأن التطبيق يرسل Firebase ID Token بدل Supabase Auth JWT. الوظيفة نفسها تتحقق من توقيع Firebase Token، والـ issuer، والـ audience، وتاريخ الانتهاء باستخدام مفاتيح Google العامة قبل تنفيذ أي عملية.

المفتاح الإداري يُقرأ داخل Edge Function من `SUPABASE_SECRET_KEYS` المدمج في Supabase، مع رجوع توافق للإعداد القديم عند الحاجة. لا تنسخ أي `secret` أو `service_role` key إلى التطبيق أو GitHub Actions.

## 3. إضافة مفتاح Supabase العام إلى GitHub Actions

في GitHub افتح:

**Repository → Settings → Secrets and variables → Actions → New repository secret**

أنشئ Secret باسم:

`SUPABASE_ANON_KEY`

واستخدم قيمة **anon / publishable key** من إعدادات API Keys في مشروع Supabase. لا تستخدم `service_role` أو أي `sb_secret_...` key.

ثم افتح تبويب **Variables** وأنشئ Repository Variable باسم:

`SUPABASE_URL`

وقيمته رابط المشروع كاملًا، بالشكل `https://<PROJECT_REF>.supabase.co`. خذ الـ Project Ref ورابط المشروع مباشرة من Supabase Dashboard → Project Settings → General، ولا تستخدم اختصارًا أو قيمة تخمينية.

الـ workflow سيفشل عمدًا برسالة واضحة إذا لم تتم إضافة المفتاح أو الرابط، بدل إنتاج APK تبدو فيه الميزة موجودة لكنها لا تستطيع الاتصال بـ Supabase.

## 4. تجربة الميزة

1. انشر الـ Edge Function وأضف `SUPABASE_ANON_KEY` قبل بناء APK.
2. شغّل GitHub Actions وابنِ النسخة الجديدة وثبّتها على أجهزة المجموعة.
3. سجّل الدخول بحساب المطور وافتح Developer Panel ثم ارفع أغنية.
4. الأغنية تُضاف إلى القائمة وتبدأ تلقائيًا عند الجميع. تغيير الأغنية أو إيقافها من لوحة المطور يرسل أمرًا مشتركًا عبر Realtime Database.
5. المستخدم العادي لا تظهر له أدوات الرفع أو اختيار الأغنية. زر الموسيقى في الإعدادات يكتم أو يشغّل الصوت على جهازه فقط.

كل جهاز يحتفظ بنسخة محلية من كل أغنية نزّلها بنجاح، فلا يعيد تنزيلها في كل مرة. اختيار أغنية جديدة يوقف القديمة عند وصول أمر التشغيل الجديد، ثم يبدأ تشغيل الجديدة بعد اكتمال التنزيل.

## ملاحظات مهمة

- لا تنشر أي قواعد Firebase Storage لهذه الميزة. ملف `firebase/storage.rules` الموجود في المشروع قديم/متبقٍ من التنفيذ السابق ولا يُستخدم لمسار الصوت الجديد.
- قواعد Firebase Realtime Database الخاصة بـ `globalMusic` ما زالت مطلوبة لقراءة قائمة الأغاني ومزامنة التشغيل، وتسمح بالكتابة لحساب المطور فقط. استخدم الـ snippet المرفق عند الحاجة، ولا تستبدل بقية القواعد.
- الأغاني التي كانت محفوظة سابقًا في Firebase Storage لا تنتقل تلقائيًا. ارفعها من جديد إلى لوحة المطور بعد إعداد Supabase.
- عند تغيير حساب المطور مستقبلًا، يجب تحديث UID في كل من `ElbashaAccess.kt` و`supabase/functions/global-music-storage/index.ts` ثم إعادة النشر.
- لم يتم إنشاء APK في بيئة التعديل الحالية لعدم توفر Gradle وAndroid SDK. فحص المشروع النصي نجح؛ نجاح التجميع النهائي يجب تأكيده من GitHub Actions.
