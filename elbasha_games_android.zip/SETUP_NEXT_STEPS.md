# ELBASHA GAMES — setup and verification

1. Extract this ZIP and review the source changes.
2. In `app/src/main/res/values/strings.xml`, set `firebase_database_url` to the exact URL shown in your Firebase Realtime Database console.
3. Review `firebase/database.rules.json` before publishing it.
4. Upload the project contents to the existing GitHub repository, preserving the `.github/workflows/android.yml` path.
5. Run the Android build workflow. If it fails, send the complete first Gradle error block.

## Included changes
- 105 bilingual football questions (up from 85).
- 151-player catalog with position groups and rating constraints.
- 5-a-side draft now uses the shared player catalog.
- Penalty Shootout has four CPU difficulty levels.

## Not included / not yet complete
- Full playable rules engines for Auction, Billion Auction, Deal or No Deal, secret-criteria Build a Team, Market Master, The Filter and Number Challenge.
- Online rooms, realtime multiplayer, voice chat, and in-app APK updater.
- Supabase music manager integration is not present in this source ZIP; the Edge Function and Dashboard setup must be completed and integrated separately.

No APK build is claimed from this environment. The Android project should be built by GitHub Actions after Firebase configuration.
