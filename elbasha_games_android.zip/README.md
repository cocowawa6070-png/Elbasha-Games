# ELBASHA GAMES

**Developer:** Mostafa Bek  
**Android package:** `com.mostafabek.elbashagames`  
**Stack:** Kotlin, Jetpack Compose, Firebase Authentication, Firebase Realtime Database  
**Build:** JDK 17, Gradle 8.13, Android Gradle Plugin 8.13.2, Android SDK 36

ELBASHA GAMES is a private football-game app for a small group of friends. This repository contains the Android client and Firebase Realtime Database rules. It is a playable foundation, not a finished online tournament platform.

## Playable game modes

- **Football Trivia:** 85 built-in football questions in Arabic and English, difficulty filter, shuffled choices, 15-second timer, speed bonus, answer streaks, feedback, and end-of-round scoring.
- **Guess the Player:** identify footballers from career and achievement clues.
- **Football Stats Challenge:** questions about historical tournament figures, match scores, and records.
- **Build a 5-a-side Team:** draft a goalkeeper, defender, midfielder, winger, and striker while staying within a limited budget. Player ratings are fictional game ratings, not official ratings.
- **Penalty Shootout:** take five penalties, then switch roles and try to save five CPU shots. Earn points for goals, saves, and winning the duel. Keeper direction and saves are randomized for a quick arcade-style match.

The **Football Auction** and **Deal or No Deal** tiles are visibly marked as in development. Online tournaments, live multiplayer rooms, a full question editor, and a fully featured developer panel are not implemented yet.

## App experience

- Arabic and English interface; the built-in question bank has translated prompts and answers.
- Dark and light appearance settings, saved on the device.
- Original synthesized menu/game music and short sound effects, with independent music and effects switches.
- Firebase leaderboard integration when the database is configured.
- Music, effects, and vibration controls are available in-game and their preferences persist between launches.

## Firebase setup

The included `app/google-services.json` is associated with Firebase project ID `elbasha-games` and the matching Android package. It does **not** contain OAuth client entries, and it does not supply a Realtime Database URL. Complete these settings in your own Firebase/Google Cloud project before expecting cloud features to work.

1. In Firebase Authentication, enable **Email/Password**. Enable **Google** only after completing its OAuth configuration.
2. Create or open the project's Realtime Database.
3. In `app/src/main/res/values/strings.xml`, fill the currently-empty `firebase_database_url` with the exact database URL shown in Firebase Console. Do not guess the region-specific URL.
4. The **Web application OAuth client ID** is already configured in `app/src/main/res/values/strings.xml` (`google_web_client_id`). It must remain the Web client ID, not an Android client ID. The supplied ID starts with this Firebase project's project number (`588936355529`), matching the included Firebase configuration.
5. In Firebase Console → Project settings → Your apps → Android app (`com.mostafabek.elbashagames`) → SHA certificate fingerprints, add the signing fingerprints supplied for this build:
   - SHA-1: `77:0B:D7:BB:75:A6:D9:52:40:59:3D:87:3E:11:07:2B:14:0C:91:69`
   - SHA-256: `7A:26:9F:68:F4:F1:01:19:69:12:5C:5B:55:C6:5C:82:DC:4A:F3:EF:4A:28:A2:20:BC:A5:4B:07:C1:A4:5B:80`
6. After enabling Google and registering the fingerprints, download the **updated** `google-services.json` from Firebase and replace `app/google-services.json` in this project. The currently included file has an empty `oauth_client` list, so it is not yet the refreshed Google-enabled configuration.
7. Publish `firebase/database.rules.json` in Firebase Console → Realtime Database → Rules. The developer UID previously supplied for this project is already inserted into the developer-only rule checks.

No Firebase Storage SDK, Storage deployment config, or Storage rules are used by this build. No Blaze upgrade is required for the included game modes.

### Question bank format

The app loads optional questions from `/questionBank/{category}/{questionId}`. Required fields:

- `question`: Arabic question text
- `answer`: correct Arabic answer
- `difficulty`: `easy`, `medium`, or `hard`
- `options`: list containing the answer and at least one distractor

Optional bilingual fields:

- `questionEn`
- `answerEn`
- `optionsEn`
- `explanation` and `explanationEn`

Cloud questions are merged with the built-in questions by ID, so an incomplete remote bank does not replace the local bank. Questions without English fields fall back to their Arabic text when the app is in English mode.

## Build the APK with GitHub Actions

1. Upload either the extracted project contents to the repository root, or upload this ZIP to the repository root. When uploading only the ZIP, name it `elbasha_games_android.zip` to match the original repository workflow.
2. Open **Actions** and run **Build Elbasha Games APK** (or push a commit to trigger it).
3. Download the `Elbasha-Games-debug-apk` artifact from the completed workflow run.
4. The APK is `app-debug.apk` inside the artifact.

The workflow installs Android SDK platform 36 and Build Tools 36.0.0, uses JDK 17 and Gradle 8.13, and builds `assembleDebug`.

## Important limitations

- `firebase_database_url` is intentionally empty. Built-in single-player games still work after Firebase Authentication sign-in; leaderboard, remote questions and cross-device score saving stay disabled until you paste the exact database URL from Firebase Console. The Web OAuth client ID is now filled in, but Google sign-in still requires the SHA fingerprints to be registered and a refreshed `google-services.json` from Firebase.
- Leaderboard points are currently calculated and submitted by the Android client. This is acceptable for a private prototype with trusted friends, but a modified APK could forge scores. A competitive/public release would need trusted server-side score validation.
- Firebase Realtime Database rules restrict user profile writes to each user, restrict room access to open rooms or their owner/members, and restrict question-bank writes to the configured developer account. Test the published rules in Firebase Console before relying on them.
- Room and tournament data rules exist as groundwork, but the corresponding online gameplay screens and synchronization are not implemented.
- Email verification is sent during registration, but sign-in is not currently blocked for unverified accounts.

## Fact-check references used while expanding football trivia

- FIFA, World Cup top scorers by edition: https://www.fifa.com/en/articles/fontaine-mbappe-ronaldo-and-more-every-world-cup-top-scorer
- FIFA, Egypt's World Cup history and 1934 debut: https://www.fifa.com/en/tournaments/mens/worldcup/canadamexicousa2026/articles/fifa.com/en/articles/egypt-team-profile-history
- FIFA, Just Fontaine's 13-goal 1958 record: https://www.fifa.com/en/articles/just-fontaine-thirteen-goals-1958
- CAF, AFCON records and historic winners: https://www.cafonline.com/media/05ebfeih/ultimate-media-guide-afcon25.pdf
- UEFA, Champions League history and final records: https://www.uefa.com/uefachampionsleague/history/
- UEFA, European Championship final results: https://www.uefa.com/uefaeuro/history/news/0259-0e5e039dd8b6-ac24fc62a240-1000/

## Brand

**ELBASHA GAMES**  
**DEVELOPED BY MOSTAFA BEK**
