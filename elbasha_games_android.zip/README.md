# ELBASHA GAMES — Android starter project

**Developer:** Mostafa Bek  
**Package:** `com.mostafabek.elbashagames`  
**Stack:** Kotlin, Jetpack Compose, Firebase Authentication, Realtime Database, Firebase Storage.

This is the first native Android foundation, not the completed game suite. It includes:

- Email/password registration and sign-in.
- Password reset and verification email on new email registrations.
- Google sign-in through Credential Manager + Firebase Auth.
- Player profile creation in Realtime Database.
- A live leaderboard reader.
- A developer-panel entry point gated by `/admins/{uid}` in the database.
- Game catalogue placeholders for auction, Deal or No Deal, Build a Team, player guessing, trivia, and stats challenges.
- GitHub Actions workflow that builds and uploads a debug APK.

The game modes, question editor, room gameplay, score submission, and fully functional developer tools are the next development stage. The current UI labels the game tiles as **قريبًا** rather than pretending the game logic is already implemented.

## 1. Create the Firebase project

1. Create a new Firebase project called `Elbasha Games`.
2. Add an Android app with package name exactly `com.mostafabek.elbashagames`.
3. Download the new `google-services.json` and replace the starter placeholder at `app/google-services.json`.
4. In Firebase Authentication, enable **Email/Password** and **Google** providers.
5. In Authentication settings, add the SHA-1 and SHA-256 fingerprints for your debug/release signing certificates. Google sign-in will not work until the OAuth setup is complete.
6. Create a Realtime Database.
7. Copy its URL into `app/src/main/res/values/strings.xml`, replacing `firebase_database_url`.
8. In the same file, replace `google_web_client_id` with the **Web application OAuth client ID** from Google Cloud/Firebase, not the Android client ID.
9. Re-download `google-services.json` after enabling Google provider and replace it in the app folder again.

Firebase's Android Google sign-in setup requires Credential Manager, a Web client ID, the Google provider enabled, and the app's signing fingerprint registered. See the official Firebase guide: https://firebase.google.com/docs/auth/android/google-signin

## 2. Set up Mostafa Bek as developer

The app does **not** contain a secret developer password in its APK. Developer access is checked against `/admins/{uid}` in Realtime Database.

1. Create your own account in the app once.
2. In Firebase Console → Authentication → Users, copy the UID for your account.
3. Replace every occurrence of `REPLACE_WITH_MOSTAFA_FIREBASE_UID` in:
   - `firebase/database.rules.json`
   - `firebase/storage.rules`
4. Publish the Realtime Database rules.
5. In Realtime Database → Data, create the value `/admins/YOUR_REAL_UID` as boolean `true` (not the text string `"true"`). This first entry is a one-time bootstrap performed manually in the Firebase Console.
6. The app will then show the Developer Panel entry for that UID.

Do not give the developer UID or console access to other group members. If you change to a new Firebase project, repeat this bootstrap.

## 3. Publish Firebase rules

- Realtime Database: paste `firebase/database.rules.json` into Firebase Console → Realtime Database → Rules.
- Storage (only if you create/enable Firebase Storage): paste `firebase/storage.rules` into Firebase Console → Storage → Rules.

The rules are deliberately closed by default. Do not replace them with public read/write rules.

### Important leaderboard limitation

The initial leaderboard path permits each signed-in user to update only their own score record, with basic range/monotonic checks. This is enough for a prototype, but a modified APK can still attempt to award itself fake points. For a competitive leaderboard, score calculation and score writes must move to trusted Cloud Functions (or another trusted backend) before public release.

## 4. Build the APK with GitHub Actions

1. Create a GitHub repository and upload the contents of this project folder.
2. Make sure the real `app/google-services.json` is present in the repository before building. The included file is only a placeholder and will not connect to Firebase.
3. Open the **Actions** tab. The workflow `Build Elbasha Games APK` runs on push, pull request, or manual dispatch.
4. Open the completed workflow run and download the artifact named `Elbasha-Games-debug-apk`.
5. Inside it, the APK is `app-debug.apk`.

The workflow uses JDK 17, Gradle 8.13, and Android SDK platform 35. It builds a debug APK; a signed release APK and Play Store setup are separate later steps.

## 5. Local build

Open the folder in a current Android Studio installation and let Android Studio install the requested Android SDK components. Then run the `assembleDebug` Gradle task.

## Firebase data layout

- `/users/{uid}` — private email and account timestamps, readable only by that account.
- `/publicProfiles/{uid}` — display name and avatar for authenticated group members.
- `/admins/{uid}` — developer flag; only Mostafa's configured UID can manage it.
- `/leaderboard/{uid}` — each user can write only their own prototype score record.
- `/rooms/{roomId}` — room metadata and per-user membership.
- `/roomMessages/{roomId}/{messageId}` — messages readable only by members of that room.
- `/questionBank/{category}/{questionId}` — authenticated users can read; only the configured developer UID can write.
- `/settings/public` and `/announcements` — developer-managed app settings and notices.

## Brand

App name: **ELBASHA GAMES**  
Developer credit: **MOSTAFA BEK**
