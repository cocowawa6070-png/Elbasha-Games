# خطوات تفعيل الموسيقى الجماعية في ELBASHA GAMES

## الملفات الموجودة في هذه النسخة

- تطبيق Android كامل، مع كود الموسيقى الجماعية في `GlobalMusic.kt`.
- Supabase Edge Function في `supabase/functions/global-music-storage/index.ts`.
- إعداد Supabase في `supabase/config.toml`.
- Workflow بناء APK في `.github/workflows/android.yml`.
- Workflow نشر وظيفة الموسيقى في `.github/workflows/deploy-music.yml`.
- تعليمات تفصيلية في `SUPABASE_GLOBAL_MUSIC_SETUP_AR.md`.

## المطلوب منك مرة واحدة على GitHub

1. افتح مستودع `cocowawa6070-png/Elbasha-Games`.
2. استبدل ملف `elbasha_games_android.zip` الموجود في جذر المستودع بهذا الملف بعد تنزيله من المحادثة، وبنفس الاسم بالضبط.
3. من داخل ملف ZIP، ارفع الملف `.github/workflows/deploy-music.yml` إلى المسار نفسه في المستودع: `.github/workflows/deploy-music.yml`، واستبدل النسخة القديمة.
4. افتح Settings → Secrets and variables → Actions، وأضف Repository Secrets التالية:
   - `SUPABASE_ACCESS_TOKEN`: Access Token من حساب Supabase، وليس مفتاح المشروع.
   - `SUPABASE_PROJECT_REF`: `ubtukbbzxrgzvarhjksf`.
   - `SUPABASE_ANON_KEY`: مفتاح anon أو publishable العام للمشروع، مطلوب لبناء التطبيق فقط.
5. في تبويب Variables أضف `SUPABASE_URL` بالقيمة `https://ubtukbbzxrgzvarhjksf.supabase.co`.
6. من Actions شغّل `Deploy Elbasha Global Music Function` يدويًا. انتظر حتى يظهر Success.
7. بعد ذلك شغّل `Build Elbasha Games APK`، ونزّل Artifact باسم `Elbasha-Games-debug-apk`.

## أمان مهم

- لا تضع `service_role` أو `sb_secret_...` في GitHub أو داخل ZIP أو التطبيق.
- لا تغيّر اسم Storage Bucket؛ يجب أن يظل `music` وPrivate.
- لا تنشئ سياسات Storage عامة للرفع أو التنزيل.
- لا ترسل `SUPABASE_ACCESS_TOKEN` أو أي مفتاح سري في المحادثة.

## ما لم يتم اختباره بعد

نجاح نشر Edge Function لا يثبت وحده أن رفع ملف صوتي حقيقي يعمل من هاتفك. بعد تثبيت APK الجديد، سجّل الدخول بحساب المطوّر وارفع أغنية صغيرة. يجب أن تظهر في Storage → music داخل مجلد `global-music/`، ثم تظهر في قائمة الأغاني داخل التطبيق. بعدها اختبر التشغيل على جهاز ثانٍ.
