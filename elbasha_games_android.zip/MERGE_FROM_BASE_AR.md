# دمج نسخة ELBASHA GAMES

## الملفات المعتمدة
- الأساس الأحدث: `ELBASHA_GAMES_BUILD62_FIXED.zip` (22 نوفمبر 2026، 695,322 bytes).
- المصدر القديم المطلوب: `elbasha_games_android.zip` (17 نوفمبر 2026، 605,617 bytes).

تم اعتماد Build62 كأساس للمشروع لأنه يحتوي على الواجهة الحديثة، منطق الألعاب، ملفات الاختبارات، وإعدادات البناء الأحدث. تمت مقارنة الملفات الموجودة في الأرشيفين، والاحتفاظ بنسخ Build62 عند اختلاف أي ملف مشترك.

## أصول استعيدت من الملف القديم
- `legacy_assets/old_audio_tracks/music_menu.ogg`
- `legacy_assets/old_audio_tracks/music_tournament.ogg`
- `firebase/storage.rules`

ملف `elbasha_logo.png` في الأرشيف القديم مطابق بايتًا ببايت للصورة الأحدث `app/src/main/res/drawable-nodpi/elbasha_logo.jpg`، لذلك لم تتم إضافة نسخة مكررة بامتداد مضلل.

## تحديثات هذا الدمج
- تم إصلاح `AppUpdater.kt`: رد GitHub HTTP 404 من `/releases/latest` أصبح حالة طبيعية تعني عدم وجود إصدار منشور، وليس خطأ اتصال.
- تم مسح نتيجة الفحص القديمة قبل كل محاولة حتى لا يظهر زر تنزيل قديم بعد فشل فحص جديد.
- تم تحسين رسائل الحالات: لا يوجد Release منشور، تحديث متاح، الإصدار الحالي هو الأحدث، أو النسخة المثبتة أحدث من المنشور.
- تم إضافة `User-Agent` وGitHub API version header، ورسائل أوضح لأخطاء GitHub، ورفض Release الذي لا يحتوي `versionCode` أو ملف APK صالحًا.

## ملاحظات الدمج
- تم الاحتفاظ بملفات المصدر الحديثة عند وجود اختلاف، ومنها `MainActivity.kt` و`ElbashaUi.kt` و`AuctionLocalGame.kt` و`firebase/database.rules.json` وسير عمل GitHub Actions.
- مجلد `legacy_assets` يحفظ ملفات الموسيقى القديمة فقط، ولا يضيفها إلى موارد APK. الإصدار الحديث يستخدم موسيقى المجموعة المشتركة من Realtime Database، كما أن فاحص الكتالوج الحالي يشترط عدم تضمين موسيقى قديمة داخل موارد التطبيق.
- تم الاحتفاظ بـ`firebase/storage.rules` كملف قديم، لكن `firebase.json` الحديث يربط قواعد Realtime Database فقط. لم يتم تفعيل قواعد Storage القديمة تلقائيًا لأنها تحتوي UID بديلًا ولا يستخدم إصدار Build62 الحالي Firebase Storage لرفع موسيقى المجموعة.

## فحص التحديثات على GitHub
وقت تجهيز هذا الدمج، المستودع عام لكن لا توجد GitHub Releases منشورة فيه. لذلك سيعرض التطبيق رسالة «لا يوجد إصدار منشور بعد» حتى يتم إنشاء أول Release يتضمن ملف APK. سير عمل `.github/workflows/release.yml` ينشر Release عند دفع Tag يبدأ بـ`v`.
