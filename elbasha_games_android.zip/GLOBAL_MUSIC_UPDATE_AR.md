# تحديث موسيقى ELBASHA GAMES إلى Supabase

## ما تم تغييره

- نقل رفع وتنزيل وحذف ملفات الصوت من Firebase Storage إلى Supabase Storage Bucket `music`، مع إبقاء الـ Bucket خاصًا.
- إضافة Supabase Edge Function باسم `global-music-storage` لتنفيذ عمليات التخزين الموقّعة.
- الوظيفة تتحقق من Firebase ID Token عبر مفاتيح Google العامة. حساب المطور المحدد في `ElbashaAccess` وحده يحصل على صلاحية إنشاء روابط الرفع والحذف.
- المستخدمون المسجلون يستطيعون طلب روابط تنزيل مؤقتة، ولا يحصل التطبيق على مفتاح `service_role`.
- أبقينا Firebase Realtime Database لقائمة الأغاني وأوامر التشغيل اللحظية، لأنها طبقة المزامنة الموجودة في النسخة التي أرسلها المستخدم.
- أبقينا كاش الأغاني في `filesDir/global_music`، مع فحص الحجم قبل اعتماد الملف المنزّل.
- أبقينا لوحة الإدارة داخل Developer Panel فقط، وزر الكتم المحلي في إعدادات كل جهاز.
- أزلنا Firebase Storage SDK من اعتماديات التطبيق.
- أضفنا إعداد BuildConfig لمفتاح Supabase العام، وربطناه بـ GitHub Actions.

## تحسين بطاقات اللاعبين

- إعادة توزيع الألوان حسب فئة التقييم: Icon داكن فاخر، Elite ذهبي فاتح، Gold برونزي، وSilver معدني.
- إضافة إطار متعدد الطبقات وظل ناعم ونقوش خلفية خفيفة.
- تكبير صورة اللاعب وتحسين تلاشيها تدريجيًا خلف شريط الاسم.
- إعادة بناء منطقة التقييم والمركز والعلم وشريط الاسم لقراءة أفضل على المقاسات المختلفة.
- لم تتم إضافة إحصائيات أو PlayStyles أسفل البطاقة، ولم يتم تغيير تقييمات اللاعبين أو ترتيب المراكز.

## خطوات التفعيل المطلوبة

راجع `SUPABASE_GLOBAL_MUSIC_SETUP_AR.md` لنشر Edge Function، والتحقق من إعدادات الـ Bucket، وإضافة GitHub Secret باسم `SUPABASE_ANON_KEY` وRepository Variable باسم `SUPABASE_URL`.

## الفحوصات

- `python3 tools/validate_catalog.py` — PASS بعد تحديث فحوصات الموسيقى لتتحقق من Supabase بدل Firebase Storage.
- يجب أن يظل Bucket `music` خاصًا، ولا تنشر قواعد Firebase Storage القديمة لهذه الميزة.
- لم يتم تشغيل Android Gradle build هنا لعدم توفر Gradle وAndroid SDK في بيئة التعديل.
