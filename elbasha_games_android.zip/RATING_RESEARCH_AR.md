# مرجع تقييمات Prime في ELBASHA GAMES

## القاعدة المعتمدة

- لو اللاعب لديه بطاقة Icon أو Hero في FC 27، تُستخدم قيمة OVR لأعلى بطاقة من النوع المطلوب والمتاحة في FC 27.
- لو لا يملك Icon/Hero، يُستخدم أعلى OVR أساسي تاريخي في إصدارات FIFA/FC التي لعب فيها، وليس أعلى بطاقة ترويجية موسمية.
- لو لا توجد له بطاقة أو تقييم في FC 27، يُستبدل بلاعب آخر من نفس الفئة/المركز وبمستوى قريب، بشرط وجود بطاقة FC 27.
- حسب قاعدة اللعبة المعتمدة، ميسي وكريستيانو رونالدو فقط بتقييم 99.
- لا يوجد حد أدنى 75؛ التقييمات الأقل من 75 مسموحة للاعبين ذوي المستوى الأقل.
- تمت مزامنة قيم الـ52 بطاقة Icon المدرجة أدناه مع كتالوج اللاعبين، ثم إعادة حساب الأسعار وفق معادلة اقتصاد اللعبة.

## مصادر البيانات

1. EA SPORTS FC 27 Ratings Database: المصدر الرسمي لتقييمات اللاعبين الأساسيين الحاليين، ويعرض أكثر من 19 ألف لاعب. لا يكفي وحده لتقييم Icon/Hero.
   https://www.ea.com/games/ea-sports-fc/ratings
2. FCData FC 27 Icon Database: مرجع لقيم OVR لبطاقات Icon المتاحة في FC 27.
   https://fcdata.io/rarities/icon/
3. FUT.GG Player History: مرجع تاريخي لمقارنة نسخ اللاعب عبر إصدارات FIFA/FC وتحديد الإصدارات السابقة.
   https://www.fut.gg/players/
4. FUT Flipper FC 27 Icons: مرجع إضافي لتأكيد وجود البطاقات وأنواعها.
   https://futflipper.com/leagues/icons

## بطاقات Icon التي تمت مطابقة قيمها في هذه المراجعة

| اللاعب | FC 27 Icon OVR |
|---|---:|
| Pelé | 95 |
| Diego Maradona | 95 |
| Ronaldo Nazário | 94 |
| Zinedine Zidane | 94 |
| Paolo Maldini | 93 |
| Ronaldinho | 93 |
| Ferenc Puskás | 92 |
| Gerd Müller | 92 |
| Gianluigi Buffon | 92 |
| Andrés Iniesta | 92 |
| Bobby Charlton | 92 |
| Cafu | 91 |
| Carlos Alberto | 91 |
| Eusébio | 91 |
| Franco Baresi | 91 |
| Marco van Basten | 91 |
| Oliver Kahn | 91 |
| Xavi | 91 |
| Zlatan Ibrahimović | 91 |
| Iker Casillas | 90 |
| Andrea Pirlo | 90 |
| George Best | 90 |
| Kaká | 90 |
| Lothar Matthäus | 90 |
| Luís Figo | 90 |
| Rivaldo | 90 |
| Wayne Rooney | 90 |
| Sergio Agüero | 90 |
| Alessandro Nesta | 89 |
| Fabio Cannavaro | 89 |
| Carles Puyol | 89 |
| Didier Drogba | 89 |
| Samuel Eto'o | 89 |
| Hristo Stoichkov | 89 |
| Javier Zanetti | 89 |
| Lilian Thuram | 89 |
| Lucio | 89 |
| Marcel Desailly | 89 |
| Nemanja Vidić | 88 |
| Frank Rijkaard | 88 |
| Xabi Alonso | 88 |
| Franck Ribéry | 88 |
| Gareth Bale | 88 |
| Gennaro Gattuso | 88 |
| Michael Essien | 88 |
| Patrick Vieira | 88 |
| Petr Čech | 88 |
| Robert Pirès | 88 |
| Robin van Persie | 88 |
| Sol Campbell | 88 |
| Toni Kroos | 90 |
| Yaya Touré | 88 |

## مراجعة Session 23

- تم تطبيق قيم Icon OVR المذكورة أعلاه على قاعدة اللاعبين، بما في ذلك تصحيح قيم كانت تختلف عن المرجع بفارق واضح (مثل Buffon وMaldini وEto'o وVieira وYaya Touré وVan Persie).
- تم تعديل مجموعة من القيم المبالغ فيها للاعبين الحاليين، ثم إعادة حساب أسعارهم آليًا على مقياس 5–11 مليون.
- بعد إعادة التوزيع: 57 لاعبًا أقل من 80، و122 لاعبًا بين 80 و89، و57 لاعبًا من 90 فأعلى. يظل الحد الأعلى 99 لميسي وكريستيانو فقط.

## ما لم يُحسم بعد

لم يتم توثيق سنة/نوع البطاقة التاريخية لكل لاعب غير Icon/Hero على حدة، لذلك لا أدّعي أن كل تقييم من الـ236 تدقيق تاريخي مستقل. هذه المراجعة أصلحت الاختلافات الكبيرة التي أمكن ربطها بمراجع المشروع، وتحتاج بقية الأسماء إلى تدقيق فردي قبل اعتماد أن كل رقم نهائي.
