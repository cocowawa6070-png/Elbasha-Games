# إصلاح فشل بناء APK رقم 115

## السبب
فشل مترجم Kotlin في `GlobalMusic.kt` عند السطر 570 برسالة:
`Missing return statement.`

الدالة `uploadToSupabase(...)` تعلن أنها تُرجع `Long`، لكنها تستخدم جسم دالة من النوع block body. كانت قيمة `temp.length()` آخر تعبير داخل `try` من دون `return` صريح، لذلك رفضها Kotlin.

## الإصلاح
تم تغيير بداية كتلة الرفع من `try {` إلى `return try {` مع الإبقاء على `finally { temp.delete() }` كما هو، لضمان إرجاع حجم الملف مع حذف الملف المؤقت في كل الحالات.

## التحقق
- `tools/validate_catalog.py`: PASS بالكامل.
- سلامة ملف ZIP: PASS.
- لم يتم الادعاء بأن APK بُني؛ يلزم تشغيل GitHub Actions بعد رفع الأرشيف.
