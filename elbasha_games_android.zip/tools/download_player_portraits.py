#!/usr/bin/env python3
"""Download one portrait per player and bundle it inside the app (offline, no runtime download).

Usage (needs internet, Python 3.8+, no extra packages):
    python3 tools/download_player_portraits.py            # download everything that is missing
    python3 tools/download_player_portraits.py --force    # re-download all
    python3 tools/download_player_portraits.py --only "Mohamed Salah" "Pele"

Images come from Wikipedia's *free-licence* page images (same strict matching rules as the app:
exact page title + "footballer" description), saved as app/src/main/assets/player_portraits/<slug>.jpg.
The app already prefers these bundled files, so after running this just rebuild.
A report of players without a free image is written to tools/portrait_report.csv.
"""
import argparse, csv, json, re, sys, time, unicodedata, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "app/src/main/java/com/mostafabek/elbashagames"
OUT = ROOT / "app/src/main/assets/player_portraits"
API = "https://en.wikipedia.org/w/api.php"
UA = "ELBASHA-GAMES/0.4 (portrait bundling script; contact: app owner)"
FOOTBALL = ["footballer", "football player", "association football", "soccer player",
            "football goalkeeper", "football defender", "football midfielder", "football forward", "football striker"]


def norm(value: str) -> str:
    value = unicodedata.normalize("NFD", value)
    value = "".join(c for c in value if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def load_names():
    names = re.findall(r'PlayerCard\("([^"]+)"\s*,\s*"[^"]+"\s*,\s*"[A-Z]+"', (BASE / "PlayerDatabase.kt").read_text(encoding="utf-8"))
    facts = (BASE / "PlayerFacts.kt").read_text(encoding="utf-8")
    names += re.findall(r'card\("([^"]+)"', facts)
    seen, out = set(), []
    for n in names:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def load_aliases():
    src = (BASE / "PlayerImage.kt").read_text(encoding="utf-8")
    block = src[src.index("private val aliases"):src.index("suspend fun")]
    return dict(re.findall(r'"([^"]+)"\s+to\s+"([^"]+)"', block))


def get(url, accept="application/json", tries=3):
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": accept})
            with urllib.request.urlopen(req, timeout=20) as resp:
                return resp.read(), resp.headers.get("Content-Type", "")
        except Exception as exc:  # noqa: BLE001
            if attempt == tries - 1:
                print("   ! request failed:", exc)
                return None, ""
            time.sleep(1.5 * (attempt + 1))
    return None, ""


def find_image(name, title):
    query = urllib.parse.urlencode({
        "action": "query", "format": "json", "formatversion": "2", "redirects": "1",
        "prop": "pageimages|pageterms", "piprop": "thumbnail", "pithumbsize": "600",
        "pilicense": "free", "wbptterms": "description", "titles": title,
    })
    body, _ = get(f"{API}?{query}")
    if not body:
        return None
    pages = json.loads(body).get("query", {}).get("pages", [])
    accepted = {norm(name), norm(title)}
    for page in pages:
        if page.get("missing") or norm(page.get("title", "")) not in accepted:
            continue
        desc = " ".join(page.get("terms", {}).get("description", [])).lower()
        if not any(word in desc for word in FOOTBALL):
            continue
        src = page.get("thumbnail", {}).get("source", "")
        if src.startswith("https://upload.wikimedia.org/"):
            return src
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--only", nargs="*")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    aliases = load_aliases()
    names = args.only or load_names()
    report, ok, missing = [], 0, 0
    for i, name in enumerate(names, 1):
        target = OUT / f"{slug(name)}.jpg"
        if target.exists() and target.stat().st_size > 2000 and not args.force:
            ok += 1
            continue
        url = find_image(name, aliases.get(name, name))
        data = None
        if url:
            data, ctype = get(url, "image/*")
            if data and (not ctype.startswith("image/") or not 2000 < len(data) < 4_000_000):
                data = None
        if data:
            target.write_bytes(data)
            ok += 1
            print(f"[{i}/{len(names)}] OK      {name}")
        else:
            missing += 1
            report.append([name, aliases.get(name, name)])
            print(f"[{i}/{len(names)}] MISSING {name}")
        time.sleep(0.3)
    with open(ROOT / "tools/portrait_report.csv", "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["player", "wikipedia_title_tried"])
        writer.writerows(report)
    print(f"\nDone. portraits ready: {ok}, missing: {missing} (see tools/portrait_report.csv)")
    print("Missing players: add an alias in PlayerImage.kt (exact Wikipedia title) and re-run, or drop <slug>.jpg in the folder by hand.")


if __name__ == "__main__":
    sys.exit(main())
