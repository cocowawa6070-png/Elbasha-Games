package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class BuildTeamPlayMode { PASS_AND_PLAY, AI }
private enum class BuildTeamStatPhase { SETUP, COUNTDOWN, HANDOVER, PICKING, AI_THINKING, RESULT }

/**
 * Build a Team is a points draft, not a nationality/OVR comparison.
 * Everyone receives the exact selected player's value for the chosen metric.
 * Example: Courtois = 200 cm = 200 points. In LOW mode the smallest total wins.
 */
@Composable
fun BuildTeamStatScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var mode by remember { mutableStateOf(BuildTeamPlayMode.PASS_AND_PLAY) }
    var phase by remember { mutableStateOf(BuildTeamStatPhase.SETUP) }
    var playerCount by remember { mutableIntStateOf(2) }
    var roundCount by remember { mutableIntStateOf(5) }
    var turnTimeSeconds by remember { mutableIntStateOf(30) }
    var turnSecondsLeft by remember { mutableIntStateOf(30) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var countdown by remember { mutableIntStateOf(3) }
    var roundIndex by remember { mutableIntStateOf(0) }
    var turnIndex by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf(BuildTeamFilter(BuildTeamPositionFilter.GK, BuildTeamLeagueFilter.LALIGA)) }
    var metric by remember { mutableStateOf(BuildTeamMetric.HEIGHT) }
    var direction by remember { mutableStateOf(BuildTeamDirection.HIGH) }
    var searchText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var pickLocked by remember { mutableStateOf(false) }
    var scoreSaved by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    val nameInputs = remember { mutableStateListOf("", "", "", "") }
    val teamPicks = remember { List(PassAndPlayRules.MAX_PLAYERS) { mutableStateListOf<BuildTeamPick>() } }
    val eligible = BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric)
    val normalizedNames = if (mode == BuildTeamPlayMode.AI) {
        listOf(user.displayName?.trim().takeUnless { it.isNullOrBlank() } ?: user.email?.substringBefore("@") ?: "مصطفى", "ELBASHA AI")
    } else {
        PassAndPlayRules.normalizeNames(nameInputs.toList(), playerCount) { if (english) "Player $it" else "لاعب $it" }
    }
    val order = if (mode == BuildTeamPlayMode.AI) listOf(0, 1) else PassAndPlayRules.pickingOrder(playerCount, roundIndex)
    val currentPlayerIndex = order.getOrNull(turnIndex) ?: 0
    val currentPlayerName = normalizedNames.getOrNull(currentPlayerIndex).orEmpty()
    val activePlayerTotal = if (mode == BuildTeamPlayMode.AI) 2 else playerCount
    val currentPlayersPicks = teamPicks[currentPlayerIndex]
    val alreadyDraftedNames = teamPicks.take(activePlayerTotal).flatten().mapTo(mutableSetOf()) { it.player.nameEn }
    // A footballer can be drafted only once in the whole match, not once per team.
    val eligibleForCurrent = eligible.filter { candidate -> candidate.nameEn !in alreadyDraftedNames }
    val suggestions = if (PlayerSearch.normalize(searchText).length >= 3) {
        PlayerSearch.suggestions(eligibleForCurrent, searchText, limit = 10)
    } else emptyList()
    val totals = (0 until (if (mode == BuildTeamPlayMode.AI) 2 else playerCount)).map { index ->
        BuildTeamStatRules.total(teamPicks[index])
    }
    val winners = if (phase == BuildTeamStatPhase.RESULT) BuildTeamStatRules.winners(totals, direction) else emptyList()
    val ranking = BuildTeamStatRules.ranking(totals, direction)
    val progress = ((roundIndex * activePlayerTotal + turnIndex).toFloat() / (roundCount * activePlayerTotal)).coerceIn(0f, 1f)

    fun fitRoundCount(availablePlayers: Int, participants: Int = activePlayerTotal) {
        val largestSupported = listOf(7, 5, 3, 2, 1).firstOrNull { it * participants <= availablePlayers }
        if (largestSupported != null && roundCount > largestSupported) roundCount = largestSupported
    }

    fun resetMatch() {
        teamPicks.forEach { it.clear() }
        roundIndex = 0
        turnIndex = 0
        turnSecondsLeft = turnTimeSeconds
        searchText = ""
        status = ""
        saveStatus = ""
        scoreSaved = false
        pickLocked = false
        countdown = 3
    }

    fun advanceAfterPick() {
        searchText = ""
        if (mode == BuildTeamPlayMode.AI) {
            if (turnIndex == 0) {
                turnIndex = 1
                phase = BuildTeamStatPhase.AI_THINKING
            } else if (roundIndex >= roundCount - 1) {
                phase = BuildTeamStatPhase.RESULT
            } else {
                roundIndex++
                turnIndex = 0
                phase = BuildTeamStatPhase.HANDOVER
            }
        } else if (turnIndex < playerCount - 1) {
            turnIndex++
            phase = BuildTeamStatPhase.HANDOVER
        } else if (roundIndex >= roundCount - 1) {
            phase = BuildTeamStatPhase.RESULT
        } else {
            roundIndex++
            turnIndex = 0
            phase = BuildTeamStatPhase.HANDOVER
        }
        sound.play(Sfx.Correct)
    }

    fun choosePlayer(player: PlayerCard) {
        if (phase != BuildTeamStatPhase.PICKING || pickLocked) return
        if (eligibleForCurrent.none { it.nameEn == player.nameEn }) return
        val value = BuildTeamStatRules.value(player, metric) ?: return
        pickLocked = true
        teamPicks[currentPlayerIndex].add(BuildTeamPick(player, value))
        sound.play(Sfx.Correct)
        sound.vibrate(22)
        advanceAfterPick()
    }

    fun startGame() {
        val candidateCount = BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric).size
        val requiredCount = roundCount * activePlayerTotal
        if (candidateCount < requiredCount) {
            status = if (english) "This challenge needs $requiredCount different players, but only $candidateCount match. Reduce rounds or broaden the filter." else "التحدي محتاج $requiredCount لاعب مختلف، لكن المتاح $candidateCount بس. قلّل الجولات أو وسّع الفلتر."
            return
        }
        resetMatch()
        phase = BuildTeamStatPhase.COUNTDOWN
        sound.play(Sfx.Click)
    }

    BackHandler { onExit() }

    LaunchedEffect(phase) {
        if (phase == BuildTeamStatPhase.COUNTDOWN) {
            for (number in 3 downTo 1) {
                countdown = number
                delay(800)
                if (phase != BuildTeamStatPhase.COUNTDOWN) return@LaunchedEffect
            }
            phase = if (mode == BuildTeamPlayMode.PASS_AND_PLAY) BuildTeamStatPhase.HANDOVER else BuildTeamStatPhase.PICKING
        }
    }
    LaunchedEffect(phase, roundIndex, turnIndex) {
        if (phase == BuildTeamStatPhase.PICKING) pickLocked = false
    }
    LaunchedEffect(phase, roundIndex, turnIndex) {
        if (phase == BuildTeamStatPhase.AI_THINKING) {
            delay(650)
            val candidates = eligible.filter { candidate -> candidate.nameEn !in alreadyDraftedNames }
            val choice = BuildTeamStatRules.chooseAiPlayer(candidates, metric, direction, aiDifficulty)
            if (choice != null) {
                val value = BuildTeamStatRules.value(choice, metric) ?: 0
                teamPicks[1].add(BuildTeamPick(choice, value))
                sound.play(Sfx.Tick)
                if (roundIndex >= roundCount - 1) phase = BuildTeamStatPhase.RESULT
                else {
                    roundIndex++
                    turnIndex = 0
                    phase = if (mode == BuildTeamPlayMode.AI) BuildTeamStatPhase.PICKING else BuildTeamStatPhase.HANDOVER
                }
            } else {
                status = if (english) "AI has no unused eligible player." else "الـAI معندوش لاعب تاني مطابق للفلتر."
                phase = BuildTeamStatPhase.RESULT
            }
        }
    }
    LaunchedEffect(phase, roundIndex, turnIndex, turnTimeSeconds) {
        if (phase == BuildTeamStatPhase.PICKING) {
            val timedRound = roundIndex
            val timedTurn = turnIndex
            for (seconds in turnTimeSeconds downTo 1) {
                turnSecondsLeft = seconds
                delay(1_000)
                if (phase != BuildTeamStatPhase.PICKING || roundIndex != timedRound || turnIndex != timedTurn) return@LaunchedEffect
            }
            if (phase == BuildTeamStatPhase.PICKING && roundIndex == timedRound && turnIndex == timedTurn) {
                val automaticPick = if (direction == BuildTeamDirection.HIGH) {
                    eligibleForCurrent.maxByOrNull { BuildTeamStatRules.value(it, metric) ?: Int.MIN_VALUE }
                } else {
                    eligibleForCurrent.minByOrNull { BuildTeamStatRules.value(it, metric) ?: Int.MAX_VALUE }
                }
                if (automaticPick != null) {
                    status = if (english) "Time expired: the best remaining eligible player was selected automatically." else "الوقت خلص، اخترنا أفضل لاعب متاح تلقائيًا حسب معيار الجولة."
                    choosePlayer(automaticPick)
                } else {
                    status = if (english) "No unused players remain for this team." else "مفيش لاعبين مطابقين متبقّيين للفريق ده."
                    phase = BuildTeamStatPhase.RESULT
                }
            }
        }
    }
    LaunchedEffect(phase, totals, winners) {
        if (phase == BuildTeamStatPhase.RESULT && mode == BuildTeamPlayMode.AI && !scoreSaved) {
            scoreSaved = true
            val userWon = winners.contains(0) && !winners.contains(1)
            val score = if (userWon) 1_000 + if (direction == BuildTeamDirection.HIGH) totals[0] else (1_000 - totals[0]).coerceAtLeast(0) else 0
            if (ElbashaAccess.isDeveloper(user.uid)) {
                saveStatus = if (english) "Developer account is excluded from competitive rankings." else "حساب المطور مستبعد من الترتيب التنافسي."
            } else {
                ScoreRepository.submit(database, user, score) { saved ->
                    saveStatus = if (saved) {
                        if (english) "Result saved to the leaderboard." else "تم حفظ النتيجة في الترتيب."
                    } else {
                        if (english) "Could not save the result. Check Firebase." else "تعذر حفظ النتيجة. راجع اتصال Firebase."
                    }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(localizedText(english, "كوّن فريق", "BUILD A TEAM"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(
            localizedText(english, "اختار الفلتر والإحصائية. كل لاعب يختار لاعبًا مختلفًا في كل جولة، وقيمة الإحصائية نفسها تتحول لنقاط: 200 سم = 200 نقطة.", "Choose a filter and a stat. Each player drafts a different footballer every round; the exact stat value becomes points: 200 cm = 200 points."),
            color = palette.muted, fontSize = 12.sp
        )

        when (phase) {
            BuildTeamStatPhase.SETUP -> {
                Text(localizedText(english, "طريقة اللعب", "PLAY MODE"), color = Cream, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChoiceCard(
                        modifier = Modifier.weight(1f),
                        title = localizedText(english, "على جهاز واحد", "Pass the phone"),
                        subtitle = localizedText(english, "2 إلى 4 لاعبين", "2 to 4 players"),
                        selected = mode == BuildTeamPlayMode.PASS_AND_PLAY
                    ) {
                        mode = BuildTeamPlayMode.PASS_AND_PLAY
                        fitRoundCount(eligible.size, playerCount)
                    }
                    ModeChoiceCard(
                        modifier = Modifier.weight(1f),
                        title = localizedText(english, "ضد AI", "Against AI"),
                        subtitle = localizedText(english, "لاعب واحد", "One player"),
                        selected = mode == BuildTeamPlayMode.AI
                    ) {
                        mode = BuildTeamPlayMode.AI
                        fitRoundCount(eligible.size, 2)
                    }
                }

                if (mode == BuildTeamPlayMode.PASS_AND_PLAY) {
                    Text(localizedText(english, "عدد اللاعبين", "PLAYERS"), color = Cream, fontWeight = FontWeight.Bold)
                    ChoiceRow((PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS).map { it.toString() }, playerCount.toString()) {
                        playerCount = it.toInt()
                        fitRoundCount(eligible.size, playerCount)
                    }
                    repeat(playerCount) { index ->
                        OutlinedTextField(
                            value = nameInputs[index], onValueChange = { nameInputs[index] = it.take(20) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text(localizedText(english, "اسم اللاعب ${index + 1}", "Player ${index + 1} name")) },
                            colors = outlinedColors()
                        )
                    }
                } else {
                    Text(localizedText(english, "هتلعب ضد ذكاء اصطناعي بيختار حسب نفس الفلتر والإحصائية.", "You play an AI that follows the same filter and scoring stat."), color = palette.muted, fontSize = 12.sp)
                    Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
                    ChoiceRow(listOf("سهل", "متوازن", "صعب", "صعب جدًا"), listOf("سهل", "متوازن", "صعب", "صعب جدًا")[aiDifficulty]) { aiDifficulty = listOf("سهل", "متوازن", "صعب", "صعب جدًا").indexOf(it).coerceAtLeast(0) }
                }

                Text(localizedText(english, "عدد جولات بناء الفريق", "SQUAD ROUNDS"), color = Cream, fontWeight = FontWeight.Bold)
                val roundOptions = listOf(1, 2, 3, 5, 7)
                ChoiceRow(
                    roundOptions.map(Int::toString), roundCount.toString(),
                    enabled = roundOptions.map { count -> if (eligible.size >= count * activePlayerTotal) 1 else 0 }
                ) { roundCount = it.toInt() }
                Text(
                    localizedText(english, "المتاح: ${eligible.size} لاعب مختلف. تحتاج ${roundCount * activePlayerTotal} اختيارًا للمباراة.", "Available: ${eligible.size} distinct players. This match needs ${roundCount * activePlayerTotal} picks."),
                    color = palette.muted, fontSize = 10.sp
                )

                Text(localizedText(english, "فلتر اللاعبين", "PLAYER FILTER"), color = Cream, fontWeight = FontWeight.Bold)
                Text(localizedText(english, "المركز", "Position"), color = palette.muted, fontSize = 11.sp)
                ChoiceRow(
                    BuildTeamPositionFilter.entries.map { if (english) it.labelEn else it.labelAr },
                    if (english) filter.position.labelEn else filter.position.labelAr,
                    enabled = BuildTeamPositionFilter.entries.map { candidate ->
                        val testFilter = filter.copy(position = candidate)
                        eligibleMetricCount(testFilter, metric)
                    }
                ) { label ->
                    filter = filter.copy(position = BuildTeamPositionFilter.entries.first { (if (english) it.labelEn else it.labelAr) == label })
                    fitRoundCount(eligibleMetricCount(filter, metric))
                }
                Text(localizedText(english, "الدوري", "League"), color = palette.muted, fontSize = 11.sp)
                ChoiceRow(
                    BuildTeamLeagueFilter.entries.map { if (english) it.labelEn else it.labelAr },
                    if (english) filter.league.labelEn else filter.league.labelAr,
                    enabled = BuildTeamLeagueFilter.entries.map { candidate -> eligibleMetricCount(filter.copy(league = candidate), metric) }
                ) { label ->
                    filter = filter.copy(league = BuildTeamLeagueFilter.entries.first { (if (english) it.labelEn else it.labelAr) == label })
                    fitRoundCount(eligibleMetricCount(filter, metric))
                }

                Text(localizedText(english, "أساس احتساب النقاط", "SCORING STAT"), color = Cream, fontWeight = FontWeight.Bold)
                ChoiceRow(
                    BuildTeamMetric.entries.map { if (english) it.labelEn else it.labelAr },
                    if (english) metric.labelEn else metric.labelAr,
                    enabled = BuildTeamMetric.entries.map { candidate -> eligibleMetricCount(filter, candidate) }
                ) { label ->
                    metric = BuildTeamMetric.entries.first { (if (english) it.labelEn else it.labelAr) == label }
                    fitRoundCount(eligibleMetricCount(filter, metric))
                }
                Text(
                    localizedText(english, "الأهداف والإنذارات: موسم 2026/27 (لقطة 21 نوفمبر 2026). السرعة تقييم ELBASHA من 100، مش قياسًا فعليًا.", "Goals and cards: 2026/27 season snapshot from 21 Nov 2026. Pace is an ELBASHA rating out of 100, not a measured sprint speed."),
                    color = palette.muted, fontSize = 10.sp
                )

                Text(localizedText(english, "مين يكسب؟", "WIN CONDITION"), color = Cream, fontWeight = FontWeight.Bold)
                ChoiceRow(
                    BuildTeamDirection.entries.map { if (english) it.labelEn else it.labelAr },
                    if (english) direction.labelEn else direction.labelAr
                ) { label -> direction = BuildTeamDirection.entries.first { (if (english) it.labelEn else it.labelAr) == label } }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val randomSetup = BuildTeamStatRules.randomValidSetup(roundCount, activePlayerTotal, Random.Default)
                            if (randomSetup == null) status = if (english) "No supported random setup is available." else "مفيش إعداد عشوائي متاح ببيانات كفاية."
                            else {
                                filter = randomSetup.first
                                metric = randomSetup.second
                                direction = randomSetup.third
                                status = if (english) "Random challenge ready." else "تم اختيار تحدي عشوائي."
                                sound.play(Sfx.Click)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = Cream)
                    ) { Text(localizedText(english, "عشوائي", "Random"), fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { startGame() },
                        modifier = Modifier.weight(1.3f),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) { Text(localizedText(english, "ابدأ اللعب", "START GAME"), fontWeight = FontWeight.Black) }
                }
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        val samplePool = BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric)
                        val sample = samplePool.sortedBy { if (it.nameEn in setOf("Joan Garcia", "Thibaut Courtois")) 0 else 1 }.take(2)
                        Text(localizedText(english, "معاينة الفلتر", "FILTER PREVIEW"), color = Gold, fontWeight = FontWeight.Bold)
                        Text(
                            "${if (english) filter.position.labelEn else filter.position.labelAr} • ${if (english) filter.league.labelEn else filter.league.labelAr}",
                            color = Cream, fontWeight = FontWeight.Bold
                        )
                        Text(
                            localizedText(english, "${eligible.size} لاعب عندهم بيانات للإحصائية دي.", "${eligible.size} player records support this stat."),
                            color = palette.muted, fontSize = 11.sp
                        )
                        sample.forEach { candidate ->
                            val value = BuildTeamStatRules.value(candidate, metric)
                            val displayedName = if (english) candidate.nameEn else candidate.nameAr
                            val displayedUnit = if (english) metric.unitEn else metric.unitAr
                            val pointsWord = if (english) "points" else "نقطة"
                            Text(
                                "$displayedName: $value $displayedUnit = $value $pointsWord",
                                color = Cream, fontSize = 12.sp
                            )
                        }
                    }
                }
                if (status.isNotBlank()) Text(status, color = palette.bad, fontSize = 12.sp)
            }

            BuildTeamStatPhase.COUNTDOWN -> CountdownStage(countdown, localizedText(english, "التحدي هيبدأ", "The challenge starts"))

            BuildTeamStatPhase.HANDOVER -> {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(localizedText(english, "سلّم الموبايل", "PASS THE PHONE"), color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        Text(currentPlayerName, color = Cream, fontWeight = FontWeight.Black, fontSize = 26.sp)
                        Text(
                            localizedText(english, "الجولة ${roundIndex + 1} من $roundCount. باقي اللاعبين يبعدوا عينهم عن الشاشة.", "Round ${roundIndex + 1} of $roundCount. Everyone else, look away."),
                            color = palette.muted, textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { searchText = ""; pickLocked = false; phase = BuildTeamStatPhase.PICKING; sound.play(Sfx.Click) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                        ) { Text(localizedText(english, "أنا $currentPlayerName — جاهز", "I'm $currentPlayerName — ready"), fontWeight = FontWeight.Bold) }
                    }
                }
            }

            BuildTeamStatPhase.AI_THINKING -> {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(localizedText(english, "ELBASHA AI بيختار", "ELBASHA AI is choosing"), color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = palette.surface)
                    }
                }
            }

            BuildTeamStatPhase.PICKING -> {
                Text(
                    localizedText(english, "دور $currentPlayerName", "${currentPlayerName}'s turn"),
                    color = Gold, fontWeight = FontWeight.Black, fontSize = 21.sp
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(localizedText(english, "الجولة ${roundIndex + 1}/$roundCount", "ROUND ${roundIndex + 1}/$roundCount"), color = Cream, fontWeight = FontWeight.Bold)
                    Text("${turnSecondsLeft}s", color = if (turnSecondsLeft <= 7) palette.bad else Gold, fontWeight = FontWeight.Black)
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = palette.panel)
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(localizedText(english, "النقاط الحالية", "LIVE SCORE"), color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        (0 until activePlayerTotal).forEach { playerIndex ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(normalizedNames[playerIndex], color = Cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("${totals[playerIndex]} ${localizedText(english, "نقطة", "pts")}", color = Gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(localizedText(english, "الفلتر", "FILTER"), color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${if (english) filter.position.labelEn else filter.position.labelAr} • ${if (english) filter.league.labelEn else filter.league.labelAr}",
                            color = Cream, fontWeight = FontWeight.Bold
                        )
                        Text(localizedText(english, "أساس النقاط: ${metric.labelAr}", "Scoring stat: ${metric.labelEn}"), color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Text(
                            localizedText(english, "قيمة ${metric.labelAr} نفسها تتحول لنقاط (${metric.unitAr}). ${direction.labelAr}.", "${metric.labelEn} value becomes points (${metric.unitEn}). ${direction.labelEn}."),
                            color = palette.muted, fontSize = 12.sp
                        )
                    }
                }
                OutlinedTextField(
                    value = searchText, onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(localizedText(english, "اكتب اسم اللاعب", "Search player name")) },
                    placeholder = { Text(localizedText(english, "اكتب 3 حروف بالعربي أو الإنجليزي", "Type 3 Arabic or English characters")) },
                    colors = outlinedColors()
                )
                if (PlayerSearch.normalize(searchText).length < 3) {
                    Text(localizedText(english, "الاقتراحات بتظهر بعد أول 3 حروف.", "Suggestions appear after the first 3 characters."), color = palette.muted, fontSize = 11.sp)
                } else if (suggestions.isEmpty()) {
                    Text(localizedText(english, "مفيش لاعب مطابق للفلتر أو متاح في فريقك.", "No player matches the filter or remains available for this team."), color = palette.bad, fontSize = 12.sp)
                }
                suggestions.forEach { player ->
                    val value = BuildTeamStatRules.value(player, metric) ?: return@forEach
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { choosePlayer(player) },
                        colors = CardDefaults.cardColors(containerColor = palette.panel),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PlayerPortrait(player, Modifier.height(76.dp).weight(0.34f), cornerRadius = 10)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if (english) player.nameEn else player.nameAr, color = Cream, fontWeight = FontWeight.Black)
                                val facts = PlayerFactsDatabase.facts(player)
                                val meta = facts?.let { "${it.club} • ${it.league}" } ?: player.nationalityAr
                                Text(meta, color = palette.muted, fontSize = 10.sp)
                                Text("${if (english) metric.labelEn else metric.labelAr}: $value ${if (english) metric.unitEn else metric.unitAr}", color = Gold, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                Text("+$value ${localizedText(english, "نقطة", "points")}", color = Cream, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
                if (status.isNotBlank()) Text(status, color = palette.bad, fontSize = 11.sp)
                if (currentPlayersPicks.isNotEmpty()) {
                    Text(localizedText(english, "اختيارات $currentPlayerName", "$currentPlayerName's picks"), color = Gold, fontWeight = FontWeight.Bold)
                    currentPlayersPicks.forEach { pick ->
                        Text("${if (english) pick.player.nameEn else pick.player.nameAr} • ${pick.value} ${if (english) metric.unitEn else metric.unitAr}", color = Cream, fontSize = 12.sp)
                    }
                }
            }

            BuildTeamStatPhase.RESULT -> {
                Text(localizedText(english, "النتيجة النهائية", "FINAL RESULT"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(
                    if (winners.size == 1) localizedText(english, "الفائز: ${normalizedNames[winners.first()]}", "Winner: ${normalizedNames[winners.first()]}")
                    else localizedText(english, "تعادل بين ${winners.joinToString(" و ") { normalizedNames[it] }}", "Draw: ${winners.joinToString(" & ") { normalizedNames[it] }}"),
                    color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp
                )
                Text(
                    localizedText(english, "${direction.labelAr}: ${metric.labelAr}", "${direction.labelEn}: ${metric.labelEn}"),
                    color = palette.muted, fontSize = 12.sp
                )
                ranking.forEachIndexed { place, playerIndex ->
                    Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${place + 1}.", color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                                Text(normalizedNames[playerIndex], color = Cream, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                Text("${totals[playerIndex]} ${localizedText(english, "نقطة", "points")}", color = Gold, fontWeight = FontWeight.Black)
                            }
                            teamPicks[playerIndex].forEachIndexed { pickIndex, pick ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${pickIndex + 1}.", color = palette.muted, modifier = Modifier.padding(end = 5.dp))
                                    Text(if (english) pick.player.nameEn else pick.player.nameAr, color = Cream, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                    Text("${pick.value} ${if (english) metric.unitEn else metric.unitAr} = ${pick.value}", color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                if (saveStatus.isNotBlank()) Text(saveStatus, color = palette.muted, fontSize = 11.sp)
                Button(
                    onClick = { resetMatch(); phase = BuildTeamStatPhase.SETUP },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "تحدي جديد", "NEW CHALLENGE"), fontWeight = FontWeight.Black) }
            }
        }
    }
}

private fun eligibleMetricCount(filter: BuildTeamFilter, metric: BuildTeamMetric): Int =
    BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric).size

@Composable
private fun ModeChoiceCard(
    modifier: Modifier,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = if (selected) Gold else palette.panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(subtitle, color = if (selected) DeepWine else palette.muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ChoiceRow(values: List<String>, selected: String, enabled: List<Int>? = null, onSelect: (String) -> Unit) {
    val palette = LocalElbashaPalette.current
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEachIndexed { index, value ->
            val isEnabled = enabled?.getOrNull(index)?.let { it > 0 } ?: true
            Box(
                Modifier.clip(RoundedCornerShape(10.dp))
                    .background(when { !isEnabled -> palette.surface; value == selected -> Gold; else -> palette.panel })
                    .clickable(enabled = isEnabled) { onSelect(value) }
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    value,
                    color = when { !isEnabled -> palette.muted; value == selected -> DeepWine; else -> Cream },
                    fontWeight = if (value == selected) FontWeight.Black else FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Cream,
    unfocusedTextColor = Cream,
    focusedBorderColor = Gold,
    unfocusedBorderColor = LocalElbashaPalette.current.muted,
    focusedLabelColor = Gold,
    unfocusedLabelColor = LocalElbashaPalette.current.muted,
    cursorColor = Gold
)
