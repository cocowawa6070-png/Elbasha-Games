package com.mostafabek.elbashagames

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared turn-time controls used by the three core games. */
@Composable
fun TurnTimeSelector(
    selectedSeconds: Int,
    onSelect: (Int) -> Unit,
    title: String = uiText("وقت كل دور", "Time per turn")
) {
    val palette = LocalElbashaPalette.current
    androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(90, 60, 30, 15).forEach { seconds ->
                val selected = seconds == selectedSeconds
                Box(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) palette.gold else palette.panel)
                        .border(1.dp, if (selected) palette.gold else palette.gold.copy(alpha = 0.28f), RoundedCornerShape(12.dp))
                        .clickable { onSelect(seconds) }
                        .padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "$seconds",
                        color = if (selected) palette.deepWine else palette.cream,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun TurnTimerPill(secondsLeft: Int, totalSeconds: Int, modifier: Modifier = Modifier) {
    val palette = LocalElbashaPalette.current
    val critical = secondsLeft <= 5
    val fill = (secondsLeft.toFloat() / totalSeconds.coerceAtLeast(1)).coerceIn(0f, 1f)
    Box(
        modifier.clip(CircleShape)
            .background(if (critical) palette.bad.copy(alpha = 0.22f) else palette.panel)
            .border(2.dp, if (critical) palette.bad else palette.good, CircleShape)
            .padding(horizontal = 15.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("$secondsLeft", color = if (critical) palette.bad else palette.cream, fontSize = 17.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun CountdownStage(number: Int, subtitle: String = uiText("استعد للجولة", "Get ready")) {
    val palette = LocalElbashaPalette.current
    androidx.compose.foundation.layout.Column(
        Modifier.fillMaxWidth().padding(vertical = 42.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(subtitle, color = palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Box(
            Modifier.clip(CircleShape)
                .background(palette.panel)
                .border(3.dp, palette.gold, CircleShape)
                .padding(horizontal = 42.dp, vertical = 25.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("$number", color = palette.gold, fontSize = 58.sp, fontWeight = FontWeight.Black)
        }
    }
}



/** Match header inspired by the supplied gameplay reference: two players and a central live clock. */
@Composable
fun VersusTimerHud(
    userName: String,
    rivalName: String,
    secondsLeft: Int,
    totalSeconds: Int,
    caption: String
) {
    val palette = LocalElbashaPalette.current
    val safeTotal = totalSeconds.coerceAtLeast(1)
    val ratio = (secondsLeft.toFloat() / safeTotal).coerceIn(0f, 1f)
    val urgent = secondsLeft <= 5
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(rivalName.take(15), color = palette.cream, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text(caption, color = palette.muted, fontSize = 9.sp, maxLines = 1)
            }
            Box(Modifier.padding(horizontal = 8.dp).size(50.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { ratio },
                    modifier = Modifier.fillMaxWidth(),
                    color = if (urgent) palette.bad else palette.good,
                    trackColor = palette.muted.copy(alpha = 0.22f),
                    strokeWidth = 4.dp
                )
                Text("$secondsLeft", color = if (urgent) palette.bad else palette.cream, fontSize = 16.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(userName.take(15), color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text(uiText("دورك", "YOUR TURN"), color = palette.muted, fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}


/** Centered circular timer used by Deal or No Deal, matching its vertical reference layout. */
@Composable
fun DealRoundTimer(secondsLeft: Int, totalSeconds: Int, round: Int, totalRounds: Int) {
    val palette = LocalElbashaPalette.current
    val ratio = (secondsLeft.toFloat() / totalSeconds.coerceAtLeast(1)).coerceIn(0f, 1f)
    val urgent = secondsLeft <= 5
    androidx.compose.foundation.layout.Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { ratio },
                modifier = Modifier.fillMaxWidth(),
                color = if (urgent) palette.bad else palette.good,
                trackColor = palette.muted.copy(alpha = 0.24f),
                strokeWidth = 5.dp
            )
            Text("$secondsLeft", color = if (urgent) palette.bad else palette.cream, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        Text(uiText("الجولة $round من $totalRounds", "ROUND $round OF $totalRounds"), color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
    }
}
