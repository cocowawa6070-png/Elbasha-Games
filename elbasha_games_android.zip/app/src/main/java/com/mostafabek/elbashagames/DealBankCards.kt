package com.mostafabek.elbashagames

enum class DealBankCard(val key: String) {
    DOUBLE_DEAL("double"),
    REVEAL_CASE("reveal"),
    SWAP_OFFER("swap")
}

/** One-use bank deck for a five-position Deal or No Deal match. */
object DealBankCardRules {
    fun canUse(
        card: DealBankCard,
        usedCards: Set<String>,
        phase: String,
        round: Int,
        userSquadSize: Int,
        rivalSquadSize: Int
    ): Boolean {
        if (phase != "decision" || card.key in usedCards) return false
        return when (card) {
            DealBankCard.DOUBLE_DEAL -> round < 5 && userSquadSize <= 3 && rivalSquadSize <= 3
            DealBankCard.REVEAL_CASE, DealBankCard.SWAP_OFFER -> true
        }
    }

    fun consume(card: DealBankCard, usedCards: Set<String>): Set<String> = usedCards + card.key
}
