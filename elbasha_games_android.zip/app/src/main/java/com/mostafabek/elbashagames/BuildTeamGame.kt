package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay

private data class BuildSlot(
    val code: String,
    val titleAr: String,
    val titleEn: String
)

private enum class BuildPhase { Setup, Countdown, Picking, Result }

private val BuildPositionLabels = mapOf(
    "GK" to ("حارس مرمى" to "Goalkeeper"),
    "RB" to ("ظهير أيمن" to "Right Back"),
    "CB" to ("قلب دفاع" to "Centre Back"),
    "LB" to ("ظهير أيسر" to "Left Back"),
    "CDM" to ("وسط دفاعي" to "Defensive Midfielder"),
    "CM" to ("وسط" to "Central Midfielder"),
    "CAM" to ("وسط هجومي" to "Attacking Midfielder"),
    "RW" to ("جناح أيمن" to "Right Winger"),
    "LW" to ("جناح أيسر" to "Left Winger"),
    "ST" to ("مهاجم" to "Striker")
)

private fun buildFormation(size: Int): List<BuildSlot> =
    ElbashaPositions.formationSlots(size.coerceIn(4, 11)).map { code ->
        val labels = BuildPositionLabels.getValue(code)
        BuildSlot(code, labels.first, labels.second)
    }

@Composable
fun BuildTeamScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    var phase by remember { mutableStateOf(BuildPhase.Setup) }
    var teamSize by remember { mutableIntStateOf(11) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var turnTimeSeconds by remember { mutableIntStateOf(30) }
    var turnSecondsLeft by remember { mutableIntStateOf(30) }
    var suggestionsEnabled by remember { mutableStateOf(true) }
    var allPlayersFilter by remember { mutableStateOf(true) }
    var filterSearchText by remember { mutableStateOf("") }
    val selectedPoolNames = remember { mutableStateListOf<String>() }
    var countdownNumber by remember { mutableIntStateOf(3) }
    var slotIndex by remember { mutableIntStateOf(0) }
    var currentChallenge by remember { mutableStateOf<NationalityChallenge?>(null) }
    var searchText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var saveStatus by remember { mutableStateOf("") }
    val playerTeam = remember { mutableStateListOf<PlayerCard>() }
    val aiTeam = remember { mutableStateListOf<PlayerCard>() }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var pickLocked by remember { mutableStateOf(false) }
    val formation = remember(teamSize) { buildFormation(teamSize) }
    val gamePlayers = if (allPlayersFilter) PlayerDatabase.players else
        PlayerDatabase.players.filter { it.nameEn in selectedPoolNames }
    val filterSuggestions = if (PlayerSearch.normalize(filterSearchText).length >= 3) {
        PlayerSearch.suggestions(PlayerDatabase.players.filter { it.nameEn !in selectedPoolNames }, filterSearchText, limit = 8)
    } else emptyList()
    val usedNames = (playerTeam + aiTeam).map { it.nameEn }.toSet()
    val challenge = currentChallenge
    val eligiblePlayers = if (challenge == null) emptyList() else
        BuildTeamRules.eligiblePlayers(gamePlayers, challenge, usedNames)
    val suggestions = if (suggestionsEnabled && PlayerSearch.normalize(searchText).length >= 3)
        PlayerSearch.suggestions(eligiblePlayers, searchText, limit = 10) else emptyList()
    val userPoints = playerTeam.indices.count { index ->
        playerTeam[index].rating > (aiTeam.getOrNull(index)?.rating ?: 0)
    }
    val aiPoints = aiTeam.indices.count { index ->
        aiTeam[index].rating > (playerTeam.getOrNull(index)?.rating ?: 0)
    }
    val totalUserRating = playerTeam.sumOf { it.rating }
    val totalAiRating = aiTeam.sumOf { it.rating }

    fun startGame() {
        playerTeam.clear()
        aiTeam.clear()
        slotIndex = 0
        searchText = ""
        status = ""
        saveStatus = ""
        scoreSubmitted = false
        pickLocked = false
        val requiredByRole = formation.groupingBy { ElbashaPositions.poolRole(it.code) }.eachCount()
        val enoughPlayers = requiredByRole.all { (role, count) ->
            gamePlayers.count { ElbashaPositions.poolRole(it.position) == role } >= count * 2
        }
        if (!enoughPlayers) {
            status = if (english) "Select at least ${formation.size * 2} eligible players with enough players in every position group." else "اختار عدد كافي من اللاعبين: لازم لاعبين لكل مركز على الأقل، ومن كل مجموعة مراكز عدد يكفي التشكيلة."
            return
        }
        currentChallenge = BuildTeamRules.createNationalityChallenge(
            gamePlayers, formation.first().code, emptySet()
        )
        if (currentChallenge == null) {
            status = if (english) "Not enough matching players in the database." else "قاعدة اللاعبين لا تحتوي على لاعبين كفاية لهذا التحدي."
            return
        }
        countdownNumber = 3
        phase = BuildPhase.Countdown
        sound.play(Sfx.Click)
    }

    fun choosePlayer(player: PlayerCard) {
        if (phase != BuildPhase.Picking || pickLocked) return
        val active = currentChallenge ?: return
        if (player.nameEn in usedNames || player !in eligiblePlayers) return
        // Lock this turn synchronously so a rapid double tap cannot draft twice.
        pickLocked = true
        playerTeam.add(player.copy(position = active.positionCode))
        val aiCandidates = BuildTeamRules.eligiblePlayers(
            gamePlayers,
            active,
            (playerTeam + aiTeam).map { it.nameEn }.toSet()
        )
        val aiChoice = BuildTeamRules.chooseAiPlayer(aiCandidates, aiDifficulty)
        if (aiChoice != null) aiTeam.add(aiChoice.copy(position = active.positionCode))
        searchText = ""
        sound.play(Sfx.Correct)
        sound.vibrate(22)
        if (slotIndex >= formation.lastIndex) {
            phase = BuildPhase.Result
        } else {
            slotIndex++
            val unavailable = (playerTeam + aiTeam).map { it.nameEn }.toSet()
            currentChallenge = BuildTeamRules.createNationalityChallenge(
                gamePlayers, formation[slotIndex].code, unavailable
            )
            if (currentChallenge == null) {
                // This is a defensive fallback for unusual player-pool edits.
                val fallback = gamePlayers.filter {
                    ElbashaPositions.supports(it, formation[slotIndex].code) && it.nameEn !in unavailable
                }
                val nation = fallback.groupBy { it.nationalityEn }.entries
                    .firstOrNull { it.value.size >= 2 }
                if (nation != null) {
                    val sample = nation.value.first()
                    val labels = BuildPositionLabels.getValue(formation[slotIndex].code)
                    currentChallenge = NationalityChallenge(sample.nationalityAr, nation.key, formation[slotIndex].code, labels.first, labels.second)
                } else {
                    status = if (english) "The player pool for this position is exhausted." else "خلصت اختيارات اللاعبين المتاحة للمركز ده."
                    phase = BuildPhase.Result
                }
            }
        }
    }

    BackHandler { onExit() }
    LaunchedEffect(phase, slotIndex) {
        // Unlock only after Compose has rendered the next slot, not inside the previous tap.
        if (phase == BuildPhase.Picking) pickLocked = false
    }
    LaunchedEffect(phase, turnTimeSeconds) {
        if (phase == BuildPhase.Countdown) {
            for (number in 3 downTo 1) {
                countdownNumber = number
                delay(850)
                if (phase != BuildPhase.Countdown) return@LaunchedEffect
            }
            phase = BuildPhase.Picking
        }
    }
    LaunchedEffect(phase, slotIndex, turnTimeSeconds) {
        if (phase == BuildPhase.Picking) {
            val timedSlot = slotIndex
            for (seconds in turnTimeSeconds downTo 1) {
                turnSecondsLeft = seconds
                delay(1_000)
                if (phase != BuildPhase.Picking || slotIndex != timedSlot) return@LaunchedEffect
            }
            val automaticPick = eligiblePlayers.maxByOrNull { it.rating }
            if (phase == BuildPhase.Picking && slotIndex == timedSlot) {
                if (automaticPick != null) {
                    status = localizedText(english, "انتهى الوقت، تم اختيار أعلى لاعب متاح تلقائيًا.", "Time expired; the highest-rated eligible player was picked automatically.")
                    choosePlayer(automaticPick)
                } else {
                    status = localizedText(english, "مفيش لاعبين متاحين للمركز ده، تم إنهاء الاختيار بأمان.", "No eligible players remain for this position. The draft was safely ended.")
                    phase = BuildPhase.Result
                }
            }
        }
    }

LaunchedEffect(phase) {
        if (phase == BuildPhase.Result && !scoreSubmitted) {
            scoreSubmitted = true
            sound.play(if (userPoints >= aiPoints) Sfx.Win else Sfx.Loss)
            if (ElbashaAccess.isDeveloper(user.uid)) {
                saveStatus = localizedText(english, "حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
            } else {
                val score = (userPoints * 1000 + totalUserRating).coerceIn(0, 100_000)
                ScoreRepository.submit(database, user, score) { saved ->
                    saveStatus = if (saved) localizedText(english, "تم حفظ نقاط التحدي ✅", "Challenge score saved ✅")
                    else localizedText(english, "تعذر حفظ النتيجة. راجع اتصال Firebase.", "Could not save the result. Check Firebase.")
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(localizedText(english, "🧩 كون فريق", "🧩 Build a Team"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)

        when (phase) {
            BuildPhase.Setup -> {
                Text(localizedText(english, "اتحدى الذكاء الاصطناعي في بناء فريقك", "Challenge the AI to build a stronger team"), color = Cream, fontWeight = FontWeight.Bold)
                Text(localizedText(english, "اختار عدد اللاعبين ووقت كل دور والتحدي، وبعدها ابدأ بناء فريقك ضد الـAI.", "Set squad size, turn time and player pool, then draft against the AI."), color = Muted, fontSize = 12.sp)
                TurnTimeSelector(selectedSeconds = turnTimeSeconds, onSelect = { turnTimeSeconds = it })
                Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(localizedText(english, "التشكيلة", "SQUAD SIZE"), color = Cream, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { teamSize = (teamSize - 1).coerceAtLeast(4) }, enabled = teamSize > 4) { Text("−", color = Gold, fontSize = 20.sp) }
                        Text("$teamSize", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp))
                        OutlinedButton(onClick = { teamSize = (teamSize + 1).coerceAtMost(11) }, enabled = teamSize < 11) { Text("+", color = Gold, fontSize = 20.sp) }
                    }
                }
                Text(localizedText(english, "اختار التحدي", "CHOOSE CHALLENGE"), color = Cream, fontWeight = FontWeight.Bold)
                Card(
                    Modifier.fillMaxWidth().border(1.dp, Gold, RoundedCornerShape(15.dp)),
                    colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(15.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("✦", color = Gold, fontSize = 23.sp)
                        Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(localizedText(english, "عشوائي", "Random"), color = Gold, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "اللعبة تختار المركز والجنسية في كل دور", "The game chooses a position and nationality requirement each turn"), color = Muted, fontSize = 11.sp)
                        }
                        Text("✓", color = Gold, fontWeight = FontWeight.Black)
                    }
                }
                Text(localizedText(english, "فلتر اللاعبين", "PLAYER FILTER"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(true to ("كل اللاعبين" to "All players"), false to ("تحديد" to "Select")).forEach { (all, labels) ->
                        val selected = allPlayersFilter == all
                        Card(
                            Modifier.weight(1f).clickable { allPlayersFilter = all; filterSearchText = "" },
                            colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (english) labels.second else labels.first, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
                        }
                    }
                }
                if (!allPlayersFilter) {
                    Text(localizedText(english, "اختار اللاعبين اللي هيدخلوا في التحدي (اكتب 3 حروف للبحث).", "Choose the players available in this draft (type 3 characters to search)."), color = Muted, fontSize = 11.sp)
                    OutlinedTextField(
                        value = filterSearchText,
                        onValueChange = { filterSearchText = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(localizedText(english, "ابحث عن لاعب", "Find a player")) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Cream, unfocusedTextColor = Cream, focusedBorderColor = Gold, unfocusedBorderColor = Muted, focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold)
                    )
                    if (PlayerSearch.normalize(filterSearchText).length >= 3) {
                        filterSuggestions.forEach { candidate ->
                            PremiumPlayerChoiceCard(candidate, english) {
                                if (candidate.nameEn !in selectedPoolNames) selectedPoolNames.add(candidate.nameEn)
                                filterSearchText = ""
                            }
                        }
                    }
                    if (selectedPoolNames.isNotEmpty()) {
                        Text(localizedText(english, "اللاعبون المحددون: ${selectedPoolNames.size}", "Selected players: ${selectedPoolNames.size}"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            selectedPoolNames.toList().forEach { name ->
                                Card(Modifier.clickable { selectedPoolNames.remove(name) }, colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(20.dp)) {
                                    Text("$name  ×", color = Cream, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                                }
                            }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(localizedText(english, "اقتراحات الأسماء أثناء الكتابة", "Player suggestions while typing"), color = Cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(localizedText(english, "تظهر بعد كتابة 3 حروف", "Shown after 3 characters"), color = Muted, fontSize = 10.sp)
                        }
                        Switch(checked = suggestionsEnabled, onCheckedChange = { suggestionsEnabled = it })
                    }
                }
                Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("سهل" to "Easy", "متوازن" to "Balanced", "صعب" to "Hard", "صعب جدًا" to "Very hard").forEachIndexed { index, pair ->
                        val selected = aiDifficulty == index
                        Card(
                            Modifier.weight(1f).clickable { aiDifficulty = index },
                            colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (english) pair.second else pair.first, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 12.dp), textAlign = TextAlign.Center, fontSize = 11.sp)
                        }
                    }
                }
                if (status.isNotBlank()) Text(status, color = LocalElbashaPalette.current.bad)
                Button(onClick = { startGame() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                    Text(localizedText(english, "ابدأ التحدي", "Start challenge"), fontWeight = FontWeight.Bold)
                }
            }

            BuildPhase.Countdown -> {
                CountdownStage(countdownNumber, localizedText(english, "الماتش هيبدأ", "The match is starting"))
            }
            BuildPhase.Picking -> {
                val slot = formation.getOrNull(slotIndex)
                VersusTimerHud(
                    userName = user.displayName?.takeIf { it.isNotBlank() } ?: user.email?.substringBefore("@") ?: "MUSTAFA",
                    rivalName = "CPU",
                    secondsLeft = turnSecondsLeft,
                    totalSeconds = turnTimeSeconds,
                    caption = localizedText(english, "اختار لاعبك", "PICK YOUR PLAYER")
                )
                Text(localizedText(english, "المركز ${slotIndex + 1} من ${formation.size}", "Position ${slotIndex + 1} of ${formation.size}"), color = Cream, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = { (slotIndex.toFloat() / formation.size).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor
                )
                if (slot != null && challenge != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(17.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(if (english) slot.titleEn else slot.titleAr, color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(localizedText(english, "الشرط: لاعب ${challenge.positionAr} من ${challenge.nationalityAr}", "Requirement: ${challenge.positionEn} from ${challenge.nationalityEn}"), color = Cream, fontWeight = FontWeight.Bold)
                            Text(localizedText(english, "الـAI بيختار في نفس الوقت، واختياره مش هيظهر غير في النتيجة.", "The AI is choosing at the same time. Its pick stays hidden until the results."), color = Muted, fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(localizedText(english, "ابحث عن لاعب مطابق", "Search for an eligible player")) },
                        placeholder = { Text(localizedText(english, "اكتب 3 حروف على الأقل", "Type at least 3 characters")) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Cream,
                            unfocusedTextColor = Cream,
                            focusedBorderColor = Gold,
                            unfocusedBorderColor = Muted,
                            focusedLabelColor = Gold,
                            unfocusedLabelColor = Muted,
                            cursorColor = Gold
                        )
                    )
                    if (!suggestionsEnabled) {
                        Text(localizedText(english, "اقتراحات الأسماء متوقفة من الإعدادات.", "Player suggestions are turned off in setup."), color = Muted, fontSize = 12.sp)
                    } else if (PlayerSearch.normalize(searchText).length < 3) {
                        Text(localizedText(english, "اكتب 3 حروف عشان تظهر اقتراحات من قاعدة اللاعبين فقط.", "Enter 3 characters to see suggestions from the player database."), color = Muted, fontSize = 12.sp)
                    } else if (suggestions.isEmpty()) {
                        Text(localizedText(english, "مفيش لاعب مطابق للبحث والشرط الحالي.", "No player matches the search and current requirement."), color = Muted, fontSize = 12.sp)
                    }
                    suggestions.forEach { player ->
                        PremiumPlayerChoiceCard(player = player, english = english) { choosePlayer(player) }
                    }
                }
                SquadFormationPitch(
                    title = localizedText(english, "تشكيلتك على الملعب", "Your squad on the pitch"),
                    players = playerTeam.toList(),
                    slotCount = teamSize,
                    detailFor = { "${it.rating} OVR" }
                )
                Text(localizedText(english, "تقدم المراكز", "POSITION PROGRESS"), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                PositionStepStrip(formation.map { it.code }, slotIndex)
            }

            BuildPhase.Result -> {
                Text(localizedText(english, "🏆 نتيجة التحدي", "🏆 Challenge results"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                        Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(localizedText(english, "فريقك", "Your team"), color = Cream)
                            Text("$userPoints", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "نقطة مركز", "position points"), color = Muted, fontSize = 10.sp)
                        }
                    }
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                        Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("AI", color = Cream)
                            Text("$aiPoints", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "نقطة مركز", "position points"), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                Text(
                    when {
                        userPoints > aiPoints -> localizedText(english, "👑 كسبت التحدي!", "👑 You won the challenge!")
                        userPoints < aiPoints -> localizedText(english, "الـAI كسب التحدي المرة دي.", "The AI won this challenge.")
                        else -> localizedText(english, "تعادل! الفريقان متساويان في النقاط.", "Draw! Both teams earned the same points.")
                    }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp
                )
                Text(localizedText(english, "التحكيم: كل مركز يُقارن بشكل منفصل، والأعلى في تقييم ELBASHA يحصل على نقطة.", "Judging: each position is compared separately; the higher ELBASHA rating earns one point."), color = Muted, fontSize = 12.sp)
                SquadFormationPitch(localizedText(english, "تشكيلتك النهائية", "Your final squad"), playerTeam.toList(), teamSize)
                SquadFormationPitch(localizedText(english, "تشكيلة الذكاء الاصطناعي", "AI final squad"), aiTeam.toList(), teamSize)
                Text(saveStatus.ifBlank { localizedText(english, "جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                formation.forEachIndexed { index, slot ->
                    val mine = playerTeam.getOrNull(index)
                    val rival = aiTeam.getOrNull(index)
                    val winner = when {
                        mine == null -> localizedText(english, "لم يتم اختيار لاعب", "No player selected")
                        rival == null -> localizedText(english, "لا يوجد خصم متاح", "No AI player available")
                        mine.rating > rival.rating -> localizedText(english, "نقطتك ✅", "Your point ✅")
                        mine.rating < rival.rating -> localizedText(english, "نقطة AI", "AI point")
                        else -> localizedText(english, "تعادل", "Tie")
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(if (english) slot.titleEn else slot.titleAr, color = Gold, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    mine?.let { PlayerPortrait(it, Modifier.fillMaxWidth().height(82.dp), cornerRadius = 10) }
                                    Text(
                                        "${localizedText(english, "فريقك:", "You:")} ${mine?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) } ?: "-"}  •  ${mine?.rating ?: 0}",
                                        color = Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    rival?.let { PlayerPortrait(it, Modifier.fillMaxWidth().height(82.dp), cornerRadius = 10) }
                                    Text(
                                        "${localizedText(english, "AI:", "AI:")} ${rival?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) } ?: "-"}  •  ${rival?.rating ?: 0}",
                                        color = Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(winner, color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Text(localizedText(english, "إجمالي تقييم فريقك: $totalUserRating", "Your squad rating total: $totalUserRating"), color = Cream)
                Text(localizedText(english, "إجمالي تقييم AI: $totalAiRating", "AI squad rating total: $totalAiRating"), color = Muted)
                Button(
                    onClick = { phase = BuildPhase.Setup; searchText = ""; playerTeam.clear(); aiTeam.clear(); currentChallenge = null },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "ابدأ تحديًا جديدًا", "Start a new challenge")) }
            }
        }
    }
}
