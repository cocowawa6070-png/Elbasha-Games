package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase

private const val SQUAD_BUDGET = 56

private data class DraftPlayer(
    val nameAr: String,
    val nameEn: String,
    val positionAr: String,
    val positionEn: String,
    val rating: Int,
    val price: Int,
    val noteAr: String,
    val noteEn: String
)

private data class DraftSlot(val titleAr: String, val titleEn: String, val players: List<DraftPlayer>)

private val DraftSlots = listOf(
    DraftSlot("حارس المرمى", "Goalkeeper", listOf(
        DraftPlayer("مانويل نوير", "Manuel Neuer", "حارس", "GK", 90, 12, "حارس شامل ورد فعل سريع", "Complete keeper with elite reflexes"),
        DraftPlayer("إيكر كاسياس", "Iker Casillas", "حارس", "GK", 85, 10, "قائد وخبرة كبيرة", "Leadership and big-game experience"),
        DraftPlayer("عصام الحضري", "Essam El-Hadary", "حارس", "GK", 78, 8, "أسطورة الحراسة المصرية", "Egyptian goalkeeping legend")
    )),
    DraftSlot("الدفاع", "Defender", listOf(
        DraftPlayer("سيرخيو راموس", "Sergio Ramos", "مدافع", "DF", 90, 12, "قوة وشخصية في المباريات الكبيرة", "Power and big-game personality"),
        DraftPlayer("فيرجيل فان دايك", "Virgil van Dijk", "مدافع", "DF", 88, 10, "قوة بدنية وقراءة ممتازة", "Physical presence and strong reading"),
        DraftPlayer("أحمد حجازي", "Ahmed Hegazi", "مدافع", "DF", 78, 8, "قلب دفاع مصري", "Egyptian centre-back")
    )),
    DraftSlot("خط الوسط", "Midfielder", listOf(
        DraftPlayer("زين الدين زيدان", "Zinedine Zidane", "وسط", "MF", 93, 12, "مهارة وتحكم وإبداع", "Technique, control and creativity"),
        DraftPlayer("أندريس إنييستا", "Andrés Iniesta", "وسط", "MF", 91, 10, "تمريرات ولمسة ساحرة", "Passing and magical touch"),
        DraftPlayer("محمد أبو تريكة", "Mohamed Aboutrika", "وسط", "MF", 84, 8, "صانع لعب وأسطورة أفريقية", "Playmaker and African legend")
    )),
    DraftSlot("الجناح", "Winger", listOf(
        DraftPlayer("محمد صلاح", "Mohamed Salah", "جناح", "WG", 92, 12, "سرعة وإنهاء بالقدم اليسرى", "Pace and left-foot finishing"),
        DraftPlayer("نيمار", "Neymar", "جناح", "WG", 90, 10, "مراوغة وصناعة فرص", "Dribbling and chance creation"),
        DraftPlayer("رياض محرز", "Riyad Mahrez", "جناح", "WG", 85, 8, "مهارة ولمسة باليسرى", "Skill and a refined left foot")
    )),
    DraftSlot("رأس الحربة", "Striker", listOf(
        DraftPlayer("كريستيانو رونالدو", "Cristiano Ronaldo", "مهاجم", "ST", 94, 12, "إنهاء وضربات رأس", "Finishing and aerial threat"),
        DraftPlayer("ديدييه دروجبا", "Didier Drogba", "مهاجم", "ST", 90, 10, "قوة وحسم في النهائيات", "Power and decisive finals"),
        DraftPlayer("صامويل إيتو", "Samuel Eto'o", "مهاجم", "ST", 88, 8, "سرعة وتحركات ذكية", "Pace and intelligent movement")
    ))
)

@Composable
fun BuildTeamScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val selectedPlayers = remember { mutableStateListOf<DraftPlayer>() }
    var slotIndex by remember { mutableIntStateOf(0) }
    var remainingBudget by remember { mutableIntStateOf(SQUAD_BUDGET) }
    var completed by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    val totalRating = selectedPlayers.sumOf { it.rating }
    val score = (totalRating * 10 + remainingBudget * 5).coerceAtLeast(0)

    BackHandler { onExit() }

    DisposableEffect(Unit) {
        sound.playMusic(Track.Tournament)
        onDispose { sound.playMusic(Track.Menu) }
    }

    LaunchedEffect(completed) {
        if (completed) {
            ScoreRepository.submit(database, user, score) { saved ->
                saveStatus = if (saved) {
                    if (english) "Squad score saved ✅" else "اتسجلت نقاط التشكيلة ✅"
                } else {
                    if (english) "Could not save your score. Check Firebase." else "تعذر حفظ النقاط. راجع Firebase."
                }
            }
        }
    }

    if (completed) {
        Column(
            Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(uiText("👑 تشكيلتك الخماسية", "👑 Your Dream Five"), color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Text("$totalRating / 500", color = Gold, fontSize = 45.sp, fontWeight = FontWeight.Black)
            Text(uiText("إجمالي تقييم الفريق الخماسي", "Combined five-player rating"), color = Muted)
            Spacer(Modifier.height(14.dp))
            selectedPlayers.forEach { player ->
                Text("${if (english) player.nameEn else player.nameAr}  •  ${player.rating}", color = Cream)
            }
            Spacer(Modifier.height(12.dp))
            Text(uiText("الميزانية المتبقية: $remainingBudget", "Budget left: $remainingBudget"), color = Gold)
            Text(uiText("مكافأة التحدي: $score نقطة", "Challenge reward: $score points"), color = Cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(
                onClick = {
                    selectedPlayers.clear()
                    slotIndex = 0
                    remainingBudget = SQUAD_BUDGET
                    completed = false
                    saveStatus = ""
                },
                modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
            ) { Text(uiText("ابنِ تشكيلة جديدة", "Build another squad")) }
            TextButton(onClick = onExit) { Text(uiText("الرجوع للألعاب", "Back to games"), color = Gold) }
        }
        return
    }

    val slot = DraftSlots[slotIndex]
    Column(
        Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(uiText("🧩 ابنِ فريقك الخماسي", "🧩 Build Your 5-a-side Team"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(uiText("اختار لاعبًا لكل مركز في فريق خماسي. معاك 56 نقطة، والتقييمات افتراضية للعبة.", "Pick one player for each position in a five-a-side team. You have 56 credits. Ratings are fictional game ratings."), color = Muted, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(uiText("المركز ${slotIndex + 1} من ${DraftSlots.size}: ${slot.titleAr}", "Position ${slotIndex + 1} of ${DraftSlots.size}: ${slot.titleEn}"), color = Cream, fontWeight = FontWeight.Bold)
            Text("💰 $remainingBudget", color = Gold, fontWeight = FontWeight.Black)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            DraftSlots.forEachIndexed { index, item ->
                Box(
                    Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (index <= slotIndex) Gold else PanelColor)
                )
            }
        }
        selectedPlayers.forEachIndexed { index, player ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelColor).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${index + 1}.", color = Gold, fontWeight = FontWeight.Black)
                Text(" ${if (english) player.nameEn else player.nameAr}", color = Cream, modifier = Modifier.weight(1f))
                Text("${player.rating} OVR", color = Gold, fontWeight = FontWeight.Bold)
            }
        }
        slot.players.forEach { player ->
            val affordable = player.price <= remainingBudget
            Card(
                modifier = Modifier.fillMaxWidth().clickable(enabled = affordable) {
                    selectedPlayers.add(player)
                    remainingBudget -= player.price
                    sound.play(Sfx.Click)
                    sound.vibrate(18)
                    if (slotIndex == DraftSlots.lastIndex) completed = true else slotIndex++
                },
                colors = CardDefaults.cardColors(containerColor = if (affordable) PanelColor else LocalElbashaPalette.current.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(if (english) player.nameEn else player.nameAr, color = if (affordable) Cream else Muted, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(if (english) player.noteEn else player.noteAr, color = Muted, fontSize = 11.sp)
                        Text("${player.rating} OVR", color = Gold, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${player.price}", color = if (affordable) Gold else Muted, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(uiText("تكلفة", "credits"), color = Muted, fontSize = 10.sp)
                        if (!affordable) Text(uiText("مش كفاية", "Too costly"), color = LocalElbashaPalette.current.bad, fontSize = 10.sp)
                    }
                }
            }
        }
        Text(uiText("فكّر قبل ما تصرف الميزانية. مش لازم تختار أعلى تقييم في كل مركز.", "Spend carefully. You cannot afford the highest-rated player in every position."), color = Muted, fontSize = 11.sp)
    }
}
