package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.key
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random
import kotlinx.coroutines.delay

/**
 * Deal or No Deal rebuilt around private cases. One player owns four cases for every slot;
 * opponents never open, choose, or receive any of that player's case contents.
 */
@Composable
fun DealOrNoDealScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current

    var passAndPlay by remember { mutableStateOf(false) }
    var localPlayerCount by remember { mutableIntStateOf(2) }
    var localNames by remember { mutableStateOf(listOf("", "", "", "")) }
    var targetCount by remember { mutableIntStateOf(6) }
    var turnTimeSeconds by remember { mutableIntStateOf(30) }
    var cardsPerPlayer by remember { mutableIntStateOf(2) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var customPlayerFilter by remember { mutableStateOf(false) }
    var selectedPlayerNames by remember { mutableStateOf(emptySet<String>()) }
    var showPlayerFilterDialog by remember { mutableStateOf(false) }
    var draftPlayerNames by remember { mutableStateOf(emptySet<String>()) }
    var playerFilterSearch by remember { mutableStateOf("") }
    var setupMessage by remember { mutableStateOf("") }

    var phase by remember { mutableStateOf("setup") }
    var countdownNumber by remember { mutableIntStateOf(3) }
    var turnSecondsLeft by remember { mutableIntStateOf(30) }
    var cardsSecondsLeft by remember { mutableIntStateOf(DealRules.FINAL_CARD_WINDOW_SECONDS) }
    var roundIndex by remember { mutableIntStateOf(0) }
    var currentActor by remember { mutableIntStateOf(0) }
    var activeCardActor by remember { mutableIntStateOf(0) }

    var participantNames by remember { mutableStateOf(listOf(if (english) "You" else "أنت", "AI")) }
    var squads by remember { mutableStateOf(listOf(emptyList<PlayerCard>(), emptyList())) }
    var seenByParticipant by remember { mutableStateOf(listOf(emptySet<String>(), emptySet())) }
    var privateCases by remember { mutableStateOf(listOf(emptyList<PlayerCard>(), emptyList())) }
    var firstCaseIndex by remember { mutableIntStateOf(-1) }
    var firstReveal by remember { mutableStateOf<PlayerCard?>(null) }
    var rejectedCaseIndex by remember { mutableIntStateOf(-1) }
    var rejectedPlayer by remember { mutableStateOf<PlayerCard?>(null) }
    var aiSelectedRiskIndex by remember { mutableIntStateOf(-1) }
    var remainingCaseReveals by remember { mutableStateOf<List<Pair<Int, PlayerCard>>>(emptyList()) }
    var remainingCaseRevealCount by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }

    var coaches by remember { mutableStateOf<List<CoachCard?>>(emptyList()) }
    var cardHands by remember { mutableStateOf<List<List<DealFinalCard>>>(emptyList()) }
    var protectedNames by remember { mutableStateOf(emptySet<String>()) }
    var selectedCardIndex by remember { mutableIntStateOf(-1) }
    var selectedStealTeam by remember { mutableIntStateOf(1) }
    var matchResults by remember { mutableStateOf(emptyList<Pair<Int, MatchScore>>()) }
    var liveMatchDone by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var scoreSubmitted by remember { mutableStateOf(false) }

    val slots = remember(targetCount) { ElbashaPositions.formationSlots(targetCount) }
    val participantCount = if (passAndPlay) localPlayerCount else 2
    val currentSlot = slots.getOrNull(roundIndex) ?: "ST"
    val currentPositionLabel = BuildTeamRules.positionLabels[currentSlot]?.let { if (english) it.second else it.first } ?: currentSlot
    val playerPool = if (customPlayerFilter) PlayerDatabase.players.filter { it.nameEn in selectedPlayerNames } else PlayerDatabase.players
    val isHumanTurn = passAndPlay || currentActor == 0
    val currentHand = cardHands.getOrNull(activeCardActor).orEmpty()
    val selectedCard = currentHand.getOrNull(selectedCardIndex)
    val allCardsEmpty = cardHands.isNotEmpty() && cardHands.all { it.isEmpty() }

    fun displayName(player: PlayerCard): String =
        if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr)

    fun safeTeamName(index: Int): String = participantNames.getOrNull(index) ?: "Player ${index + 1}"

    fun createCaseSets(
        slot: String,
        squadsNow: List<List<PlayerCard>>,
        seenNow: List<Set<String>>
    ): List<List<PlayerCard>> = DealRules.createPrivateCaseSets(
        players = playerPool,
        slot = slot,
        participantSeenNames = seenNow,
        draftedNames = squadsNow.flatten().map { it.nameEn }.toSet(),
        random = Random.Default
    )

    fun resetTurnReveal() {
        firstCaseIndex = -1
        firstReveal = null
        rejectedCaseIndex = -1
        rejectedPlayer = null
        aiSelectedRiskIndex = -1
        remainingCaseReveals = emptyList()
        remainingCaseRevealCount = 0
    }

    fun beginCardsPhase() {
        cardHands = List(participantCount) { DealRules.createFinalCardHand(cardsPerPlayer) }
        protectedNames = emptySet()
        activeCardActor = 0
        selectedCardIndex = -1
        selectedStealTeam = if (participantCount > 1) 1 else 0
        cardsSecondsLeft = DealRules.FINAL_CARD_WINDOW_SECONDS
        phase = "cards"
        status = localizedText(
            english,
            "بدأت مرحلة الكروت النهائية: معاكم 60 ثانية فقط.",
            "Final card phase started: you have 60 seconds."
        )
    }

    fun advanceAfterPick() {
        resetTurnReveal()
        remainingCaseReveals = emptyList()
        remainingCaseRevealCount = 0
        aiSelectedRiskIndex = -1
        if (currentActor + 1 < participantCount) {
            currentActor += 1
            phase = "draft"
            return
        }
        val nextRound = roundIndex + 1
        if (nextRound >= slots.size) {
            // Coaches are assigned only after every participant has completed every slot.
            coaches = CoachDatabase.all.shuffled().take(participantCount).map { it }
            cardHands = emptyList()
            phase = "coachReveal"
        } else {
            roundIndex = nextRound
            currentActor = 0
            privateCases = createCaseSets(slots[nextRound], squads, seenByParticipant)
            status = localizedText(
                english,
                "المركز التالي: ${BuildTeamRules.positionLabels[slots[nextRound]]?.first ?: slots[nextRound]}. لكل لاعب صناديقه الخاصة.",
                "Next slot: ${BuildTeamRules.positionLabels[slots[nextRound]]?.second ?: slots[nextRound]}. Every participant gets a private case set."
            )
            phase = "draft"
        }
    }

    fun acceptPlayer(player: PlayerCard, rejected: PlayerCard? = null, acceptedCaseIndex: Int = firstCaseIndex) {
        val cases = privateCases.getOrNull(currentActor).orEmpty()
        val updatedTeams = squads.toMutableList()
        updatedTeams[currentActor] = updatedTeams[currentActor] + player
        squads = updatedTeams
        val updatedSeen = seenByParticipant.toMutableList()
        updatedSeen[currentActor] = updatedSeen[currentActor] + player.nameEn + listOfNotNull(rejected?.nameEn)
        seenByParticipant = updatedSeen

        // Reveal every unopened case after the decision so the player sees what they missed.
        // With Deal, three cases remain. With No Deal, the rejected and accepted cases are
        // already known, so the final two unopened cases are revealed in sequence.
        remainingCaseReveals = DealRules.unopenedCasesAfterDecision(
            cases = cases,
            acceptedIndex = acceptedCaseIndex,
            rejectedIndex = rejectedCaseIndex
        )
        remainingCaseRevealCount = 0
        aiSelectedRiskIndex = -1
        status = if (rejected == null) {
            localizedText(english, "تم قبول ${displayName(player)} وانضم للتشكيلة. استعد تشوف اللاعبين اللي سبتهم في الصناديق الباقية.", "${player.nameEn} accepted and added. Now reveal the players left in the other cases.")
        } else {
            localizedText(
                english,
                "رفضت ${displayName(rejected)} نهائيًا، والصندوق البديل أضاف ${displayName(player)} لتشكيلتك. باقي الصناديق هتتكشف دلوقتي.",
                "${rejected.nameEn} was permanently rejected; ${player.nameEn} joined from the replacement case. The other cases will now be revealed."
            )
        }
        sound.play(if (rejected == null) Sfx.Deal else Sfx.Unlock)
        phase = "acceptedReveal"
    }

    fun openFirstCase(index: Int) {
        val cases = privateCases.getOrNull(currentActor).orEmpty()
        if (phase != "draft" || !isHumanTurn || index !in cases.indices) return
        firstCaseIndex = index
        firstReveal = cases[index]
        rejectedCaseIndex = -1
        rejectedPlayer = null
        phase = "reveal"
        sound.play(Sfx.CaseOpen)
    }

    fun acceptDeal() {
        val cases = privateCases.getOrNull(currentActor).orEmpty()
        val result = DealRules.acceptDeal(cases, firstCaseIndex) ?: return
        acceptPlayer(result.accepted, acceptedCaseIndex = result.openedIndex)
    }

    fun chooseRiskCase(index: Int) {
        val cases = privateCases.getOrNull(currentActor).orEmpty()
        if (phase !in setOf("riskPick", "aiRiskPick") || index !in cases.indices || index == rejectedCaseIndex) return
        val result = DealRules.acceptRisk(cases, rejectedCaseIndex, index) ?: return
        acceptPlayer(result.accepted, result.rejected, result.openedIndex)
    }

    fun poolValidationMessage(): String? {
        slots.forEachIndexed { index, slot ->
            val role = ElbashaPositions.poolRole(slot)
            val required = DealRules.minimumCandidatesRequired(slots, index, participantCount) ?: return null
            val available = playerPool.count { ElbashaPositions.poolRole(it.position) == role }
            if (available < required) {
                val roleLabel = BuildTeamRules.positionLabels[slot]?.let { if (english) it.second else it.first } ?: role
                return localizedText(
                    english,
                    "فلتر اللاعبين ناقص في مركز $roleLabel: محتاج $required لاعبًا على الأقل، والمتاح $available.",
                    "The player filter is too small for $roleLabel: need at least $required players, but only $available are selected."
                )
            }
        }
        return null
    }

    fun startNewMatch() {
        val filterError = poolValidationMessage()
        if (filterError != null) {
            setupMessage = filterError
            return
        }
        setupMessage = ""
        participantNames = if (passAndPlay) {
            PassAndPlayRules.normalizeNames(localNames.take(localPlayerCount), localPlayerCount) {
                if (english) "Player $it" else "لاعب $it"
            }
        } else listOf(if (english) "You" else "أنت", if (english) "AI Rival" else "الصاروخ")
        squads = List(participantCount) { emptyList() }
        seenByParticipant = List(participantCount) { emptySet() }
        roundIndex = 0
        currentActor = 0
        resetTurnReveal()
        privateCases = createCaseSets(slots.first(), squads, seenByParticipant)
        coaches = emptyList()
        cardHands = emptyList()
        protectedNames = emptySet()
        matchResults = emptyList()
        liveMatchDone = false
        saveStatus = ""
        scoreSubmitted = false
        status = ""
        turnSecondsLeft = turnTimeSeconds
        countdownNumber = 3
        phase = "countdown"
    }

    fun endCardTurn() {
        selectedCardIndex = -1
        val nextOpponent = (1 until participantCount)
            .asSequence()
            .map { (activeCardActor + it) % participantCount }
            .firstOrNull { cardHands.getOrNull(it).orEmpty().isNotEmpty() }
        val next = nextOpponent ?: activeCardActor.takeIf { cardHands.getOrNull(it).orEmpty().isNotEmpty() }
        if (next == null) phase = "finished" else activeCardActor = next
    }

    fun consumeCardAndAdvance(actionStatus: String) {
        val hand = cardHands.getOrNull(activeCardActor).orEmpty()
        if (selectedCardIndex !in hand.indices) return
        val updatedHands = cardHands.toMutableList()
        updatedHands[activeCardActor] = hand.toMutableList().also { it.removeAt(selectedCardIndex) }
        cardHands = updatedHands
        status = actionStatus
        sound.play(Sfx.Correct)
        endCardTurn()
    }

    fun useSteal(targetTeamIndex: Int, target: PlayerCard) {
        val updated = DealRules.stealPlayer(
            teams = squads,
            stealingTeam = activeCardActor,
            targetTeam = targetTeamIndex,
            targetName = target.nameEn,
            protectedNames = protectedNames
        ) ?: return
        squads = updated
        consumeCardAndAdvance(
            localizedText(
                english,
                "${safeTeamName(activeCardActor)} سرق ${displayName(target)} من ${safeTeamName(targetTeamIndex)}.",
                "${safeTeamName(activeCardActor)} stole ${target.nameEn} from ${safeTeamName(targetTeamIndex)}."
            )
        )
    }

    fun useShield(target: PlayerCard) {
        val updated = DealRules.protectPlayer(squads[activeCardActor], protectedNames, target.nameEn) ?: return
        protectedNames = updated
        consumeCardAndAdvance(
            localizedText(english, "تمت حماية ${displayName(target)}.", "${target.nameEn} is now protected.")
        )
    }

    fun performAiCard() {
        val hand = cardHands.getOrNull(activeCardActor).orEmpty()
        if (hand.isEmpty()) {
            endCardTurn()
            return
        }
        val actor = activeCardActor
        val stealCardIndex = hand.indexOfFirst { it.type == DealFinalCardType.STEAL }
        val stealTargets = squads.indices.filter { it != actor }.flatMap { teamIndex ->
            squads[teamIndex].filter { DealRules.canSteal(it, protectedNames) }.map { teamIndex to it }
        }
        var actionText = ""
        var consumedIndex = -1
        if (stealCardIndex >= 0 && stealTargets.isNotEmpty()) {
            val target = stealTargets.minByOrNull { it.second.rating }!!
            val updated = DealRules.stealPlayer(squads, actor, target.first, target.second.nameEn, protectedNames)
            if (updated != null) {
                squads = updated
                actionText = localizedText(english, "الصاروخ سرق لاعبًا من ${safeTeamName(target.first)}.", "The AI stole a player from ${safeTeamName(target.first)}.")
                consumedIndex = stealCardIndex
            }
        } else {
            val shieldIndex = hand.indexOfFirst { it.type == DealFinalCardType.SHIELD }
            val target = squads[actor].filterNot { it.nameEn in protectedNames }.maxByOrNull { it.rating }
            if (shieldIndex >= 0 && target != null) {
                protectedNames = DealRules.protectPlayer(squads[actor], protectedNames, target.nameEn) ?: protectedNames
                actionText = localizedText(english, "الصاروخ فعّل الحماية على لاعب من تشكيلته.", "The AI protected one of its players.")
                consumedIndex = shieldIndex
            }
        }
        if (actionText.isBlank()) actionText = localizedText(english, "الصاروخ لم يجد كارتًا صالحًا للاستخدام.", "The AI had no valid card target.")
        val updatedHands = cardHands.toMutableList()
        // The AI spends a useful card first; if no target exists it discards its first card.
        if (consumedIndex < 0) consumedIndex = 0
        updatedHands[actor] = hand.toMutableList().also { it.removeAt(consumedIndex.coerceIn(it.indices)) }
        cardHands = updatedHands
        status = actionText
        endCardTurn()
    }

    // Make the AI's private decision visible: show its opening case, its Deal/No Deal choice,
    // and (when it risks) the second case it selects from its own three remaining cases.
    LaunchedEffect(phase, currentActor, roundIndex, privateCases) {
        if (phase == "draft" && !passAndPlay && currentActor == 1) {
            delay(850)
            if (phase != "draft" || currentActor != 1) return@LaunchedEffect
            val aiCases = privateCases.getOrNull(1).orEmpty()
            val firstIndex = DealRules.chooseAiOpeningIndex(aiCases, aiDifficulty) ?: return@LaunchedEffect
            firstCaseIndex = firstIndex
            firstReveal = aiCases[firstIndex]
            rejectedCaseIndex = -1
            rejectedPlayer = null
            status = localizedText(english, "الصاروخ اختار الصندوق رقم ${firstIndex + 1}...", "AI selected case ${firstIndex + 1}...")
            phase = "aiReveal"
            sound.play(Sfx.CaseOpen)
        }
    }

    LaunchedEffect(phase, currentActor, privateCases, aiDifficulty) {
        if (phase == "aiReveal" && currentActor == 1) {
            delay(1_250)
            if (phase != "aiReveal" || currentActor != 1) return@LaunchedEffect
            val aiCases = privateCases.getOrNull(1).orEmpty()
            val opened = aiCases.getOrNull(firstCaseIndex) ?: return@LaunchedEffect
            if (DealRules.aiShouldRisk(opened, aiCases, aiDifficulty)) {
                rejectedCaseIndex = firstCaseIndex
                rejectedPlayer = opened
                val updatedSeen = seenByParticipant.toMutableList()
                updatedSeen[1] = updatedSeen[1] + opened.nameEn
                seenByParticipant = updatedSeen
                aiSelectedRiskIndex = DealRules.chooseAiRiskIndex(aiCases, firstCaseIndex, aiDifficulty) ?: firstCaseIndex
                status = localizedText(english, "الصاروخ رفض اللاعب الأول وبيفاضل بين الصناديق الثلاثة الباقية.", "AI rejected the first player and is choosing from its three remaining cases.")
                phase = "aiRiskPick"
            } else {
                acceptPlayer(opened, acceptedCaseIndex = firstCaseIndex)
            }
        }
    }

    LaunchedEffect(phase, currentActor, aiSelectedRiskIndex) {
        if (phase == "aiRiskPick" && currentActor == 1) {
            delay(1_350)
            if (phase == "aiRiskPick" && currentActor == 1 && aiSelectedRiskIndex >= 0) {
                sound.play(Sfx.Tick)
                chooseRiskCase(aiSelectedRiskIndex)
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == "countdown") {
            for (number in 3 downTo 1) {
                countdownNumber = number
                delay(850)
                if (phase != "countdown") return@LaunchedEffect
            }
            phase = "draft"
        }
    }

    // One timer per human decision. Expiry never transfers an opened/rejected case to a rival.
    LaunchedEffect(phase, currentActor, roundIndex, turnTimeSeconds) {
        if ((phase == "draft" || phase == "decision" || phase == "riskPick") && isHumanTurn) {
            val timedPhase = phase
            val timedActor = currentActor
            val timedRound = roundIndex
            for (remaining in turnTimeSeconds downTo 1) {
                turnSecondsLeft = remaining
                delay(1_000)
                if (phase != timedPhase || currentActor != timedActor || roundIndex != timedRound) return@LaunchedEffect
            }
            if (phase == timedPhase && currentActor == timedActor && roundIndex == timedRound) {
                when (timedPhase) {
                    "draft" -> openFirstCase(privateCases[currentActor].indices.random())
                    "decision" -> acceptDeal()
                    "riskPick" -> {
                        val available = privateCases[currentActor].indices.filter { it != rejectedCaseIndex }
                        available.randomOrNull()?.let { chooseRiskCase(it) }
                    }
                }
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == "reveal") {
            delay(900)
            if (phase == "reveal") phase = "decision"
        } else if (phase == "acceptedReveal") {
            delay(950)
            if (phase == "acceptedReveal") {
                if (remainingCaseReveals.isNotEmpty()) {
                    remainingCaseRevealCount = 0
                    phase = "caseRegretReveal"
                } else advanceAfterPick()
            }
        } else if (phase == "caseRegretReveal") {
            // Each missed player gets enough time to flip over and be read. The screen then waits
            // for the player to tap "Continue" instead of vanishing on its own.
            for (count in 1..remainingCaseReveals.size) {
                delay(if (count == 1) 700 else 2_400)
                if (phase != "caseRegretReveal") return@LaunchedEffect
                remainingCaseRevealCount = count
                sound.play(Sfx.CaseOpen)
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == "cards") {
            for (remaining in DealRules.FINAL_CARD_WINDOW_SECONDS downTo 1) {
                cardsSecondsLeft = remaining
                delay(1_000)
                if (phase != "cards") return@LaunchedEffect
            }
            if (phase == "cards") phase = "finished"
        }
    }

    LaunchedEffect(phase, activeCardActor, cardHands) {
        if (phase == "cards") {
            if (allCardsEmpty) {
                phase = "finished"
            } else if (!passAndPlay && activeCardActor == 1) {
                delay(750)
                if (phase == "cards" && activeCardActor == 1) performAiCard()
            } else if (cardHands.getOrNull(activeCardActor).orEmpty().isEmpty()) {
                endCardTurn()
            }
        }
    }

    LaunchedEffect(phase, scoreSubmitted) {
        if (phase == "finished") {
            val resultsForMatch = if (matchResults.isEmpty()) {
                (1 until participantCount).map { opponentIndex ->
                    opponentIndex to MatchEngine.simulate(
                        userTeam = squads[0],
                        opponentTeam = squads[opponentIndex],
                        userCoachBonus = coaches.getOrNull(0)?.matchBonus ?: 0.0,
                        opponentCoachBonus = coaches.getOrNull(opponentIndex)?.matchBonus ?: 0.0,
                        targetSquadSize = targetCount
                    )
                }.also { calculated ->
                    matchResults = calculated
                }
            } else matchResults
            if (!passAndPlay && !scoreSubmitted) {
                scoreSubmitted = true
                val result = resultsForMatch.firstOrNull()?.second
                val totalRating = squads.firstOrNull().orEmpty().sumOf { it.rating }
                val bonus = when {
                    result?.userWon == true -> 1_000
                    result?.isDraw == true -> 500
                    else -> 0
                }
                ScoreRepository.submit(database, user, totalRating * 10 + bonus) { saved ->
                    saveStatus = if (saved) localizedText(english, "تم حفظ نقاط اللعبة", "Game score saved")
                    else localizedText(english, "تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                }
            } else if (passAndPlay) {
                saveStatus = localizedText(english, "مباراة جهاز واحد: النتيجة محلية وغير مضافة للترتيب.", "Pass-and-play result is local and is not added to the leaderboard.")
            }
        }
    }

    BackHandler { onExit() }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = palette.gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text("DEAL OR NO DEAL", color = palette.gold, fontSize = 23.sp, fontWeight = FontWeight.Black)

        if (phase == "setup") {
            Text(
                localizedText(english, "كل لاعب عنده أربع صناديق خاصة به في كل مركز. مفيش صناديق مشتركة.", "Each participant has four private cases for every position. Cases are never shared."),
                color = palette.cream, fontSize = 13.sp, lineHeight = 19.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { local ->
                    val selected = passAndPlay == local
                    Card(
                        Modifier.weight(1f).clickable { passAndPlay = local },
                        colors = CardDefaults.cardColors(containerColor = if (selected) palette.gold else palette.panel),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (local) localizedText(english, "جهاز واحد", "PASS & PLAY") else localizedText(english, "ضد الصاروخ", "VS AI"), color = if (selected) palette.deepWine else palette.cream, fontWeight = FontWeight.Black)
                            Text(if (local) localizedText(english, "من 2 إلى 4 لاعبين", "2–4 participants") else localizedText(english, "لاعب ضد AI", "One player vs AI"), color = if (selected) palette.deepWine else palette.muted, fontSize = 10.sp)
                        }
                    }
                }
            }
            if (passAndPlay) {
                Text(localizedText(english, "عدد المشاركين", "Number of participants"), color = palette.cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (2..4).forEach { count ->
                        ChoicePill(text = count.toString(), selected = count == localPlayerCount, onClick = { localPlayerCount = count })
                    }
                }
                repeat(localPlayerCount) { index ->
                    OutlinedTextField(
                        value = localNames[index],
                        onValueChange = { value -> localNames = localNames.toMutableList().also { it[index] = value.take(20) } },
                        label = { Text(localizedText(english, "اسم اللاعب ${index + 1}", "Player ${index + 1} name")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Text(localizedText(english, "عدد لاعبي التشكيلة", "Squad size"), color = palette.cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                (6..11).forEach { count -> ChoicePill(count.toString(), count == targetCount) { targetCount = count } }
            }
            TurnTimeSelector(turnTimeSeconds, onSelect = { turnTimeSeconds = it })
            Text(localizedText(english, "عدد الكروت لكل لاعب", "Cards per participant"), color = palette.cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..5).forEach { count -> ChoicePill(count.toString(), count == cardsPerPlayer) { cardsPerPlayer = count } }
            }
            Text(localizedText(english, "فلتر اللاعبين", "PLAYER FILTER"), color = palette.cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoicePill(
                    text = localizedText(english, "كل اللاعبين", "ALL PLAYERS"),
                    selected = !customPlayerFilter,
                    onClick = { customPlayerFilter = false; selectedPlayerNames = emptySet(); setupMessage = "" }
                )
                ChoicePill(
                    text = localizedText(english, "تحديد قائمة", "CHOOSE LIST"),
                    selected = customPlayerFilter,
                    onClick = {
                        draftPlayerNames = if (customPlayerFilter) selectedPlayerNames else PlayerDatabase.players.map { it.nameEn }.toSet()
                        playerFilterSearch = ""
                        showPlayerFilterDialog = true
                    }
                )
            }
            if (customPlayerFilter) {
                Text(
                    localizedText(english, "تم تحديد ${selectedPlayerNames.size} لاعبًا", "${selectedPlayerNames.size} players selected"),
                    color = palette.muted,
                    fontSize = 11.sp
                )
            }
            if (setupMessage.isNotBlank()) Text(setupMessage, color = palette.bad, fontSize = 11.sp, lineHeight = 16.sp)
            if (!passAndPlay) {
                Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI difficulty"), color = palette.cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("سهل", "متوازن", "صعب", "صعب جدًا").forEachIndexed { index, label ->
                        ChoicePill(if (english) listOf("Easy", "Balanced", "Hard", "Expert")[index] else label, index == aiDifficulty) { aiDifficulty = index }
                    }
                }
            }
            Button(onClick = { startNewMatch() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                Text(localizedText(english, "ابدأ تكوين الفريق", "Start building squads"), fontWeight = FontWeight.Black)
            }
        } else if (phase == "countdown") {
            CountdownStage(countdownNumber, localizedText(english, "جهّز نفسك لفتح الصناديق", "Get ready to open your cases"))
        } else if (phase == "coachReveal") {
            Text(localizedText(english, "التشكيلات اكتملت. المدربون اتحددوا لكل فريق.", "All squads are complete. Each participant now has a coach."), color = palette.gold, fontWeight = FontWeight.Black)
            coaches.forEachIndexed { index, coach ->
                coach?.let {
                    Card(Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.45f), RoundedCornerShape(17.dp)), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("♛", color = palette.gold, fontSize = 30.sp)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(safeTeamName(index), color = palette.muted, fontSize = 10.sp)
                                Text(if (english) it.nameEn else it.nameAr, color = palette.cream, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                Text("${it.rating} OVR  •  ${if (english) it.styleEn else it.styleAr}", color = palette.gold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            squads.forEachIndexed { index, squad ->
                SquadFormationPitch(
                    title = "${safeTeamName(index)} • ${coaches.getOrNull(index)?.let { if (english) it.nameEn else it.nameAr } ?: ""}",
                    players = squad,
                    slotCount = targetCount,
                    detailFor = { "${it.rating} OVR" }
                )
            }
            Button(onClick = { beginCardsPhase() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                Text(localizedText(english, "ابدأ مرحلة الكروت • 60 ثانية", "Start final card phase • 60 seconds"), fontWeight = FontWeight.Black)
            }
        } else if (phase == "cards") {
            Text(localizedText(english, "مرحلة الكروت النهائية", "FINAL CARD PHASE"), color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(localizedText(english, "اللاعب الحالي: ${safeTeamName(activeCardActor)}", "Current participant: ${safeTeamName(activeCardActor)}"), color = palette.cream, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = if (cardsSecondsLeft <= 10) palette.bad.copy(alpha = 0.18f) else palette.panel)) {
                    Text("${cardsSecondsLeft}s", color = if (cardsSecondsLeft <= 10) palette.bad else palette.gold, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
            squads.forEachIndexed { index, squad ->
                SquadFormationPitch(
                    title = "${safeTeamName(index)} • ${coaches.getOrNull(index)?.let { if (english) it.nameEn else it.nameAr } ?: ""}",
                    players = squad,
                    slotCount = targetCount,
                    detailFor = { player -> if (player.nameEn in protectedNames) "SHIELDED" else "${player.rating} OVR" }
                )
            }
            if (selectedCard == null) {
                Text(localizedText(english, "اختار كارت من إيدك. السرقة تستهدف أي خصم، والحماية تستهدف لاعبًا من تشكيلتك.", "Choose one of your cards. Steal can target any opponent; Shield targets one of your own players."), color = palette.muted, fontSize = 12.sp)
                currentHand.forEachIndexed { index, card ->
                    val isSteal = card.type == DealFinalCardType.STEAL
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedCardIndex = index; selectedStealTeam = squads.indices.firstOrNull { it != activeCardActor } ?: 0 },
                        colors = CardDefaults.cardColors(containerColor = palette.panel),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isSteal) "↗" else "⬡", color = palette.gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(if (isSteal) localizedText(english, "كارت السرقة", "STEAL CARD") else localizedText(english, "كارت الحماية", "SHIELD CARD"), color = palette.cream, fontWeight = FontWeight.Black)
                                Text(if (isSteal) localizedText(english, "اختار خصمًا ثم اللاعب المستهدف", "Choose an opponent, then a player") else localizedText(english, "اختار لاعبًا من تشكيلتك لحمايته", "Choose one of your players to protect"), color = palette.muted, fontSize = 10.sp)
                            }
                            Text("${index + 1}", color = palette.gold, fontWeight = FontWeight.Black)
                        }
                    }
                }
                OutlinedButton(onClick = { endCardTurn() }, modifier = Modifier.fillMaxWidth()) {
                    Text(localizedText(english, "تخطي دوري", "Skip turn"), color = palette.cream)
                }
            } else if (selectedCard.type == DealFinalCardType.STEAL) {
                Text(localizedText(english, "اختار التشكيلة اللي هتسرق منها", "SELECT AN OPPONENT SQUAD"), color = palette.gold, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    squads.indices.filter { it != activeCardActor }.forEach { teamIndex ->
                        ChoicePill(safeTeamName(teamIndex), teamIndex == selectedStealTeam) { selectedStealTeam = teamIndex }
                    }
                }
                val targets = squads.getOrNull(selectedStealTeam).orEmpty().filter { it.nameEn !in protectedNames }
                if (targets.isEmpty()) {
                    Text(localizedText(english, "كل لاعبي التشكيلة دي محميون. اختار خصمًا تانيًا.", "Every player in this squad is protected. Choose another opponent."), color = palette.muted)
                } else {
                    targets.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) { useSteal(selectedStealTeam, player) }
                    }
                }
                OutlinedButton(onClick = { selectedCardIndex = -1 }, modifier = Modifier.fillMaxWidth()) { Text(localizedText(english, "إلغاء", "Cancel"), color = palette.cream) }
            } else {
                Text(localizedText(english, "اختار لاعبًا من تشكيلتك للحماية", "SELECT A PLAYER FROM YOUR SQUAD TO SHIELD"), color = palette.gold, fontWeight = FontWeight.Black)
                squads[activeCardActor].forEach { player ->
                    val alreadyProtected = player.nameEn in protectedNames
                    PremiumPlayerChoiceCard(player, english) {
                        if (!alreadyProtected) useShield(player)
                    }
                }
                OutlinedButton(onClick = { selectedCardIndex = -1 }, modifier = Modifier.fillMaxWidth()) { Text(localizedText(english, "إلغاء", "Cancel"), color = palette.cream) }
            }
            if (status.isNotBlank()) Text(status, color = palette.gold, fontSize = 12.sp)
            squads.forEachIndexed { index, squad ->
                SquadProgressStrip(safeTeamName(index), squad, targetCount, detailFor = { player -> if (player.nameEn in protectedNames) "SHIELD" else "${player.rating}" })
            }
        } else if (phase == "finished" && !liveMatchDone) {
            val firstMatch = matchResults.firstOrNull()
            if (firstMatch == null) {
                Text(localizedText(english, "جاري تجهيز المباراة…", "Preparing the match…"), color = palette.muted, fontSize = 12.sp)
            } else {
                val rivalIndex = firstMatch.first
                Text(localizedText(english, "⚽ المباراة النهائية", "⚽ THE FINAL MATCH"), color = palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                LiveMatchSimulation(
                    userName = safeTeamName(0),
                    opponentName = safeTeamName(rivalIndex),
                    userSquad = squads.getOrNull(0).orEmpty(),
                    opponentSquad = squads.getOrNull(rivalIndex).orEmpty(),
                    score = firstMatch.second,
                    english = english,
                    sound = sound,
                    onFinished = {
                        sound.play(if (firstMatch.second.userWon) Sfx.Win else Sfx.Loss)
                        liveMatchDone = true
                    }
                )
            }
        } else if (phase == "finished") {
            Text(localizedText(english, "النتيجة النهائية", "FINAL RESULTS"), color = palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
            squads.forEachIndexed { index, squad ->
                SquadFormationPitch(
                    title = "${safeTeamName(index)} • ${coaches.getOrNull(index)?.nameEn ?: ""}",
                    players = squad,
                    slotCount = targetCount,
                    detailFor = { player -> if (player.nameEn in protectedNames) "SHIELDED" else "${player.rating} OVR" }
                )
            }
            matchResults.forEach { (opponentIndex, result) ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${safeTeamName(0)}  ${result.userGoals} - ${result.opponentGoals}  ${safeTeamName(opponentIndex)}", color = palette.gold, fontWeight = FontWeight.Black)
                        Text(when { result.userWon -> localizedText(english, "فوز", "WIN"); result.isDraw -> localizedText(english, "تعادل", "DRAW"); else -> localizedText(english, "خسارة", "LOSS") }, color = palette.cream)
                    }
                }
            }
            if (saveStatus.isNotBlank()) Text(saveStatus, color = palette.muted, fontSize = 11.sp)
            Button(onClick = onExit, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                Text(localizedText(english, "إنهاء", "Finish"), fontWeight = FontWeight.Black)
            }
        } else {
            // Private case opening and decision flow.
            Text(localizedText(english, "المركز ${roundIndex + 1} من ${slots.size}: $currentPositionLabel", "Position ${roundIndex + 1} of ${slots.size}: $currentPositionLabel"), color = palette.gold, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(localizedText(english, "دور ${safeTeamName(currentActor)}", "${safeTeamName(currentActor)}'s turn"), color = palette.cream, fontWeight = FontWeight.Bold)
                if (phase in setOf("draft", "decision", "riskPick") && isHumanTurn) TurnTimerPill(turnSecondsLeft, turnTimeSeconds)
                else if (!isHumanTurn) Text(localizedText(english, "الصاروخ يختار من صناديقه الخاصة", "AI is using its own private cases"), color = palette.muted, fontSize = 10.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(slots.size) { index ->
                    Box(Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(5.dp)).background(if (index <= roundIndex) palette.gold else palette.panel))
                }
            }
            if (phase == "draft" && isHumanTurn) {
                Text(localizedText(english, "أربع صناديق خاصة بيك. افتح واحد بس.", "Your four private cases. Open one case."), color = palette.cream, fontWeight = FontWeight.Bold)
                for (row in 0..1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (column in 0..1) {
                            val index = row * 2 + column
                            CaseTile(index + 1, Modifier.weight(1f)) { openFirstCase(index) }
                        }
                    }
                }
            } else if (phase == "draft" && !isHumanTurn) {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(localizedText(english, "الصاروخ بيختار من صناديقه الخاصة", "AI is choosing from its own private cases"), color = palette.gold, fontWeight = FontWeight.Black)
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = palette.gold, trackColor = palette.surface)
                        Text(localizedText(english, "مش بيشوف صناديقك ولا بيأثر على اختيارك.", "It cannot see your cases or influence your decision."), color = palette.muted, fontSize = 11.sp)
                    }
                }
            } else if (phase == "aiReveal") {
                Text(localizedText(english, "اختيار الصاروخ", "AI CASE REVEAL"), color = palette.gold, fontWeight = FontWeight.Black)
                Text(localizedText(english, "الصاروخ فتح الصندوق رقم ${firstCaseIndex + 1}.", "AI opened case ${firstCaseIndex + 1}."), color = palette.cream, fontWeight = FontWeight.Bold)
                firstReveal?.let { DealRevealCard(it, english, localizedText(english, "اللاعب داخل صندوق الصاروخ", "PLAYER IN AI'S CASE")) }
                Text(localizedText(english, "الصاروخ بيقرر: Deal ولا No Deal؟", "AI is deciding: Deal or No Deal?"), color = palette.gold, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = palette.gold, trackColor = palette.surface)
            } else if (phase == "aiRiskPick") {
                rejectedPlayer?.let { DealRevealCard(it, english, localizedText(english, "الصاروخ رفض اللاعب ده نهائيًا", "AI PERMANENTLY REJECTED THIS PLAYER")) }
                Text(localizedText(english, "الصاروخ بيختار صندوقًا من الثلاثة الباقية", "AI is choosing one of the three remaining cases"), color = palette.gold, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    privateCases.getOrNull(1).orEmpty().forEachIndexed { index, player ->
                        if (index != rejectedCaseIndex) {
                            CaseTile(
                                index + 1,
                                Modifier.weight(1f),
                                selected = aiSelectedRiskIndex == index,
                                enabled = false
                            ) { }
                        }
                    }
                }
                if (aiSelectedRiskIndex >= 0) Text(localizedText(english, "اختار الصندوق رقم ${aiSelectedRiskIndex + 1}", "AI selected case ${aiSelectedRiskIndex + 1}"), color = palette.cream, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = palette.gold, trackColor = palette.surface)
            } else if (phase == "reveal" || phase == "decision") {
                firstReveal?.let { DealRevealCard(it, english, localizedText(english, "اللاعب داخل صندوقك", "PLAYER IN YOUR CASE")) }
                if (phase == "decision") {
                    Text(localizedText(english, "Deal ولا No Deal؟", "DEAL OR NO DEAL?"), color = palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { acceptDeal() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.good, contentColor = Color(0xFF10251D))) {
                        Text(localizedText(english, "Deal • أقبل اللاعب", "Deal • Keep this player"), fontWeight = FontWeight.Black)
                    }
                    OutlinedButton(onClick = {
                        rejectedCaseIndex = firstCaseIndex
                        rejectedPlayer = firstReveal
                        val updatedSeen = seenByParticipant.toMutableList()
                        updatedSeen[currentActor] = updatedSeen[currentActor] + listOfNotNull(firstReveal?.nameEn)
                        seenByParticipant = updatedSeen
                        sound.play(Sfx.NoDeal)
                        phase = "riskPick"
                        status = localizedText(english, "اللاعب اترفض نهائيًا. اختار واحدًا من الصناديق الثلاثة الباقية.", "This player is rejected permanently. Choose one of the three remaining cases.")
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text(localizedText(english, "No Deal • أرفض وأخاطر", "No Deal • Reject and risk"), color = palette.gold, fontWeight = FontWeight.Black)
                    }
                }
            } else if (phase == "riskPick") {
                rejectedPlayer?.let {
                    Card(colors = CardDefaults.cardColors(containerColor = palette.panel.copy(alpha = 0.65f)), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            PlayerPortrait(it, Modifier.size(width = 48.dp, height = 56.dp), cornerRadius = 9)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                Text(displayName(it), color = palette.muted, fontWeight = FontWeight.Bold)
                                Text(localizedText(english, "مرفوض نهائيًا • لا يمكن الرجوع له", "PERMANENTLY REJECTED • LOCKED"), color = palette.bad, fontSize = 10.sp)
                            }
                            Text("✕", color = palette.bad, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                Text(localizedText(english, "اختار صندوقًا من الثلاثة الباقية. اللاعب اللي يظهر هينضم إجباريًا.", "Choose one of the three remaining cases. Its player joins your squad automatically."), color = palette.gold, fontWeight = FontWeight.Bold)
                for (row in 0..1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (column in 0..1) {
                            val index = row * 2 + column
                            if (index == rejectedCaseIndex) {
                                Box(Modifier.weight(1f).height(132.dp).clip(RoundedCornerShape(17.dp)).background(palette.panel.copy(alpha = 0.35f)).border(1.dp, palette.bad.copy(alpha = 0.35f), RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
                                    Text(localizedText(english, "REJECTED", "مرفوض"), color = palette.bad, fontWeight = FontWeight.Black)
                                }
                            } else {
                                CaseTile(index + 1, Modifier.weight(1f)) { chooseRiskCase(index) }
                            }
                        }
                    }
                }
            } else if (phase == "acceptedReveal") {
                squads.getOrNull(currentActor)?.lastOrNull()?.let { DealRevealCard(it, english, localizedText(english, "اللاعب انضم لتشكيلتك", "PLAYER ADDED TO YOUR SQUAD")) }
                Text(localizedText(english, "قرارك اتثبت. افتحنا لك كشف الصناديق الباقية...", "Your decision is locked. Now revealing the remaining cases..."), color = palette.gold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            } else if (phase == "caseRegretReveal") {
                Text(localizedText(english, "يا خسارة! شوف اللاعبين اللي سبتهم", "THE ONES THAT GOT AWAY"), color = palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text(localizedText(english, "الصناديق اللي ما اخترتها هتتفتح واحد ورا التاني.", "The cases you did not choose are opening one by one."), color = palette.muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                remainingCaseReveals.take(remainingCaseRevealCount).forEach { (caseIndex, player) ->
                    key(caseIndex, player.nameEn) {
                        Card(
                            modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.45f), RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = palette.panel),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                FlipRevealCard(
                                    player = player,
                                    english = english,
                                    size = FifaCardSize.Medium,
                                    modifier = Modifier.width(128.dp),
                                    startDelayMillis = 150,
                                    flipMillis = 1_500
                                )
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(localizedText(english, "الصندوق رقم ${caseIndex + 1}", "CASE ${caseIndex + 1}"), color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                    Text(displayName(player), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 15.sp)
                                    Text("${player.rating} OVR • ${player.position}", color = palette.muted, fontSize = 12.sp)
                                    Text(localizedText(english, "فاتك", "MISSED"), color = palette.bad, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                Text(localizedText(english, "${remainingCaseRevealCount} / ${remainingCaseReveals.size} صندوق اتكشف", "${remainingCaseRevealCount} / ${remainingCaseReveals.size} cases revealed"), color = palette.muted, fontSize = 10.sp)
                if (remainingCaseRevealCount >= 1) {
                    Button(
                        onClick = { advanceAfterPick() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
                    ) {
                        Text(
                            if (remainingCaseRevealCount >= remainingCaseReveals.size) localizedText(english, "كمّل", "Continue")
                            else localizedText(english, "تخطي وكمّل", "Skip and continue"),
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
            if (status.isNotBlank()) Text(status, color = palette.gold, fontSize = 11.sp, lineHeight = 16.sp)
            squads.forEachIndexed { index, squad ->
                SquadProgressStrip(
                    title = safeTeamName(index),
                    players = squad,
                    slotCount = targetCount,
                    detailFor = { player -> if (player.nameEn in protectedNames) "SHIELD" else "${player.rating} OVR" }
                )
            }
        }
        if (showPlayerFilterDialog) {
            val filteredPlayers = PlayerDatabase.players.filter { player ->
                val arabicName = PlayerSearch.arabicName(player.nameEn, player.nameAr)
                player.nameEn.contains(playerFilterSearch, ignoreCase = true) || arabicName.contains(playerFilterSearch, ignoreCase = true)
            }
            Dialog(onDismissRequest = { showPlayerFilterDialog = false }) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = palette.panelAlt)
                ) {
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 650.dp).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        Text(localizedText(english, "حدد اللاعبين المتاحين في الصناديق", "SELECT PLAYERS AVAILABLE IN CASES"), color = palette.gold, fontWeight = FontWeight.Black)
                        OutlinedTextField(
                            value = playerFilterSearch,
                            onValueChange = { playerFilterSearch = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text(localizedText(english, "بحث عربي أو إنجليزي", "Search in Arabic or English")) }
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { draftPlayerNames = PlayerDatabase.players.map { it.nameEn }.toSet() }, modifier = Modifier.weight(1f)) {
                                Text(localizedText(english, "تحديد الكل", "Select all"), color = palette.cream, fontSize = 11.sp)
                            }
                            OutlinedButton(onClick = { draftPlayerNames = emptySet() }, modifier = Modifier.weight(1f)) {
                                Text(localizedText(english, "مسح الكل", "Clear all"), color = palette.cream, fontSize = 11.sp)
                            }
                        }
                        Text(localizedText(english, "المحدد: ${draftPlayerNames.size} / ${PlayerDatabase.players.size}", "Selected: ${draftPlayerNames.size} / ${PlayerDatabase.players.size}"), color = palette.muted, fontSize = 11.sp)
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f, fill = true).heightIn(min = 160.dp, max = 390.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(filteredPlayers, key = { it.nameEn }) { player ->
                                val isSelected = player.nameEn in draftPlayerNames
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        draftPlayerNames = if (isSelected) draftPlayerNames - player.nameEn else draftPlayerNames + player.nameEn
                                    }.padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = isSelected, onCheckedChange = { checked ->
                                        draftPlayerNames = if (checked) draftPlayerNames + player.nameEn else draftPlayerNames - player.nameEn
                                    })
                                    Column(Modifier.weight(1f)) {
                                        Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("${player.rating} OVR • ${player.position} • ${player.nationalityEn}", color = palette.muted, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showPlayerFilterDialog = false }, modifier = Modifier.weight(1f)) {
                                Text(localizedText(english, "إلغاء", "Cancel"), color = palette.cream)
                            }
                            Button(
                                onClick = {
                                    selectedPlayerNames = draftPlayerNames
                                    customPlayerFilter = draftPlayerNames.size != PlayerDatabase.players.size
                                    setupMessage = ""
                                    showPlayerFilterDialog = false
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
                            ) {
                                Text(localizedText(english, "حفظ الفلتر", "Save filter"), fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChoicePill(text: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Box(
        Modifier.clip(RoundedCornerShape(11.dp))
            .background(if (selected) palette.gold else palette.panel)
            .border(1.dp, if (selected) palette.gold else palette.gold.copy(alpha = 0.35f), RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) palette.deepWine else palette.cream, fontWeight = FontWeight.Bold, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CaseTile(
    index: Int,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = modifier.height(132.dp)
            .border(if (selected) 2.dp else 1.dp, if (selected) palette.gold else palette.gold.copy(alpha = 0.22f), RoundedCornerShape(17.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .animateContentSize(),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) palette.panel else palette.panelAlt)
    ) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(if (selected) listOf(palette.gold.copy(alpha = 0.22f), palette.deepWine) else listOf(palette.panelAlt, palette.deepWine))).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(if (selected) "★" else "▣", color = palette.gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
            Text("${if (index < 10) "0$index" else index}", color = palette.cream, fontSize = 17.sp, fontWeight = FontWeight.Black)
            Text(
                when {
                    selected -> uiText("الصاروخ اختار الصندوق", "AI SELECTED")
                    enabled -> uiText("اضغط لفتح الصندوق", "TAP TO OPEN")
                    else -> uiText("صندوق الصاروخ", "AI CASE")
                },
                color = if (selected) palette.gold else palette.muted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DealRevealCard(player: PlayerCard, english: Boolean, eyebrow: String) {
    val palette = LocalElbashaPalette.current
    AnimatedVisibility(visible = true, enter = fadeIn(tween(300)) + scaleIn(initialScale = 0.82f, animationSpec = tween(300))) {
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(eyebrow, color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            FifaPlayerCard(player, english, size = FifaCardSize.Large)
            Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}", color = palette.muted, fontSize = 11.sp)
        }
    }
}
