package com.mostafabek.elbashagames

/** Pure guards shared by every realtime match before the Firebase transaction commits a move. */
object OnlineMatchRules {
    fun canCommit(
        expectedRevision: Long,
        actualRevision: Long,
        currentTurnUid: String?,
        actorUid: String,
        phase: String?
    ): Boolean = expectedRevision == actualRevision &&
        currentTurnUid == actorUid &&
        phase != "finished" && actorUid.isNotBlank()

    fun nextTurn(players: List<String>, currentIndex: Int): String? {
        if (players.isEmpty()) return null
        return players[(currentIndex + 1).mod(players.size)]
    }

    fun validBid(amount: Int, currentBid: Int, openingBid: Int, budget: Int): Boolean =
        amount >= maxOf(openingBid, currentBid + 1) && amount <= budget && budget >= 0

    fun shouldFinish(nextRound: Int, targetRounds: Int): Boolean = targetRounds > 0 && nextRound >= targetRounds
}
