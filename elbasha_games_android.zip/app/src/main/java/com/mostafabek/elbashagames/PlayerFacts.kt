package com.mostafabek.elbashagames

/**
 * Match facts used by the Build a Team points game.
 * Physical measurements and 2026/27 LaLiga stats are curated from official player/league profiles.
 * paceRating is an ELBASHA gameplay attribute (0..100), not a measured sprint speed.
 */
data class PlayerGameFacts(
    val club: String,
    val league: String,
    val season: String = "2026/27",
    val heightCm: Int? = null,
    val weightKg: Int? = null,
    val goalsSeason: Int? = null,
    val yellowCardsSeason: Int? = null,
    val paceRating: Int? = null,
    val isCurrent: Boolean = true
)

object PlayerFactsDatabase {
    private fun card(
        nameEn: String, nameAr: String, nationalityAr: String, nationalityEn: String,
        rating: Int, flag: String, position: String = "GK"
    ) = PlayerCard(
        nameEn = nameEn, nameAr = nameAr, position = position, rating = rating,
        price = maxOf(5, minOf(11, 5 + ((rating - 80) * 6 + 7) / 15)),
        flag = flag, nationalityAr = nationalityAr, nationalityEn = nationalityEn
    )

    /** Active LaLiga goalkeepers missing from the older prime-player catalog. */
    private val additionalPlayers = listOf(
        card("Joan Garcia", "خوان جارسيا", "إسبانيا", "Spain", 87, "🇪🇸"),
        card("Alex Remiro", "أليكس ريميرو", "إسبانيا", "Spain", 86, "🇪🇸"),
        card("Wojciech Szczesny", "فويتشيك تشيزني", "بولندا", "Poland", 86, "🇵🇱"),
        card("Andrii Lunin", "أندري لونين", "أوكرانيا", "Ukraine", 84, "🇺🇦"),
        card("Juan Musso", "خوان موسو", "الأرجنتين", "Argentina", 82, "🇦🇷"),
        card("David Soria", "دافيد سوريا", "إسبانيا", "Spain", 80, "🇪🇸"),
        card("Paulo Gazzaniga", "باولو جازانيجا", "الأرجنتين", "Argentina", 80, "🇦🇷"),

        // Current LaLiga outfield players used to make every position filter playable.
        card("Fermin Lopez", "فيرمين لوبيز", "إسبانيا", "Spain", 84, "🇪🇸", "MF"),
        card("Julian Alvarez", "جوليان ألفاريز", "الأرجنتين", "Argentina", 90, "🇦🇷", "ST"),
        card("Ante Budimir", "أنتي بوديمير", "كرواتيا", "Croatia", 85, "🇭🇷", "ST"),
        card("Sergio Camello", "سيرخيو كاميلو", "إسبانيا", "Spain", 78, "🇪🇸", "ST"),
        card("Alejandro Grimaldo", "أليخاندرو جريمالدو", "إسبانيا", "Spain", 87, "🇪🇸", "DF"),
        card("Giuliano Simeone", "جوليانو سيميوني", "الأرجنتين", "Argentina", 82, "🇦🇷", "WG"),
        card("Alejandro Balde", "أليخاندرو بالدي", "إسبانيا", "Spain", 86, "🇪🇸", "DF"),
        card("Sergio Gomez", "سيرخيو جوميز", "إسبانيا", "Spain", 81, "🇪🇸", "DF"),
        card("Pablo Barrios", "بابلو باريوس", "إسبانيا", "Spain", 83, "🇪🇸", "MF"),
        card("Lucas Boye", "لوكاس بويي", "الأرجنتين", "Argentina", 82, "🇦🇷", "ST"),
        card("Isaac Romero", "إسحاق روميرو", "إسبانيا", "Spain", 80, "🇪🇸", "ST"),
        card("Isco", "إيسكو", "إسبانيا", "Spain", 84, "🇪🇸", "MF"),
        card("Sergio Carreira", "سيرخيو كاريرا", "إسبانيا", "Spain", 77, "🇪🇸", "DF"),
        card("Adria Pedrosa", "أدريا بيدروسا", "إسبانيا", "Spain", 78, "🇪🇸", "DF"),
        card("Jose Gaya", "خوسيه جايا", "إسبانيا", "Spain", 80, "🇪🇸", "DF"),
        card("Javi Rodriguez", "خافي رودريجيز", "إسبانيا", "Spain", 75, "🇪🇸", "DF"),
        card("Alex Calatrava", "أليكس كالافاترا", "إسبانيا", "Spain", 74, "🇪🇸", "WG")
    )

    private val baseNames = PlayerDatabase.players.mapTo(mutableSetOf()) { it.nameEn }
    val players: List<PlayerCard> = PlayerDatabase.players + additionalPlayers.filter { it.nameEn !in baseNames }

    private val byName: Map<String, PlayerGameFacts> = mapOf(
        // Goalkeepers: LaLiga official profiles, 2026/27 season snapshot.
        "Joan Garcia" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 193, weightKg = 85, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 58),
        "Thibaut Courtois" to PlayerGameFacts("Real Madrid", "LaLiga", heightCm = 200, weightKg = 96, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 55),
        "Jan Oblak" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 188, weightKg = 87, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 54),
        "Unai Simon" to PlayerGameFacts("Athletic Club", "LaLiga", heightCm = 190, weightKg = 88, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 60),
        "Alex Remiro" to PlayerGameFacts("Real Sociedad", "LaLiga", heightCm = 191, weightKg = 79, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 57),
        "Wojciech Szczesny" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 195, weightKg = 90, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 52),
        "Andrii Lunin" to PlayerGameFacts("Real Madrid", "LaLiga", heightCm = 191, weightKg = 80, goalsSeason = 0, yellowCardsSeason = 1, paceRating = 59),
        "Juan Musso" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 191, weightKg = 93, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 56),
        "David Soria" to PlayerGameFacts("Getafe CF", "LaLiga", heightCm = 192, weightKg = 83, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 55),
        "Paulo Gazzaniga" to PlayerGameFacts("Girona FC", "LaLiga", heightCm = 195, weightKg = 90, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 57),

        // Field players: season goals/cards from official LaLiga 2026/27 player pages.
        // Pace is intentionally presented as an ELBASHA gameplay score, not a physical measurement.
        "Raphinha" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 176, weightKg = 64, goalsSeason = 15, yellowCardsSeason = 0, paceRating = 89),
        "Lamine Yamal" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 178, weightKg = 76, goalsSeason = 10, yellowCardsSeason = 2, paceRating = 94),
        "Kylian Mbappe" to PlayerGameFacts("Real Madrid", "LaLiga", heightCm = 178, weightKg = 75, goalsSeason = 13, yellowCardsSeason = 3, paceRating = 97),
        "Vinicius Junior" to PlayerGameFacts("Real Madrid", "LaLiga", heightCm = 176, weightKg = 77, goalsSeason = 1, yellowCardsSeason = 2, paceRating = 96),
        "Jude Bellingham" to PlayerGameFacts("Real Madrid", "LaLiga", heightCm = 186, weightKg = 75, goalsSeason = 4, yellowCardsSeason = 2, paceRating = 86),
        "Fermin Lopez" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 174, weightKg = 64, goalsSeason = 7, yellowCardsSeason = 3, paceRating = 85),
        "Julian Alvarez" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 170, weightKg = 71, goalsSeason = 1, yellowCardsSeason = 0, paceRating = 91),
        "Ante Budimir" to PlayerGameFacts("CA Osasuna", "LaLiga", heightCm = 190, weightKg = 75, goalsSeason = 8, yellowCardsSeason = 2, paceRating = 76),
        "Sergio Camello" to PlayerGameFacts("Rayo Vallecano", "LaLiga", heightCm = 177, weightKg = 69, goalsSeason = 7, yellowCardsSeason = 3, paceRating = 83),
        "Alejandro Grimaldo" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 171, weightKg = 63, goalsSeason = 4, yellowCardsSeason = 0, paceRating = 88),
        "Giuliano Simeone" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 173, weightKg = 75, goalsSeason = 4, yellowCardsSeason = 1, paceRating = 87),
        "Alejandro Balde" to PlayerGameFacts("FC Barcelona", "LaLiga", heightCm = 177, weightKg = 76, goalsSeason = 0, yellowCardsSeason = 1, paceRating = 93),
        "Sergio Gomez" to PlayerGameFacts("Real Sociedad", "LaLiga", heightCm = 173, weightKg = 71, goalsSeason = 0, yellowCardsSeason = 1, paceRating = 82),
        "Pablo Barrios" to PlayerGameFacts("Atlético de Madrid", "LaLiga", heightCm = 183, weightKg = 75, goalsSeason = 0, yellowCardsSeason = 0, paceRating = 83),
        "Lucas Boye" to PlayerGameFacts("Deportivo Alavés", "LaLiga", heightCm = 179, weightKg = 81, goalsSeason = 5, yellowCardsSeason = 1, paceRating = 80),
        "Isaac Romero" to PlayerGameFacts("Sevilla FC", "LaLiga", heightCm = 184, weightKg = 70, goalsSeason = 3, yellowCardsSeason = 3, paceRating = 84),
        "Isco" to PlayerGameFacts("Real Betis", "LaLiga", heightCm = 176, weightKg = 79, goalsSeason = 2, yellowCardsSeason = 0, paceRating = 76),
        "Sergio Carreira" to PlayerGameFacts("RC Celta", "LaLiga", heightCm = 170, weightKg = 70, goalsSeason = 0, yellowCardsSeason = 2, paceRating = 83),
        "Adria Pedrosa" to PlayerGameFacts("Rayo Vallecano", "LaLiga", heightCm = 172, weightKg = 69, goalsSeason = 1, yellowCardsSeason = 2, paceRating = 84),
        "Jose Gaya" to PlayerGameFacts("Valencia CF", "LaLiga", heightCm = 172, weightKg = 66, goalsSeason = 0, yellowCardsSeason = 1, paceRating = 80),
        "Javi Rodriguez" to PlayerGameFacts("RC Celta", "LaLiga", heightCm = 178, weightKg = 70, goalsSeason = 1, yellowCardsSeason = 0, paceRating = 79),
        "Alex Calatrava" to PlayerGameFacts("RCD Espanyol", "LaLiga", heightCm = 175, weightKg = 69, goalsSeason = 1, yellowCardsSeason = 3, paceRating = 81)
    )

    fun facts(player: PlayerCard): PlayerGameFacts? = byName[player.nameEn]
    fun facts(nameEn: String): PlayerGameFacts? = byName[nameEn]
    fun allFactPlayers(): List<PlayerCard> = players.filter { byName.containsKey(it.nameEn) }
}
