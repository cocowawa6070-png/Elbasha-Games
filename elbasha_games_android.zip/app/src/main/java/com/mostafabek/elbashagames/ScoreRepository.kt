package com.mostafabek.elbashagames

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction

/**
 * Adds a completed game's points to the player's prototype leaderboard record.
 * A Realtime Database transaction prevents two games finishing at nearly the same time
 * from overwriting one another's points.
 */
object ScoreRepository {
    fun submit(database: FirebaseDatabase?, user: FirebaseUser, points: Int, onDone: (Boolean) -> Unit) {
        // Developer account is excluded from competitive totals and leaderboard records.
        if (ElbashaAccess.isDeveloper(user.uid)) {
            onDone(true)
            return
        }
        if (database == null) {
            onDone(false)
            return
        }
        val safePoints = points.coerceIn(0, 100_000)
        val leaderboardRef = database.reference.child("leaderboard").child(user.uid)
        database.reference.child("publicProfiles").child(user.uid).child("displayName").get()
            .addOnSuccessListener { nameSnapshot ->
                val name = nameSnapshot.getValue(String::class.java)?.trim()?.take(28)
                if (name.isNullOrBlank()) {
                    onDone(false)
                    return@addOnSuccessListener
                }

                leaderboardRef.runTransaction(object : Transaction.Handler {
                    override fun doTransaction(currentData: MutableData): Transaction.Result {
                        val oldTotal = currentData.child("totalPoints").getValue(Long::class.java) ?: 0L
                        val oldBest = currentData.child("bestScore").getValue(Long::class.java) ?: 0L
                        val record = hashMapOf<String, Any>(
                            "displayName" to name,
                            "totalPoints" to (oldTotal + safePoints).coerceAtMost(1_000_000L),
                            "bestScore" to maxOf(oldBest, safePoints.toLong()).coerceAtMost(100_000L),
                            "updatedAt" to System.currentTimeMillis()
                        )
                        currentData.value = record
                        return Transaction.success(currentData)
                    }

                    override fun onComplete(
                        error: DatabaseError?,
                        committed: Boolean,
                        currentData: DataSnapshot?
                    ) {
                        onDone(error == null && committed)
                    }
                })
            }
            .addOnFailureListener { onDone(false) }
    }
}
