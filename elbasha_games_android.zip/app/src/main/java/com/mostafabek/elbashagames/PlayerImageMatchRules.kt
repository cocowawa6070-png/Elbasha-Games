package com.mostafabek.elbashagames

import java.text.Normalizer

/** Strict metadata checks for player portraits. Missing evidence means no portrait. */
object PlayerImageMatchRules {
    fun normalizeTitle(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    fun isExactPlayerTitle(actualTitle: String?, requestedNames: Set<String>): Boolean {
        if (actualTitle.isNullOrBlank()) return false
        val actual = normalizeTitle(actualTitle)
        return actual.isNotBlank() && requestedNames.any { normalizeTitle(it) == actual }
    }

    /** Wikidata page description must positively identify a football player, not just a person. */
    fun isFootballerDescription(description: String?): Boolean {
        if (description.isNullOrBlank()) return false
        val value = normalizeTitle(description)
        return listOf(
            "footballer",
            "football player",
            "association football player",
            "association football defender",
            "association football midfielder",
            "association football forward",
            "association football goalkeeper",
            "soccer player",
            "professional football player",
            "football goalkeeper",
            "football defender",
            "football midfielder",
            "football forward",
            "football striker"
        ).any(value::contains)
    }
}
