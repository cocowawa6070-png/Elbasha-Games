package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random
import kotlinx.coroutines.delay

private data class AuctionLot(val player: PlayerCard, val opening: Int)

private val AiDifficultyAr = listOf("سهل", "متوازن", "صعب", "صعب جدًا")
private val AiDifficultyEn = listOf("Easy", "Balanced", "Hard", "Very hard")

@Composable
fun AuctionGameScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var oneDeviceMode by remember { mutableStateOf(false) }
    var onlineMode by remember { mutableStateOf(false) }
    if (onlineMode) {
        OnlineAuctionScreen(user, database, sound) { onlineMode = false }
        return
    }
    if (oneDeviceMode) {
        AuctionLocalGameScreen(sound = sound, english = english, onExit = { oneDeviceMode = false })
        return
    }
    var pro by remember { mutableStateOf(false) }
    var cardsMode by remember { mutableStateOf(true) }
    var postAuctionCardsPhase by remember { mutableStateOf(false) }
    var postAuctionSeconds by remember { mutableIntStateOf(PostAuctionCardRules.WINDOW_SECONDS) }
    var userProtectedName by remember { mutableStateOf<String?>(null) }
    var aiProtectedName by remember { mutableStateOf<String?>(null) }
    var userProtectionUsed by remember { mutableStateOf(false) }
    var userStealUsed by remember { mutableStateOf(false) }
    var aiStealUsed by remember { mutableStateOf(false) }
    var userSelectingProtection by remember { mutableStateOf(false) }
    var userSelectingSteal by remember { mutableStateOf(false) }
    var selectedStealTarget by remember { mutableStateOf<PlayerCard?>(null) }
    var hiddenRevealCountdown by remember { mutableStateOf(false) }
    var hiddenRevealCountdownNumber by remember { mutableIntStateOf(3) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var started by remember { mutableStateOf(false) }
    var startingCountdown by remember { mutableStateOf(false) }
    var countdownNumber by remember { mutableIntStateOf(3) }
    var turnTimeSeconds by remember { mutableIntStateOf(30) }
    var turnSecondsLeft by remember { mutableIntStateOf(30) }
    var budget by remember { mutableIntStateOf(100) }
    var aiBudget by remember { mutableIntStateOf(100) }
    var bought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var aiBought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var hiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var aiHiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var remainingLots by remember { mutableStateOf(emptyList<PlayerCard>()) }
    var bid by remember { mutableIntStateOf(0) }
    var currentBid by remember { mutableIntStateOf(0) }
    var aiMaxForLot by remember { mutableIntStateOf(0) }
    var aiLotSpendLimit by remember { mutableIntStateOf(0) }
    var aiIsLeading by remember { mutableStateOf(false) }
    var lotResolved by remember { mutableStateOf(false) }
    var revealPlayer by remember { mutableStateOf<PlayerCard?>(null) }
    var revealCaption by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var ended by remember { mutableStateOf(false) }
    var showSquadReveal by remember { mutableStateOf(false) }
    var revealSeconds by remember { mutableIntStateOf(5) }
    var coachRevealPending by remember { mutableStateOf(false) }
    var coachAuctionStarted by remember { mutableStateOf(false) }
    var coachAuctionActive by remember { mutableStateOf(false) }
    var coachLot by remember { mutableStateOf<CoachCard?>(null) }
    var userCoach by remember { mutableStateOf<CoachCard?>(null) }
    var aiCoach by remember { mutableStateOf<CoachCard?>(null) }
    var coachCurrentBid by remember { mutableIntStateOf(0) }
    var coachBidDraft by remember { mutableIntStateOf(0) }
    var coachAiCeiling by remember { mutableIntStateOf(0) }
    var coachAiLeading by remember { mutableStateOf(false) }
    var wildCardActive by remember { mutableStateOf(false) }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var matchResult by remember { mutableStateOf<MatchScore?>(null) }
    val targetCount = if (pro) 11 else 5
    val startBudget = if (pro) 200 else 100
    val pool = remember(pro, started) {
        ElbashaPositions.auctionPool(if (pro) 11 else 5, if (pro) 42 else 24)
    }
    val lot = remainingLots.firstOrNull()
    val userRating = bought.sumOf { it.first.rating } + hiddenPlayers.sumOf { it.rating }
    val aiRating = aiBought.sumOf { it.first.rating } + aiHiddenPlayers.sumOf { it.rating }
    val userSquad = bought.map { it.first } + hiddenPlayers
    val aiSquad = aiBought.map { it.first } + aiHiddenPlayers
    val userCoachBonus = userCoach?.matchBonus ?: 0.0
    val aiCoachBonus = aiCoach?.matchBonus ?: 0.0
    fun startPostAuctionCards() {
        if (cardsMode) {
            postAuctionCardsPhase = true
            postAuctionSeconds = PostAuctionCardRules.WINDOW_SECONDS
            aiProtectedName = aiSquad.maxByOrNull { it.rating }?.nameEn
            userProtectedName = null
            userProtectionUsed = false
            userStealUsed = false
            aiStealUsed = false
            userSelectingProtection = false
            userSelectingSteal = false
            selectedStealTarget = null
            message = localizedText(english, "اختار الحماية والسرقة خلال 20 ثانية.", "Choose your shield and steal within 20 seconds.")
        } else ended = true
    }

    LaunchedEffect(lot?.nameEn, aiDifficulty, aiBudget, remainingLots) {
        if (lot != null) {
            lotResolved = false
            val opening = AuctionRules.openingPrice(lot.rating)
            currentBid = opening - 1
            // The visible counter always starts at the minimum legal amount for this turn.
            bid = AuctionRules.minimumNextUserBid(currentBid, opening)
            aiIsLeading = false
            wildCardActive = false
            val upcomingLots = remainingLots.drop(1)
            val requiredSlots = ElbashaPositions.formationSlots(targetCount).toMutableList()
            aiSquad.forEach { owned ->
                val ownedSlot = requiredSlots.indexOf(owned.position)
                if (ownedSlot >= 0) requiredSlots.removeAt(ownedSlot)
            }
            val positionNeed = requiredSlots.count { it == lot.position }
            val currentSlotIndex = requiredSlots.indexOf(lot.position)
            val futureSlots = requiredSlots.toMutableList().also { slots ->
                if (currentSlotIndex >= 0) slots.removeAt(currentSlotIndex)
            }
            // Reserve only the cheapest queued lot for each still-missing formation slot,
            // not every alternative in the queue. The old all-lots reserve could starve the AI.
            val reserveCandidates = AuctionRules.reserveLotsForRequiredSlots(
                requiredSlots = futureSlots,
                upcomingLots = upcomingLots
            )
            val fundsAvailableForThisLot = AuctionRules.availableBudgetForCurrentLot(
                totalBudget = aiBudget,
                currentOpeningPrice = opening,
                upcomingLots = reserveCandidates
            )
            aiLotSpendLimit = fundsAvailableForThisLot
            aiMaxForLot = if (aiSquad.size >= targetCount || positionNeed <= 0) 0
                else AuctionRules.calculateAiBidCeiling(lot.rating, opening, fundsAvailableForThisLot, aiDifficulty, positionNeed)
        }
    }

    LaunchedEffect(ended) {
        if (ended) {
            val result = matchResult ?: MatchEngine.simulate(userSquad, aiSquad, userCoachBonus, aiCoachBonus, targetSquadSize = targetCount).also {
                matchResult = it
            }
            sound.play(if (result.userWon) Sfx.Win else Sfx.Loss)
            if (!scoreSubmitted) {
                scoreSubmitted = true
                if (ElbashaAccess.isDeveloper(user.uid)) {
                    saveStatus = localizedText(english, "حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
                } else {
                    val matchBonus = when {
                        result.userWon -> 1_000
                        result.isDraw -> 500
                        else -> 0
                    }
                    ScoreRepository.submit(database, user, userRating * 10 + matchBonus) { saved ->
                        saveStatus = if (saved) localizedText(english, "تم حفظ نقاط المزاد", "Auction score saved")
                        else localizedText(english, "تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                    }
                }
            }
        }
    }

    fun grantHiddenPlayer(position: String, toUser: Boolean): PlayerCard? {
        if (toUser && bought.size + hiddenPlayers.size >= targetCount) return null
        if (!toUser && aiBought.size + aiHiddenPlayers.size >= targetCount) return null
        val alreadyUsed = (bought.map { it.first } + aiBought.map { it.first } + hiddenPlayers + aiHiddenPlayers)
            .map { it.nameEn }.toSet()
        val hidden = PlayerDatabase.players
            .filter { ElbashaPositions.supports(it, position) && it.nameEn !in alreadyUsed }
            .randomOrNull()?.copy(position = position) ?: return null
        // Keep the number of auction rounds stable if the hidden reward was queued as a lot.
        val occupiedNames = (bought.map { it.first } + aiBought.map { it.first } + hiddenPlayers + aiHiddenPlayers)
            .map { it.nameEn }.toSet()
        remainingLots = AuctionRules.preserveQueueAfterHiddenReward(
            remainingLots = remainingLots,
            hiddenPlayer = hidden,
            occupiedNames = occupiedNames
        )
        if (toUser) hiddenPlayers = hiddenPlayers + hidden else aiHiddenPlayers = aiHiddenPlayers + hidden
        revealPlayer = hidden
        revealCaption = if (toUser) localizedText(english, "اللاعب المخفي بتاعك", "Your hidden bonus player")
            else localizedText(english, "اللاعب المخفي للخصم", "AI hidden bonus player")
        sound.play(Sfx.HiddenReveal)
        return hidden
    }

    fun startCoachAuction() {
        if (coachAuctionStarted || coachAuctionActive || ended) return
        coachAuctionStarted = true
        val nextCoach = CoachDatabase.all
            .filter { CoachAuctionRules.openingPrice(it) <= maxOf(budget, aiBudget) }
            .randomOrNull() ?: run { startPostAuctionCards(); return }
        coachLot = nextCoach
        val opening = CoachAuctionRules.openingPrice(nextCoach)
        coachCurrentBid = opening - 1
        coachBidDraft = opening
        coachAiCeiling = CoachAuctionRules.aiCeiling(nextCoach, opening, aiBudget, aiDifficulty)
        coachAiLeading = false
        coachAuctionActive = true
        message = localizedText(english, "بعد اكتمال اللاعبين، بدأ مزاد المدربين.", "Player auction complete. The coach auction is now live.")
        sound.play(Sfx.Click)
    }

    fun finishCoachAuction(userWon: Boolean, price: Int) {
        val selectedCoach = coachLot ?: return
        if (!CoachAuctionRules.canPay(price, if (userWon) budget else aiBudget)) return
        if (userWon) {
            userCoach = selectedCoach
            budget -= price
            message = localizedText(english, "كسبت المدرب ${selectedCoach.nameAr} بـ$price مليون", "You won ${selectedCoach.nameEn} for $price M")
        } else {
            aiCoach = selectedCoach
            aiBudget -= price
            message = localizedText(english, "الخصم كسب المدرب ${selectedCoach.nameAr} بـ$price مليون", "The AI won ${selectedCoach.nameEn} for $price M")
        }
        coachAuctionActive = false
        coachRevealPending = true
        revealPlayer = null
        revealCaption = if (userWon) localizedText(english, "مدرب فريقك الجديد", "Your new head coach")
            else localizedText(english, "مدرب الفريق المنافس", "The rival's new head coach")
        revealSeconds = 5
        showSquadReveal = true
        sound.play(Sfx.Correct)
    }

    fun advanceRound() {
        // Hidden reward reveal gets a dramatic 3-2-1 before the card and both squads appear.
        showSquadReveal = true
        revealSeconds = 5
        coachRevealPending = false
        hiddenRevealCountdown = revealPlayer != null
        hiddenRevealCountdownNumber = 3
        sound.play(Sfx.Click)
    }

    fun passPlayerLot() {
        val activeLot = lot ?: return
        if (lotResolved) return
        lotResolved = true
        val openingPrice = AuctionRules.openingPrice(activeLot.rating)
        val settlement = AuctionRules.settleWhenUserPasses(
            currentBid = currentBid,
            openingPrice = openingPrice,
            aiIsLeading = aiIsLeading,
            aiCeiling = aiMaxForLot,
            aiBudget = aiBudget
        )
        when (settlement.winner) {
            AuctionWinner.Ai -> {
                aiBought = aiBought + (activeLot to settlement.price)
                aiBudget -= settlement.price
                grantHiddenPlayer(activeLot.position, toUser = true)
                message = if (aiIsLeading)
                    localizedText(english, "عملت Pass! الخصم كسب اللاعب بـ${settlement.price} مليون", "You passed! AI won the lot for ${settlement.price} M")
                else localizedText(english, "انسحبت من أول مزايدة، والخصم كسب اللاعب", "You passed; AI won the opening bid")
                sound.play(Sfx.Wrong)
            }
            AuctionWinner.User -> Unit
            AuctionWinner.Unsold -> {
                message = localizedText(english, "الطرفان انسحبا، اللاعب لم يُشترَ", "Both sides passed; the lot went unsold")
                sound.play(Sfx.Click)
            }
        }
        advanceRound()
    }

    LaunchedEffect(showSquadReveal, hiddenRevealCountdown) {
        if (showSquadReveal && hiddenRevealCountdown) {
            for (number in 3 downTo 1) {
                hiddenRevealCountdownNumber = number
                delay(850)
                if (!showSquadReveal || !hiddenRevealCountdown) return@LaunchedEffect
            }
            hiddenRevealCountdown = false
            return@LaunchedEffect
        }
        if (showSquadReveal && !hiddenRevealCountdown) {
            for (seconds in 5 downTo 1) {
                revealSeconds = seconds
                delay(1_000)
                if (!showSquadReveal) return@LaunchedEffect
            }
            showSquadReveal = false
            hiddenRevealCountdown = false
            if (coachRevealPending) {
                coachRevealPending = false
                startPostAuctionCards()
            } else {
                remainingLots = remainingLots.drop(1)
                revealPlayer = null
                revealCaption = ""
                wildCardActive = false
                bid = 0
                val userCount = bought.size + hiddenPlayers.size
                val aiCount = aiBought.size + aiHiddenPlayers.size
                if ((userCount >= targetCount && aiCount >= targetCount) || remainingLots.isEmpty()) {
                    startCoachAuction()
                }
            }
        }
    }
    LaunchedEffect(started, lot?.nameEn, currentBid, lotResolved, showSquadReveal, coachAuctionActive, turnTimeSeconds) {
        if (started && !ended && !showSquadReveal && !coachAuctionActive && lot != null && !lotResolved) {
            val timedLot = lot.nameEn
            for (seconds in turnTimeSeconds downTo 1) {
                turnSecondsLeft = seconds
                delay(1_000)
                if (!started || ended || showSquadReveal || coachAuctionActive || lot?.nameEn != timedLot || lotResolved) return@LaunchedEffect
            }
            if (started && !showSquadReveal && !coachAuctionActive && lot?.nameEn == timedLot && !lotResolved) {
                message = localizedText(english, "انتهى وقت المزايدة، تم الانسحاب تلقائيًا.", "Bid timer expired. You passed automatically.")
                passPlayerLot()
            }
        }
    }
    LaunchedEffect(coachAuctionActive, coachCurrentBid, coachAiLeading, showSquadReveal, turnTimeSeconds) {
        if (coachAuctionActive && !showSquadReveal) {
            val timedBid = coachCurrentBid
            for (seconds in turnTimeSeconds downTo 1) {
                turnSecondsLeft = seconds
                delay(1_000)
                if (!coachAuctionActive || showSquadReveal || coachCurrentBid != timedBid) return@LaunchedEffect
            }
            if (coachAuctionActive && coachCurrentBid == timedBid) {
                val coach = coachLot
                if (coach != null) {
                    val opening = CoachAuctionRules.openingPrice(coach)
                    val aiWins = coachAiLeading || CoachAuctionRules.canPay(opening, aiBudget)
                    val userCanPay = CoachAuctionRules.canPay(if (coachAiLeading) coachCurrentBid + 1 else opening, budget)
                    when {
                        aiWins -> finishCoachAuction(userWon = false, price = if (coachAiLeading) coachCurrentBid else opening)
                        userCanPay -> finishCoachAuction(userWon = true, price = if (coachAiLeading) coachCurrentBid + 1 else opening)
                        else -> { coachAuctionActive = false; startPostAuctionCards() }
                    }
                }
            }
        }
    }
    LaunchedEffect(startingCountdown) {
        if (startingCountdown) {
            for (number in 3 downTo 1) {
                countdownNumber = number
                delay(850)
                if (!startingCountdown) return@LaunchedEffect
            }
            startingCountdown = false
            started = true
            sound.play(Sfx.Click)
        }
    }

    LaunchedEffect(lot?.nameEn, userSquad.size, aiSquad.size, showSquadReveal, coachAuctionActive, started) {
        if (started && !showSquadReveal && !coachAuctionActive && lot != null && userSquad.size >= targetCount && aiSquad.size < targetCount && !lotResolved) {
            // Once the user's squad is full, pass automatically so the remaining lots
            // can only be taken by the rival or go unsold.
            passPlayerLot()
        }
    }

    /** Swap the stolen player for one of the attacker's players in the exact same position. */
    fun moveAiPlayerToUser(target: PlayerCard, replacement: PlayerCard): Boolean {
        if (!PostAuctionCardRules.canExchange(target, replacement)) return false
        val incomingPaid = aiBought.firstOrNull { it.first.nameEn == target.nameEn }
        val incomingBonus = aiHiddenPlayers.firstOrNull { it.nameEn == target.nameEn }
        val outgoingPaid = bought.firstOrNull { it.first.nameEn == replacement.nameEn }
        val outgoingBonus = hiddenPlayers.firstOrNull { it.nameEn == replacement.nameEn }
        if ((incomingPaid == null && incomingBonus == null) || (outgoingPaid == null && outgoingBonus == null)) return false

        if (incomingPaid != null) {
            aiBought = aiBought.filterNot { it.first.nameEn == target.nameEn }
            bought = bought + incomingPaid
        } else {
            aiHiddenPlayers = aiHiddenPlayers.filterNot { it.nameEn == target.nameEn }
            hiddenPlayers = hiddenPlayers + incomingBonus!!
        }
        if (outgoingPaid != null) {
            bought = bought.filterNot { it.first.nameEn == replacement.nameEn }
            aiBought = aiBought + outgoingPaid
        } else {
            hiddenPlayers = hiddenPlayers.filterNot { it.nameEn == replacement.nameEn }
            aiHiddenPlayers = aiHiddenPlayers + outgoingBonus!!
        }
        return true
    }

    /** The AI follows the same position-for-position exchange rule as the human player. */
    fun moveUserPlayerToAi(target: PlayerCard, replacement: PlayerCard): Boolean {
        if (!PostAuctionCardRules.canExchange(target, replacement)) return false
        val incomingPaid = bought.firstOrNull { it.first.nameEn == target.nameEn }
        val incomingBonus = hiddenPlayers.firstOrNull { it.nameEn == target.nameEn }
        val outgoingPaid = aiBought.firstOrNull { it.first.nameEn == replacement.nameEn }
        val outgoingBonus = aiHiddenPlayers.firstOrNull { it.nameEn == replacement.nameEn }
        if ((incomingPaid == null && incomingBonus == null) || (outgoingPaid == null && outgoingBonus == null)) return false

        if (incomingPaid != null) {
            bought = bought.filterNot { it.first.nameEn == target.nameEn }
            aiBought = aiBought + incomingPaid
        } else {
            hiddenPlayers = hiddenPlayers.filterNot { it.nameEn == target.nameEn }
            aiHiddenPlayers = aiHiddenPlayers + incomingBonus!!
        }
        if (outgoingPaid != null) {
            aiBought = aiBought.filterNot { it.first.nameEn == replacement.nameEn }
            bought = bought + outgoingPaid
        } else {
            aiHiddenPlayers = aiHiddenPlayers.filterNot { it.nameEn == replacement.nameEn }
            hiddenPlayers = hiddenPlayers + outgoingBonus!!
        }
        return true
    }

    fun finishPostAuctionCards() {
        if (!postAuctionCardsPhase) return
        val aiShouldSteal = aiDifficulty >= 3 || (aiDifficulty >= 1 && aiRating < userRating)
        if (!aiStealUsed && aiShouldSteal) {
            val target = userSquad
                .filter { candidate -> candidate.nameEn == userProtectedName || aiSquad.any { it.position == candidate.position } }
                .maxByOrNull { it.rating }
            if (target != null) {
                aiStealUsed = true
                when {
                    PostAuctionCardRules.isProtectedTarget(target, userProtectedName) -> {
                        message = localizedText(english, "الحماية صدّت محاولة سرقة الـAI. كارت السرقة ضاع.", "Your Shield blocked the AI's attempt. Its Steal card was wasted.")
                    }
                    else -> {
                        val replacement = aiSquad.filter { it.position == target.position }.minByOrNull { it.rating }
                        if (replacement != null && moveUserPlayerToAi(target, replacement)) {
                            message = localizedText(english, "الـAI سرق ${target.nameAr} مقابل ${replacement.nameAr} من نفس المركز.", "AI stole ${target.nameEn} and gave you ${replacement.nameEn} in the same position.")
                        } else {
                            message = localizedText(english, "الـAI لم يجد لاعبًا بديلًا في نفس المركز، وكارت السرقة ضاع.", "AI had no same-position player to exchange. Its Steal card was wasted.")
                        }
                    }
                }
            }
        }
        postAuctionCardsPhase = false
        userSelectingProtection = false
        userSelectingSteal = false
        ended = true
    }

    LaunchedEffect(postAuctionCardsPhase) {
        if (postAuctionCardsPhase) {
            for (seconds in PostAuctionCardRules.WINDOW_SECONDS downTo 1) {
                postAuctionSeconds = seconds
                delay(1_000)
                if (!postAuctionCardsPhase) return@LaunchedEffect
            }
            finishPostAuctionCards()
        }
    }

    BackHandler { onExit() }
Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f)); SoundToggles(sound)
        }
        Text(localizedText(english, "🔨 المزاد الكروي", "🔨 Football Auction"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
        if (!started && !startingCountdown) {
            Text(localizedText(english, "طريقة اللعب", "PLAY MODE"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Card(Modifier.weight(1f).clickable { oneDeviceMode = false; onlineMode = false }, colors = CardDefaults.cardColors(containerColor = if (!oneDeviceMode && !onlineMode) Gold else PanelColor), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "ضد AI", "VS AI"), color = if (!oneDeviceMode && !onlineMode) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Text(localizedText(english, "كمبيوتر", "Computer"), color = if (!oneDeviceMode && !onlineMode) DeepWine else Muted, fontSize = 9.sp)
                    }
                }
                Card(Modifier.weight(1f).clickable { oneDeviceMode = true; onlineMode = false }, colors = CardDefaults.cardColors(containerColor = if (oneDeviceMode) Gold else PanelColor), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "جهاز واحد", "ONE DEVICE"), color = if (oneDeviceMode) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Text(localizedText(english, "لاعبان", "Two players"), color = if (oneDeviceMode) DeepWine else Muted, fontSize = 9.sp)
                    }
                }
                Card(Modifier.weight(1f).clickable { onlineMode = true; oneDeviceMode = false }, colors = CardDefaults.cardColors(containerColor = if (onlineMode) Gold else PanelColor), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "أونلاين", "ONLINE"), color = if (onlineMode) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Text(localizedText(english, "غرفة", "Room"), color = if (onlineMode) DeepWine else Muted, fontSize = 9.sp)
                    }
                }
            }
        }
        if (startingCountdown) {
            CountdownStage(countdownNumber, localizedText(english, "المزاد هيبدأ", "Auction is starting"))
        } else if (!started) {
            HowToPlayCard(
                title = localizedText(english, "إزاي تكسب المزاد؟", "How to win the auction"),
                steps = if (english) listOf(
                    "Choose Classic (5 players / 100M) or Pro Max (11 players / 200M).",
                    "A player card appears with a starting price. Raise your bid by 1M, 5M or 10M.",
                    "Use Last Bid to add 3M once, Wild Card for 2M off a winning price, or Random Swap to replace one squad player for free.",
                    "Bidding alternates: you raise, then the AI responds. Keep raising until one side passes.",
                    "After a lot is settled, both line-ups appear for 5 seconds; then the next player starts automatically. The losing side receives a same-position hidden player.",
                    "After the player lots, the coach gets a separate final auction. The coach rating affects the simulated match."
                ) else listOf(
                    "اختار كلاسيك: 5 لاعبين و100 مليون، أو Pro Max: 11 لاعب و200 مليون.",
                    "هتظهر بطاقة لاعب بسعر افتتاحي. زوّد مزايدتك بمليون أو 5 أو 10 مليون.",
                    "Last Bid يزوّد 3 مليون مرة واحدة، وWild Card يخصم 2 مليون لو كسبت، وRandom Swap يبدّل لاعبًا من تشكيلتك مجانًا.",
                    "المزاد بالدور: أنت تزايد، ثم يرد الـAI، وتستمر المزايدة حتى ينسحب أحدكما.",
                    "بعد حسم كل لاعب، التشكيلتين بيظهروا 5 ثواني، وبعدها يبدأ اللاعب التالي تلقائيًا. الطرف الخاسر يحصل على لاعب مخفي من نفس المركز.",
                    "بعد مزاد اللاعبين، يبدأ مزاد منفصل للمدرب. تقييم المدرب يؤثر في نتيجة المباراة المحاكاة."
                ),
                note = localizedText(english, "بعد كل لاعب فيه كشف للتشكيلة لمدة 5 ثوانٍ، والمدرب له مزاد مستقل في النهاية.", "Each settled lot is followed by a 5-second line-up reveal; the coach has a separate final auction.")
            )
            Text(localizedText(english, "اختار نظام المزاد", "Choose auction mode"), color = Cream, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { mode ->
                    Card(Modifier.weight(1f).clickable { pro = mode }, colors = CardDefaults.cardColors(containerColor = if (pro == mode) Gold else PanelColor)) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (mode) "PRO MAX" else "CLASSIC", color = if (pro == mode) DeepWine else Cream, fontWeight = FontWeight.Black)
                            Text(if (mode) "11 ${localizedText(english, "لاعبًا", "players")} • 200M" else "5 ${localizedText(english, "لاعبين", "players")} • 100M", color = if (pro == mode) DeepWine else Muted)
                        }
                    }
                }
            }
            Text(localizedText(english, "نظام الكروت بعد المزاد", "POST-AUCTION CARD MODE"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f).clickable { cardsMode = true }, colors = CardDefaults.cardColors(containerColor = if (cardsMode) Gold else PanelColor), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(localizedText(english, "مود الكروت", "CARDS MODE"), color = if (cardsMode) DeepWine else Cream, fontWeight = FontWeight.Black)
                        Text(localizedText(english, "20 ثانية • حماية + سرقة", "20 sec • Shield + Steal"), color = if (cardsMode) DeepWine else Muted, fontSize = 10.sp)
                    }
                }
                Card(Modifier.weight(1f).clickable { cardsMode = false }, colors = CardDefaults.cardColors(containerColor = if (!cardsMode) Gold else PanelColor), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(localizedText(english, "المود الطبيعي", "NORMAL MODE"), color = if (!cardsMode) DeepWine else Cream, fontWeight = FontWeight.Black)
                        Text(localizedText(english, "من غير كروت", "No special cards"), color = if (!cardsMode) DeepWine else Muted, fontSize = 10.sp)
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(localizedText(english, "منافسة ضد الذكاء الاصطناعي", "Play against AI"), color = Cream, fontWeight = FontWeight.Bold)
                    Text(localizedText(english, "كل لاعب يدخل المزاد مرة واحدة. راقب ميزانيتك، والخصم يزايد وفق تقييم اللاعب وميزانيته ومستوى الصعوبة.", "You bid against an AI rival. It considers player rating, remaining budget and difficulty."), color = Muted, fontSize = 12.sp)
                }
            }
            Text(localizedText(english, "مستوى AI", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                AiDifficultyAr.indices.forEach { level ->
                    val selected = aiDifficulty == level
                    Card(Modifier.weight(1f).clickable { aiDifficulty = level }, colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor), shape = RoundedCornerShape(10.dp)) {
                        Text(if (english) AiDifficultyEn[level] else AiDifficultyAr[level], color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                    }
                }
            }
            TurnTimeSelector(selectedSeconds = turnTimeSeconds, onSelect = { turnTimeSeconds = it })
            Button(onClick = {
                startingCountdown = true
                countdownNumber = 3
                started = false
                postAuctionCardsPhase = false
                postAuctionSeconds = PostAuctionCardRules.WINDOW_SECONDS
                userProtectedName = null
                aiProtectedName = null
                userProtectionUsed = false
                userStealUsed = false
                aiStealUsed = false
                userSelectingProtection = false
                userSelectingSteal = false
                budget = startBudget
                aiBudget = startBudget
                bought = emptyList()
                aiBought = emptyList()
                hiddenPlayers = emptyList()
                aiHiddenPlayers = emptyList()
                remainingLots = pool
                bid = 0
                currentBid = 0
                aiIsLeading = false
                revealPlayer = null
                ended = false
                showSquadReveal = false
                coachRevealPending = false
                coachAuctionStarted = false
                coachAuctionActive = false
                coachLot = null
                userCoach = null
                aiCoach = null
                coachCurrentBid = 0
                coachBidDraft = 0
                coachAiCeiling = 0
                coachAiLeading = false
                revealPlayer = null
                message = ""
                wildCardActive = false
                scoreSubmitted = false
                saveStatus = ""
                matchResult = null
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine), modifier = Modifier.fillMaxWidth()) {
                Text(localizedText(english, "ابدأ المزاد", "Start auction"))
            }
        } else if (postAuctionCardsPhase) {
            Text(localizedText(english, "كروت ما بعد المزاد", "POST-AUCTION CARDS"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(localizedText(english, "قدامك 20 ثانية: احمِ لاعبًا واحدًا واسرق لاعبًا واحدًا من الخصم. لكل طرف كارت حماية وكارت سرقة.", "You have 20 seconds: protect one player and steal one rival player. Each side gets one Shield and one Steal."), color = Cream, fontSize = 12.sp, textAlign = TextAlign.Center)
            TurnTimerPill(postAuctionSeconds, PostAuctionCardRules.WINDOW_SECONDS, Modifier.align(Alignment.CenterHorizontally))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريقك", "YOUR TEAM"), color = Cream, fontWeight = FontWeight.Bold)
                        Text("${userSquad.size}/$targetCount", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريق AI", "AI TEAM"), color = Cream, fontWeight = FontWeight.Bold)
                        Text("${aiSquad.size}/$targetCount", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    }
                }
            }
            PremiumAbilityCard(
                symbol = "🛡️",
                title = localizedText(english, "كارت الحماية", "SHIELD CARD"),
                description = localizedText(english, "اختار لاعبًا واحدًا من تشكيلتك. لا يمكن سرقته بعد كده.", "Protect one player in your squad. The rival cannot steal this player."),
                status = if (userProtectionUsed) localizedText(english, "مستخدم", "USED") else localizedText(english, "متاح", "READY"),
                enabled = PostAuctionCardRules.canProtect(userProtectionUsed, userSquad.size)
            ) { userSelectingProtection = !userSelectingProtection }
            if (userSelectingProtection && !userProtectionUsed) {
                userSquad.forEach { candidate ->
                    PremiumPlayerChoiceCard(candidate, english) {
                        if (postAuctionCardsPhase && !userProtectionUsed) {
                            userProtectedName = candidate.nameEn
                            userProtectionUsed = true
                            userSelectingProtection = false
                            message = localizedText(english, "اتحمى ${candidate.nameAr} من السرقة.", "${candidate.nameEn} is protected from Steal.")
                            sound.play(Sfx.Correct)
                        }
                    }
                }
            }
            PremiumAbilityCard(
                symbol = "🦹",
                title = localizedText(english, "كارت السرقة", "STEAL CARD"),
                description = localizedText(english, "اسرق لاعبًا ثم أعطِ الخصم لاعبًا من نفس المركز. لو اللاعب محمي، المحاولة تفشل والكارت يضيع.", "Steal a player and give the rival one of yours in the same position. A shielded target blocks the attempt and wastes the card."),
                status = if (userStealUsed) localizedText(english, "مستخدم", "USED") else localizedText(english, "متاح", "READY"),
                enabled = PostAuctionCardRules.canSteal(userStealUsed, aiSquad, aiProtectedName) && userSquad.isNotEmpty()
            ) {
                userSelectingSteal = !userSelectingSteal
                selectedStealTarget = null
            }
            if (userSelectingSteal && !userStealUsed && selectedStealTarget == null) {
                Text(localizedText(english, "اختار لاعب الخصم. علامة الحماية لا تمنع المحاولة، لكنها هتضيّع كارت السرقة.", "Choose a rival player. A shield does not hide the target; it blocks the attempt and wastes your Steal card."), color = Cream, fontSize = 11.sp)
                aiSquad.filter { candidate ->
                    candidate.nameEn == aiProtectedName || userSquad.any { it.position == candidate.position }
                }.forEach { candidate ->
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        if (candidate.nameEn == aiProtectedName) {
                            Text(localizedText(english, "محمي بالحماية", "SHIELDED"), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        }
                        PremiumPlayerChoiceCard(candidate, english) {
                            if (postAuctionCardsPhase && !userStealUsed) {
                                if (PostAuctionCardRules.isProtectedTarget(candidate, aiProtectedName)) {
                                    userStealUsed = true
                                    userSelectingSteal = false
                                    selectedStealTarget = null
                                    message = localizedText(english, "الحماية صدّت السرقة. اللاعب فضل في فريقه وكارت السرقة ضاع.", "Shield blocked the steal. The player stays with AI and your Steal card is wasted.")
                                    sound.play(Sfx.Wrong)
                                } else {
                                    selectedStealTarget = candidate
                                    message = localizedText(english, "اختار لاعبًا من تشكيلتك في مركز ${candidate.position} عشان تبدّله باللاعب ده.", "Choose one of your ${candidate.position} players to exchange for this target.")
                                    sound.play(Sfx.Click)
                                }
                            }
                        }
                    }
                }
            } else if (userSelectingSteal && !userStealUsed && selectedStealTarget != null) {
                val target = selectedStealTarget!!
                Text(localizedText(english, "الهدف: ${target.nameAr}. اختار اللاعب اللي هتديه للخصم من نفس المركز (${target.position}).", "Target: ${target.nameEn}. Choose the player you give the rival in the same position (${target.position})."), color = Gold, fontWeight = FontWeight.Bold)
                val replacements = PostAuctionCardRules.eligibleReplacements(userSquad, target)
                if (replacements.isEmpty()) {
                    Text(localizedText(english, "مفيش لاعب عندك في نفس المركز، الكارت هيتلغى.", "You have no player in the same position. The card will be wasted."), color = Muted)
                } else {
                    replacements.forEach { replacement ->
                        PremiumPlayerChoiceCard(replacement, english) {
                            if (postAuctionCardsPhase && !userStealUsed && moveAiPlayerToUser(target, replacement)) {
                                userStealUsed = true
                                userSelectingSteal = false
                                selectedStealTarget = null
                                message = localizedText(english, "تم التبديل: كسبت ${target.nameAr} وأعطيت الخصم ${replacement.nameAr}.", "Swap complete: you took ${target.nameEn} and gave AI ${replacement.nameEn}.")
                                sound.play(Sfx.Correct)
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { selectedStealTarget = null }, modifier = Modifier.fillMaxWidth()) {
                    Text(localizedText(english, "اختار هدفًا آخر", "Choose another target"), color = Cream)
                }
            }
            if (userProtectedName != null) Text(localizedText(english, "المحمي: $userProtectedName", "Protected: $userProtectedName"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            if (aiProtectedName != null) Text(localizedText(english, "الخصم حمى لاعبًا واحدًا من تشكيلته.", "The AI has protected one player in its squad."), color = Muted, fontSize = 11.sp)
            if (message.isNotBlank()) Text(message, color = Cream, fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(onClick = { finishPostAuctionCards() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(localizedText(english, "إنهاء الكروت والنتيجة", "Finish cards and show result"), fontWeight = FontWeight.Black)
            }
        } else if (ended) {
            Text(localizedText(english, "🏆 انتهى المزاد", "🏆 Auction complete"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(localizedText(english, "نتيجة المنافسة", "Match result"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريقك", "Your team"), color = Cream)
                        Text("$userRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${userSquad.size}/$targetCount", color = Muted)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "الخصم AI", "AI rival"), color = Cream)
                        Text("$aiRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${aiSquad.size}/$targetCount", color = Muted)
                    }
                }
            }
            Text(localizedText(english, "نتيجة المباراة المحاكاة", "Simulated match result"), color = Cream, fontWeight = FontWeight.Bold)
            Text(
                matchResult?.let { "${it.userGoals}  -  ${it.opponentGoals}" } ?: localizedText(english, "جاري محاكاة المباراة…", "Simulating match…"),
                color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Black
            )
            Text(
                when {
                    matchResult == null -> localizedText(english, "جاري تجهيز النتيجة", "Preparing result")
                    matchResult!!.userWon -> localizedText(english, "👑 كسبت المباراة!", "👑 You won the match!")
                    matchResult!!.opponentWon -> localizedText(english, "الخصم كسب المباراة.", "The AI won the match.")
                    else -> localizedText(english, "المباراة انتهت بالتعادل.", "The match ended in a draw.")
                }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Text(localizedText(english, "المدرب: ${userCoach?.nameAr ?: "بدون مدرب"} • الخصم: ${aiCoach?.nameAr ?: "بدون مدرب"}", "Coach: ${userCoach?.nameEn ?: "No coach"} • Rival: ${aiCoach?.nameEn ?: "No coach"}"), color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(localizedText(english, "تأثير المدرب محسوب في محاكاة المباراة", "Coach ratings are included in the match simulation"), color = Muted, fontSize = 11.sp)
            Text(localizedText(english, "ميزانيتك المتبقية: $budget مليون", "Your remaining budget: $budget M"), color = Cream)
            Text(localizedText(english, "ميزانية الخصم المتبقية: $aiBudget مليون", "AI remaining budget: $aiBudget M"), color = Muted)
            Text(saveStatus.ifBlank { localizedText(english, "جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp)
            SquadFormationPitch(
                title = localizedText(english, "تشكيلتك على الملعب", "Your squad on the pitch"),
                players = userSquad,
                slotCount = targetCount,
                detailFor = { player -> bought.firstOrNull { it.first.nameEn == player.nameEn }?.let { "${it.second}M" } ?: localizedText(english, "هدية", "BONUS") }
            )
            SquadFormationPitch(
                title = localizedText(english, "تشكيلة الخصم", "AI squad"),
                players = aiSquad,
                slotCount = targetCount,
                detailFor = { player -> aiBought.firstOrNull { it.first.nameEn == player.nameEn }?.let { "${it.second}M" } ?: localizedText(english, "هدية", "BONUS") }
            )
            Button(onClick = { started = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(localizedText(english, "العب من جديد", "Play again"))
            }
        } else if (showSquadReveal && hiddenRevealCountdown) {
            Card(
                Modifier.fillMaxWidth().border(1.5.dp, Gold.copy(alpha = 0.8f), RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = PanelAltColor),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(localizedText(english, "اللاعب المخفي على وشك الظهور", "THE HIDDEN PLAYER IS ABOUT TO BE REVEALED"), color = Gold, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Crossfade(targetState = hiddenRevealCountdownNumber, animationSpec = tween(260), label = "hidden-player-countdown") { number ->
                        Text(number.toString(), color = Gold, fontSize = 92.sp, fontWeight = FontWeight.Black)
                    }
                    Text(localizedText(english, "3 • 2 • 1", "3 • 2 • 1"), color = Cream, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        } else if (showSquadReveal) {
            Text(localizedText(english, "التشكيلة بعد المزايدة", "Line-up after the auction"), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            TurnTimerPill(revealSeconds, 5, Modifier.align(Alignment.CenterHorizontally))
            if (coachRevealPending) {
                coachLot?.let { CoachAuctionCard(it, english, CoachAuctionRules.openingPrice(it)) }
                Text(revealCaption, color = Gold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                val winnerCoach = userCoach ?: aiCoach
                winnerCoach?.let { Text(if (english) "Won by: ${if (userCoach != null) "YOU" else "AI"}" else "الفائز بالمدرب: ${if (userCoach != null) "أنت" else "الخصم"}", color = Cream, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
            } else {
                revealPlayer?.let { PlayerReveal(it, english) }
                if (revealCaption.isNotBlank()) Text(revealCaption, color = Gold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                SquadFormationPitch(
                    title = localizedText(english, "تشكيلتك", "Your line-up"), players = userSquad,
                    slotCount = targetCount,
                    detailFor = { player -> bought.firstOrNull { it.first.nameEn == player.nameEn }?.let { "${it.second}M" } ?: localizedText(english, "مكافأة", "BONUS") }
                )
                SquadFormationPitch(
                    title = localizedText(english, "تشكيلة الخصم", "Rival line-up"), players = aiSquad,
                    slotCount = targetCount,
                    detailFor = { player -> aiBought.firstOrNull { it.first.nameEn == player.nameEn }?.let { "${it.second}M" } ?: localizedText(english, "مكافأة", "BONUS") }
                )
                Text(localizedText(english, "المزايدة التالية بعد انتهاء العد التنازلي", "Next lot starts when the countdown ends"), color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        } else if (coachAuctionActive) {
            val activeCoach = coachLot
            if (activeCoach != null) {
                Text(localizedText(english, "المزاد الأخير: المدرب", "Final auction: head coach"), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(localizedText(english, "دورك في مزايدة المدرب", "Your coach bid"), color = Cream, fontWeight = FontWeight.Bold)
                    TurnTimerPill(turnSecondsLeft, turnTimeSeconds)
                }
                HiddenCoachAuctionCard(english, CoachAuctionRules.openingPrice(activeCoach))
                Text(localizedText(english, "السعر الحالي: $coachCurrentBid مليون • ميزانيتك: $budget مليون", "Current bid: $coachCurrentBid M • Your budget: $budget M"), color = Cream, fontWeight = FontWeight.Bold)
                Text(if (coachAiLeading) localizedText(english, "الخصم متصدر، دورك ترفع أو تنسحب", "AI is leading; raise or pass") else localizedText(english, "ابدأ مزايدة المدرب", "Open the coach bidding"), color = Gold, fontWeight = FontWeight.Bold)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(localizedText(english, "مزايدتك المقترحة", "YOUR BID DRAFT"), color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("$coachBidDraft M", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = { AuctionRules.adjustUserBidDraft(coachBidDraft, -1, coachCurrentBid + 1, budget)?.let { coachBidDraft = it } }, enabled = coachBidDraft > coachCurrentBid + 1, modifier = Modifier.weight(1f)) { Text("−1", color = Cream) }
                            listOf(1, 5, 10).forEach { step ->
                                OutlinedButton(onClick = { AuctionRules.adjustUserBidDraft(coachBidDraft, step, coachCurrentBid + 1, budget)?.let { coachBidDraft = it } }, enabled = coachBidDraft + step <= budget, modifier = Modifier.weight(1f)) { Text("+$step", color = Cream) }
                            }
                        }
                        Text(localizedText(english, "الميزانية بعد المدرب: ${budget - coachBidDraft} مليون", "Budget after coach bid: ${budget - coachBidDraft} M"), color = Muted, fontSize = 11.sp)
                    }
                }
                Button(onClick = {
                    if (coachBidDraft > budget || coachBidDraft <= coachCurrentBid) {
                        message = localizedText(english, "المزايدة غير صالحة أو الميزانية غير كافية", "Invalid bid or insufficient budget")
                    } else {
                        coachCurrentBid = coachBidDraft
                        val nextAi = CoachAuctionRules.nextAiBid(coachCurrentBid, coachAiCeiling, aiBudget)
                        if (nextAi == null) finishCoachAuction(true, coachCurrentBid)
                        else {
                            coachCurrentBid = nextAi
                            coachBidDraft = (nextAi + 1).coerceAtMost(budget)
                            coachAiLeading = true
                            message = localizedText(english, "الخصم زايد للمدرب إلى $nextAi مليون", "AI raised the coach bid to $nextAi M")
                            sound.play(Sfx.Click)
                        }
                    }
                }, modifier = Modifier.fillMaxWidth(), enabled = coachBidDraft <= budget && coachBidDraft > coachCurrentBid, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                    Text(localizedText(english, "زايد على المدرب", "Bid for coach"), fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = {
                    val opening = CoachAuctionRules.openingPrice(activeCoach)
                    val aiWins = coachAiLeading || CoachAuctionRules.canPay(opening, aiBudget)
                    val userCanPay = CoachAuctionRules.canPay(if (coachAiLeading) coachCurrentBid + 1 else opening, budget)
                    when {
                        aiWins -> finishCoachAuction(userWon = false, price = if (coachAiLeading) coachCurrentBid else opening)
                        userCanPay -> finishCoachAuction(userWon = true, price = if (coachAiLeading) coachCurrentBid + 1 else opening)
                        else -> { coachAuctionActive = false; startPostAuctionCards() }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(localizedText(english, "Pass / انسحاب", "Pass / Withdraw"), color = Cream) }
                if (message.isNotBlank()) Text(message, color = Gold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        } else if (lot != null) {
            VersusTimerHud(
                userName = user.displayName?.takeIf { it.isNotBlank() } ?: user.email?.substringBefore("@") ?: "MUSTAFA",
                rivalName = "AI",
                secondsLeft = turnSecondsLeft,
                totalSeconds = turnTimeSeconds,
                caption = localizedText(english, "لاعب ${userSquad.size + 1} من $targetCount", "PLAYER ${userSquad.size + 1} OF $targetCount")
            )
            Text("$budget M  •  ${localizedText(english, "الميزانية المتبقية", "REMAINING BUDGET")}", color = Gold, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(localizedText(english, "الخصم: ${aiSquad.size} لاعب • $aiBudget مليون", "AI: ${aiSquad.size} players • $aiBudget M"), color = Muted, fontSize = 12.sp)
            LinearProgressIndicator(progress = { (userSquad.size.toFloat() / targetCount).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor)
            val openingPrice = AuctionRules.openingPrice(lot.rating)
            PremiumPlayerCard(
                player = lot,
                detail = localizedText(english, "سعر البداية: $openingPrice مليون", "Starting bid: $openingPrice M"),
                eyebrow = localizedText(english, "بطاقة اللاعب المعروض", "PLAYER ON THE BLOCK")
            )
            if (aiIsLeading) {
                Crossfade(targetState = currentBid, animationSpec = tween(220), label = "auction-current-bid") { animatedBid ->
                    Text(localizedText(english, "السعر الحالي: $animatedBid مليون", "Current highest bid: $animatedBid M"), color = Gold, fontWeight = FontWeight.Bold)
                }
            } else {
                Text(localizedText(english, "أول مزايدة تبدأ من $openingPrice مليون", "Opening bid starts at $openingPrice M"), color = Gold, fontWeight = FontWeight.Bold)
            }
            Text(if (aiIsLeading) localizedText(english, "الخصم متصدر المزاد، دورك تزايد أو تنسحب", "AI is leading. Raise or pass.") else localizedText(english, "دورك تبدأ المزايدة", "Your turn to open the bidding"), color = Cream, fontWeight = FontWeight.Bold)
            Text(
                localizedText(english, "زوّد المبلغ من الأزرار، استخدم البطاقة المناسبة لو محتاج، وبعدها ثبّت المزايدة أو اعمل Pass.", "Use the bid buttons, activate a card if needed, then confirm your bid or Pass."),
                color = Muted, fontSize = 11.sp
            )
            val minimumNextBid = AuctionRules.minimumNextUserBid(currentBid, openingPrice)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PanelColor),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(localizedText(english, "مزايدتك المقترحة", "YOUR BID DRAFT"), color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Crossfade(targetState = bid, animationSpec = tween(220), label = "auction-bid-draft") { animatedBid ->
                        Text("$animatedBid M", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    }
                    Text(
                        localizedText(english, "أقل مزايدة مسموحة: $minimumNextBid مليون", "Minimum legal bid: $minimumNextBid M"),
                        color = Muted, fontSize = 11.sp
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = {
                                AuctionRules.adjustUserBidDraft(bid, -1, minimumNextBid, budget)?.let { bid = it }
                            },
                            enabled = !lotResolved && bid > minimumNextBid,
                            modifier = Modifier.weight(1f)
                        ) { Text("−1 M", color = Cream, fontWeight = FontWeight.Bold) }
                        listOf(1, 5, 10).forEach { increment ->
                            OutlinedButton(
                                onClick = {
                                    val adjusted = AuctionRules.adjustUserBidDraft(bid, increment, minimumNextBid, budget)
                                    if (adjusted != null) bid = adjusted
                                    else message = localizedText(english, "ميزانيتك مش مكفية للمزايدة دي", "Not enough budget for this bid")
                                },
                                enabled = !lotResolved && bid + increment <= budget,
                                modifier = Modifier.weight(1f)
                            ) { Text("+$increment", color = Cream) }
                        }
                    }
                    Text(
                        localizedText(english, "السعر المعروض حاليًا: $currentBid مليون • ميزانيتك: $budget مليون", "Current price: $currentBid M • Your budget: $budget M"),
                        color = Cream, fontSize = 10.sp, textAlign = TextAlign.Center
                    )
                }
            }
            Text(localizedText(english, "الكروت الخاصة مقفولة أثناء المزايدة وتُفتح بعد نهايتها في مود الكروت فقط.", "Special cards stay locked during bidding and activate only after the auction in Cards Mode."), color = Muted, fontSize = 11.sp)
            Button(onClick = {
                if (!lotResolved) {
                val opening = openingPrice
                val proposed = bid
                if (proposed > budget) {
                    message = localizedText(english, "ميزانيتك لا تكفي للمزايدة دي", "Not enough budget for this bid")
                } else if (!AuctionRules.isValidUserBid(proposed, currentBid, opening, budget)) {
                    message = localizedText(english, "لازم تزايد أعلى من السعر الحالي", "Your bid must exceed the current price")
                } else {
                    // User has the current turn. The AI must respond with a higher bid or Pass.
                    currentBid = proposed
                    bid = proposed
                    val aiNextBid = AuctionRules.nextAiBid(currentBid, aiMaxForLot, aiLotSpendLimit)
                    if (aiNextBid == null) {
                        val settlement = AuctionRules.settleWhenAiPasses(currentBid, opening, wildCardActive)
                        lotResolved = true
                        bought = bought + (lot to settlement.price)
                        val payable = settlement.price
                        budget -= payable
                        grantHiddenPlayer(lot.position, toUser = false)
                        message = localizedText(english, "الخصم عمل Pass! كسبت المزاد بـ$payable مليون", "AI passed! You won the lot for $payable M")
                        sound.play(Sfx.Correct)
                        advanceRound()
                    } else {
                        currentBid = aiNextBid
                        aiIsLeading = true
                        message = localizedText(english, "الخصم زايد إلى $currentBid مليون. دورك!", "AI raised to $currentBid M. Your turn!")
                        bid = AuctionRules.minimumNextUserBid(currentBid, opening)
                        sound.play(Sfx.Click)
                    }
                }
                sound.vibrate(20)
                }
            }, enabled = !lotResolved, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(localizedText(english, "زايد / ثبّت السعر", "Place bid"), fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = { passPlayerLot() }, enabled = !lotResolved, modifier = Modifier.fillMaxWidth()) {
                Text(localizedText(english, "Pass / انسحاب", "Pass / Withdraw"), color = Cream)
            }
            if (message.isNotBlank()) Text(message, color = Cream, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(
                localizedText(english, "التشكيلة مخفية أثناء المزايدة • ${userSquad.size}/$targetCount لاعب", "Line-up hidden during bidding • ${userSquad.size}/$targetCount players"),
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }

}


@Composable
private fun PlayerReveal(player: PlayerCard, english: Boolean) {
    val palette = LocalElbashaPalette.current
    AnimatedVisibility(
        visible = true,
        enter = fadeIn(tween(360)) + scaleIn(initialScale = 0.72f, animationSpec = tween(360))
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier.fillMaxWidth(0.82f)
                    .border(1.5.dp, palette.gold.copy(alpha = 0.8f), RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth().background(
                        Brush.verticalGradient(listOf(palette.panelAlt, palette.panel, palette.deepWine))
                    ).padding(15.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(if (english) "PLAYER REVEALED" else "اللاعب داخل الحقيبة", color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    PlayerPortrait(player = player, modifier = Modifier.size(width = 132.dp, height = 156.dp), cornerRadius = 18)
                    Text("${player.rating} OVR", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = palette.cream, fontSize = 18.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.position}", color = palette.muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }
}
