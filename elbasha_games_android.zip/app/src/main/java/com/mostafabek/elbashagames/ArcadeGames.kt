package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase

private val ArcadePanel: Color
    @Composable get() = PanelColor

private data class ArcadeSummary(val points: Int, val correct: Int, val total: Int)

@Composable
fun GuessPlayerScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    QuickQuizScreen(
        user = user,
        database = database,
        sound = sound,
        onExit = onExit,
        titleAr = "🕵️ خمن اللاعب",
        titleEn = "🕵️ Guess the Player",
        introAr = "اقرأ التلميحات واختار اللاعب الصح. كل سؤال عليه 100 نقطة.",
        introEn = "Read the clues and identify the player. Each correct answer earns 100 points.",
        questions = GuessPlayerQuestions.items
    )
}

@Composable
fun StatsChallengeScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    QuickQuizScreen(
        user = user,
        database = database,
        sound = sound,
        onExit = onExit,
        titleAr = "📊 تحدي الإحصائيات",
        titleEn = "📊 Football Stats Challenge",
        introAr = "أرقام ونتائج من تاريخ الكرة. ركّز في البطولة والسنة قبل ما تجاوب.",
        introEn = "Historic football numbers and results. Check the tournament and year before answering.",
        questions = StatsChallengeQuestions.items
    )
}

@Composable
private fun QuickQuizScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit,
    titleAr: String,
    titleEn: String,
    introAr: String,
    introEn: String,
    questions: List<Question>
) {
    val english = LocalAppUiSettings.current.english
    var roundSeed by remember { mutableIntStateOf(0) }
    val round = remember(questions, english, roundSeed) {
        questions.shuffled().take(10).map { q ->
            val options = q.choices(english).shuffled()
            q.copy(
                text = q.prompt(english),
                options = options,
                answer = q.correctAnswer(english),
                explanation = q.explanationText(english)
            )
        }
    }
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }

    BackHandler { onExit() }
LaunchedEffect(finished) {
        if (finished) {
            ScoreRepository.submit(database, user, score) { saved ->
                saveStatus = if (saved) {
                    if (english) "Your score was added to the leaderboard ✅" else "اتحفظت نقاطك في لوحة المتصدرين ✅"
                } else {
                    if (english) "Your result is ready, but saving failed. Check Firebase setup." else "النتيجة اتحسبت، لكن حفظها فشل. راجع إعدادات Firebase."
                }
            }
        }
    }

    if (finished) {
        Column(
            Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(uiText("🏆 خلص التحدي!", "🏆 Challenge complete!"), color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(18.dp))
            Text("$score", color = Gold, fontSize = 54.sp, fontWeight = FontWeight.Black)
            Text(uiText("نقطة", "points"), color = Muted)
            Spacer(Modifier.height(10.dp))
            Text(uiText("الإجابات الصحيحة: $correct / ${round.size}", "Correct answers: $correct / ${round.size}"), color = Cream, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving your result…") }, color = Muted, textAlign = TextAlign.Center, fontSize = 12.sp)
            Spacer(Modifier.height(22.dp))
            Button(
                onClick = {
                    index = 0
                    selected = -1
                    score = 0
                    correct = 0
                    saveStatus = ""
                    roundSeed++
                    finished = false
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
            ) { Text(uiText("العب جولة جديدة", "Play another round"), fontWeight = FontWeight.Bold) }
            TextButton(onClick = onExit) { Text(uiText("الرجوع للألعاب", "Back to games"), color = Gold) }
        }
        return
    }

    val question = round[index]
    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(if (english) titleEn else titleAr, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(if (english) introEn else introAr, color = Muted, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(uiText("سؤال ${index + 1} من ${round.size}", "Question ${index + 1} of ${round.size}"), color = Cream)
            Text("⭐ $score", color = Gold, fontWeight = FontWeight.Black)
        }
        Card(colors = CardDefaults.cardColors(containerColor = ArcadePanel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text(question.text, color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        question.options.forEachIndexed { optionIndex, option ->
            val isCorrect = selected >= 0 && option == question.answer
            val isWrong = selected == optionIndex && !isCorrect
            val rowColor = when {
                selected < 0 -> ArcadePanel
                isCorrect -> LocalElbashaPalette.current.good
                isWrong -> LocalElbashaPalette.current.bad
                else -> LocalElbashaPalette.current.surface
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(rowColor)
                    .clickable(enabled = selected < 0) {
                        selected = optionIndex
                        if (option == question.answer) {
                            correct++
                            score += 100
                            sound.play(Sfx.Correct)
                            sound.vibrate(25)
                        } else {
                            sound.play(Sfx.Wrong)
                            sound.vibrate(90)
                        }
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(option, color = Cream, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (isCorrect) Text("✓", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                if (isWrong) Text("✕", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
        }
        if (selected >= 0) {
            val gotIt = question.options[selected] == question.answer
            Text(
                if (gotIt) uiText("إجابة صحيحة! +100 نقطة", "Correct! +100 points")
                else uiText("مش دي. الإجابة: ${question.answer}", "Not quite. Correct answer: ${question.answer}"),
                color = if (gotIt) LocalElbashaPalette.current.good else LocalElbashaPalette.current.bad,
                fontWeight = FontWeight.Bold
            )
            if (question.explanation.isNotBlank()) Text(question.explanation, color = Muted, fontSize = 12.sp)
            Button(
                onClick = {
                    if (index + 1 >= round.size) finished = true
                    else { index++; selected = -1 }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
            ) { Text(if (index + 1 >= round.size) uiText("النتيجة 🏆", "See results 🏆") else uiText("السؤال التالي ←", "Next question →"), fontWeight = FontWeight.Bold) }
        }
    }
}

private object BrushCompat {
    @Composable fun background() = androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Wine, DeepWine))
}

private object GuessPlayerQuestions {
    val items = listOf(
        q("g1", "أنا أرجنتيني، فزت بكأس العالم 2022، ولعبت معظم مسيرتي مع برشلونة. مين أنا؟", "ليونيل ميسي", listOf("دييجو مارادونا", "أنخيل دي ماريا", "سيرجيو أجويرو"), "I am Argentine, won the 2022 World Cup, and spent much of my career at Barcelona. Who am I?", "Lionel Messi", listOf("Diego Maradona", "Ángel Di María", "Sergio Agüero")),
        q("g2", "أنا مصري، جناح أيمن، وفزت بدوري أبطال أوروبا مع ليفربول سنة 2019. مين أنا؟", "محمد صلاح", listOf("محمد النني", "أحمد حجازي", "رمضان صبحي"), "I am Egyptian, a right winger, and won the Champions League with Liverpool in 2019. Who am I?", "Mohamed Salah", listOf("Mohamed Elneny", "Ahmed Hegazi", "Ramadan Sobhi")),
        q("g3", "أنا برتغالي، لعبت لريال مدريد ومانشستر يونايتد، وارتديت الرقم 7. مين أنا؟", "كريستيانو رونالدو", listOf("لويس فيجو", "برونو فيرنانديز", "ديكو"), "I am Portuguese, played for Real Madrid and Manchester United, and wore number 7. Who am I?", "Cristiano Ronaldo", listOf("Luís Figo", "Bruno Fernandes", "Deco")),
        q("g4", "أنا لاعب فرنسي، سجّلت هاتريك في نهائي مونديال 2022 رغم خسارة فريقي. مين أنا؟", "كيليان مبابي", listOf("كريم بنزيما", "أنطوان جريزمان", "أوليفييه جيرو"), "I am French and scored a hat-trick in the 2022 World Cup final, despite my team's defeat. Who am I?", "Kylian Mbappé", listOf("Karim Benzema", "Antoine Griezmann", "Olivier Giroud")),
        q("g5", "أنا برازيلي، اشتهرت بالمراوغات والمهارات، وفزت بكأس العالم 2002. مين أنا؟", "رونالدينيو", listOf("كاكا", "ريفالدو", "روبرتو كارلوس"), "I am Brazilian, famous for tricks and dribbling, and won the 2002 World Cup. Who am I?", "Ronaldinho", listOf("Kaká", "Rivaldo", "Roberto Carlos")),
        q("g6", "أنا لاعب فرنسي من أصول جزائرية، فزت بالكرة الذهبية 1998. مين أنا؟", "زين الدين زيدان", listOf("تييري هنري", "فرانك ريبيري", "باتريك فييرا"), "I am French with Algerian roots and won the 1998 Ballon d'Or. Who am I?", "Zinedine Zidane", listOf("Thierry Henry", "Franck Ribéry", "Patrick Vieira")),
        q("g7", "أنا لاعب إيفواري، قُدت تشيلسي وكنت مهاجمًا قويًا، وفزت بدوري الأبطال 2012. مين أنا؟", "ديدييه دروجبا", listOf("يايا توريه", "صامويل إيتو", "سيدو دومبيا"), "I am Ivorian, led Chelsea's attack, and won the Champions League in 2012. Who am I?", "Didier Drogba", listOf("Yaya Touré", "Samuel Eto'o", "Seydou Doumbia")),
        q("g8", "أنا كاميروني، لعبت لبرشلونة وإنتر ميلان، وفزت بدوري الأبطال مع إنتر سنة 2010. مين أنا؟", "صامويل إيتو", listOf("روجيه ميلا", "أندريه أونانا", "إريك ماكسيم تشوبو موتينغ"), "I am Cameroonian, played for Barcelona and Inter, and won the 2010 Champions League with Inter. Who am I?", "Samuel Eto'o", listOf("Roger Milla", "André Onana", "Eric Maxim Choupo-Moting")),
        q("g9", "أنا حارس إيطالي أسطوري، لعبت ليوفنتوس ورفعت كأس العالم 2006. مين أنا؟", "جانلويجي بوفون", listOf("إيكر كاسياس", "ديدا", "مانويل نوير"), "I am an Italian legendary goalkeeper, played for Juventus, and lifted the 2006 World Cup. Who am I?", "Gianluigi Buffon", listOf("Iker Casillas", "Dida", "Manuel Neuer")),
        q("g10", "أنا لاعب وسط إسباني، اشتهرت بالتمريرات القصيرة وفزت بكأس العالم 2010. مين أنا؟", "تشافي", listOf("سيرجيو راموس", "فرناندو توريس", "دافيد فيا"), "I am a Spanish midfielder known for short passing and won the 2010 World Cup. Who am I?", "Xavi", listOf("Sergio Ramos", "Fernando Torres", "David Villa")),
        q("g11", "أنا مهاجم برازيلي، سجّلت هدفين في نهائي كأس العالم 2002. مين أنا؟", "رونالدو نازاريو", listOf("ريفالدو", "رونالدينيو", "كاكا"), "I am a Brazilian striker who scored twice in the 2002 World Cup final. Who am I?", "Ronaldo Nazário", listOf("Rivaldo", "Ronaldinho", "Kaká")),
        q("g12", "أنا لاعب مصري، صانع ألعاب سابق في الأهلي، ولقبي الماجيكو. مين أنا؟", "محمد أبو تريكة", listOf("محمد بركات", "حسام غالي", "عماد متعب"), "I am a former Egyptian playmaker for Al Ahly, nicknamed El Magico. Who am I?", "Mohamed Aboutrika", listOf("Mohamed Barakat", "Hossam Ghaly", "Emad Moteab"))
    )
}

private object StatsChallengeQuestions {
    val items = listOf(
        q("st1", "في مونديال 1958، مين سجل أهداف أكتر: جوست فونتين ولا بيليه؟", "جوست فونتين", listOf("بيليه", "الاتنين نفس العدد", "ولا واحد فيهم سجل"), "At the 1958 World Cup, who scored more: Just Fontaine or Pelé?", "Just Fontaine", listOf("Pelé", "They scored the same", "Neither scored")),
        q("st2", "كام هدف سجّل جوست فونتين في كأس العالم 1958؟", "13", listOf("9", "11", "15"), "How many goals did Just Fontaine score at the 1958 World Cup?", "13", listOf("9", "11", "15")),
        q("st3", "كام هدف سجّل هاري كين في مونديال 2018؟", "6", listOf("4", "5", "8"), "How many goals did Harry Kane score at the 2018 World Cup?", "6", listOf("4", "5", "8")),
        q("st4", "كام هدف سجّل كيليان مبابي في مونديال 2022؟", "8", listOf("5", "6", "7"), "How many goals did Kylian Mbappé score at the 2022 World Cup?", "8", listOf("5", "6", "7")),
        q("st5", "في سنة 2012، مين سجّل أهداف أكتر في السنة الميلادية: ميسي ولا رونالدو؟", "ميسي", listOf("رونالدو", "الاتنين نفس العدد", "نيمار"), "In calendar year 2012, who scored more goals: Messi or Ronaldo?", "Messi", listOf("Ronaldo", "They scored the same", "Neymar")),
        q("st6", "نتيجة نهائي دوري الأبطال 2005 بعد الوقت الإضافي كانت كام؟", "3-3", listOf("2-1", "3-2", "4-3"), "What was the score after extra time in the 2005 Champions League final?", "3-3", listOf("2-1", "3-2", "4-3")),
        q("st7", "كام هدف سجّلت ألمانيا في فوزها الشهير 7-1 على البرازيل؟", "7", listOf("5", "6", "8"), "How many goals did Germany score in the famous 7-1 win over Brazil?", "7", listOf("5", "6", "8")),
        q("st8", "في نهائي كأس العالم 2022، كام هدف سجّل ميسي؟", "2", listOf("1", "3", "4"), "How many goals did Messi score in the 2022 World Cup final?", "2", listOf("1", "3", "4")),
        q("st9", "كام هدف سجّل مبابي في نهائي كأس العالم 2022؟", "3", listOf("1", "2", "4"), "How many goals did Mbappé score in the 2022 World Cup final?", "3", listOf("1", "2", "4")),
        q("st10", "في نهائي يورو 2016، البرتغال فازت على فرنسا بنتيجة كام؟", "1-0", listOf("2-0", "2-1", "1-1"), "What was Portugal's score against France in the Euro 2016 final?", "1-0", listOf("2-0", "2-1", "1-1")),
        q("st11", "كام دقيقة استمر الوقت الأصلي في مباراة كرة قدم كاملة؟", "90", listOf("80", "100", "120"), "How many minutes are in normal football playing time?", "90", listOf("80", "100", "120")),
        q("st12", "كام متر بين علامة الجزاء وخط المرمى؟", "11", listOf("9", "10", "12"), "How many metres separate the penalty mark from the goal line?", "11", listOf("9", "10", "12"))
    )
}

private fun q(
    id: String,
    ar: String,
    answer: String,
    wrong: List<String>,
    en: String,
    answerEn: String,
    wrongEn: List<String>
) = Question(
    id = id,
    text = ar,
    options = listOf(answer) + wrong,
    answer = answer,
    difficulty = "medium",
    category = "arcade",
    textEn = en,
    optionsEn = listOf(answerEn) + wrongEn,
    answerEn = answerEn
)
