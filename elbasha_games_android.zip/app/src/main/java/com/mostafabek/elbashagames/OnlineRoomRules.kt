package com.mostafabek.elbashagames

import kotlin.random.Random

private const val ROOM_CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
const val ELBASHA_ROOM_CAPACITY = 4

/** Pure room-code and capacity rules shared by the online lobby and regression tests. */
object ElbashaRoomRules {
    fun normalizeCode(code: String) = code.uppercase().filter { it.isLetterOrDigit() }.take(8)
    fun validCode(code: String) = normalizeCode(code).length == 8
    fun generateCode(random: Random = Random.Default): String = buildString(8) { repeat(8) { append(ROOM_CODE_CHARS[random.nextInt(ROOM_CODE_CHARS.length)]) } }
    fun canJoin(memberCount: Int, alreadyMember: Boolean, capacity: Int = ELBASHA_ROOM_CAPACITY) = alreadyMember || (capacity in 2..ELBASHA_ROOM_CAPACITY && memberCount < capacity)
}
