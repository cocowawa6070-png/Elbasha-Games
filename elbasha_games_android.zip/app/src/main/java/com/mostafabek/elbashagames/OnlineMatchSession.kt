package com.mostafabek.elbashagames

import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

/** Realtime room state for actual turn-based matches. The server revision prevents stale/double moves. */
class OnlineMatchSession(
    private val database: FirebaseDatabase,
    private val user: FirebaseUser,
    val gameType: String,
    private val maxPlayers: Int
) {
    private val root = database.reference.child("onlineRooms")
    var roomCode by mutableStateOf<String?>(null)
        private set
    var roomData by mutableStateOf<Map<String, Any?>?>(null)
        private set
    var gameState by mutableStateOf<Map<String, Any?>?>(null)
        private set
    var busy by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set
    private var roomRef: DatabaseReference? = null
    private var roomListener: ValueEventListener? = null
    private var localHost = false

    val members: List<OnlineRoomMember>
        get() {
            val map = roomData?.get("members").asStringMap()
            return map.entries.mapNotNull { (uid, raw) ->
                val member = raw.asStringMap()
                if (member.isEmpty()) null else OnlineRoomMember(
                    uid = uid,
                    name = member["name"] as? String ?: "Player",
                    seat = onlineInt(member["seat"], 99),
                    ready = member["ready"] as? Boolean ?: false
                )
            }.sortedBy { it.seat }
        }
    val isHost: Boolean get() = localHost || roomData?.get("hostUid") == user.uid
    val currentTurnUid: String? get() = gameState?.get("turnUid") as? String
    val revision: Long get() = (gameState?.get("revision") as? Number)?.toLong() ?: 0L
    val phase: String get() = gameState?.get("phase") as? String ?: ""
    val data: Map<String, Any?> get() = gameState?.get("data").asStringMap()

    fun createRoom() {
        if (busy) return
        busy = true
        status = "جاري إنشاء الغرفة…"
        val code = buildString {
            repeat(8) {
                append("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[kotlin.random.Random.nextInt(32)])
            }
        }
        val name = user.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: user.email?.substringBefore("@")?.takeIf { it.isNotEmpty() }
            ?: "Player"
        val payload = mapOf(
            "hostUid" to user.uid,
            "createdAt" to ServerValue.TIMESTAMP,
            "status" to "lobby",
            "gameType" to gameType,
            "maxPlayers" to maxPlayers,
            "members" to mapOf(user.uid to mapOf(
                "name" to name.take(40), "ready" to true, "joinedAt" to ServerValue.TIMESTAMP, "seat" to 0
            ))
        )
        root.child(code).setValue(payload).addOnCompleteListener { task ->
            busy = false
            if (task.isSuccessful) {
                attach(code)
                localHost = true
                status = "الغرفة اتعملت. ابعت الكود للاعبين."
            } else status = task.exception?.localizedMessage ?: "فشل إنشاء الغرفة."
        }
    }

    fun joinRoom(rawCode: String) {
        if (busy) return
        val code = rawCode.trim().uppercase().filter { it.isLetterOrDigit() }
        if (code.length != 8) { status = "كود الغرفة لازم يكون 8 حروف أو أرقام."; return }
        busy = true
        status = "جاري الانضمام…"
        val ref = root.child(code)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                if (current.value == null) return Transaction.abort()
                if (current.child("gameType").value != gameType || current.child("status").value != "lobby") return Transaction.abort()
                val membersNode = current.child("members")
                val existing = membersNode.child(user.uid).value != null
                if (existing) return Transaction.success(current)
                val capacity = (current.child("maxPlayers").value as? Number)?.toInt() ?: maxPlayers
                if (membersNode.childrenCount >= capacity) return Transaction.abort()
                val occupied = membersNode.children.mapNotNull { (it.child("seat").value as? Number)?.toInt() }.toSet()
                val seat = (0 until capacity).firstOrNull { it !in occupied } ?: return Transaction.abort()
                val name = user.displayName?.trim()?.takeIf { it.isNotEmpty() }
                    ?: user.email?.substringBefore("@")?.takeIf { it.isNotEmpty() } ?: "Player"
                membersNode.child(user.uid).value = mapOf(
                    "name" to name.take(40), "ready" to true, "joinedAt" to ServerValue.TIMESTAMP, "seat" to seat
                )
                return Transaction.success(current)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                when {
                    error?.code == DatabaseError.PERMISSION_DENIED -> status =
                        "Firebase رفض الانضمام. انشر آخر قواعد firebase/database.rules.json في Realtime Database > Rules، وتأكد أنها على نفس مشروع Firebase المستخدم في التطبيق."
                    error != null -> status = error.message
                    committed -> { attach(code); status = "تم الانضمام للغرفة." }
                    else -> status = "الغرفة غير موجودة، أو للعبة مختلفة، أو بدأت بالفعل، أو اكتمل عددها."
                }
            }
        })
    }

    private fun attach(code: String) {
        detach()
        roomCode = code
        val ref = root.child(code)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    roomData = null; gameState = null; roomCode = null
                    status = "الغرفة اتقفلت أو لم تعد موجودة."
                    return
                }
                roomData = snapshot.value.asStringMap()
                gameState = snapshot.child("gameState").value.asStringMap().takeIf { it.isNotEmpty() }
            }
            override fun onCancelled(error: DatabaseError) { status = error.message }
        }
        roomRef = ref
        roomListener = listener
        ref.addValueEventListener(listener)
    }

    fun startMatch(initialData: Map<String, Any?>, firstTurnUid: String) {
        if (!isHost || members.size < 2 || busy) return
        busy = true
        val initial = mapOf(
            "revision" to 0L,
            "phase" to "playing",
            "turnUid" to firstTurnUid,
            "updatedAt" to System.currentTimeMillis(),
            "data" to initialData
        )
        roomRef?.updateChildren(mapOf("status" to "started", "gameState" to initial))
            ?.addOnCompleteListener { task ->
                busy = false
                status = if (task.isSuccessful) "المباراة بدأت." else task.exception?.localizedMessage ?: "تعذر بدء المباراة."
            } ?: run { busy = false; status = "الغرفة غير متصلة." }
    }

    /** Only the player whose turn is current may commit this revision. */
    fun submitTurn(nextPhase: String, nextTurnUid: String, nextData: Map<String, Any?>) {
        val code = roomCode ?: return
        if (busy) return
        busy = true
        val expectedRevision = revision
        val ref = root.child(code).child("gameState")
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                val liveRevision = (current.child("revision").value as? Number)?.toLong() ?: -1L
                val liveTurn = current.child("turnUid").value as? String
                if (!OnlineMatchRules.canCommit(
                        expectedRevision = expectedRevision,
                        actualRevision = liveRevision,
                        currentTurnUid = liveTurn,
                        actorUid = user.uid,
                        phase = current.child("phase").value as? String
                    )) return Transaction.abort()
                current.child("revision").value = liveRevision + 1L
                current.child("phase").value = nextPhase
                current.child("turnUid").value = nextTurnUid
                current.child("updatedAt").value = System.currentTimeMillis()
                current.child("data").value = nextData
                return Transaction.success(current)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                if (error != null) status = error.message
                else if (!committed) status = "الدور اتغير أو فيه حركة أحدث. تم تحديث الحالة تلقائيًا."
                else status = ""
            }
        }, false)
    }

    fun leave() {
        val ref = roomRef
        if (ref != null) {
            // A started match cannot safely continue if a participant leaves while it may be their turn.
            // Close that match for everyone instead of leaving the opponent stuck on a departed UID.
            val matchStarted = roomData?.get("status") == "started" || gameState != null
            val task = if (isHost || matchStarted) ref.removeValue()
                else ref.child("members").child(user.uid).removeValue()
            task.addOnCompleteListener { detach(); localHost = false; roomCode = null; roomData = null; gameState = null }
        } else { detach(); localHost = false; roomCode = null; roomData = null; gameState = null }
    }

    fun report(message: String) { status = message }

    fun dispose() = detach()

    private fun detach() {
        val ref = roomRef
        val listener = roomListener
        if (ref != null && listener != null) ref.removeEventListener(listener)
        roomRef = null
        roomListener = null
    }
}

data class OnlineRoomMember(val uid: String, val name: String, val seat: Int, val ready: Boolean)

@Composable
fun rememberOnlineMatchSession(database: FirebaseDatabase?, user: FirebaseUser, gameType: String, maxPlayers: Int): OnlineMatchSession? {
    if (database == null) return null
    val session = remember(database, user.uid, gameType, maxPlayers) { OnlineMatchSession(database, user, gameType, maxPlayers) }
    DisposableEffect(session) { onDispose { session.dispose() } }
    return session
}

private fun Any?.asStringMap(): Map<String, Any?> = (this as? Map<*, *>)
    ?.entries?.mapNotNull { entry -> (entry.key as? String)?.let { it to entry.value } }?.toMap()
    ?: emptyMap()

fun onlineMap(value: Any?): Map<String, Any?> = value.asStringMap()
fun onlineInt(value: Any?, default: Int = 0): Int = (value as? Number)?.toInt() ?: value?.toString()?.toIntOrNull() ?: default
fun onlineLong(value: Any?, default: Long = 0L): Long = (value as? Number)?.toLong() ?: value?.toString()?.toLongOrNull() ?: default
fun onlineString(value: Any?, default: String = ""): String = value as? String ?: default
fun onlineStringList(value: Any?): List<String> = when (value) {
    is List<*> -> value.mapNotNull { it as? String }
    is Map<*, *> -> value.entries.sortedBy { (it.key as? String)?.toIntOrNull() ?: Int.MAX_VALUE }.mapNotNull { it.value as? String }
    else -> emptyList()
}
fun onlineNameMap(value: Any?): Map<String, String> = value.asStringMap().mapNotNull { (k, v) -> (v as? String)?.let { k to it } }.toMap()
