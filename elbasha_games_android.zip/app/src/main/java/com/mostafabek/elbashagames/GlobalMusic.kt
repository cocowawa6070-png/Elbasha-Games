package com.mostafabek.elbashagames

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.tasks.Task
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val GLOBAL_MUSIC_MAX_BYTES = 60L * 1024L * 1024L

/** Metadata shared by every signed-in ELBASHA GAMES user. Audio bytes live in Firebase Storage. */
data class GlobalMusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val storagePath: String,
    val contentType: String,
    val byteSize: Long,
    val uploadedAt: Long
)

/**
 * Group-wide music service. Realtime Database carries only playlist/playback metadata;
 * Firebase Storage carries the audio file. Each device caches a downloaded song in filesDir.
 */
class GlobalMusicRepository(
    context: Context,
    private val database: FirebaseDatabase?,
    private val userUid: String,
    private val sound: SoundManager
) {
    private val app = context.applicationContext
    private val storage = runCatching { FirebaseStorage.getInstance() }.getOrNull()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val tracksReference = database?.reference?.child("globalMusic")?.child("tracks")
    private val playbackReference = database?.reference?.child("globalMusic")?.child("playback")
    private val cacheDirectory = File(app.filesDir, "global_music").apply { mkdirs() }

    var tracks by mutableStateOf<List<GlobalMusicTrack>>(emptyList())
        private set
    var currentTrackId by mutableStateOf<String?>(null)
        private set
    var globallyPlaying by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var statusMessage by mutableStateOf("")
        private set

    private var tracksListener: ValueEventListener? = null
    private var playbackListener: ValueEventListener? = null
    private var pendingPlayback: PlaybackCommand? = null
    private var downloadJob: Job? = null
    private var started = false
    private var commandRevision = ""
    private var sharedPositionMs = 0L
    private var sharedStartedAtMs = 0L
    private var sharedPlaybackRequested = false

    private data class PlaybackCommand(
        val trackId: String,
        val playing: Boolean,
        val positionMs: Long,
        val startedAtMs: Long,
        val revision: String
    )

    val isDeveloper: Boolean get() = ElbashaAccess.isDeveloper(userUid)

    fun start() {
        if (started) return
        started = true
        if (database == null || tracksReference == null || playbackReference == null) {
            statusMessage = "اتصال قاعدة البيانات غير متاح."
            return
        }
        tracksListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                tracks = snapshot.children.mapNotNull { child ->
                    val id = child.key ?: return@mapNotNull null
                    val path = child.child("storagePath").getValue(String::class.java).orEmpty()
                    val title = child.child("title").getValue(String::class.java).orEmpty()
                    if (path.isBlank() || title.isBlank()) return@mapNotNull null
                    GlobalMusicTrack(
                        id = id,
                        title = title,
                        artist = child.child("artist").getValue(String::class.java).orEmpty(),
                        durationMs = child.child("durationMs").getValue(Long::class.java) ?: 0L,
                        storagePath = path,
                        contentType = child.child("contentType").getValue(String::class.java).orEmpty(),
                        byteSize = child.child("byteSize").getValue(Long::class.java) ?: 0L,
                        uploadedAt = child.child("uploadedAt").getValue(Long::class.java) ?: 0L
                    )
                }.sortedWith(compareBy<GlobalMusicTrack> { it.uploadedAt }.thenBy { it.title.lowercase(Locale.ROOT) })
                pruneDeletedTrackCache()
                pendingPlayback?.let(::applyPlaybackCommand)
            }

            override fun onCancelled(error: DatabaseError) {
                statusMessage = "تعذر تحميل قائمة الأغاني: ${error.message}"
            }
        }
        playbackListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val command = PlaybackCommand(
                    trackId = snapshot.child("trackId").getValue(String::class.java).orEmpty(),
                    playing = snapshot.child("isPlaying").getValue(Boolean::class.java) == true,
                    positionMs = snapshot.child("positionMs").getValue(Long::class.java) ?: 0L,
                    startedAtMs = snapshot.child("startedAt").getValue(Long::class.java) ?: System.currentTimeMillis(),
                    revision = snapshot.child("revision").getValue(String::class.java).orEmpty()
                )
                pendingPlayback = command
                sharedPositionMs = command.positionMs.coerceAtLeast(0L)
                sharedStartedAtMs = command.startedAtMs.coerceAtLeast(0L)
                sharedPlaybackRequested = command.playing
                applyPlaybackCommand(command)
            }

            override fun onCancelled(error: DatabaseError) {
                statusMessage = "تعذر مزامنة تشغيل الموسيقى: ${error.message}"
            }
        }
        tracksReference.addValueEventListener(tracksListener!!)
        playbackReference.addValueEventListener(playbackListener!!)
    }

    fun onGamePageChanged(inGame: Boolean) {
        if (!inGame) pendingPlayback?.let(::applyPlaybackCommand)
    }

    fun stop() {
        tracksListener?.let { tracksReference?.removeEventListener(it) }
        playbackListener?.let { playbackReference?.removeEventListener(it) }
        tracksListener = null
        playbackListener = null
        downloadJob?.cancel()
        scope.cancel()
        sound.clearGlobalTrack()
        started = false
    }

    private fun applyPlaybackCommand(command: PlaybackCommand) {
        currentTrackId = command.trackId.takeIf { it.isNotBlank() }
        globallyPlaying = command.playing
        if (command.trackId.isBlank()) {
            downloadJob?.cancel()
            sound.clearGlobalTrack()
            return
        }

        val track = tracks.firstOrNull { it.id == command.trackId }
        if (track == null) {
            // The playlist listener may arrive after the playback listener.
            if (tracks.none { it.id == command.trackId }) sound.clearGlobalTrack()
            return
        }

        // Stop the previous song immediately when the developer switches tracks.
        // Do not let an old song keep playing while the new file is downloading.
        if (sound.globalTrackId != null && sound.globalTrackId != track.id) {
            downloadJob?.cancel()
            sound.clearGlobalTrack()
        }

        if (!command.playing) {
            downloadJob?.cancel()
            sound.updateGlobalPlayback(false, command.positionMs, command.startedAtMs)
            commandRevision = command.revision
            return
        }

        if (sound.isGlobalTrackLoaded(track.id)) {
            sound.updateGlobalPlayback(true, command.positionMs, command.startedAtMs)
            commandRevision = command.revision
            return
        }

        // Do not download large audio files while a game/online room is open.
        if (sound.isGameActive) return
        if (commandRevision == command.revision && downloadJob?.isActive == true) return
        commandRevision = command.revision
        downloadJob?.cancel()
        downloadJob = scope.launch {
            try {
                val file = ensureDownloaded(track)
                val latest = pendingPlayback
                if (latest?.revision != command.revision || !latest.playing || latest.trackId != track.id) return@launch
                sound.playGlobalTrack(
                    trackId = track.id,
                    title = track.title,
                    artist = track.artist,
                    file = file,
                    expectedPositionMs = command.positionMs,
                    startedAtMs = command.startedAtMs
                )
                statusMessage = "بتشغّل للجميع: ${track.title}"
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                statusMessage = "تعذر تنزيل الأغنية: ${error.localizedMessage ?: "خطأ غير معروف"}"
            }
        }
    }

    private suspend fun ensureDownloaded(track: GlobalMusicTrack): File = withContext(Dispatchers.IO) {
        val target = File(cacheDirectory, "${track.id}.audio")
        val expectedBytes = track.byteSize
        if (target.isFile && target.length() > 0L && (expectedBytes <= 0L || target.length() == expectedBytes)) {
            return@withContext target
        }
        target.delete()
        val temporary = File(cacheDirectory, "${track.id}.part")
        temporary.delete()
        val storageService = storage ?: throw IllegalStateException("Firebase Storage غير مهيأ")
        try {
            storageService.reference.child(track.storagePath).getFile(temporary).awaitTask()
            if (!temporary.isFile || temporary.length() == 0L) {
                throw IllegalStateException("الملف الصوتي فارغ")
            }
            if (expectedBytes > 0L && temporary.length() != expectedBytes) {
                throw IllegalStateException("حجم الأغنية بعد التنزيل غير مطابق؛ أعد المحاولة")
            }
            if (!temporary.renameTo(target)) {
                temporary.copyTo(target, overwrite = true)
                temporary.delete()
            }
        } catch (error: Exception) {
            temporary.delete()
            target.delete()
            throw error
        }
        target
    }

    private fun pruneDeletedTrackCache() {
        val validNames = tracks.mapTo(mutableSetOf()) { "${it.id}.audio" }
        scope.launch(Dispatchers.IO) {
            cacheDirectory.listFiles()?.forEach { file ->
                if (file.name.endsWith(".audio") && file.name !in validNames) file.delete()
            }
        }
    }

    fun upload(uri: Uri) {
        if (!isDeveloper) {
            statusMessage = "رفع الأغاني متاح للمطور فقط."
            return
        }
        if (busy) return
        scope.launch {
            busy = true
            statusMessage = "جاري فحص ورفع الأغنية..."
            var uploadedPath: String? = null
            var uploadedTrackId: String? = null
            var metadataSaved = false
            try {
                val metadata = withContext(Dispatchers.IO) { readAudioMetadata(uri) }
                val reference = tracksReference ?: throw IllegalStateException("قاعدة البيانات غير متاحة")
                val storageService = storage ?: throw IllegalStateException("Firebase Storage غير مهيأ")
                val id = reference.push().key ?: throw IllegalStateException("تعذر إنشاء معرّف للأغنية")
                uploadedTrackId = id
                val path = "global-music/$id.audio"
                uploadedPath = path
                val storageMetadata = StorageMetadata.Builder()
                    .setContentType(metadata.contentType)
                    .setCustomMetadata("uploadedBy", userUid)
                    .build()
                val uploadedFile = storageService.reference.child(path).putFile(uri, storageMetadata).awaitTask()
                val byteSize = uploadedFile.totalByteCount
                if (byteSize <= 0L || byteSize > GLOBAL_MUSIC_MAX_BYTES) {
                    throw IllegalStateException("حجم الملف غير صالح أو أكبر من 60 ميجابايت")
                }

                val trackData = mapOf(
                    "title" to metadata.title,
                    "artist" to metadata.artist,
                    "durationMs" to metadata.durationMs,
                    "storagePath" to path,
                    "contentType" to metadata.contentType,
                    "byteSize" to byteSize,
                    "uploadedAt" to ServerValue.TIMESTAMP
                )
                reference.child(id).setValue(trackData).awaitTask()
                metadataSaved = true
                try {
                    writePlayback(id, true, 0L)
                    statusMessage = "تم رفع ${metadata.title} وتشغيلها عند المستخدمين."
                } catch (playError: Exception) {
                    statusMessage = "تم رفع ${metadata.title}، لكن تعذر بدء التشغيل الجماعي: ${playError.localizedMessage ?: "خطأ في المزامنة"}"
                }
            } catch (error: Exception) {
                if (metadataSaved && uploadedTrackId != null) {
                    runCatching { tracksReference?.child(uploadedTrackId!!)?.removeValue()?.awaitTask() }
                }
                if (uploadedPath != null) {
                    runCatching { storage?.reference?.child(uploadedPath!!)?.delete()?.awaitTask() }
                }
                statusMessage = "فشل رفع الأغنية: ${error.localizedMessage ?: error.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun playTrack(track: GlobalMusicTrack) {
        if (!isDeveloper || busy) return
        scope.launch {
            busy = true
            try {
                writePlayback(track.id, true, 0L)
                statusMessage = "تم إرسال أمر تشغيل ${track.title} لكل المستخدمين."
            } catch (error: Exception) {
                statusMessage = "تعذر تشغيل الأغنية: ${error.localizedMessage ?: error.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun toggleGlobalPlayback() {
        if (!isDeveloper || busy) return
        val id = currentTrackId ?: tracks.firstOrNull()?.id ?: return
        scope.launch {
            busy = true
            try {
                val position = sharedPositionNow()
                writePlayback(id, !globallyPlaying, position)
            } catch (error: Exception) {
                statusMessage = "تعذر تغيير حالة التشغيل: ${error.localizedMessage ?: error.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun stopForEveryone() {
        if (!isDeveloper || busy) return
        scope.launch {
            busy = true
            try {
                writePlayback("", false, 0L)
            } catch (error: Exception) {
                statusMessage = "تعذر إيقاف الموسيقى: ${error.localizedMessage ?: error.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun playNext(delta: Int) {
        if (!isDeveloper || tracks.isEmpty() || busy) return
        val index = tracks.indexOfFirst { it.id == currentTrackId }.let { if (it < 0) 0 else it }
        val nextIndex = (index + delta + tracks.size) % tracks.size
        playTrack(tracks[nextIndex])
    }

    fun deleteTrack(track: GlobalMusicTrack) {
        if (!isDeveloper || busy) return
        scope.launch {
            busy = true
            try {
                if (currentTrackId == track.id) writePlayback("", false, 0L)
                tracksReference?.child(track.id)?.removeValue()?.awaitTask()
                storage?.reference?.child(track.storagePath)?.delete()?.awaitTask()
                withContext(Dispatchers.IO) { File(cacheDirectory, "${track.id}.audio").delete() }
                statusMessage = "تم حذف ${track.title}."
            } catch (error: Exception) {
                statusMessage = "تعذر حذف الأغنية: ${error.localizedMessage ?: error.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    private fun sharedPositionNow(): Long {
        val id = currentTrackId
        if (id != null && sound.isGlobalTrackLoaded(id)) return sound.globalPositionNow()
        val elapsed = if (sharedPlaybackRequested && sharedStartedAtMs > 0L) {
            (System.currentTimeMillis() - sharedStartedAtMs).coerceAtLeast(0L)
        } else 0L
        val absolutePosition = sharedPositionMs + elapsed
        val duration = tracks.firstOrNull { it.id == id }?.durationMs ?: 0L
        return if (duration > 0L) absolutePosition % duration else absolutePosition
    }

    private suspend fun writePlayback(trackId: String, playing: Boolean, positionMs: Long) {
        val reference = playbackReference ?: throw IllegalStateException("قاعدة البيانات غير متاحة")
        val nowRevision = "${System.currentTimeMillis()}-${trackId.hashCode()}"
        reference.setValue(
            mapOf(
                "trackId" to trackId,
                "isPlaying" to playing,
                "positionMs" to positionMs.coerceAtLeast(0L),
                "startedAt" to ServerValue.TIMESTAMP,
                "revision" to nowRevision
            )
        ).awaitTask()
    }

    private data class AudioMetadata(
        val title: String,
        val artist: String,
        val durationMs: Long,
        val contentType: String
    )

    private suspend fun readAudioMetadata(uri: Uri): AudioMetadata = withContext(Dispatchers.IO) {
        val displayName = runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: "ELBASHA_TRACK"

        val size = runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else -1L
            }
        }.getOrNull() ?: -1L
        if (size > GLOBAL_MUSIC_MAX_BYTES) throw IllegalStateException("حجم الأغنية أكبر من 60 ميجابايت")

        val retriever = MediaMetadataRetriever()
        var title: String? = null
        var artist: String? = null
        var duration = 0L
        try {
            retriever.setDataSource(app, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            runCatching { retriever.release() }
        }
        val mime = app.contentResolver.getType(uri)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"
        AudioMetadata(
            title = title?.trim()?.takeIf { it.isNotEmpty() } ?: displayName.substringBeforeLast('.'),
            artist = artist?.trim().orEmpty(),
            durationMs = duration.coerceAtLeast(0L),
            contentType = mime
        )
    }

    private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { continuation ->
        addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result) }
        addOnFailureListener { error -> if (continuation.isActive) continuation.resumeWithException(error) }
    }
}

@Composable
fun GlobalMusicAdminPanel(repository: GlobalMusicRepository) {
    val palette = LocalElbashaPalette.current
    var pendingDelete by remember { mutableStateOf<GlobalMusicTrack?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) repository.upload(uri)
    }

    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(uiText("الموسيقى الجماعية", "GROUP MUSIC"), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text(uiText("اختيار وتشغيل الأغاني لكل المستخدمين", "Choose and play songs for every user"), color = palette.muted, fontSize = 11.sp)
                }
                if (repository.busy) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = palette.gold, strokeWidth = 2.dp)
            }

            val currentTrack = repository.tracks.firstOrNull { it.id == repository.currentTrackId }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(palette.panelAlt).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text(currentTrack?.title ?: uiText("لا توجد أغنية مختارة", "No track selected"), color = palette.gold, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    if (repository.globallyPlaying) uiText("تعمل الآن عند المستخدمين", "Playing for all users") else uiText("متوقفة عند المستخدمين", "Paused for all users"),
                    color = palette.muted, fontSize = 11.sp
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Button(onClick = { repository.playNext(-1) }, enabled = repository.tracks.size > 1 && !repository.busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.panel, contentColor = palette.cream)) { Text("⏮") }
                    Button(onClick = { repository.toggleGlobalPlayback() }, enabled = currentTrack != null && !repository.busy, modifier = Modifier.weight(2f), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                        Text(if (repository.globallyPlaying) uiText("إيقاف مؤقت للجميع", "Pause for everyone") else uiText("تشغيل للجميع", "Play for everyone"), fontWeight = FontWeight.Black)
                    }
                    Button(onClick = { repository.playNext(1) }, enabled = repository.tracks.size > 1 && !repository.busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.panel, contentColor = palette.cream)) { Text("⏭") }
                }
                TextButton(onClick = { repository.stopForEveryone() }, enabled = repository.currentTrackId != null && !repository.busy, modifier = Modifier.fillMaxWidth()) {
                    Text(uiText("إيقاف الموسيقى عند الجميع", "Stop music for everyone"), color = palette.bad, fontWeight = FontWeight.Bold)
                }
            }

            Text(uiText("قائمة الأغاني", "SHARED PLAYLIST"), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 12.sp)
            if (repository.tracks.isEmpty()) {
                Text(uiText("لسه مفيش أغاني مرفوعة. أول أغنية هترفعها هتشتغل تلقائيًا عند كل المستخدمين.", "No uploaded songs yet. The first uploaded song will start automatically for everyone."), color = palette.muted, fontSize = 11.sp)
            } else {
                repository.tracks.forEach { track ->
                    val selected = track.id == repository.currentTrackId
                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) palette.panelAlt else palette.panel)
                            .border(1.dp, if (selected) palette.gold.copy(alpha = 0.65f) else palette.gold.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                            .clickable(enabled = !repository.busy) { repository.playTrack(track) }
                            .padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(Modifier.size(32.dp).clip(CircleShape).background(palette.gold.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                            Text(if (selected && repository.globallyPlaying) "♪" else "▶", color = palette.gold, fontWeight = FontWeight.Black)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(track.title, color = if (selected) palette.gold else palette.cream, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(track.artist.ifBlank { uiText("مرفوعة بواسطة المطور", "Uploaded by developer") }, color = palette.muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        TextButton(onClick = { pendingDelete = track }, enabled = !repository.busy) { Text(uiText("حذف", "Delete"), color = palette.bad, fontSize = 11.sp) }
                    }
                }
            }

            Button(
                onClick = { picker.launch(arrayOf("audio/*")) },
                enabled = !repository.busy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
            ) { Text(uiText("رفع أغنية وتشغيلها عند الجميع", "Upload song and play for everyone"), fontWeight = FontWeight.Black) }

            if (repository.statusMessage.isNotBlank()) Text(repository.statusMessage, color = palette.gold, fontSize = 11.sp)
            Text(uiText("الملفات تُرفع مرة واحدة إلى التخزين السحابي، وكل جهاز يحتفظ بنسخة داخل التطبيق بعد أول تنزيل.", "Songs are uploaded once to cloud storage; each device keeps an app-private copy after its first download."), color = palette.muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }

    pendingDelete?.let { track ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(uiText("حذف الأغنية؟", "Delete song?"), color = palette.cream, fontWeight = FontWeight.Black) },
            text = { Text(uiText("هتتشال من قائمة الجميع ومن التخزين السحابي.", "This removes the song from everyone's playlist and cloud storage."), color = palette.muted) },
            confirmButton = {
                TextButton(onClick = { repository.deleteTrack(track); pendingDelete = null }) {
                    Text(uiText("حذف", "Delete"), color = palette.bad, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text(uiText("إلغاء", "Cancel"), color = palette.gold) } },
            containerColor = palette.panel
        )
    }
}

@Composable
fun MusicDeviceControlPanel(sound: SoundManager) {
    val palette = LocalElbashaPalette.current
    Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(uiText("موسيقى القوائم", "MENU MUSIC"), color = palette.cream, fontWeight = FontWeight.Bold)
                Text(
                    uiText("المطور بيختار الأغاني ويشغلها للجميع. الزر ده بيكتمها على جهازك بس.", "The developer chooses and plays songs for everyone. This only mutes music on your device."),
                    color = palette.muted, fontSize = 10.sp, lineHeight = 14.sp
                )
            }
            Button(onClick = { sound.toggleMusic() }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = if (sound.musicOn) palette.good else palette.panelAlt, contentColor = palette.cream)) {
                Text(if (sound.musicOn) uiText("مسموعة", "ON") else uiText("مكتومة", "MUTED"), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}
