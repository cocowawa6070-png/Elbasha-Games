package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay
import kotlin.random.Random

private fun memberNameMap(members: List<OnlineRoomMember>) = members.associate { it.uid to it.name }
private fun memberUids(members: List<OnlineRoomMember>) = members.sortedBy { it.seat }.map { it.uid }
private fun playerByName(name: String): PlayerCard? = PlayerDatabase.players.firstOrNull { it.nameEn == name }
private fun indexedStrings(value: Any?): List<String> = onlineStringList(value)
private fun mapStringLists(value: Any?): Map<String, List<String>> = onlineMap(value).mapValues { indexedStrings(it.value) }
private fun mapInts(value: Any?): Map<String, Int> = onlineMap(value).mapValues { onlineInt(it.value) }
private fun onlineRows(value: Any?): List<Map<String, Any?>> = when (value) {
    is List<*> -> value.map(::onlineMap)
    is Map<*, *> -> value.entries.sortedBy { (it.key as? String)?.toIntOrNull() ?: Int.MAX_VALUE }.map { onlineMap(it.value) }
    else -> emptyList()
}
private fun appendNameMap(source: Any?, uid: String, name: String): Map<String, Any?> {
    val copy = onlineMap(source).toMutableMap()
    copy[uid] = indexedStrings(copy[uid]) + name
    return copy
}
private fun localizedPlayerName(player: PlayerCard?, english: Boolean): String = player?.let { if (english) it.nameEn else it.nameAr } ?: "-"
private fun coachByName(name: String): CoachCard? = CoachDatabase.all.firstOrNull { it.nameEn == name }

@Composable
private fun OnlineMatchLobby(
    session: OnlineMatchSession,
    title: String,
    english: Boolean,
    onStart: (List<OnlineRoomMember>) -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    var codeInput by remember(session) { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(title, color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(if (english) "Live match room • Realtime turn sync" else "غرفة مباراة مباشرة • مزامنة الأدوار لحظيًا", color = palette.muted, fontSize = 12.sp)
        Text(if (session.connected) (if (english) "Server connected" else "السيرفر متصل") else (if (english) "Server disconnected" else "السيرفر غير متصل"), color = if (session.connected) palette.gold else palette.bad, fontSize = 10.sp)
        if (session.roomCode == null) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = session::createRoom, enabled = !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                        Text(if (english) "Create online room" else "إنشاء غرفة أونلاين", fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.uppercase().filter(Char::isLetterOrDigit).take(8) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(if (english) "8-character room code" else "كود الغرفة من 8 خانات") }
                    )
                    OutlinedButton(onClick = { session.joinRoom(codeInput) }, enabled = !session.busy && codeInput.length == 8, modifier = Modifier.fillMaxWidth()) {
                        Text(if (english) "Join room" else "دخول الغرفة")
                    }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (english) "ROOM CODE" else "كود الغرفة", color = palette.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(session.roomCode.orEmpty(), color = palette.gold, fontSize = 32.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(if (english) "Players (${session.members.size}/${onlineInt(session.roomData?.get("maxPlayers"), 2)})" else "اللاعبون (${session.members.size}/${onlineInt(session.roomData?.get("maxPlayers"), 2)})", color = palette.cream, fontWeight = FontWeight.Bold)
                    session.members.forEach { member ->
                        Row(Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${member.seat + 1}.", color = palette.gold, fontWeight = FontWeight.Bold)
                            Text(member.name, color = palette.cream, modifier = Modifier.weight(1f))
                            Text(if (member.ready) (if (english) "READY" else "جاهز") else (if (english) "NOT READY" else "مش جاهز"), color = if (member.ready) palette.gold else palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            if (member.uid == session.roomData?.get("hostUid")) Text(if (english) " • HOST" else " • المضيف", color = palette.gold, fontSize = 9.sp)
                        }
                    }
                    OutlinedButton(
                        onClick = session::toggleReady,
                        enabled = !session.busy && session.roomData?.get("status") == "lobby",
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val myReady = session.isCurrentUserReady
                        Text(if (myReady) (if (english) "Cancel ready" else "إلغاء الجاهزية") else (if (english) "I'm ready" else "أنا جاهز"))
                    }
                    if (session.isHost) {
                        Button(onClick = { onStart(session.members) }, enabled = session.allReady && !session.busy && session.gameState == null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                            Text(if (english) "Start match" else "ابدأ المباراة", fontWeight = FontWeight.Black)
                        }
                        Text(if (session.allReady) (if (english) "Everyone is ready." else "كل اللاعبين جاهزين.") else (if (english) "Every player must tap I'm ready first." else "لازم كل اللاعبين يدوسوا أنا جاهز الأول."), color = palette.muted, fontSize = 10.sp)
                    } else {
                        Text(if (english) "Waiting for the host to start after everyone is ready…" else "مستني المضيف يبدأ بعد ما الكل يبقى جاهز…", color = palette.gold, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = session::leave, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Leave room" else "مغادرة الغرفة") }
                }
            }
        }
        if (session.status.isNotBlank()) Text(session.status, color = palette.bad, fontSize = 12.sp)
    }
}

@Composable
fun OnlineAuctionScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit,
    initialPro: Boolean = false,
    initialCardsMode: Boolean = true,
    setupLocked: Boolean = false
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var pro by remember { mutableStateOf(initialPro) }
    var cardsMode by remember { mutableStateOf(initialCardsMode) }
    val auctionModeId = "${if (pro) "pro_max" else "classic"}_${if (cardsMode) "cards" else "normal"}"
    val auctionOptions = remember(pro, cardsMode) { mapOf<String, Any?>("proMax" to pro, "cardsMode" to cardsMode) }
    val session = rememberOnlineMatchSession(database, user, "auction", 2, auctionModeId, auctionOptions)
    var bidDraft by remember { mutableIntStateOf(0) }
    var liveMatchDone by remember(session) { mutableStateOf(false) }
    var hiddenRevealCards by remember(session) { mutableStateOf(emptyList<Pair<String, PlayerCard>>()) }
    var hiddenRevealCountdown by remember(session) { mutableIntStateOf(0) }
    BackHandler { session?.leave(); onExit() }
    if (session == null) {
        Text(if (english) "Firebase connection unavailable." else "اتصال Firebase غير متاح.", color = palette.bad)
        return
    }
    val members = session.members
    if (session.gameState == null) {
        Column(Modifier.fillMaxSize().elbashaAtmosphere().padding(16.dp)) {
            Text(if (english) "AUCTION • ONLINE" else "المزاد • أونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
            if (!setupLocked) Text(if (english) "Choose the same auction size and post-auction mode as the local game." else "اختار حجم المزاد ومود ما بعد المزاد زي اللعب المحلي.", color = palette.muted)
            if (!setupLocked && session.roomCode == null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { value ->
                    Card(Modifier.weight(1f).clickable { pro = value }, colors = CardDefaults.cardColors(containerColor = if (pro == value) palette.gold else palette.panel), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (value) "PRO MAX" else "CLASSIC", color = if (pro == value) palette.deepWine else palette.cream, fontWeight = FontWeight.Black)
                            Text(if (value) "11 players • 200M" else "5 players • 100M", color = if (pro == value) palette.deepWine else palette.muted, fontSize = 10.sp)
                        }
                    }
                }
            }
            if (!setupLocked) Text(if (english) "POST-AUCTION MODE" else "مود ما بعد المزاد", color = palette.cream, fontWeight = FontWeight.Bold)
            if (!setupLocked && session.roomCode == null) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(true, false).forEach { value ->
                    Card(Modifier.weight(1f).clickable { cardsMode = value }, colors = CardDefaults.cardColors(containerColor = if (cardsMode == value) palette.gold else palette.panel), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (value) (if (english) "CARDS MODE" else "مود الكروت") else (if (english) "NORMAL MODE" else "المود الطبيعي"), color = if (cardsMode == value) palette.deepWine else palette.cream, fontWeight = FontWeight.Black, fontSize = 11.sp)
                            Text(if (value) (if (english) "Shield + Steal" else "حماية + سرقة") else (if (english) "No special cards" else "من غير كروت"), color = if (cardsMode == value) palette.deepWine else palette.muted, fontSize = 9.sp)
                        }
                    }
                }
            }
            val selectedModeLabel = "${if (pro) "PRO MAX" else "CLASSIC"} • ${if (cardsMode) if (english) "Cards" else "الكروت" else if (english) "Normal" else "طبيعي"}"
            OnlineMatchLobby(session, if (english) "Auction • $selectedModeLabel" else "المزاد • $selectedModeLabel", english, onStart = { joined ->
                val players = memberUids(joined).take(2)
                if (players.size < 2) return@OnlineMatchLobby
                val target = if (pro) 11 else 5
                val pool = ElbashaPositions.auctionPool(target, if (pro) 42 else 24)
                val startBudget = if (pro) 200 else 100
                val names = memberNameMap(joined)
                val initial = mapOf<String, Any?>(
                    "players" to players,
                    "names" to names,
                    "targetCount" to target,
                    "proMax" to pro,
                    "cardsMode" to cardsMode,
                    "subPhase" to "bidding",
                    "cardStep" to 0,
                    "protected" to emptyMap<String, String>(),
                    "selectedTarget" to "",
                    "budgetStart" to startBudget,
                    "budgets" to players.associateWith { startBudget },
                    "lots" to pool.map { it.nameEn },
                    "round" to 0,
                    "currentBid" to (pool.firstOrNull()?.let { AuctionRules.openingPrice(it.rating) - 1 } ?: 0),
                    "leaderUid" to "",
                    "passes" to 0,
                    "squads" to players.associateWith { emptyList<String>() },
                    "hidden" to players.associateWith { emptyList<String>() },
                    "message" to "",
                    "coachRound" to -1,
                    "coachLotName" to "",
                    "coachWinners" to emptyMap<String, Any?>(),
                    "lastReveal" to emptyList<Map<String, String>>(),
                    "lastRevealRevision" to -1L
                )
                session.startMatch(initial, players.first())
            }, onBack = { session.leave(); onExit() })
        }
        return
    }
    val data = session.data
    val players = indexedStrings(data["players"])
    if (players.size != 2 || user.uid !in players) {
        Text(if (english) "This online room has invalid player data. Leave and create a new room." else "بيانات اللاعبين في الغرفة غير سليمة. اخرج وأنشئ غرفة جديدة.", color = palette.bad)
        return
    }
    val names = onlineNameMap(data["names"])
    val round = onlineInt(data["round"])
    val target = onlineInt(data["targetCount"], 5)
    val lotNames = indexedStrings(data["lots"])
    val lot = lotNames.getOrNull(round)?.let(::playerByName)
    val budgets = mapInts(data["budgets"])
    val squads = mapStringLists(data["squads"])
    val hidden = mapStringLists(data["hidden"])
    val leaderUid = onlineString(data["leaderUid"])
    val currentBid = onlineInt(data["currentBid"])
    val subPhase = onlineString(data["subPhase"], "bidding")
    val cardsModeActive = data["cardsMode"] == true
    val cardStep = onlineInt(data["cardStep"])
    val protected = onlineNameMap(data["protected"])
    val selectedTarget = onlineString(data["selectedTarget"])
    val coachRound = onlineInt(data["coachRound"], -1)
    val coachLotName = onlineString(data["coachLotName"])
    val coachLot = coachByName(coachLotName)
    val coachWinners = onlineMap(data["coachWinners"])
    LaunchedEffect(session.revision, data["lastRevealRevision"]) {
        val revealRevision = onlineLong(data["lastRevealRevision"], -1L)
        if (revealRevision == session.revision) {
            val revealRows = onlineRows(data["lastReveal"]).mapNotNull { row ->
                val uid = onlineString(row["uid"])
                val player = playerByName(onlineString(row["name"]))
                if (uid.isBlank() || player == null) null else uid to player
            }
            if (revealRows.isNotEmpty()) {
                hiddenRevealCards = emptyList()
                for (count in 3 downTo 1) {
                    hiddenRevealCountdown = count
                    sound.play(Sfx.Beep)
                    delay(850)
                }
                hiddenRevealCountdown = 0
                sound.play(Sfx.Go)
                hiddenRevealCards = revealRows
                delay(5_400)
                hiddenRevealCards = emptyList()
            }
        }
    }
    val isMyTurn = session.currentTurnUid == user.uid && session.phase == "playing"
    val minimum = if (subPhase == "coachBidding") {
        coachLot?.let { maxOf(CoachAuctionRules.openingPrice(it), currentBid + 1) } ?: 1
    } else lot?.let { maxOf(AuctionRules.openingPrice(it.rating), currentBid + 1) } ?: 1
    LaunchedEffect(session.revision, round, currentBid, subPhase, coachLotName) { bidDraft = minimum }

    fun finalizeOnlineMatch(nextData: MutableMap<String, Any?>) {
        val finalSquadsRaw = onlineMap(nextData["squads"])
        val finalTeams = players.map { uid -> indexedStrings(finalSquadsRaw[uid]).mapNotNull(::playerByName) }
        val finalCoachWinners = onlineMap(nextData["coachWinners"])
        val firstCoach = onlineMap(finalCoachWinners[players[0]])
        val secondCoach = onlineMap(finalCoachWinners[players[1]])
        val firstBonus = (firstCoach["bonus"] as? Number)?.toDouble() ?: 0.0
        val secondBonus = (secondCoach["bonus"] as? Number)?.toDouble() ?: 0.0
        val score = MatchEngine.simulate(finalTeams[0], finalTeams[1], firstBonus, secondBonus, targetSquadSize = target)
        nextData["finalMatch"] = mapOf("userGoals" to score.userGoals, "opponentGoals" to score.opponentGoals)
        nextData["subPhase"] = "finished"
        session.submitTurn("finished", "", nextData)
    }

    fun finishAfterCoachAuctions(nextData: MutableMap<String, Any?>) {
        if (cardsModeActive) {
            nextData["subPhase"] = "protect"
            nextData["cardStep"] = 0
            nextData["protected"] = emptyMap<String, String>()
            nextData["selectedTarget"] = ""
            session.submitTurn("playing", players.first(), nextData)
        } else {
            finalizeOnlineMatch(nextData)
        }
    }

    fun continueAfterCoachRound(nextData: MutableMap<String, Any?>) {
        if (coachRound == 0) {
            val secondCoach = CoachDatabase.randomCoach(setOfNotNull(coachLotName))
            if (secondCoach != null) {
                nextData["coachRound"] = 1
                nextData["coachLotName"] = secondCoach.nameEn
                nextData["currentBid"] = CoachAuctionRules.openingPrice(secondCoach) - 1
                nextData["leaderUid"] = ""
                nextData["passes"] = 0
                nextData["subPhase"] = "coachBidding"
                nextData["message"] = if (english) "The visible coach auction is over. The mystery coach is next." else "مزاد المدرب الظاهر خلص. دلوقتي مزاد المدرب الخفي."
                session.submitTurn("playing", players.first(), nextData)
            } else finishAfterCoachAuctions(nextData)
        } else finishAfterCoachAuctions(nextData)
    }

    fun settleCoachAuction(winnerUid: String?) {
        if (session.busy) return
        val nextData = data.toMutableMap()
        val nextBudgets = budgets.toMutableMap()
        val nextCoachWinners = coachWinners.toMutableMap()
        if (!winnerUid.isNullOrBlank() && coachLot != null) {
            nextBudgets[winnerUid] = ((nextBudgets[winnerUid] ?: 0) - currentBid).coerceAtLeast(0)
            val previous = onlineMap(nextCoachWinners[winnerUid])
            if (coachLot.rating >= onlineInt(previous["rating"])) {
                nextCoachWinners[winnerUid] = mapOf("name" to coachLot.nameEn, "rating" to coachLot.rating, "bonus" to coachLot.matchBonus)
            }
            nextData["message"] = if (coachRound == 0) "${names[winnerUid] ?: "Player"} won ${coachLot.nameEn} for $currentBid M." else "${names[winnerUid] ?: "Player"} won the mystery coach: ${coachLot.nameEn}."
        } else {
            nextData["message"] = if (coachRound == 0) "The visible coach went unsold." else "The mystery coach went unsold."
        }
        nextData["budgets"] = nextBudgets
        nextData["coachWinners"] = nextCoachWinners
        nextData["leaderUid"] = ""
        nextData["passes"] = 0
        continueAfterCoachRound(nextData)
    }

    fun afterPlayerLot(nextData: MutableMap<String, Any?>, nextRound: Int) {
        if (nextRound >= target) {
            val firstCoach = CoachDatabase.randomCoach()
            if (firstCoach == null) finishAfterCoachAuctions(nextData)
            else {
                nextData["coachRound"] = 0
                nextData["coachLotName"] = firstCoach.nameEn
                nextData["coachWinners"] = emptyMap<String, Any?>()
                nextData["subPhase"] = "coachBidding"
                nextData["currentBid"] = CoachAuctionRules.openingPrice(firstCoach) - 1
                nextData["leaderUid"] = ""
                nextData["passes"] = 0
                nextData["message"] = if (english) "Player lots are complete. The visible coach auction begins." else "مزاد اللاعبين خلص. بدأ مزاد المدرب الظاهر."
                session.submitTurn("playing", players.first(), nextData)
            }
        } else {
            nextData["subPhase"] = "bidding"
            session.submitTurn("playing", players.first(), nextData)
        }
    }

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { session.leave(); onExit() }) { Text(if (english) "← Exit" else "→ خروج", color = palette.gold) }
            Spacer(Modifier.weight(1f)); Text(session.roomCode.orEmpty(), color = palette.gold, fontWeight = FontWeight.Black)
        }
        Text(if (english) "ONLINE AUCTION" else "المزاد الأونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        if (hiddenRevealCountdown > 0 || hiddenRevealCards.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (english) "HIDDEN PLAYER REVEAL" else "كشف اللاعب المخفي", color = palette.gold, fontWeight = FontWeight.Black)
                    if (hiddenRevealCountdown > 0) Text(hiddenRevealCountdown.toString(), color = palette.cream, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    hiddenRevealCards.forEachIndexed { index, (ownerUid, player) ->
                        Text(if (english) "${names[ownerUid] ?: "Player"}'s reward" else "مكافأة ${names[ownerUid] ?: "اللاعب"}", color = palette.gold, fontWeight = FontWeight.Bold)
                        FlipRevealCard(player = player, english = english, size = FifaCardSize.Medium, startDelayMillis = 180 + index * 220, flipMillis = 1_700)
                    }
                }
            }
        }
        if (session.phase == "finished" || subPhase == "finished") {
            Text(if (english) "FINAL SQUADS" else "التشكيلات النهائية", color = palette.gold, fontWeight = FontWeight.Black)
            players.forEach { uid ->
                val team = squads[uid].orEmpty().mapNotNull(::playerByName)
                val total = team.sumOf { it.rating }
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(names[uid] ?: "Player", color = palette.gold, fontWeight = FontWeight.Bold)
                        Text("$total OVR", color = palette.cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        team.forEach { Text("${it.position} • ${it.nameEn} (${it.rating})${if (it.nameEn in hidden[uid].orEmpty()) " • HIDDEN" else ""}", color = palette.muted, fontSize = 11.sp) }
                    }
                }
            }
            val totals = players.map { uid -> squads[uid].orEmpty().mapNotNull(::playerByName).sumOf { it.rating } }
            val finalTeams = players.map { uid -> squads[uid].orEmpty().mapNotNull(::playerByName) }
            val coach0 = onlineMap(coachWinners[players[0]])
            val coach1 = onlineMap(coachWinners[players[1]])
            val coachBonus0 = (coach0["bonus"] as? Number)?.toDouble() ?: 0.0
            val coachBonus1 = (coach1["bonus"] as? Number)?.toDouble() ?: 0.0
            players.forEach { uid ->
                val coach = onlineMap(coachWinners[uid])
                val coachName = onlineString(coach["name"])
                if (coachName.isNotBlank()) Text("${names[uid]} • ${if (english) "Coach" else "المدرب"}: $coachName", color = palette.gold, fontSize = 11.sp)
            }
            val storedScore = onlineMap(data["finalMatch"])
            val finalMatch = if (storedScore.containsKey("userGoals") && storedScore.containsKey("opponentGoals")) {
                MatchScore(onlineInt(storedScore["userGoals"]), onlineInt(storedScore["opponentGoals"]))
            } else null
            if (!liveMatchDone && finalMatch != null) {
                LiveMatchSimulation(
                    userName = names[players[0]] ?: "Player 1",
                    opponentName = names[players[1]] ?: "Player 2",
                    userSquad = finalTeams[0],
                    opponentSquad = finalTeams[1],
                    score = finalMatch,
                    english = english,
                    sound = sound,
                    onFinished = { liveMatchDone = true; sound.play(Sfx.Win) }
                )
            } else if (finalMatch != null) {
                Text(if (finalMatch.userWon) (if (english) "${names[players[0]]} wins the simulated match" else "${names[players[0]]} كسب المباراة المحاكاة") else if (finalMatch.opponentWon) (if (english) "${names[players[1]]} wins the simulated match" else "${names[players[1]]} كسب المباراة المحاكاة") else (if (english) "Simulated match: Draw" else "المباراة المحاكاة: تعادل"), color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("${names[players[0]]}: ${finalMatch.userGoals}  -  ${finalMatch.opponentGoals}: ${names[players[1]]}", color = palette.cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
            Button(onClick = { session.leave(); onExit() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Return" else "رجوع") }
        } else if (subPhase == "coachBidding") {
            val coachOpening = coachLot?.let { CoachAuctionRules.openingPrice(it) } ?: 1
            val coachMinimum = maxOf(coachOpening, currentBid + 1)
            val visibleCoach = coachRound == 0
            Text(if (english) "COACH AUCTION • ${if (visibleCoach) "VISIBLE" else "MYSTERY"}" else "مزاد المدربين • ${if (visibleCoach) "ظاهر" else "خفي"}", color = palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
            if (visibleCoach && coachLot != null) {
                Text(coachLot.nameEn, color = palette.cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("${coachLot.styleEn} • ${coachLot.rating} OVR", color = palette.muted, fontSize = 11.sp)
            } else {
                Text(if (english) "The coach identity is hidden. Bid without seeing the name or rating." else "هوية المدرب مخفية. زايد من غير ما تعرف اسمه أو تقييمه.", color = palette.cream, fontWeight = FontWeight.Bold)
            }
            Text("${names[session.currentTurnUid] ?: "-"} • ${if (isMyTurn) if (english) "YOUR TURN" else "دورك" else if (english) "WAITING" else "في الانتظار"}", color = if (isMyTurn) palette.gold else palette.muted, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                players.forEach { uid -> Text("${names[uid]}: ${budgets[uid] ?: 0}M", color = palette.cream, fontSize = 12.sp) }
            }
            Text(if (leaderUid.isBlank()) "$coachOpening M • Opening bid" else "${names[leaderUid] ?: "-"} leads • $currentBid M", color = palette.gold, fontWeight = FontWeight.Bold)
            if (isMyTurn) {
                Text("$bidDraft M", color = palette.gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick = { bidDraft = (bidDraft - 1).coerceAtLeast(coachMinimum) }, enabled = bidDraft > coachMinimum, modifier = Modifier.weight(1f)) { Text("−1") }
                    listOf(1, 5, 10).forEach { step ->
                        OutlinedButton(onClick = { bidDraft = (bidDraft + step).coerceAtMost(budgets[user.uid] ?: 0) }, enabled = bidDraft + step <= (budgets[user.uid] ?: 0), modifier = Modifier.weight(1f)) { Text("+$step") }
                    }
                }
                Button(onClick = {
                    if (CoachAuctionRules.canPay(bidDraft, budgets[user.uid] ?: 0) && bidDraft >= coachMinimum) {
                        val other = players.first { it != user.uid }
                        val next = data.toMutableMap().apply { put("currentBid", bidDraft); put("leaderUid", user.uid); put("passes", 0); put("message", "${names[user.uid]} raised the coach bid to $bidDraft M") }
                        session.submitTurn("playing", other, next)
                        sound.play(Sfx.Coin)
                    }
                }, enabled = CoachAuctionRules.canPay(bidDraft, budgets[user.uid] ?: 0) && bidDraft >= coachMinimum && !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(if (english) "Confirm coach bid" else "زايد على المدرب", fontWeight = FontWeight.Black)
                }
                OutlinedButton(onClick = {
                    if (leaderUid.isNotBlank()) settleCoachAuction(leaderUid)
                    else {
                        val nextPasses = onlineInt(data["passes"]) + 1
                        if (nextPasses >= 2) settleCoachAuction(null)
                        else {
                            val other = players.first { it != user.uid }
                            val next = data.toMutableMap().apply { put("passes", nextPasses); put("message", "No coach bid yet. The other player may open.") }
                            session.submitTurn("playing", other, next)
                        }
                    }
                }, enabled = !session.busy, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Pass / Withdraw" else "انسحاب / Pass") }
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.muted, fontSize = 11.sp)
        } else if (subPhase in setOf("protect", "stealTarget", "stealReplacement")) {
            val actorUid = session.currentTurnUid.orEmpty()
            val actorIndex = players.indexOf(actorUid).coerceAtLeast(0)
            val defenderUid = players[1 - actorIndex]
            val actorSquad = squads[actorUid].orEmpty().mapNotNull(::playerByName)
            val defenderSquad = squads[defenderUid].orEmpty().mapNotNull(::playerByName)
            Text(if (english) "POST-AUCTION CARDS" else "كروت ما بعد المزاد", color = palette.gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("${names[actorUid] ?: "-"} • ${if (isMyTurn) if (english) "YOUR CARD TURN" else "دور كارتك" else if (english) "WAITING" else "في الانتظار"}", color = if (isMyTurn) palette.gold else palette.muted, fontWeight = FontWeight.Bold)
            when (subPhase) {
                "protect" -> {
                    Text(if (english) "Choose one player from your squad to protect." else "اختار لاعب واحد من تشكيلتك تحميه.", color = palette.cream)
                    if (isMyTurn) actorSquad.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) {
                            val nextProtected = protected.toMutableMap().apply { put(actorUid, player.nameEn) }
                            val nextData = data.toMutableMap().apply {
                                put("protected", nextProtected)
                                put("message", "${names[actorUid]} protected ${player.nameEn}")
                            }
                            val nextActor = if (actorIndex == 0) players[1] else players[0]
                            val nextPhase = if (actorIndex == 0) "protect" else "stealTarget"
                            nextData["subPhase"] = nextPhase
                            session.submitTurn("playing", nextActor, nextData)
                        }
                    }
                }
                "stealTarget" -> {
                    Text(if (english) "Choose an opponent player to steal. A protected player blocks the card." else "اختار لاعب من الخصم تسرقه. لو محمي، كارت السرقة هيتصد.", color = palette.cream)
                    val eligibleTargets = defenderSquad.filter { targetPlayer ->
                        protected[defenderUid] == targetPlayer.nameEn || actorSquad.any { owned -> owned.position == targetPlayer.position }
                    }
                    if (isMyTurn) eligibleTargets.forEach { targetPlayer ->
                        Card(Modifier.fillMaxWidth().clickable {
                            val isProtected = protected[defenderUid] == targetPlayer.nameEn
                            val nextData = data.toMutableMap().apply {
                                put("message", if (isProtected) "Shield blocked ${names[actorUid]}'s Steal card." else "${names[actorUid]} selected ${targetPlayer.nameEn}")
                                if (isProtected) {
                                    if (actorIndex == 0) put("subPhase", "stealTarget") else put("subPhase", "finished")
                                    if (actorIndex == 0) put("selectedTarget", "")
                                } else {
                                    put("subPhase", "stealReplacement")
                                    put("selectedTarget", targetPlayer.nameEn)
                                }
                            }
                            if (isProtected && actorIndex == 1) finalizeOnlineMatch(nextData)
                            else session.submitTurn("playing", if (isProtected) players[1] else actorUid, nextData)
                        }, colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(12.dp)) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${targetPlayer.position} • ${targetPlayer.nameEn}", color = palette.cream, fontWeight = FontWeight.Bold)
                                if (protected[defenderUid] == targetPlayer.nameEn) Text("🛡️", color = palette.gold)
                            }
                        }
                    }
                }
                "stealReplacement" -> {
                    val targetPlayer = playerByName(selectedTarget)
                    val replacements = if (targetPlayer == null) emptyList() else PostAuctionCardRules.eligibleReplacements(actorSquad, targetPlayer)
                    Text(if (english) "Give away a player in the exact same position as ${targetPlayer?.nameEn ?: "the target"}." else "اختار لاعب من تشكيلتك في نفس مركز ${targetPlayer?.nameAr ?: "اللاعب المستهدف"} بالضبط.", color = palette.cream)
                    if (isMyTurn && replacements.isNotEmpty()) replacements.forEach { outgoing ->
                        PremiumPlayerChoiceCard(outgoing, english) {
                            val target = targetPlayer ?: return@PremiumPlayerChoiceCard
                            val updatedSquads = squads.toMutableMap()
                            updatedSquads[actorUid] = (squads[actorUid].orEmpty() - outgoing.nameEn) + target.nameEn
                            updatedSquads[defenderUid] = (squads[defenderUid].orEmpty() - target.nameEn) + outgoing.nameEn
                            val nextData = data.toMutableMap().apply {
                                put("squads", updatedSquads)
                                put("selectedTarget", "")
                                put("message", "${names[actorUid]} exchanged ${outgoing.nameEn} for ${target.nameEn}")
                                if (actorIndex == 0) put("subPhase", "stealTarget") else put("subPhase", "finished")
                            }
                            if (actorIndex == 1) finalizeOnlineMatch(nextData)
                            else session.submitTurn("playing", players[1], nextData)
                            sound.play(Sfx.Correct)
                        }
                    }
                    if (isMyTurn && replacements.isEmpty()) {
                        Text(if (english) "No same-position replacement is available. Your Steal card is lost." else "مفيش لاعب بديل في نفس المركز؛ كارت السرقة ضاع.", color = palette.bad)
                        Button(onClick = {
                            val nextData = data.toMutableMap().apply {
                                put("selectedTarget", "")
                                put("subPhase", if (actorIndex == 0) "stealTarget" else "finished")
                            }
                            if (actorIndex == 1) finalizeOnlineMatch(nextData)
                            else session.submitTurn("playing", players[1], nextData)
                        }, enabled = !session.busy) { Text(if (english) "Continue" else "كمّل") }
                    }
                }
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.muted, fontSize = 11.sp)
        } else {
            Text(if (english) "LOT ${round + 1} OF $target" else "اللاعب ${round + 1} من $target", color = palette.cream, fontWeight = FontWeight.Bold)
            Text("${names[session.currentTurnUid] ?: "-"} • ${if (isMyTurn) if (english) "YOUR TURN" else "دورك" else if (english) "WAITING FOR OPPONENT" else "في انتظار الخصم"}", color = if (isMyTurn) palette.gold else palette.muted, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                players.forEach { uid -> Text("${names[uid]}: ${budgets[uid] ?: 0}M", color = palette.cream, fontSize = 12.sp) }
            }
            lot?.let { PremiumPlayerCard(it, detail = "${AuctionRules.openingPrice(it.rating)}M", eyebrow = if (english) "PLAYER ON THE BLOCK" else "اللاعب المعروض") }
            Text(if (leaderUid.isBlank()) "${lot?.let { AuctionRules.openingPrice(it.rating) } ?: 0}M • Opening bid" else "${names[leaderUid] ?: "-"} leads • $currentBid M", color = palette.gold, fontWeight = FontWeight.Bold)
            if (isMyTurn) {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (english) "YOUR BID" else "مزايدتك", color = palette.muted, fontWeight = FontWeight.Bold)
                        Text("$bidDraft M", color = palette.gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = { bidDraft = (bidDraft - 1).coerceAtLeast(minimum) }, enabled = bidDraft > minimum, modifier = Modifier.weight(1f)) { Text("−1") }
                            listOf(1, 5, 10).forEach { step -> OutlinedButton(onClick = { bidDraft = (bidDraft + step).coerceAtMost(budgets[user.uid] ?: 0) }, enabled = bidDraft + step <= (budgets[user.uid] ?: 0), modifier = Modifier.weight(1f)) { Text("+$step") } }
                        }
                    }
                }
                Button(onClick = {
                    if (OnlineMatchRules.validBid(bidDraft, currentBid, lot?.let { AuctionRules.openingPrice(it.rating) } ?: minimum, budgets[user.uid] ?: 0)) {
                        val next = data.toMutableMap().apply {
                            put("currentBid", bidDraft); put("leaderUid", user.uid); put("passes", 0); put("message", "${names[user.uid]} raised to $bidDraft M")
                        }
                        val other = players.firstOrNull { it != user.uid }.orEmpty()
                        session.submitTurn("playing", other, next)
                        sound.play(Sfx.Click)
                    }
                }, enabled = OnlineMatchRules.validBid(bidDraft, currentBid, lot?.let { AuctionRules.openingPrice(it.rating) } ?: minimum, budgets[user.uid] ?: 0) && !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Confirm bid" else "زايد وثبّت", fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = {
                    val other = players.firstOrNull { it != user.uid }.orEmpty()
                    val currentLeader = leaderUid
                    if (currentLeader.isNotBlank()) {
                        val newSquads = squads.toMutableMap()
                        newSquads[currentLeader] = squads[currentLeader].orEmpty() + lot!!.nameEn
                        val loser = players.first { it != currentLeader }
                        val taken = (newSquads.values.flatten() + lotNames).toSet()
                        val hiddenPlayer = PlayerNaturalPositions.randomBest(
                            PlayerDatabase.players.filter { ElbashaPositions.supports(it, lot!!.position) && it.nameEn !in taken },
                            lot!!.position
                        )?.copy(position = lot.position)
                        val revealRows = if (hiddenPlayer == null) emptyList() else listOf(mapOf("uid" to loser, "name" to hiddenPlayer.nameEn))
                        if (hiddenPlayer != null) newSquads[loser] = newSquads[loser].orEmpty() + hiddenPlayer.nameEn
                        val newHidden = hidden.toMutableMap().apply { if (hiddenPlayer != null) put(loser, hidden[loser].orEmpty() + hiddenPlayer.nameEn) }
                        val newBudgets = budgets.toMutableMap().apply { put(currentLeader, ((get(currentLeader) ?: 0) - currentBid).coerceAtLeast(0)) }
                        val nextRound = round + 1
                        val nextData = data.toMutableMap().apply {
                            put("squads", newSquads)
                            put("hidden", newHidden)
                            put("budgets", newBudgets)
                            put("round", nextRound)
                            put("currentBid", lotNames.getOrNull(nextRound)?.let { n -> playerByName(n)?.let { AuctionRules.openingPrice(it.rating) - 1 } } ?: 0)
                            put("leaderUid", "")
                            put("passes", 0)
                            put("message", "${names[currentLeader]} won ${lot.nameEn}")
                            put("lastReveal", revealRows)
                            put("lastRevealRevision", session.revision + 1L)
                        }
                        afterPlayerLot(nextData, nextRound)
                    } else {
                        val passCount = onlineInt(data["passes"]) + 1
                        if (passCount < 2) {
                            val next = data.toMutableMap().apply { put("passes", passCount); put("message", "No opening bid. Other player may bid or pass.") }
                            session.submitTurn("playing", other, next)
                        } else {
                            val taken = (squads.values.flatten() + lotNames).toMutableSet()
                            val newSquads = squads.toMutableMap()
                            val newHidden = hidden.toMutableMap()
                            val revealRows = mutableListOf<Map<String, String>>()
                            players.forEach { uid ->
                                val gift = PlayerNaturalPositions.randomBest(
                                    PlayerDatabase.players.filter { ElbashaPositions.supports(it, lot!!.position) && it.nameEn !in taken },
                                    lot!!.position
                                )?.copy(position = lot.position)
                                if (gift != null) {
                                    taken.add(gift.nameEn)
                                    newSquads[uid] = newSquads[uid].orEmpty() + gift.nameEn
                                    newHidden[uid] = newHidden[uid].orEmpty() + gift.nameEn
                                    revealRows += mapOf("uid" to uid, "name" to gift.nameEn)
                                }
                            }
                            val nextRound = round + 1
                            val next = data.toMutableMap().apply {
                                put("squads", newSquads)
                                put("hidden", newHidden)
                                put("round", nextRound)
                                put("leaderUid", "")
                                put("passes", 0)
                                put("currentBid", lotNames.getOrNull(nextRound)?.let { n -> playerByName(n)?.let { AuctionRules.openingPrice(it.rating) - 1 } } ?: 0)
                                put("message", "Both players passed. Hidden players were dealt.")
                                put("lastReveal", revealRows)
                                put("lastRevealRevision", session.revision + 1L)
                            }
                            afterPlayerLot(next, nextRound)
                        }
                    }
                    sound.play(Sfx.Correct)
                }, enabled = !session.busy, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Pass / Withdraw" else "انسحاب / Pass") }
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.muted, textAlign = TextAlign.Center)
            Text(if (english) "The bid, budgets, lot and turn are synchronized to every connected player." else "المزايدة والميزانيات واللاعب المعروض والدور متزامنين عند كل اللاعبين.", color = palette.muted, fontSize = 10.sp)
        }
    }
}

private fun encodeBuildChallenge(challenge: BuildTeamRoundChallenge): Map<String, Any?> = mapOf(
    "slot" to challenge.slot,
    "rosterFilter" to challenge.rosterFilter.name,
    "filterKey" to challenge.filterKey,
    "filterLabelAr" to challenge.filterLabelAr,
    "filterLabelEn" to challenge.filterLabelEn,
    "metric" to challenge.metric.name,
    "direction" to challenge.direction.name
)

private fun decodeBuildChallenge(raw: Any?): BuildTeamRoundChallenge? {
    val row = onlineMap(raw)
    if (row.isEmpty()) return null
    return runCatching {
        BuildTeamRoundChallenge(
            slot = onlineString(row["slot"]),
            rosterFilter = BuildTeamRosterFilter.valueOf(onlineString(row["rosterFilter"])),
            filterKey = onlineString(row["filterKey"]),
            filterLabelAr = onlineString(row["filterLabelAr"]),
            filterLabelEn = onlineString(row["filterLabelEn"]),
            metric = BuildTeamMetric.valueOf(onlineString(row["metric"])),
            direction = BuildTeamDirection.valueOf(onlineString(row["direction"]))
        )
    }.getOrNull()
}

@Composable
fun OnlineBuildTeamScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit,
    initialRosterFilter: BuildTeamRosterFilter = BuildTeamRosterFilter.RANDOM,
    setupLocked: Boolean = false
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var rosterFilter by remember { mutableStateOf(initialRosterFilter) }
    val buildModeId = "build_${rosterFilter.name.lowercase()}"
    val buildOptions = remember(rosterFilter) { mapOf<String, Any?>("rosterFilter" to rosterFilter.name, "roundCount" to 11) }
    val session = rememberOnlineMatchSession(database, user, "build", 4, buildModeId, buildOptions)
    var search by remember { mutableStateOf("") }
    BackHandler { session?.leave(); onExit() }
    if (session == null) { Text(if (english) "Firebase unavailable" else "Firebase غير متاح", color = palette.bad); return }
    val formation = remember { ElbashaPositions.formationSlots(11) }

    if (session.gameState == null) {
        Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (session.roomCode == null) {
                Text(if (english) "BUILD A TEAM • ONLINE" else "كوّن فريق • أونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                if (!setupLocked) Text(if (english) "Choose the player pool. The challenge and stat change every formation slot, just like the local game." else "اختار مجموعة اللاعبين. التحدي والإحصائية بيتغيروا في كل مركز بنفس نظام اللعب المحلي.", color = palette.muted, fontSize = 12.sp)
                if (!setupLocked && session.roomCode == null) listOf(
                    BuildTeamRosterFilter.ALL,
                    BuildTeamRosterFilter.CURRENT,
                    BuildTeamRosterFilter.RETIRED,
                    BuildTeamRosterFilter.RANDOM
                ).forEach { option ->
                    val selected = rosterFilter == option
                    Card(Modifier.fillMaxWidth().clickable { rosterFilter = option }, colors = CardDefaults.cardColors(containerColor = if (selected) palette.gold else palette.panel), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (english) option.labelEn else option.labelAr, color = if (selected) palette.deepWine else palette.cream, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (selected) Text("✓", color = palette.deepWine, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
            val selectedModeLabel = when (rosterFilter) {
                BuildTeamRosterFilter.ALL -> if (english) "All players" else "كل اللاعبين"
                BuildTeamRosterFilter.CURRENT -> if (english) "Current players" else "الحاليين"
                BuildTeamRosterFilter.RETIRED -> if (english) "Retired players" else "المعتزلين"
                BuildTeamRosterFilter.RANDOM -> if (english) "Random pool" else "اختيار عشوائي"
            }
            OnlineMatchLobby(session, if (english) "Build a Team • $selectedModeLabel" else "كوّن فريق • $selectedModeLabel", english, onStart = { joined ->
                val players = memberUids(joined).take(4)
                if (players.size !in 2..4) return@OnlineMatchLobby
                if (!BuildTeamStatRules.canBuildFullRoster(PlayerFactsDatabase.players, rosterFilter, players.size, formation)) {
                    session.report(if (english) "This player pool cannot fill all 11 positions for every player. Choose All or Random." else "مجموعة اللاعبين دي مش كفاية لملء الـ11 مركز لكل لاعب. اختار الكل أو عشوائي.")
                    return@OnlineMatchLobby
                }
                val firstChallenge = BuildTeamStatRules.randomRoundChallenge(
                    players = PlayerFactsDatabase.players,
                    slot = formation.first(),
                    selectedRosterFilter = rosterFilter,
                    usedNames = emptySet(),
                    participantCount = players.size,
                    random = Random.Default
                )
                if (firstChallenge == null) {
                    session.report(if (english) "Not enough eligible players for this player-pool setting." else "عدد اللاعبين المؤهلين مش كفاية مع الفلتر ده.")
                    return@OnlineMatchLobby
                }
                val initial = mapOf<String, Any?>(
                    "players" to players,
                    "names" to memberNameMap(joined),
                    "roundCount" to formation.size,
                    "round" to 0,
                    "turnIndex" to 0,
                    "subPhase" to "pick",
                    "rosterFilter" to rosterFilter.name,
                    "challenge" to encodeBuildChallenge(firstChallenge),
                    "challengeKeys" to listOf(firstChallenge.filterKey),
                    "picks" to players.associateWith { emptyList<Map<String, Any?>>() },
                    "message" to ""
                )
                session.startMatch(initial, players[PassAndPlayRules.pickingOrder(players.size, 0).first()])
            }, onBack = { session.leave(); onExit() })
        }
        return
    }

    val data = session.data
    val players = indexedStrings(data["players"])
    if (players.size !in 2..4 || user.uid !in players) {
        Text(if (english) "This online room has invalid player data. Leave and create a new room." else "بيانات اللاعبين في الغرفة غير سليمة. اخرج وأنشئ غرفة جديدة.", color = palette.bad)
        return
    }
    val names = onlineNameMap(data["names"])
    val roundCount = onlineInt(data["roundCount"], 11).coerceIn(1, 11)
    val round = onlineInt(data["round"]).coerceIn(0, roundCount)
    val turnIndex = onlineInt(data["turnIndex"]).coerceIn(0, players.lastIndex)
    val subPhase = onlineString(data["subPhase"], "pick")
    val challenge = decodeBuildChallenge(data["challenge"])
    val roster = runCatching { BuildTeamRosterFilter.valueOf(onlineString(data["rosterFilter"], "RANDOM")) }.getOrDefault(BuildTeamRosterFilter.RANDOM)
    val picksMap = onlineMap(data["picks"])
    val picksByUid = players.associateWith { uid ->
        val rows = when (val raw = picksMap[uid]) {
            is List<*> -> raw
            is Map<*, *> -> raw.entries.sortedBy { (it.key as? String)?.toIntOrNull() ?: Int.MAX_VALUE }.map { it.value }
            else -> emptyList()
        }
        rows.mapNotNull { raw ->
            val row = onlineMap(raw)
            val player = playerByName(onlineString(row["name"]))
            val value = onlineInt(row["value"], -1)
            if (player != null && value >= 0) BuildTeamPick(player, value) else null
        }
    }
    val usedNames = picksByUid.values.flatten().map { it.player.nameEn }.toSet()
    val eligible = challenge?.let { BuildTeamStatRules.playersForChallenge(PlayerFactsDatabase.players, it, usedNames) }.orEmpty()
    val suggestions = if (PlayerSearch.normalize(search).length >= 3) PlayerSearch.suggestions(eligible, search, 12) else emptyList()
    val roundPickOrder = PassAndPlayRules.pickingOrder(players.size, round)
    val activeUid = players.getOrNull(roundPickOrder.getOrNull(turnIndex) ?: 0).orEmpty()
    val myTurn = activeUid == user.uid && session.phase == "playing" && subPhase == "pick"
    val totals = players.map { uid -> BuildTeamStatRules.total(picksByUid[uid].orEmpty()) }
    val finished = session.phase == "finished" || round >= roundCount
    val currentRoundPicks = players.mapNotNull { uid -> picksByUid[uid].getOrNull(round) }
    val roundWinnerIndexes = if (currentRoundPicks.size == players.size && currentRoundPicks.isNotEmpty()) {
        BuildTeamStatRules.winners(currentRoundPicks.map { it.value }, challenge?.direction ?: BuildTeamDirection.HIGH)
    } else emptyList()

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { session.leave(); onExit() }) { Text(if (english) "← Exit" else "→ خروج", color = palette.gold) }
            Spacer(Modifier.weight(1f)); Text(session.roomCode.orEmpty(), color = palette.gold, fontWeight = FontWeight.Black)
        }
        Text(if (english) "BUILD A TEAM • ONLINE" else "كوّن فريق • أونلاين", color = palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Black)

        if (finished) {
            Text(if (english) "FINAL SCORE • 11 SLOTS" else "النتيجة النهائية • 11 مركز", color = palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
            players.forEachIndexed { index, uid ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(names[uid] ?: "Player", color = palette.gold, fontWeight = FontWeight.Bold)
                        Text("${totals[index]} ${if (english) "points" else "نقطة"}", color = palette.cream, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        picksByUid[uid].orEmpty().forEachIndexed { slotIndex, pick ->
                            val slot = formation.getOrNull(slotIndex) ?: pick.player.position
                            val labels = BuildTeamRules.positionLabels[slot]
                            Text("${if (english) labels?.second ?: slot else labels?.first ?: slot} • ${pick.player.nameEn} • ${pick.value}", color = palette.muted, fontSize = 10.sp)
                        }
                    }
                }
            }
            val winningIndexes = BuildTeamStatRules.winners(totals, BuildTeamDirection.HIGH)
            Text(if (winningIndexes.size == players.size) (if (english) "Draw" else "تعادل") else winningIndexes.joinToString(" • ") { names[players[it]] ?: "Player" } + if (english) " wins" else " فاز", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Button(onClick = { session.leave(); onExit() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Return" else "رجوع") }
        } else if (subPhase == "roundReveal") {
            Text(if (english) "ROUND ${round + 1} RESULT" else "نتيجة الجولة ${round + 1}", color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
            challenge?.let {
                val label = BuildTeamRules.positionLabels[it.slot]
                Text("${if (english) label?.second ?: it.slot else label?.first ?: it.slot} • ${if (english) it.filterLabelEn else it.filterLabelAr} • ${if (english) it.metric.labelEn else it.metric.labelAr}", color = palette.cream, fontWeight = FontWeight.Bold)
            }
            players.forEachIndexed { index, uid ->
                val pick = picksByUid[uid].getOrNull(round)
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(13.dp)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(names[uid] ?: "Player", color = palette.cream, fontWeight = FontWeight.Bold)
                            Text(pick?.player?.nameEn ?: "-", color = palette.muted, fontSize = 11.sp)
                        }
                        Text(pick?.value?.toString() ?: "-", color = if (index in roundWinnerIndexes) palette.gold else palette.cream, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        if (index in roundWinnerIndexes) Text("🏆", fontSize = 18.sp)
                    }
                }
            }
            val canContinue = session.currentTurnUid == user.uid && subPhase == "roundReveal"
            if (canContinue) {
                Button(onClick = {
                    val nextRound = round + 1
                    if (nextRound >= roundCount) {
                        val finalData = data.toMutableMap().apply { put("round", nextRound); put("subPhase", "finished") }
                        session.submitTurn("finished", "", finalData)
                    } else {
                        val previousKeys = onlineStringList(data["challengeKeys"]).toSet()
                        val newChallenge = BuildTeamStatRules.randomRoundChallenge(
                            players = PlayerFactsDatabase.players,
                            slot = formation[nextRound],
                            selectedRosterFilter = roster,
                            usedNames = usedNames,
                            participantCount = players.size,
                            previousFilterKeys = previousKeys,
                            random = Random.Default
                        )
                        if (newChallenge == null) {
                            val finalData = data.toMutableMap().apply { put("round", nextRound); put("subPhase", "finished") }
                            session.submitTurn("finished", "", finalData)
                        } else {
                            val nextData = data.toMutableMap().apply {
                                put("round", nextRound)
                                put("turnIndex", 0)
                                put("subPhase", "pick")
                                put("challenge", encodeBuildChallenge(newChallenge))
                                put("challengeKeys", previousKeys + newChallenge.filterKey)
                                put("message", "")
                            }
                            session.submitTurn("playing", players.first(), nextData)
                        }
                    }
                }, enabled = !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(if (round + 1 >= roundCount) (if (english) "Show final result" else "اعرض النتيجة النهائية") else (if (english) "Next position" else "المركز التالي"), fontWeight = FontWeight.Black)
                }
            } else {
                Text(if (english) "Waiting for the last player to continue…" else "في انتظار آخر لاعب يكمل الجولة…", color = palette.muted)
            }
        } else {
            if (challenge == null) {
                Text(if (english) "The challenge data is missing. Leave and create a new room." else "بيانات التحدي ناقصة. اخرج واعمل غرفة جديدة.", color = palette.bad)
                return@Column
            }
            val slotLabels = BuildTeamRules.positionLabels[challenge.slot]
            Text(if (english) "ROUND ${round + 1} OF $roundCount" else "الجولة ${round + 1} من $roundCount", color = palette.cream, fontWeight = FontWeight.Bold)
            Text("${if (english) slotLabels?.second ?: challenge.slot else slotLabels?.first ?: challenge.slot} • ${names[activeUid] ?: "-"} • ${if (myTurn) if (english) "YOUR PICK" else "اختيارك" else if (english) "WAITING FOR PLAYER" else "في انتظار اللاعب"}", color = if (myTurn) palette.gold else palette.muted, fontWeight = FontWeight.Black)
            val directionLabel = when (challenge.direction) {
                BuildTeamDirection.HIGH -> if (english) "Highest wins" else "الأعلى يكسب"
                BuildTeamDirection.LOW -> if (english) "Lowest wins" else "الأقل يكسب"
            }
            Text("${if (english) challenge.filterLabelEn else challenge.filterLabelAr} • ${if (english) challenge.metric.labelEn else challenge.metric.labelAr} • $directionLabel", color = palette.gold, fontWeight = FontWeight.Bold)
            players.forEachIndexed { index, uid ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(names[uid] ?: "Player", color = palette.cream, fontWeight = FontWeight.Bold)
                            Text("${totals[index]} ${if (english) "pts" else "نقطة"}", color = palette.gold, fontWeight = FontWeight.Black)
                        }
                        SquadFormationPitch(title = if (english) "Selected players" else "اللاعبون المختارون", players = picksByUid[uid].orEmpty().map { it.player }, slotCount = 11)
                        picksByUid[uid].getOrNull(round)?.let { pick -> Text("${pick.player.nameEn} • ${pick.value}", color = palette.muted, fontSize = 10.sp) }
                    }
                }
            }
            if (myTurn) {
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (english) "Search player (3+ letters)" else "ابحث عن لاعب (3 حروف أو أكثر)") })
                if (PlayerSearch.normalize(search).length >= 3) {
                    if (suggestions.isEmpty()) Text(if (english) "No eligible player matches this challenge." else "مفيش لاعب مطابق للتحدي.", color = palette.muted)
                    suggestions.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) {
                            val value = BuildTeamStatRules.value(player, challenge.metric) ?: return@PremiumPlayerChoiceCard
                            val nextPicks = picksByUid.mapValues { (_, list) -> list.map { pick -> mapOf("name" to pick.player.nameEn, "value" to pick.value) } }.toMutableMap()
                            nextPicks[user.uid] = nextPicks[user.uid].orEmpty() + mapOf("name" to player.nameEn, "value" to value)
                            val lastPicker = turnIndex >= players.lastIndex
                            val nextTurnIndex = if (lastPicker) turnIndex else turnIndex + 1
                            val nextSubPhase = if (lastPicker) "roundReveal" else "pick"
                            val nextData = data.toMutableMap().apply {
                                put("picks", nextPicks)
                                put("turnIndex", nextTurnIndex)
                                put("subPhase", nextSubPhase)
                                put("message", "${names[user.uid]} picked ${player.nameEn} (${value})")
                            }
                            val nextUid = if (lastPicker) user.uid else players[roundPickOrder[nextTurnIndex]]
                            session.submitTurn("playing", nextUid, nextData)
                            search = ""
                            sound.play(Sfx.Correct)
                        }
                    }
                } else {
                    Text(if (english) "This position uses its own changing challenge and statistic, just like the local Build a Team game." else "المركز ده له تحدي وإحصائية متغيرين، زي لعبة كوّن فريق المحلية.", color = palette.muted, fontSize = 11.sp)
                }
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.gold, fontSize = 11.sp)
        }
    }
}

// Deal or No Deal keeps every participant's case hand and final-card hand in a
// separate, owner-readable Firebase path. Only revealed picks enter public gameState.
private const val ONLINE_DEAL_CASE_SEPARATOR = "\u001f"

private fun encodeOnlineDealCases(cases: List<PlayerCard>): String = cases.joinToString(ONLINE_DEAL_CASE_SEPARATOR) {
    "${it.nameEn}~${it.position}"
}

private fun decodeOnlineDealCases(raw: Any?): List<PlayerCard> = onlineString(raw)
    .split(ONLINE_DEAL_CASE_SEPARATOR)
    .mapNotNull { item ->
        val parts = item.split('~', limit = 2)
        if (parts.size != 2) null else playerByName(parts[0])?.copy(position = parts[1])
    }

private fun onlineDealCoachData(coach: CoachCard): Map<String, Any?> = mapOf(
    "nameEn" to coach.nameEn,
    "nameAr" to coach.nameAr,
    "rating" to coach.rating,
    "styleEn" to coach.styleEn,
    "styleAr" to coach.styleAr
)

private fun onlineDealCoach(raw: Any?): CoachCard? {
    val row = onlineMap(raw)
    val name = onlineString(row["nameEn"])
    return CoachDatabase.all.firstOrNull { it.nameEn == name }
}

private fun writeOnlineDealSecrets(
    database: FirebaseDatabase,
    roomCode: String,
    secrets: Map<String, Map<String, Any?>>,
    onComplete: (String?) -> Unit
) {
    val entries = secrets.entries.toList()
    fun writeAt(index: Int) {
        if (index >= entries.size) {
            onComplete(null)
            return
        }
        val (uid, payload) = entries[index]
        database.reference.child("onlinePrivate").child(roomCode).child(uid).setValue(payload)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) writeAt(index + 1)
                else onComplete(task.exception?.localizedMessage ?: "Could not prepare private cases.")
            }
    }
    writeAt(0)
}

private fun updateOnlineDealSecrets(
    database: FirebaseDatabase,
    roomCode: String,
    updates: Map<String, Map<String, Any?>>,
    onComplete: (String?) -> Unit
) {
    val entries = updates.entries.toList()
    fun updateAt(index: Int) {
        if (index >= entries.size) {
            onComplete(null)
            return
        }
        val (uid, payload) = entries[index]
        database.reference.child("onlinePrivate").child(roomCode).child(uid).updateChildren(payload)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) updateAt(index + 1)
                else onComplete(task.exception?.localizedMessage ?: "Could not prepare the next private cases.")
            }
    }
    updateAt(0)
}

@Composable
fun OnlineDealScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit,
    targetCount: Int = 6,
    turnTimeSeconds: Int = 30,
    cardsPerPlayer: Int = 2,
    setupLocked: Boolean = false
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    val modeId = "deal_${targetCount}_${turnTimeSeconds}_${cardsPerPlayer}"
    val options = remember(targetCount, turnTimeSeconds, cardsPerPlayer) {
        mapOf<String, Any?>(
            "targetCount" to targetCount,
            "turnTimeSeconds" to turnTimeSeconds,
            "cardsPerPlayer" to cardsPerPlayer,
            "privateCases" to true
        )
    }
    val session = rememberOnlineMatchSession(database, user, "deal", 4, modeId, options)
    var privateData by remember(session) { mutableStateOf<Map<String, Any?>>(emptyMap()) }
    var preparedRound by remember(session) { mutableIntStateOf(-1) }
    var selectedCardIndex by remember(session) { mutableIntStateOf(-1) }
    var selectedStealTeam by remember(session) { mutableIntStateOf(-1) }
    var secondsLeft by remember(session) { mutableIntStateOf(turnTimeSeconds) }
    var cardsSecondsLeft by remember(session) { mutableIntStateOf(DealRules.FINAL_CARD_WINDOW_SECONDS) }
    var scoreSubmitted by remember(session) { mutableStateOf(false) }
    var preparingFinalCards by remember(session) { mutableStateOf(false) }

    BackHandler { session?.leave(); onExit() }
    if (session == null || database == null) {
        Text(if (english) "Firebase connection unavailable." else "اتصال Firebase غير متاح.", color = palette.bad)
        return
    }

    DisposableEffect(session, session.roomCode) {
        val code = session.roomCode
        if (code == null) {
            privateData = emptyMap()
            onDispose { }
        } else {
            val ref = database.reference.child("onlinePrivate").child(code).child(user.uid)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    privateData = onlineMap(snapshot.value)
                }
                override fun onCancelled(error: DatabaseError) {
                    session.report(if (english) "Private case sync failed: ${error.message}" else "فشل مزامنة صناديقك السرية: ${error.message}")
                }
            }
            ref.addValueEventListener(listener)
            onDispose { ref.removeEventListener(listener) }
        }
    }

    val data = session.data
    if (session.gameState == null) {
        Column(Modifier.fillMaxSize().elbashaAtmosphere().padding(16.dp)) {
            Text(if (english) "DEAL OR NO DEAL • ONLINE" else "صندوق الحظ • أونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
            OnlineMatchLobby(
                session = session,
                title = if (english) "Deal or No Deal" else "صندوق الحظ",
                english = english,
                onStart = { joined ->
                    val players = memberUids(joined).take(4)
                    if (players.size !in 2..4) {
                        session.report(if (english) "Deal needs 2–4 players." else "صندوق الحظ محتاج من لاعبين لـ4 لاعبين.")
                        return@OnlineMatchLobby
                    }
                    val formation = ElbashaPositions.formationSlots(targetCount)
                    val invalidSlotIndex = formation.indices.firstOrNull { index ->
                        val slot = formation[index]
                        val minimum = DealRules.minimumCandidatesRequired(formation, index, players.size) ?: Int.MAX_VALUE
                        PlayerDatabase.players.count { ElbashaPositions.poolRole(it.position) == ElbashaPositions.poolRole(slot) } < minimum
                    }
                    if (invalidSlotIndex != null) {
                        val invalidSlot = formation[invalidSlotIndex]
                        session.report(if (english) "Not enough eligible players for $invalidSlot with ${players.size} participants." else "عدد اللاعبين المؤهلين مش كفاية لمركز $invalidSlot مع ${players.size} مشاركين.")
                        return@OnlineMatchLobby
                    }
                    val firstHands = DealRules.createPrivateCaseSets(
                        players = PlayerDatabase.players,
                        slot = formation.first(),
                        participantSeenNames = players.map { emptySet() },
                        draftedNames = emptySet(),
                        random = Random.Default
                    )
                    val secrets = players.mapIndexed { index, uid ->
                        uid to mapOf(
                            "round" to 0,
                            "cases" to encodeOnlineDealCases(firstHands[index]),
                            // Final cards are created at the same phase as local play, not at match start.
                            "cards" to ""
                        )
                    }.toMap()
                    val code = session.roomCode
                    if (code == null) {
                        session.report(if (english) "Create the room before starting." else "أنشئ الغرفة الأول قبل بدء المباراة.")
                        return@OnlineMatchLobby
                    }
                    session.report(if (english) "Preparing each player's private cases…" else "جاري تجهيز الصناديق السرية لكل لاعب…")
                    writeOnlineDealSecrets(database, code, secrets) { error ->
                        if (error != null) {
                            session.report(error)
                        } else {
                            val initial = mapOf<String, Any?>(
                                "players" to players,
                                "names" to memberNameMap(joined),
                                "targetCount" to targetCount,
                                "turnTimeSeconds" to turnTimeSeconds,
                                "cardsPerPlayer" to cardsPerPlayer,
                                "round" to 0,
                                "subPhase" to "draft",
                                "currentActorIndex" to 0,
                                "squads" to players.associateWith { emptyList<String>() },
                                "seenByUid" to players.associateWith { emptyList<String>() },
                                "firstCaseIndex" to -1,
                                "firstName" to "",
                                "firstPosition" to "",
                                "rejectedCaseIndex" to -1,
                                "rejectedName" to "",
                                "acceptedName" to "",
                                "acceptedPosition" to "",
                                "acceptedCaseIndex" to -1,
                                "unopenedCount" to 0,
                                "revealedMissed" to emptyList<Map<String, Any?>>(),
                                "revealCount" to 0,
                                "coaches" to emptyMap<String, Any>(),
                                "protectedNames" to emptyList<String>(),
                                "cardCounts" to players.associateWith { cardsPerPlayer },
                                "activeCardActorIndex" to 0,
                                "turnDeadlineMs" to System.currentTimeMillis() + turnTimeSeconds * 1000L,
                                "cardsDeadlineMs" to 0L,
                                "message" to ""
                            )
                            session.startMatch(initial, players.first())
                        }
                    }
                },
                onBack = { session.leave(); onExit() }
            )
        }
        return
    }

    val players = indexedStrings(data["players"])
    if (players.size !in 2..4 || user.uid !in players) {
        Text(if (english) "This online room has invalid player data. Leave and create a new room." else "بيانات الغرفة غير سليمة. اخرج وأنشئ غرفة جديدة.", color = palette.bad)
        return
    }

    val formation = remember(targetCount) { ElbashaPositions.formationSlots(targetCount) }
    val round = onlineInt(data["round"]).coerceIn(0, formation.lastIndex)
    val subPhase = onlineString(data["subPhase"], "draft")
    val actorIndex = onlineInt(data["currentActorIndex"]).coerceIn(0, players.lastIndex)
    val actorUid = players[actorIndex]
    val names = onlineNameMap(data["names"])
    val squadsByUid = mapStringLists(data["squads"])
    fun decodeSquadPlayer(value: String): PlayerCard? {
        val parts = value.split('~', limit = 2)
        val player = playerByName(parts.firstOrNull().orEmpty()) ?: return null
        return player.copy(position = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: player.position)
    }
    val squads = players.map { uid ->
        squadsByUid[uid].orEmpty().mapNotNull(::decodeSquadPlayer)
    }
    val coachesByUid = onlineMap(data["coaches"])
    val coachList = players.map { uid -> onlineDealCoach(coachesByUid[uid]) }
    val protectedNames = indexedStrings(data["protectedNames"]).toSet()
    val cardCounts = mapInts(data["cardCounts"])
    val currentSlot = formation.getOrNull(round) ?: "ST"
    val slotLabel = BuildTeamRules.positionLabels[currentSlot]?.let { if (english) it.second else it.first } ?: currentSlot
    val myTurn = actorUid == user.uid && session.currentTurnUid == user.uid
    val privateRound = onlineInt(privateData["round"], -1)
    val myCases = decodeOnlineDealCases(privateData["cases"])
    val myCards = onlineString(privateData["cards"]).split('|').filter { it == DealFinalCardType.STEAL.name || it == DealFinalCardType.SHIELD.name }
    val firstPlayer = onlineString(data["firstName"]).let { playerByName(it)?.copy(position = onlineString(data["firstPosition"])) }
    val acceptedPlayer = onlineString(data["acceptedName"]).let { playerByName(it)?.copy(position = onlineString(data["acceptedPosition"])) }
    val rejectedPlayer = onlineString(data["rejectedName"]).let { playerByName(it)?.copy(position = currentSlot) }
    val revealedMissed = onlineRows(data["revealedMissed"])
    val unopenedCount = onlineInt(data["unopenedCount"]).coerceIn(0, 3)
    val revealCount = onlineInt(data["revealCount"]).coerceIn(0, unopenedCount)
    val activeCardIndex = onlineInt(data["activeCardActorIndex"]).coerceIn(0, players.lastIndex)
    val activeCardUid = players[activeCardIndex]
    val myActiveCardTurn = subPhase == "cards" && activeCardUid == user.uid && session.currentTurnUid == user.uid
    val turnDeadline = onlineLong(data["turnDeadlineMs"])
    val cardsDeadline = onlineLong(data["cardsDeadlineMs"])
    val roomCode = session.roomCode.orEmpty()

    fun nextTurnDeadline() = System.currentTimeMillis() + turnTimeSeconds * 1000L
    fun updatedSeen(uid: String, vararg values: String): Map<String, Any?> {
        val updated = mapStringLists(data["seenByUid"]).toMutableMap()
        updated[uid] = (updated[uid].orEmpty() + values.filter { it.isNotBlank() }).distinct()
        return updated
    }
    fun publicSquads(value: List<List<PlayerCard>>): Map<String, List<String>> = players.mapIndexed { index, uid ->
        uid to value.getOrNull(index).orEmpty().map { "${it.nameEn}~${it.position}" }
    }.toMap()
    fun beginAcceptedReveal(accepted: PlayerCard, rejected: PlayerCard?, acceptedIndex: Int, rejectedIndex: Int, cases: List<PlayerCard>) {
        val missedCount = DealRules.unopenedCasesAfterDecision(cases, acceptedIndex, rejectedIndex).size
        val updated = data.toMutableMap().apply {
            put("subPhase", "acceptedReveal")
            put("acceptedName", accepted.nameEn)
            put("acceptedPosition", accepted.position)
            put("acceptedCaseIndex", acceptedIndex)
            put("rejectedName", rejected?.nameEn.orEmpty())
            put("rejectedCaseIndex", rejectedIndex)
            put("unopenedCount", missedCount)
            put("revealedMissed", emptyList<Map<String, Any?>>())
            put("revealCount", 0)
            put("seenByUid", updatedSeen(user.uid, accepted.nameEn, rejected?.nameEn.orEmpty()))
            put("message", if (rejected == null) "${names[user.uid] ?: "Player"} accepted ${accepted.nameEn}." else "${names[user.uid] ?: "Player"} rejected ${rejected.nameEn} and was forced to take ${accepted.nameEn}.")
        }
        session.submitTurn("playing", user.uid, updated)
        sound.play(if (rejected == null) Sfx.Deal else Sfx.Unlock)
    }

    fun advanceAfterPick() {
        val accepted = playerByName(onlineString(data["acceptedName"]))?.copy(
            position = onlineString(data["acceptedPosition"], currentSlot)
        )
        if (accepted == null) {
            session.report(if (english) "The accepted player could not be resolved. The round was not advanced." else "تعذر تحديد اللاعب المقبول؛ لم يتم الانتقال للجولة التالية.")
            return
        }
        val completedSquads = squads.mapIndexed { index, team ->
            if (index == actorIndex) team + accepted else team
        }
        val encodedSquads = publicSquads(completedSquads)
        val nextActor = actorIndex + 1
        if (nextActor < players.size) {
            val updated = data.toMutableMap().apply {
                put("squads", encodedSquads)
                put("currentActorIndex", nextActor)
                put("subPhase", "draft")
                put("firstCaseIndex", -1)
                put("firstName", "")
                put("firstPosition", "")
                put("rejectedCaseIndex", -1)
                put("rejectedName", "")
                put("acceptedName", "")
                put("acceptedPosition", "")
                put("acceptedCaseIndex", -1)
                put("unopenedCount", 0)
                put("revealedMissed", emptyList<Map<String, Any?>>())
                put("revealCount", 0)
                put("turnDeadlineMs", nextTurnDeadline())
                put("message", "")
            }
            session.submitTurn("playing", players[nextActor], updated)
        } else {
            val nextRound = round + 1
            if (nextRound < formation.size) {
                val updated = data.toMutableMap().apply {
                    put("round", nextRound)
                    put("squads", encodedSquads)
                    put("currentActorIndex", 0)
                    put("subPhase", "preparing")
                    put("firstCaseIndex", -1)
                    put("firstName", "")
                    put("firstPosition", "")
                    put("rejectedCaseIndex", -1)
                    put("rejectedName", "")
                    put("acceptedName", "")
                    put("acceptedPosition", "")
                    put("acceptedCaseIndex", -1)
                    put("unopenedCount", 0)
                    put("revealedMissed", emptyList<Map<String, Any?>>())
                    put("revealCount", 0)
                    put("turnDeadlineMs", 0L)
                    put("message", "Preparing private cases for ${formation[nextRound]}…")
                }
                session.submitTurn("playing", players.first(), updated)
            } else {
                val coaches = CoachDatabase.all.shuffled(Random(roomCode.hashCode())).take(players.size)
                val coachMap = players.mapIndexed { index, uid -> uid to onlineDealCoachData(coaches[index]) }.toMap()
                val updated = data.toMutableMap().apply {
                    put("squads", encodedSquads)
                    put("subPhase", "coachReveal")
                    put("currentActorIndex", 0)
                    put("coaches", coachMap)
                    put("turnDeadlineMs", 0L)
                    put("message", "All squads are complete. Coaches have been assigned.")
                }
                session.submitTurn("playing", players.first(), updated)
            }
        }
    }

    fun calculateFinalResults(source: Map<String, Any?>): Map<String, Any?> {
        val teamNames = mapStringLists(source["squads"])
        val allTeams = players.map { uid -> teamNames[uid].orEmpty().mapNotNull(::decodeSquadPlayer) }
        val coachRows = onlineMap(source["coaches"])
        val firstUid = players.first()
        val firstCoach = onlineDealCoach(coachRows[firstUid])
        val results = players.drop(1).map { opponentUid ->
            val opponentCoach = onlineDealCoach(coachRows[opponentUid])
            val result = MatchEngine.simulate(
                userTeam = allTeams.firstOrNull().orEmpty(),
                opponentTeam = allTeams.getOrNull(players.indexOf(opponentUid)).orEmpty(),
                userCoachBonus = firstCoach?.matchBonus ?: 0.0,
                opponentCoachBonus = opponentCoach?.matchBonus ?: 0.0,
                random = Random((roomCode + opponentUid).hashCode()),
                targetSquadSize = targetCount
            )
            mapOf("opponentUid" to opponentUid, "firstGoals" to result.userGoals, "opponentGoals" to result.opponentGoals)
        }
        return source.toMutableMap().apply {
            put("subPhase", "finished")
            put("matchResults", results)
            put("message", "Final matches are ready.")
        }
    }

    // The host prepares the next private case set only after the previous round has been fully revealed.
    LaunchedEffect(session.roomCode, subPhase, round) {
        if (subPhase == "preparing" && session.isHost && preparedRound != round) {
            preparedRound = round
            val seen = mapStringLists(data["seenByUid"])
            val drafted = squadsByUid.values.flatten().map { it.substringBefore('~') }.toSet()
            val nextSlot = formation[round]
            val hands = runCatching {
                DealRules.createPrivateCaseSets(
                    players = PlayerDatabase.players,
                    slot = nextSlot,
                    participantSeenNames = players.map { seen[it].orEmpty().toSet() },
                    draftedNames = drafted,
                    random = Random.Default
                )
            }.getOrNull()
            if (hands == null) {
                preparedRound = -1
                session.report(if (english) "Not enough eligible players to prepare the next round." else "عدد اللاعبين المؤهلين مش كفاية لتجهيز الجولة التالية.")
            } else {
                val updates = players.mapIndexed { index, uid ->
                    uid to mapOf<String, Any?>("round" to round, "cases" to encodeOnlineDealCases(hands[index]))
                }.toMap()
                updateOnlineDealSecrets(database, roomCode, updates) { error ->
                    if (error != null) {
                        preparedRound = -1
                        session.report(error)
                    } else {
                        val latest = session.data.toMutableMap().apply {
                            put("subPhase", "draft")
                            put("turnDeadlineMs", nextTurnDeadline())
                            put("message", "")
                        }
                        session.submitTurn("playing", players.first(), latest)
                    }
                }
            }
        }
    }

    // Short reveal pauses and the missed-case sequence are committed by the active player so
    // every connected device sees the same reveal order.
    LaunchedEffect(subPhase, round, actorIndex, session.currentTurnUid, privateRound, session.revision) {
        if (!myTurn) return@LaunchedEffect
        if (subPhase == "reveal") {
            delay(900)
            if (onlineString(session.data["subPhase"]) == "reveal" && session.currentTurnUid == user.uid) {
                val updated = session.data.toMutableMap().apply {
                    put("subPhase", "decision")
                    put("turnDeadlineMs", nextTurnDeadline())
                }
                session.submitTurn("playing", user.uid, updated)
            }
        } else if (subPhase == "acceptedReveal") {
            delay(950)
            if (onlineString(session.data["subPhase"]) == "acceptedReveal" && session.currentTurnUid == user.uid) {
                val updated = session.data.toMutableMap().apply { put("subPhase", "caseRegretReveal"); put("revealCount", 0) }
                session.submitTurn("playing", user.uid, updated)
            }
        } else if (subPhase == "caseRegretReveal") {
            if (privateRound != round || myCases.size != 4) return@LaunchedEffect
            val cases = myCases
            val acceptedIndex = onlineInt(data["acceptedCaseIndex"], -1)
            val rejectedIndex = onlineInt(data["rejectedCaseIndex"], -1)
            val missedRows = DealRules.unopenedCasesAfterDecision(cases, acceptedIndex, rejectedIndex).map { (index, player) ->
                mapOf("index" to index, "name" to player.nameEn, "position" to player.position)
            }
            val total = onlineInt(data["unopenedCount"]).coerceAtMost(missedRows.size)
            val revealed = onlineInt(data["revealCount"])
            if (revealed < total) {
                delay(if (revealed == 0) 700 else 2_400)
                val latest = session.data
                if (onlineString(latest["subPhase"]) == "caseRegretReveal" &&
                    session.currentTurnUid == user.uid && !session.busy &&
                    onlineInt(latest["revealCount"]) == revealed
                ) {
                    val nextRow = missedRows.getOrNull(revealed) ?: return@LaunchedEffect
                    val updated = latest.toMutableMap().apply {
                        put("revealedMissed", onlineRows(latest["revealedMissed"]) + nextRow)
                        put("revealCount", revealed + 1)
                    }
                    session.submitTurn("playing", user.uid, updated)
                }
            }
        }
    }

    // The local game's turn timer is retained: draft chooses a random case, Deal accepts the
    // first case, and No Deal forces one of the other three when time expires.
    LaunchedEffect(subPhase, round, actorIndex, turnDeadline, myTurn) {
        if (!myTurn || subPhase !in setOf("draft", "decision", "riskPick") || turnDeadline <= 0L) return@LaunchedEffect
        while (true) {
            val remaining = ((turnDeadline - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
            secondsLeft = remaining
            if (remaining <= 0) break
            delay(250)
        }
        if (session.currentTurnUid != user.uid || session.busy) return@LaunchedEffect
        val latest = session.data
        val cases = decodeOnlineDealCases(privateData["cases"])
        when (onlineString(latest["subPhase"])) {
            "draft" -> cases.indices.randomOrNull()?.let { index ->
                val player = cases.getOrNull(index) ?: return@let
                val updated = latest.toMutableMap().apply {
                    put("subPhase", "reveal")
                    put("firstCaseIndex", index)
                    put("firstName", player.nameEn)
                    put("firstPosition", player.position)
                    put("turnDeadlineMs", 0L)
                    put("message", "${names[user.uid] ?: "Player"} opened case ${index + 1}.")
                }
                session.submitTurn("playing", user.uid, updated)
            }
            "decision" -> {
                val index = onlineInt(latest["firstCaseIndex"], -1)
                val deal = DealRules.acceptDeal(cases, index)
                deal?.let { beginAcceptedReveal(it.accepted, null, it.openedIndex, -1, cases) }
            }
            "riskPick" -> {
                val rejectedIndex = onlineInt(latest["rejectedCaseIndex"], -1)
                cases.indices.filter { it != rejectedIndex }.randomOrNull()?.let { index ->
                    val risk = DealRules.acceptRisk(cases, rejectedIndex, index)
                    risk?.let { beginAcceptedReveal(it.accepted, it.rejected, it.openedIndex, rejectedIndex, cases) }
                }
            }
        }
    }

    LaunchedEffect(subPhase, cardsDeadline, activeCardIndex, session.currentTurnUid) {
        if (subPhase == "cards" && cardsDeadline > 0L) {
            while (true) {
                val remaining = ((cardsDeadline - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
                cardsSecondsLeft = remaining
                if (remaining <= 0) break
                delay(500)
            }
            if (subPhase == "cards" && session.currentTurnUid == user.uid && !session.busy) {
                session.submitTurn("finished", "", calculateFinalResults(session.data))
            }
        }
    }

    LaunchedEffect(subPhase, session.revision) {
        if (subPhase == "finished" && !scoreSubmitted) {
            scoreSubmitted = true
            val resultRows = onlineRows(data["matchResults"])
            val ownIndex = players.indexOf(user.uid)
            val ownResult = if (ownIndex == 0) resultRows.firstOrNull()
                else resultRows.firstOrNull { onlineString(it["opponentUid"]) == user.uid }
            val firstGoals = onlineInt(ownResult?.get("firstGoals"))
            val rivalGoals = onlineInt(ownResult?.get("opponentGoals"))
            val ownWon = if (ownIndex == 0) firstGoals > rivalGoals else rivalGoals > firstGoals
            val draw = firstGoals == rivalGoals
            val ownRating = squads.getOrNull(ownIndex).orEmpty().sumOf { it.rating }
            val bonus = when { ownWon -> 1_000; draw -> 500; else -> 0 }
            ScoreRepository.submit(database, user, ownRating * 10 + bonus) { saved ->
                session.report(if (saved) (if (english) "Your online score was saved." else "تم حفظ نقاطك في الأونلاين.") else (if (english) "The score could not be saved." else "تعذر حفظ النقاط."))
            }
        }
    }

    fun beginCardsPhase() {
        if (!session.isHost || session.currentTurnUid != user.uid || preparingFinalCards || session.busy) return
        preparingFinalCards = true
        val privateHands = players.associateWith {
            DealRules.createFinalCardHand(cardsPerPlayer).joinToString("|") { card -> card.type.name }
        }.mapValues { (_, hand) -> mapOf<String, Any?>("cards" to hand) }
        updateOnlineDealSecrets(database, roomCode, privateHands) { error ->
            preparingFinalCards = false
            if (error != null) {
                session.report(error)
            } else {
                val latest = session.data.toMutableMap().apply {
                    put("subPhase", "cards")
                    put("activeCardActorIndex", 0)
                    put("cardsDeadlineMs", System.currentTimeMillis() + DealRules.FINAL_CARD_WINDOW_SECONDS * 1000L)
                    put("message", "Final card phase started: 60 seconds.")
                }
                session.submitTurn("playing", players.first(), latest)
            }
        }
    }

    fun nextCardActorIndex(counts: Map<String, Int>, from: Int): Int? {
        val following = (1 until players.size).asSequence().map { (from + it) % players.size }
            .firstOrNull { (counts[players[it]] ?: 0) > 0 }
        return following ?: from.takeIf { (counts[players[it]] ?: 0) > 0 }
    }


    fun skipCardTurn() {
        if (!myActiveCardTurn || selectedCardIndex >= 0 || session.busy) return
        val next = nextCardActorIndex(cardCounts, activeCardIndex)
        if (next == null) session.submitTurn("finished", "", calculateFinalResults(data))
        else {
            val updated = data.toMutableMap().apply {
                put("activeCardActorIndex", next)
                put("message", "${names[user.uid] ?: "Player"} skipped their card turn.")
            }
            session.submitTurn("playing", players[next], updated)
        }
    }

    fun commitCardAction(newSquads: List<List<PlayerCard>>, newProtected: Set<String>, actionMessage: String) {
        if (!myActiveCardTurn || selectedCardIndex !in myCards.indices || session.busy) return
        val remainingCards = myCards.toMutableList().also { it.removeAt(selectedCardIndex) }
        database.reference.child("onlinePrivate").child(roomCode).child(user.uid).child("cards")
            .setValue(remainingCards.joinToString("|"))
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    session.report(task.exception?.localizedMessage ?: "Could not update your private card hand.")
                    return@addOnCompleteListener
                }
                val updatedCounts = cardCounts.toMutableMap().apply { put(user.uid, remainingCards.size) }
                val next = nextCardActorIndex(updatedCounts, activeCardIndex)
                val updated = data.toMutableMap().apply {
                    put("squads", publicSquads(newSquads))
                    put("protectedNames", newProtected.toList())
                    put("cardCounts", updatedCounts)
                    put("message", actionMessage)
                    if (next != null) put("activeCardActorIndex", next)
                }
                if (next == null) session.submitTurn("finished", "", calculateFinalResults(updated))
                else session.submitTurn("playing", players[next], updated)
                selectedCardIndex = -1
                sound.play(Sfx.Correct)
            }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { session.leave(); onExit() }) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
            Spacer(Modifier.weight(1f))
            Text("DEAL OR NO DEAL", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        Text(if (english) "ROUND ${round + 1} / ${formation.size} • $slotLabel" else "الجولة ${round + 1} من ${formation.size} • $slotLabel", color = palette.cream, fontWeight = FontWeight.Bold)
        if (subPhase in setOf("draft", "reveal", "decision", "riskPick")) {
            Text(
                if (myTurn) (if (english) "YOUR TURN" else "دورك") else (if (english) "${names[actorUid] ?: "Player"}'s turn" else "دور ${names[actorUid] ?: "اللاعب"}"),
                color = if (myTurn) palette.gold else palette.muted,
                fontWeight = FontWeight.Black
            )
            if (myTurn && subPhase in setOf("draft", "decision", "riskPick")) TurnTimerPill(secondsLeft, turnTimeSeconds)
        }
        if (subPhase == "preparing") {
            Text(if (english) "Preparing the next round's private cases…" else "جاري تجهيز صناديق الجولة التالية السرية…", color = palette.gold, fontWeight = FontWeight.Bold)
            if (!session.isHost) Text(if (english) "Waiting for the room host to finish secure case preparation." else "في انتظار المضيف يجهز الصناديق السرية بأمان.", color = palette.muted, fontSize = 11.sp)
        } else if (subPhase in setOf("draft", "reveal", "decision", "riskPick", "acceptedReveal", "caseRegretReveal")) {
            if (subPhase == "draft") {
                if (myTurn && privateRound == round && myCases.size == 4) {
                    Text(if (english) "Choose one of your four private cases." else "اختار صندوق واحد من صناديقك الأربعة السرية.", color = palette.gold, fontWeight = FontWeight.Bold)
                    for (row in 0..1) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            for (column in 0..1) {
                                val index = row * 2 + column
                                Card(
                                    Modifier.weight(1f).height(125.dp).clickable(enabled = !session.busy) {
                                        val player = myCases.getOrNull(index) ?: return@clickable
                                        val updated = data.toMutableMap().apply {
                                            put("subPhase", "reveal")
                                            put("firstCaseIndex", index)
                                            put("firstName", player.nameEn)
                                            put("firstPosition", player.position)
                                            put("turnDeadlineMs", 0L)
                                            put("message", "${names[user.uid] ?: "Player"} opened case ${index + 1}.")
                                        }
                                        session.submitTurn("playing", user.uid, updated)
                                        sound.play(Sfx.CaseOpen)
                                    },
                                    colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
                                    shape = RoundedCornerShape(17.dp)
                                ) {
                                    Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text("▣", color = palette.gold, fontSize = 36.sp)
                                        Text("${index + 1}", color = palette.cream, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                        Text(if (english) "OPEN CASE" else "افتح الصندوق", color = palette.muted, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                } else if (myTurn) {
                    Text(if (english) "Your private cases are syncing…" else "صناديقك السرية بتتزامن…", color = palette.muted)
                } else {
                    Text(if (english) "Waiting for ${names[actorUid] ?: "the current player"} to open a private case." else "في انتظار ${names[actorUid] ?: "اللاعب الحالي"} يفتح صندوقه السري.", color = palette.muted)
                }
            } else if (subPhase in setOf("reveal", "decision")) {
                firstPlayer?.let { FifaPlayerCard(it, english, size = FifaCardSize.Large, modifier = Modifier.fillMaxWidth()) }
                if (subPhase == "decision") {
                    if (myTurn) {
                        Text(if (english) "DEAL OR NO DEAL?" else "هتقبل اللاعب ولا هتخاطر؟", color = palette.gold, fontSize = 19.sp, fontWeight = FontWeight.Black)
                        Button(onClick = {
                            val deal = DealRules.acceptDeal(myCases, onlineInt(data["firstCaseIndex"], -1)) ?: return@Button
                            beginAcceptedReveal(deal.accepted, null, deal.openedIndex, -1, myCases)
                        }, enabled = !session.busy && myCases.size == 4, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.good, contentColor = Color(0xFF10251D))) {
                            Text(if (english) "Deal • Keep this player" else "Deal • أقبل اللاعب", fontWeight = FontWeight.Black)
                        }
                        OutlinedButton(onClick = {
                            val index = onlineInt(data["firstCaseIndex"], -1)
                            val rejected = myCases.getOrNull(index) ?: return@OutlinedButton
                            val updated = data.toMutableMap().apply {
                                put("subPhase", "riskPick")
                                put("rejectedCaseIndex", index)
                                put("rejectedName", rejected.nameEn)
                                put("turnDeadlineMs", nextTurnDeadline())
                                put("message", "${rejected.nameEn} was rejected. Choose one of the other three cases.")
                            }
                            session.submitTurn("playing", user.uid, updated)
                            sound.play(Sfx.NoDeal)
                        }, enabled = !session.busy && myCases.size == 4, modifier = Modifier.fillMaxWidth()) {
                            Text(if (english) "No Deal • Reject and risk" else "No Deal • أرفض وأخاطر", color = palette.gold, fontWeight = FontWeight.Black)
                        }
                    } else Text(if (english) "Waiting for the current player to decide…" else "في انتظار اللاعب الحالي يقرر Deal ولا No Deal…", color = palette.muted)
                } else Text(if (english) "Opening case…" else "جاري فتح الصندوق…", color = palette.gold, fontWeight = FontWeight.Bold)
            } else if (subPhase == "riskPick") {
                rejectedPlayer?.let { FifaPlayerCard(it, english, size = FifaCardSize.Medium, modifier = Modifier.fillMaxWidth()) }
                Text(if (english) "Rejected permanently. Choose one of the other three cases; that player joins your squad." else "اللاعب اترفض نهائيًا. اختار صندوقًا من الثلاثة الباقية واللاعب اللي فيه هينضم إجباريًا.", color = palette.gold, fontWeight = FontWeight.Bold)
                if (myTurn && privateRound == round && myCases.size == 4) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        myCases.indices.filter { it != onlineInt(data["rejectedCaseIndex"], -1) }.forEach { index ->
                            Card(Modifier.weight(1f).height(118.dp).clickable(enabled = !session.busy) {
                                val rejectedIndex = onlineInt(data["rejectedCaseIndex"], -1)
                                val risk = DealRules.acceptRisk(myCases, rejectedIndex, index) ?: return@clickable
                                beginAcceptedReveal(risk.accepted, risk.rejected, risk.openedIndex, rejectedIndex, myCases)
                            }, colors = CardDefaults.cardColors(containerColor = palette.panelAlt), shape = RoundedCornerShape(15.dp)) {
                                Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Text("▣", color = palette.gold, fontSize = 31.sp)
                                    Text("${index + 1}", color = palette.cream, fontWeight = FontWeight.Black)
                                    Text(if (english) "TAKE THIS" else "اختار", color = palette.muted, fontSize = 8.sp)
                                }
                            }
                        }
                    }
                } else if (!myTurn) Text(if (english) "Waiting for the forced-risk choice…" else "في انتظار اختيار الصندوق البديل…", color = palette.muted)
            } else if (subPhase == "acceptedReveal") {
                acceptedPlayer?.let { FifaPlayerCard(it, english, size = FifaCardSize.Large, modifier = Modifier.fillMaxWidth()) }
                Text(if (english) "Your decision is locked. Revealing the remaining cases…" else "قرارك اتثبت. جاري كشف الصناديق الباقية…", color = palette.gold, fontWeight = FontWeight.Bold)
            } else if (subPhase == "caseRegretReveal") {
                Text(if (english) "THE ONES THAT GOT AWAY" else "يا خسارة! شوف اللاعبين اللي سبتهم", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
                revealedMissed.take(revealCount).forEach { row ->
                    val player = playerByName(onlineString(row["name"]))?.copy(position = onlineString(row["position"]))
                    if (player != null) Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                            PlayerPortrait(player, Modifier.size(width = 58.dp, height = 68.dp), cornerRadius = 9)
                            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                Text(if (english) "CASE ${onlineInt(row["index"]) + 1}" else "الصندوق رقم ${onlineInt(row["index"]) + 1}", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 10.sp)
                                Text(if (english) player.nameEn else player.nameAr, color = palette.cream, fontWeight = FontWeight.Bold)
                                Text("${player.rating} OVR • ${player.position}", color = palette.muted, fontSize = 10.sp)
                            }
                            Text(if (english) "MISSED" else "فاتك", color = palette.bad, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        }
                    }
                }
                Text("$revealCount / $unopenedCount", color = palette.muted, fontSize = 10.sp)
                if (revealCount >= unopenedCount && myTurn && privateRound == round && myCases.size == 4) {
                    Button(onClick = { advanceAfterPick() }, enabled = !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                        Text(if (actorIndex == players.lastIndex && round == formation.lastIndex) (if (english) "Reveal coaches" else "كشف المدربين") else (if (english) "Continue" else "كمّل"), fontWeight = FontWeight.Black)
                    }
                } else if (myTurn && (privateRound != round || myCases.size != 4)) Text(if (english) "Your private cases are syncing…" else "صناديقك السرية بتتزامن…", color = palette.muted)
                else if (!myTurn) Text(if (english) "The current player is revealing the remaining cases…" else "اللاعب الحالي بيكشف الصناديق الباقية…", color = palette.muted)
            }
        } else if (subPhase == "coachReveal") {
            Text(if (english) "ALL SQUADS COMPLETE • COACH REVEAL" else "التشكيلات اكتملت • كشف المدربين", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            players.forEachIndexed { index, uid ->
                val coach = coachList.getOrNull(index)
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(names[uid] ?: "Player", color = palette.muted, fontSize = 10.sp)
                        Text(if (english) coach?.nameEn ?: "-" else coach?.nameAr ?: "-", color = palette.cream, fontWeight = FontWeight.Black)
                        Text("${coach?.rating ?: 0} OVR • ${if (english) coach?.styleEn.orEmpty() else coach?.styleAr.orEmpty()}", color = palette.gold, fontSize = 10.sp)
                        Text(squads.getOrNull(index).orEmpty().joinToString(" • ") { it.nameEn }, color = palette.muted, fontSize = 9.sp)
                    }
                }
            }
            if (session.isHost && session.currentTurnUid == user.uid) {
                Button(onClick = { beginCardsPhase() }, enabled = !session.busy && !preparingFinalCards, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(
                        if (preparingFinalCards) (if (english) "Preparing private cards…" else "جاري تجهيز الكروت السرية…")
                        else if (english) "Start final card phase • 60 seconds" else "ابدأ مرحلة الكروت • 60 ثانية",
                        fontWeight = FontWeight.Black
                    )
                }
            } else Text(if (english) "Waiting for the host to start the final cards…" else "في انتظار المضيف يبدأ مرحلة الكروت النهائية…", color = palette.muted)
        } else if (subPhase == "cards") {
            val timerRatio = (cardsSecondsLeft.toFloat() / DealRules.FINAL_CARD_WINDOW_SECONDS).coerceIn(0f, 1f)
            Text(if (english) "FINAL CARD PHASE" else "مرحلة الكروت النهائية", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text("${cardsSecondsLeft}s", color = if (cardsSecondsLeft <= 10) palette.bad else palette.gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
            LinearProgressIndicator(progress = { timerRatio }, modifier = Modifier.fillMaxWidth(), color = if (cardsSecondsLeft <= 10) palette.bad else palette.gold, trackColor = palette.panel)
            players.forEachIndexed { index, uid ->
                Card(colors = CardDefaults.cardColors(containerColor = if (index == activeCardIndex) palette.panelAlt else palette.panel), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(9.dp)) {
                        Text("${names[uid] ?: "Player"} • ${cardCounts[uid] ?: 0} ${if (english) "cards left" else "كارت متبقي"}", color = if (index == activeCardIndex) palette.gold else palette.cream, fontWeight = FontWeight.Bold)
                        Text(squads.getOrNull(index).orEmpty().joinToString(" • ") { player -> if (player.nameEn in protectedNames) "${player.nameEn} 🛡" else player.nameEn }, color = palette.muted, fontSize = 9.sp)
                    }
                }
            }
            if (myActiveCardTurn) {
                if (privateRound < 0 || myCards.isEmpty()) {
                    Text(if (english) "Your private cards are syncing…" else "كروتك السرية بتتزامن…", color = palette.muted)
                } else if (selectedCardIndex < 0) {
                    Text(if (english) "Choose a card from your private hand." else "اختار كارت من إيدك السرية.", color = palette.gold, fontWeight = FontWeight.Bold)
                    myCards.forEachIndexed { index, type ->
                        val steal = type == DealFinalCardType.STEAL.name
                        Card(Modifier.fillMaxWidth().clickable { selectedCardIndex = index; selectedStealTeam = players.indices.firstOrNull { it != activeCardIndex } ?: 0 }, colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(13.dp)) {
                            Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (steal) "↗" else "⬡", color = palette.gold, fontSize = 27.sp)
                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                    Text(if (steal) (if (english) "STEAL CARD" else "كارت السرقة") else (if (english) "SHIELD CARD" else "كارت الحماية"), color = palette.cream, fontWeight = FontWeight.Black)
                                    Text(if (steal) (if (english) "Take an unprotected player from an opponent" else "اسرق لاعبًا غير محمي من خصم") else (if (english) "Protect one player in your own squad" else "احمِ لاعبًا من تشكيلتك"), color = palette.muted, fontSize = 10.sp)
                                }
                                Text("${index + 1}", color = palette.gold, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    OutlinedButton(onClick = { skipCardTurn() }, enabled = !session.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(if (english) "Skip turn" else "تخطي دوري", color = palette.cream)
                    }
                } else if (myCards.getOrNull(selectedCardIndex) == DealFinalCardType.STEAL.name) {
                    Text(if (english) "SELECT AN OPPONENT SQUAD" else "اختار التشكيلة اللي هتسرق منها", color = palette.gold, fontWeight = FontWeight.Black)
                    players.indices.filter { it != activeCardIndex }.forEach { index ->
                        OutlinedButton(onClick = { selectedStealTeam = index }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (selectedStealTeam == index) "✓ ${names[players[index]] ?: "Player"}" else (names[players[index]] ?: "Player"), color = palette.cream)
                        }
                    }
                    val targetPlayers = squads.getOrNull(selectedStealTeam).orEmpty().filter { it.nameEn !in protectedNames }
                    if (targetPlayers.isEmpty()) Text(if (english) "No unprotected player in that squad." else "مفيش لاعب غير محمي في التشكيلة دي.", color = palette.muted)
                    targetPlayers.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) {
                            val updatedTeams = DealRules.stealPlayer(squads, activeCardIndex, selectedStealTeam, player.nameEn, protectedNames) ?: return@PremiumPlayerChoiceCard
                            commitCardAction(updatedTeams, protectedNames, "${names[user.uid] ?: "Player"} stole ${player.nameEn}.")
                        }
                    }
                    OutlinedButton(onClick = { selectedCardIndex = -1 }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Cancel" else "إلغاء", color = palette.cream) }
                } else {
                    Text(if (english) "SELECT A PLAYER TO SHIELD" else "اختار لاعبًا من تشكيلتك للحماية", color = palette.gold, fontWeight = FontWeight.Black)
                    squads.getOrNull(activeCardIndex).orEmpty().filterNot { it.nameEn in protectedNames }.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) {
                            val protected = DealRules.protectPlayer(squads[activeCardIndex], protectedNames, player.nameEn) ?: return@PremiumPlayerChoiceCard
                            commitCardAction(squads, protected, "${player.nameEn} is protected.")
                        }
                    }
                    OutlinedButton(onClick = { selectedCardIndex = -1 }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Cancel" else "إلغاء", color = palette.cream) }
                }
            } else Text(if (english) "${names[activeCardUid] ?: "The next player"} is playing their private card." else "${names[activeCardUid] ?: "اللاعب التالي"} بيلعب كروته السرية.", color = palette.muted)
        } else if (subPhase == "finished") {
            Text(if (english) "FINAL RESULTS" else "النتيجة النهائية", color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
            players.forEachIndexed { index, uid ->
                val coach = coachList.getOrNull(index)
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${names[uid] ?: "Player"} • ${coach?.nameEn ?: ""}", color = palette.gold, fontWeight = FontWeight.Black)
                        Text(squads.getOrNull(index).orEmpty().joinToString(" • ") { "${it.nameEn} (${it.rating})" }, color = palette.cream, fontSize = 10.sp)
                        Text("${squads.getOrNull(index).orEmpty().sumOf { it.rating }} OVR", color = palette.muted, fontSize = 10.sp)
                    }
                }
            }
            onlineRows(data["matchResults"]).forEach { result ->
                val opponentUid = onlineString(result["opponentUid"])
                val firstGoals = onlineInt(result["firstGoals"])
                val opponentGoals = onlineInt(result["opponentGoals"])
                Card(colors = CardDefaults.cardColors(containerColor = palette.panelAlt), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${names[players.first()] ?: "Player 1"}  $firstGoals - $opponentGoals  ${names[opponentUid] ?: "Player"}", color = palette.gold, fontWeight = FontWeight.Black)
                        Text(when { firstGoals > opponentGoals -> (if (english) "${names[players.first()] ?: "Player 1"} wins" else "${names[players.first()] ?: "اللاعب الأول"} فاز"); firstGoals < opponentGoals -> (if (english) "${names[opponentUid] ?: "Player"} wins" else "${names[opponentUid] ?: "اللاعب"} فاز"); else -> (if (english) "Draw" else "تعادل") }, color = palette.cream)
                    }
                }
            }
            if (session.status.isNotBlank()) Text(session.status, color = palette.muted, fontSize = 10.sp)
            Button(onClick = { session.leave(); onExit() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Return" else "رجوع") }
        }
        if (onlineString(data["message"]).isNotBlank() && subPhase !in setOf("preparing", "finished")) {
            Text(onlineString(data["message"]), color = palette.muted, fontSize = 10.sp)
        }
        if (subPhase != "finished") {
            Text(if (english) "Every player's four cases and final cards are private. Only opened/revealed players are synchronized to the room." else "الصناديق الأربعة وكروت كل لاعب سرية. اللي بيتزامن مع الغرفة هو اللاعب اللي اتفتح واتكشف بس.", color = palette.muted, fontSize = 9.sp)
        }
    }
}
