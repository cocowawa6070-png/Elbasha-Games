package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random

private fun memberNameMap(members: List<OnlineRoomMember>) = members.associate { it.uid to it.name }
private fun memberUids(members: List<OnlineRoomMember>) = members.sortedBy { it.seat }.map { it.uid }
private fun playerByName(name: String): PlayerCard? = PlayerDatabase.players.firstOrNull { it.nameEn == name }
private fun indexedStrings(value: Any?): List<String> = onlineStringList(value)
private fun mapStringLists(value: Any?): Map<String, List<String>> = onlineMap(value).mapValues { indexedStrings(it.value) }
private fun mapInts(value: Any?): Map<String, Int> = onlineMap(value).mapValues { onlineInt(it.value) }
private fun appendNameMap(source: Any?, uid: String, name: String): Map<String, Any?> {
    val copy = onlineMap(source).toMutableMap()
    copy[uid] = indexedStrings(copy[uid]) + name
    return copy
}
private fun localizedPlayerName(player: PlayerCard?, english: Boolean): String = player?.let { if (english) it.nameEn else it.nameAr } ?: "-"

@Composable
private fun OnlineMatchLobby(
    session: OnlineMatchSession,
    title: String,
    english: Boolean,
    onStart: (List<OnlineRoomMember>) -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    var codeInput by remember(session) { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(title, color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(if (english) "Live match room • Realtime turn sync" else "غرفة مباراة مباشرة • مزامنة الأدوار لحظيًا", color = palette.muted, fontSize = 12.sp)
        if (session.roomCode == null) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = session::createRoom, enabled = !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                        Text(if (english) "Create online room" else "إنشاء غرفة أونلاين", fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.uppercase().filter(Char::isLetterOrDigit).take(8) },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(if (english) "8-character room code" else "كود الغرفة من 8 خانات") }
                    )
                    OutlinedButton(onClick = { session.joinRoom(codeInput) }, enabled = !session.busy && codeInput.length == 8, modifier = Modifier.fillMaxWidth()) {
                        Text(if (english) "Join room" else "دخول الغرفة")
                    }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (english) "ROOM CODE" else "كود الغرفة", color = palette.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(session.roomCode.orEmpty(), color = palette.gold, fontSize = 32.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(if (english) "Players (${session.members.size}/${onlineInt(session.roomData?.get("maxPlayers"), 2)})" else "اللاعبون (${session.members.size}/${onlineInt(session.roomData?.get("maxPlayers"), 2)})", color = palette.cream, fontWeight = FontWeight.Bold)
                    session.members.forEach { member ->
                        Row(Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${member.seat + 1}.", color = palette.gold, fontWeight = FontWeight.Bold)
                            Text(member.name, color = palette.cream, modifier = Modifier.weight(1f))
                            if (member.uid == session.roomData?.get("hostUid")) Text(if (english) "HOST" else "المضيف", color = palette.gold, fontSize = 9.sp)
                        }
                    }
                    if (session.isHost) {
                        Button(onClick = { onStart(session.members) }, enabled = session.members.size >= 2 && !session.busy && session.gameState == null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                            Text(if (english) "Start match" else "ابدأ المباراة", fontWeight = FontWeight.Black)
                        }
                        Text(if (english) "You can start once at least one opponent joins." else "تقدر تبدأ أول ما لاعب تاني ينضم.", color = palette.muted, fontSize = 10.sp)
                    } else {
                        Text(if (english) "Waiting for the host to start…" else "مستني المضيف يبدأ المباراة…", color = palette.gold, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = session::leave, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Leave room" else "مغادرة الغرفة") }
                }
            }
        }
        if (session.status.isNotBlank()) Text(session.status, color = palette.bad, fontSize = 12.sp)
    }
}

@Composable
fun OnlineAuctionScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    val session = rememberOnlineMatchSession(database, user, "auction", 2)
    var pro by remember { mutableStateOf(false) }
    var bidDraft by remember { mutableIntStateOf(0) }
    BackHandler { session?.leave(); onExit() }
    if (session == null) {
        Text(if (english) "Firebase connection unavailable." else "اتصال Firebase غير متاح.", color = palette.bad)
        return
    }
    val members = session.members
    if (session.gameState == null) {
        Column(Modifier.fillMaxSize().elbashaAtmosphere().padding(16.dp)) {
            Text(if (english) "AUCTION • ONLINE" else "المزاد • أونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(if (english) "Choose the auction size before creating your room." else "اختار حجم المزاد قبل إنشاء الغرفة.", color = palette.muted)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { value ->
                    Card(Modifier.weight(1f).clickable { pro = value }, colors = CardDefaults.cardColors(containerColor = if (pro == value) palette.gold else palette.panel), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (value) "PRO MAX" else "CLASSIC", color = if (pro == value) palette.deepWine else palette.cream, fontWeight = FontWeight.Black)
                            Text(if (value) "11 players • 200M" else "5 players • 100M", color = if (pro == value) palette.deepWine else palette.muted, fontSize = 10.sp)
                        }
                    }
                }
            }
            OnlineMatchLobby(session, if (english) "Create or join an auction" else "إنشاء أو دخول غرفة المزاد", english, onStart = { joined ->
                val players = memberUids(joined).take(2)
                if (players.size < 2) return@OnlineMatchLobby
                val target = if (pro) 11 else 5
                val pool = ElbashaPositions.auctionPool(target, target)
                val startBudget = if (pro) 200 else 100
                val names = memberNameMap(joined)
                val initial = mapOf<String, Any?>(
                    "players" to players,
                    "names" to names,
                    "targetCount" to target,
                    "budgetStart" to startBudget,
                    "budgets" to players.associateWith { startBudget },
                    "lots" to pool.map { it.nameEn },
                    "round" to 0,
                    "currentBid" to (pool.firstOrNull()?.let { AuctionRules.openingPrice(it.rating) - 1 } ?: 0),
                    "leaderUid" to "",
                    "passes" to 0,
                    "squads" to players.associateWith { emptyList<String>() },
                    "hidden" to players.associateWith { emptyList<String>() },
                    "message" to ""
                )
                session.startMatch(initial, players.first())
            }, onBack = { session.leave(); onExit() })
        }
        return
    }
    val data = session.data
    val players = indexedStrings(data["players"])
    if (players.size != 2 || user.uid !in players) {
        Text(if (english) "This online room has invalid player data. Leave and create a new room." else "بيانات اللاعبين في الغرفة غير سليمة. اخرج وأنشئ غرفة جديدة.", color = palette.bad)
        return
    }
    val names = onlineNameMap(data["names"])
    val round = onlineInt(data["round"])
    val target = onlineInt(data["targetCount"], 5)
    val lotNames = indexedStrings(data["lots"])
    val lot = lotNames.getOrNull(round)?.let(::playerByName)
    val budgets = mapInts(data["budgets"])
    val squads = mapStringLists(data["squads"])
    val hidden = mapStringLists(data["hidden"])
    val leaderUid = onlineString(data["leaderUid"])
    val currentBid = onlineInt(data["currentBid"])
    val isMyTurn = session.currentTurnUid == user.uid && session.phase == "playing"
    val minimum = lot?.let { maxOf(AuctionRules.openingPrice(it.rating), currentBid + 1) } ?: 1
    LaunchedEffect(session.revision, round, currentBid) { bidDraft = minimum }

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { session.leave(); onExit() }) { Text(if (english) "← Exit" else "→ خروج", color = palette.gold) }
            Spacer(Modifier.weight(1f)); Text(session.roomCode.orEmpty(), color = palette.gold, fontWeight = FontWeight.Black)
        }
        Text(if (english) "ONLINE AUCTION" else "المزاد الأونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        if (session.phase == "finished" || round >= target || lot == null) {
            Text(if (english) "FINAL SQUADS" else "التشكيلات النهائية", color = palette.gold, fontWeight = FontWeight.Black)
            players.forEach { uid ->
                val team = squads[uid].orEmpty().mapNotNull(::playerByName)
                val total = team.sumOf { it.rating }
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(names[uid] ?: "Player", color = palette.gold, fontWeight = FontWeight.Bold)
                        Text("$total OVR", color = palette.cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        team.forEach { Text("${it.position} • ${it.nameEn} (${it.rating})${if (it.nameEn in hidden[uid].orEmpty()) " • HIDDEN" else ""}", color = palette.muted, fontSize = 11.sp) }
                    }
                }
            }
            val totals = players.map { uid -> squads[uid].orEmpty().mapNotNull(::playerByName).sumOf { it.rating } }
            Text(when { totals.size < 2 -> ""; totals[0] > totals[1] -> "${names[players[0]]} wins"; totals[1] > totals[0] -> "${names[players[1]]} wins"; else -> "Draw" }, color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Button(onClick = { session.leave(); onExit() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Return" else "رجوع") }
        } else {
            Text(if (english) "LOT ${round + 1} OF $target" else "اللاعب ${round + 1} من $target", color = palette.cream, fontWeight = FontWeight.Bold)
            Text("${names[session.currentTurnUid] ?: "-"} • ${if (isMyTurn) if (english) "YOUR TURN" else "دورك" else if (english) "WAITING FOR OPPONENT" else "في انتظار الخصم"}", color = if (isMyTurn) palette.gold else palette.muted, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                players.forEach { uid -> Text("${names[uid]}: ${budgets[uid] ?: 0}M", color = palette.cream, fontSize = 12.sp) }
            }
            lot?.let { PremiumPlayerCard(it, detail = "${AuctionRules.openingPrice(it.rating)}M", eyebrow = if (english) "PLAYER ON THE BLOCK" else "اللاعب المعروض") }
            Text(if (leaderUid.isBlank()) "${lot?.let { AuctionRules.openingPrice(it.rating) } ?: 0}M • Opening bid" else "${names[leaderUid] ?: "-"} leads • $currentBid M", color = palette.gold, fontWeight = FontWeight.Bold)
            if (isMyTurn) {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (english) "YOUR BID" else "مزايدتك", color = palette.muted, fontWeight = FontWeight.Bold)
                        Text("$bidDraft M", color = palette.gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = { bidDraft = (bidDraft - 1).coerceAtLeast(minimum) }, enabled = bidDraft > minimum, modifier = Modifier.weight(1f)) { Text("−1") }
                            listOf(1, 5, 10).forEach { step -> OutlinedButton(onClick = { bidDraft = (bidDraft + step).coerceAtMost(budgets[user.uid] ?: 0) }, enabled = bidDraft + step <= (budgets[user.uid] ?: 0), modifier = Modifier.weight(1f)) { Text("+$step") } }
                        }
                    }
                }
                Button(onClick = {
                    if (OnlineMatchRules.validBid(bidDraft, currentBid, lot?.let { AuctionRules.openingPrice(it.rating) } ?: minimum, budgets[user.uid] ?: 0)) {
                        val next = data.toMutableMap().apply {
                            put("currentBid", bidDraft); put("leaderUid", user.uid); put("passes", 0); put("message", "${names[user.uid]} raised to $bidDraft M")
                        }
                        val other = players.firstOrNull { it != user.uid }.orEmpty()
                        session.submitTurn("playing", other, next)
                        sound.play(Sfx.Click)
                    }
                }, enabled = OnlineMatchRules.validBid(bidDraft, currentBid, lot?.let { AuctionRules.openingPrice(it.rating) } ?: minimum, budgets[user.uid] ?: 0) && !session.busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Confirm bid" else "زايد وثبّت", fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = {
                    val other = players.firstOrNull { it != user.uid }.orEmpty()
                    val currentLeader = leaderUid
                    if (currentLeader.isNotBlank()) {
                        val newSquads = squads.toMutableMap()
                        newSquads[currentLeader] = squads[currentLeader].orEmpty() + lot!!.nameEn
                        val loser = players.first { it != currentLeader }
                        val taken = (newSquads.values.flatten() + lotNames).toSet()
                        val hiddenPlayer = PlayerDatabase.players.filter { ElbashaPositions.supports(it, lot!!.position) && it.nameEn !in taken }.randomOrNull()
                        if (hiddenPlayer != null) newSquads[loser] = newSquads[loser].orEmpty() + hiddenPlayer.nameEn
                        val newHidden = hidden.toMutableMap().apply { if (hiddenPlayer != null) put(loser, hidden[loser].orEmpty() + hiddenPlayer.nameEn) }
                        val newBudgets = budgets.toMutableMap().apply { put(currentLeader, (get(currentLeader) ?: 0) - currentBid) }
                        val nextRound = round + 1
                        val nextData = data.toMutableMap().apply {
                            put("squads", newSquads); put("hidden", newHidden); put("budgets", newBudgets); put("round", nextRound)
                            put("currentBid", lotNames.getOrNull(nextRound)?.let { n -> playerByName(n)?.let { AuctionRules.openingPrice(it.rating) - 1 } } ?: 0)
                            put("leaderUid", ""); put("passes", 0); put("message", "${names[currentLeader]} won ${lot.nameEn}")
                        }
                        val finish = nextRound >= target
                        val nextStarterUid = if (finish) "" else players[nextRound % players.size]
                        session.submitTurn(if (finish) "finished" else "playing", nextStarterUid, nextData)
                    } else {
                        val passCount = onlineInt(data["passes"]) + 1
                        if (passCount < 2) {
                            val next = data.toMutableMap().apply { put("passes", passCount); put("message", "No opening bid. Other player may bid or pass.") }
                            session.submitTurn("playing", other, next)
                        } else {
                            val taken = (squads.values.flatten() + lotNames).toMutableSet()
                            val newSquads = squads.toMutableMap()
                            val newHidden = hidden.toMutableMap()
                            players.forEach { uid ->
                                val gift = PlayerDatabase.players.filter { ElbashaPositions.supports(it, lot!!.position) && it.nameEn !in taken }.randomOrNull()
                                if (gift != null) {
                                    taken.add(gift.nameEn)
                                    newSquads[uid] = newSquads[uid].orEmpty() + gift.nameEn
                                    newHidden[uid] = newHidden[uid].orEmpty() + gift.nameEn
                                }
                            }
                            val nextRound = round + 1
                            val next = data.toMutableMap().apply {
                                put("squads", newSquads); put("hidden", newHidden); put("round", nextRound); put("leaderUid", ""); put("passes", 0)
                                put("currentBid", lotNames.getOrNull(nextRound)?.let { n -> playerByName(n)?.let { AuctionRules.openingPrice(it.rating) - 1 } } ?: 0)
                            }
                            val finish = nextRound >= target
                            val nextStarterUid = if (finish) "" else players[nextRound % players.size]
                            session.submitTurn(if (finish) "finished" else "playing", nextStarterUid, next)
                        }
                    }
                    sound.play(Sfx.Correct)
                }, enabled = !session.busy, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Pass / Withdraw" else "انسحاب / Pass") }
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.muted, textAlign = TextAlign.Center)
            Text(if (english) "The bid, budgets, lot and turn are synchronized to every connected player." else "المزايدة والميزانيات واللاعب المعروض والدور متزامنين عند كل اللاعبين.", color = palette.muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun OnlineBuildTeamScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    val session = rememberOnlineMatchSession(database, user, "build", 4)
    var search by remember { mutableStateOf("") }
    BackHandler { session?.leave(); onExit() }
    if (session == null) { Text(if (english) "Firebase unavailable" else "Firebase غير متاح", color = palette.bad); return }
    if (session.gameState == null) {
        Column(Modifier.fillMaxSize().elbashaAtmosphere().padding(16.dp)) {
            OnlineMatchLobby(session, if (english) "Build a Team • Online" else "كوّن فريق • أونلاين", english, onStart = { joined ->
                val players = memberUids(joined).take(4)
                if (players.size < 2) return@OnlineMatchLobby
                val setup = BuildTeamStatRules.randomValidSetup(5, players.size, Random.Default) ?: BuildTeamStatRules.randomValidSetup(4, players.size, Random.Default)
                if (setup == null) { session.report("مش لاقي فلتر فيه لاعبين كفاية لكل المشاركين."); return@OnlineMatchLobby }
                val filter = setup.first; val metric = setup.second; val direction = setup.third
                val count = if (BuildTeamStatRules.hasEnoughPlayers(PlayerFactsDatabase.players, filter, metric, 5, players.size)) 5 else 4
                val names = memberNameMap(joined)
                val initial = mapOf<String, Any?>(
                    "players" to players, "names" to names, "roundCount" to count,
                    "round" to 0, "turnIndex" to 0,
                    "filterPosition" to filter.position.name, "filterLeague" to filter.league.name,
                    "metric" to metric.name, "direction" to direction.name,
                    "picks" to players.associateWith { emptyList<Map<String, Any?>>() },
                    "message" to ""
                )
                session.startMatch(initial, players.first())
            }, onBack = { session.leave(); onExit() })
        }
        return
    }
    val data = session.data
    val players = indexedStrings(data["players"])
    if (players.size !in 2..4 || user.uid !in players) {
        Text(if (english) "This online room has invalid player data. Leave and create a new room." else "بيانات اللاعبين في الغرفة غير سليمة. اخرج وأنشئ غرفة جديدة.", color = palette.bad)
        return
    }
    val names = onlineNameMap(data["names"])
    val filter = BuildTeamFilter(
        runCatching { BuildTeamPositionFilter.valueOf(onlineString(data["filterPosition"], "ANY")) }.getOrDefault(BuildTeamPositionFilter.ANY),
        runCatching { BuildTeamLeagueFilter.valueOf(onlineString(data["filterLeague"], "ANY")) }.getOrDefault(BuildTeamLeagueFilter.ANY)
    )
    val metric = runCatching { BuildTeamMetric.valueOf(onlineString(data["metric"], "HEIGHT")) }.getOrDefault(BuildTeamMetric.HEIGHT)
    val direction = runCatching { BuildTeamDirection.valueOf(onlineString(data["direction"], "HIGH")) }.getOrDefault(BuildTeamDirection.HIGH)
    val roundCount = onlineInt(data["roundCount"], 5)
    val round = onlineInt(data["round"])
    val turnIndex = onlineInt(data["turnIndex"])
    val picksMap = onlineMap(data["picks"])
    val picksByUid = players.associateWith { uid ->
        val rows = picksMap[uid]
        val items = when (rows) { is List<*> -> rows; is Map<*, *> -> rows.entries.sortedBy { (it.key as? String)?.toIntOrNull() ?: Int.MAX_VALUE }.map { it.value }; else -> emptyList() }
        items.mapNotNull { raw ->
            val row = onlineMap(raw)
            val name = onlineString(row["name"])
            val player = playerByName(name)
            val value = onlineInt(row["value"], -1)
            if (player != null && value >= 0) BuildTeamPick(player, value) else null
        }
    }
    val used = picksByUid.values.flatten().map { it.player.nameEn }.toSet()
    val eligible = BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric).filterNot { it.nameEn in used }
    val suggestions = if (PlayerSearch.normalize(search).length >= 3) PlayerSearch.suggestions(eligible, search, 12) else emptyList()
    val activeUid = players.getOrNull(turnIndex).orEmpty()
    val myTurn = activeUid == user.uid && session.phase == "playing"
    val totals = players.map { uid -> BuildTeamStatRules.total(picksByUid[uid].orEmpty()) }
    val finished = session.phase == "finished" || round >= roundCount

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { session.leave(); onExit() }) { Text(if (english) "← Exit" else "→ خروج", color = palette.gold) }
            Spacer(Modifier.weight(1f)); Text(session.roomCode.orEmpty(), color = palette.gold, fontWeight = FontWeight.Black)
        }
        Text(if (english) "BUILD A TEAM • ONLINE" else "كوّن فريق • أونلاين", color = palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("${if (english) "CHALLENGE" else "التحدي"}: ${if (english) filter.position.labelEn else filter.position.labelAr} • ${if (english) filter.league.labelEn else filter.league.labelAr}", color = palette.cream, fontWeight = FontWeight.Bold)
        Text("${if (english) metric.labelEn else metric.labelAr} • ${if (english) direction.labelEn else direction.labelAr}", color = palette.gold, fontWeight = FontWeight.Bold)
        if (finished) {
            Text(if (english) "FINAL SCORE" else "النتيجة النهائية", color = palette.gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            players.forEachIndexed { index, uid ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(names[uid] ?: "Player", color = palette.gold, fontWeight = FontWeight.Bold)
                        Text("${totals[index]} ${metric.unitEn}", color = palette.cream, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        picksByUid[uid].orEmpty().forEach { Text("${it.player.nameEn} • ${it.value}", color = palette.muted, fontSize = 11.sp) }
                    }
                }
            }
            val winningIndices = BuildTeamStatRules.winners(totals, direction)
            Text(if (winningIndices.size == players.size) if (english) "Draw" else "تعادل" else winningIndices.joinToString(" • ") { names[players[it]] ?: "Player" } + if (english) " wins" else " فاز", color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Button(onClick = { session.leave(); onExit() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Return" else "رجوع") }
        } else {
            Text(if (english) "ROUND ${round + 1} OF $roundCount" else "الجولة ${round + 1} من $roundCount", color = palette.cream, fontWeight = FontWeight.Bold)
            Text("${names[activeUid] ?: "-"} • ${if (myTurn) if (english) "YOUR PICK" else "اختيارك" else if (english) "WAITING FOR PLAYER" else "في انتظار اللاعب"}", color = if (myTurn) palette.gold else palette.muted, fontWeight = FontWeight.Black)
            players.forEachIndexed { index, uid ->
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(13.dp)) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(names[uid] ?: "Player", color = palette.cream, fontWeight = FontWeight.Bold)
                            Text("${totals[index]} ${metric.unitEn}", color = palette.gold, fontWeight = FontWeight.Black)
                        }
                        SquadFormationPitch(title = if (english) "Selected players" else "اللاعبون المختارون", players = picksByUid[uid].orEmpty().map { it.player }, slotCount = roundCount)
                    }
                }
            }
            if (myTurn) {
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (english) "Search player (3+ letters)" else "ابحث عن لاعب (3 حروف أو أكثر)") })
                if (PlayerSearch.normalize(search).length >= 3) {
                    if (suggestions.isEmpty()) Text(if (english) "No eligible player matches this challenge." else "مفيش لاعب مطابق للتحدي.", color = palette.muted)
                    suggestions.forEach { player ->
                        PremiumPlayerChoiceCard(player, english) {
                            val value = BuildTeamStatRules.value(player, metric) ?: return@PremiumPlayerChoiceCard
                            val nextPicks = picksByUid.mapValues { it.value.map { pick -> mapOf("name" to pick.player.nameEn, "value" to pick.value) } }.toMutableMap()
                            nextPicks[user.uid] = nextPicks[user.uid].orEmpty() + mapOf("name" to player.nameEn, "value" to value)
                            val isLastTurn = turnIndex >= players.lastIndex
                            val nextRound = if (isLastTurn) round + 1 else round
                            val nextTurn = if (isLastTurn) 0 else turnIndex + 1
                            val finish = nextRound >= roundCount
                            val nextData = data.toMutableMap().apply {
                                put("picks", nextPicks); put("round", nextRound); put("turnIndex", nextTurn)
                                put("message", "${names[user.uid]} picked ${player.nameEn} (${value})")
                            }
                            session.submitTurn(if (finish) "finished" else "playing", if (finish) "" else players[nextTurn], nextData)
                            search = ""
                            sound.play(Sfx.Correct)
                        }
                    }
                } else Text(if (english) "The current player chooses one player matching the shared challenge." else "اللاعب صاحب الدور يختار لاعبًا مطابقًا للتحدي المشترك.", color = palette.muted, fontSize = 11.sp)
            }
            if (onlineString(data["message"]).isNotBlank()) Text(onlineString(data["message"]), color = palette.gold, fontSize = 11.sp)
        }
    }
}
