package com.mostafabek.elbashagames

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

@Composable
fun ElbashaApp(
    auth: FirebaseAuth,
    sound: SoundManager,
    databaseUrl: String,
    onGoogleSignIn: ((String?) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val settingsPrefs = remember { context.getSharedPreferences("elbasha_ui", android.content.Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(settingsPrefs.getBoolean("english", false)) }
    var darkTheme by remember { mutableStateOf(settingsPrefs.getBoolean("dark_theme", true)) }
    val settings = AppUiSettings(english = english, darkTheme = darkTheme)
    val palette = paletteFor(darkTheme)
    val database = remember(databaseUrl) {
        val candidate = databaseUrl.trim().trimEnd('/')
        val host = candidate.removePrefix("https://").substringBefore('/')
        val looksLikeRealtimeDatabaseUrl = candidate.startsWith("https://") &&
            (host.endsWith(".firebaseio.com") || host.endsWith(".firebasedatabase.app"))
        if (looksLikeRealtimeDatabaseUrl) runCatching { FirebaseDatabase.getInstance(candidate) }.getOrNull() else null
    }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var isDeveloper by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf<String?>(null) }

    val toggleLanguage = {
        english = !english
        settingsPrefs.edit().putBoolean("english", english).apply()
    }
    val toggleTheme = {
        darkTheme = !darkTheme
        settingsPrefs.edit().putBoolean("dark_theme", darkTheme).apply()
    }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(currentUser?.uid) {
        val user = currentUser
        if (user == null) {
            isDeveloper = false
        } else {
            saveUserProfile(database, user)
            if (database == null) {
                isDeveloper = false
            } else {
                database.reference.child("admins").child(user.uid).get()
                    .addOnSuccessListener { isDeveloper = it.getValue(Boolean::class.java) == true }
                    .addOnFailureListener { isDeveloper = false }
            }
        }
    }

    val colorScheme = if (darkTheme) darkColorScheme(
        primary = palette.gold,
        onPrimary = palette.deepWine,
        secondary = Color(0xFFCF8A3C),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    ) else lightColorScheme(
        primary = palette.gold,
        onPrimary = Color.White,
        secondary = Color(0xFFB56A19),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    )

    CompositionLocalProvider(
        LocalAppUiSettings provides settings,
        LocalElbashaPalette provides palette,
        LocalLayoutDirection provides if (english) LayoutDirection.Ltr else LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = colorScheme) {
            Surface(modifier = Modifier.fillMaxSize(), color = DeepWine) {
                if (currentUser == null) {
                    AuthScreen(
                        auth = auth,
                        database = database,
                        message = authMessage,
                        onMessage = { authMessage = it },
                        onGoogleSignIn = {
                            onGoogleSignIn { error -> authMessage = error ?: if (english) "Signed in with Google" else "تم تسجيل الدخول بحساب Google" }
                        },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                } else {
                    MainHub(
                        user = currentUser!!,
                        database = database,
                        sound = sound,
                        isDeveloper = isDeveloper,
                        onSignOut = { auth.signOut() },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                }
            }
        }
    }
}

private fun saveUserProfile(database: FirebaseDatabase?, user: FirebaseUser) {
    if (database == null) return
    val displayName = (user.displayName?.takeIf { it.isNotBlank() }
        ?: user.email?.substringBefore("@")
        ?: "لاعب جديد").take(28)

    // Keep email in the private user node; only the public profile is readable by other players.
    val privateReference = database.reference.child("users").child(user.uid)
    privateReference.get().addOnSuccessListener { snapshot ->
        val privateUpdates = hashMapOf<String, Any>(
            "email" to (user.email ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) privateUpdates["createdAt"] = ServerValue.TIMESTAMP
        privateReference.updateChildren(privateUpdates)
    }

    val publicReference = database.reference.child("publicProfiles").child(user.uid)
    publicReference.get().addOnSuccessListener { snapshot ->
        val publicUpdates = hashMapOf<String, Any>(
            "displayName" to displayName,
            "photoUrl" to (user.photoUrl?.toString() ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) publicUpdates["createdAt"] = ServerValue.TIMESTAMP
        publicReference.updateChildren(publicUpdates)
    }
}

@Composable
private fun AuthScreen(
    auth: FirebaseAuth,
    database: FirebaseDatabase?,
    message: String?,
    onMessage: (String?) -> Unit,
    onGoogleSignIn: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    var registerMode by remember { mutableStateOf(true) }
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val english = LocalAppUiSettings.current.english
    val contextText = if (registerMode) uiText("إنشاء حساب جديد", "Create account") else uiText("تسجيل الدخول", "Sign in")

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.elbasha_logo),
                contentDescription = "Elbasha Games logo",
                modifier = Modifier.size(220.dp),
                contentScale = ContentScale.Fit
            )
            Text("ELBASHA GAMES", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("THE FOOTBALL PLAYGROUND", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onToggleLanguage) { Text(if (LocalAppUiSettings.current.english) "العربية" else "English", color = Gold) }
                TextButton(onClick = onToggleTheme) { Text(if (LocalAppUiSettings.current.darkTheme) uiText("☀️ الوضع النهاري", "☀️ Light mode") else uiText("🌙 الوضع الليلي", "🌙 Dark mode"), color = Gold) }
            }
            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = PanelColor)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(contextText, color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (registerMode) {
                        OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(uiText("اسم اللاعب", "Player name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(uiText("البريد الإلكتروني", "Email address")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(uiText("كلمة المرور", "Password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            onMessage(null)
                            if (!email.contains("@") || password.length < 6 || (registerMode && displayName.trim().length !in 2..28)) {
                                onMessage(if (english) "Check your email, password (6+ characters), and player name (2-28 characters)." else "راجع البريد وكلمة المرور (6 أحرف على الأقل) واسم اللاعب (من حرفين إلى 28)")
                            } else {
                                busy = true
                                val task = if (registerMode) auth.createUserWithEmailAndPassword(email.trim(), password)
                                    else auth.signInWithEmailAndPassword(email.trim(), password)
                                task.addOnCompleteListener { result ->
                                    busy = false
                                    if (result.isSuccessful) {
                                        val signedUser = auth.currentUser
                                        if (registerMode && signedUser != null) {
                                            val request = UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
                                            signedUser.updateProfile(request).addOnCompleteListener {
                                                saveUserProfile(database, signedUser)
                                                signedUser.sendEmailVerification()
                                                onMessage(if (english) "Account created. Check your inbox to verify your email." else "تم إنشاء الحساب. راجع بريدك لتأكيده.")
                                            }
                                        } else {
                                            onMessage(if (english) "Signed in successfully" else "تم تسجيل الدخول بنجاح")
                                        }
                                    } else {
                                        onMessage(result.exception?.localizedMessage ?: "تعذر إكمال العملية")
                                    }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = DeepWine, strokeWidth = 2.dp)
                        else Text(if (registerMode) uiText("إنشاء الحساب", "Create account") else uiText("دخول", "Sign in"), fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onGoogleSignIn,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
                    ) { Text(uiText("الدخول باستخدام Google", "Continue with Google")) }
                    TextButton(onClick = { registerMode = !registerMode; onMessage(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (registerMode) uiText("عندك حساب؟ سجّل دخول", "Already have an account? Sign in") else uiText("لسه جديد؟ أنشئ حساب", "New here? Create an account"), color = Gold)
                    }
                    if (!registerMode) {
                        TextButton(onClick = {
                            if (!email.contains("@")) onMessage(if (english) "Enter your email address first" else "اكتب بريدك الإلكتروني الأول")
                            else auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { task ->
                                onMessage(if (task.isSuccessful) {
                                    if (english) "Password reset link sent" else "تم إرسال رابط استعادة كلمة المرور"
                                } else task.exception?.localizedMessage ?: if (english) "Could not send the link" else "تعذر إرسال الرابط")
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(uiText("نسيت كلمة المرور؟", "Forgot password?"), color = Muted) }
                    }
                    message?.let { Text(it, color = if (it.contains("نجاح") || it.contains("تم إنشاء") || it.contains("تم إرسال") || it.contains("successfully") || it.contains("created") || it.contains("sent")) Gold else LocalElbashaPalette.current.bad, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("DEVELOPED BY MOSTAFA BEK", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class GameItem(val id: String, val titleAr: String, val titleEn: String, val subtitleAr: String, val subtitleEn: String, val emoji: String, val ready: Boolean = false)
private data class RankItem(val uid: String, val name: String, val points: Long)

@Composable
private fun MainHub(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    isDeveloper: Boolean,
    onSignOut: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    var page by remember { mutableStateOf("home") }
    var leaderboard by remember { mutableStateOf<List<RankItem>>(emptyList()) }
    val games = listOf(
        GameItem("auction", "المزاد الكروي", "Football Auction", "زايد على النجوم وابنِ فريقك", "Bid for stars and build your squad", "🔨"),
        GameItem("deal", "صندوق الحظ", "Deal or No Deal", "افتح الصناديق واختبر حظك", "Open the boxes and test your luck", "🎁"),
        GameItem("build", "بناء فريق خماسي", "Build a 5-a-side Team", "كوّن فريقًا خماسيًا بميزانية محدودة", "Draft a five-a-side team on a limited budget", "🧩", ready = true),
        GameItem("guess", "خمن اللاعب", "Guess the Player", "تلميحات عن نجوم الكرة", "Clues about football legends", "🕵️", ready = true),
        GameItem("trivia", "تحدي المعلومات", "Football Trivia", "85 سؤالًا كرويًا بالعربي والإنجليزي", "85 football questions in Arabic and English", "🧠", ready = true),
        GameItem("stats", "تحدي الإحصائيات", "Football Stats", "أرقام ونتائج من تاريخ الكرة", "Numbers and results from football history", "📊", ready = true),
        GameItem("penalty", "ضربات الترجيح", "Penalty Shootout", "سدد وصدّ خمس ضربات", "Take five shots and make five saves", "🥅", ready = true)
    )

    LaunchedEffect(Unit) { sound.playMusic(Track.Menu) }

    DisposableEffect(database) {
        val reference = database?.reference?.child("leaderboard")
        if (reference == null) {
            leaderboard = emptyList()
            onDispose { }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    leaderboard = snapshot.children.map { child ->
                        RankItem(
                            uid = child.key ?: "",
                            name = child.child("displayName").getValue(String::class.java) ?: "لاعب",
                            points = child.child("totalPoints").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedByDescending { it.points }.take(50)
                }
                override fun onCancelled(error: DatabaseError) { }
            }
            reference.addValueEventListener(listener)
            onDispose { reference.removeEventListener(listener) }
        }
    }

    when (page) {
        "trivia" -> { TriviaScreen(user, database, sound) { page = "home" }; return }
        "guess" -> { GuessPlayerScreen(user, database, sound) { page = "home" }; return }
        "stats" -> { StatsChallengeScreen(user, database, sound) { page = "home" }; return }
        "build" -> { BuildTeamScreen(user, database, sound) { page = "home" }; return }
        "penalty" -> { PenaltyShootoutScreen(user, database, sound) { page = "home" }; return }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine)))
            .verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(76.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("ELBASHA GAMES", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text(uiText("أهلاً يا ${user.displayName ?: user.email?.substringBefore("@") ?: "باشا"}", "Welcome, ${user.displayName ?: user.email?.substringBefore("@") ?: "Boss"}"), color = Cream, fontSize = 15.sp)
            }
            SoundToggles(sound)
        }
        Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text(uiText("الملعب تحت أمرك", "The pitch is yours"), color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(uiText("اجمع نقاطك، نافس أصحابك، واثبت إنك مش حافظ ويكيبيديا بس.", "Earn points, challenge your friends, and prove your football knowledge."), color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallStat(uiText("الألعاب", "Games"), "${games.size}", Modifier.weight(1f))
                    SmallStat(uiText("المتصدرون", "Players"), "${leaderboard.size}", Modifier.weight(1f))
                    SmallStat(uiText("الرتبة", "Rank"), if (leaderboard.any { it.uid == user.uid }) "${leaderboard.indexOfFirst { it.uid == user.uid } + 1}" else "—", Modifier.weight(1f))
                }
            }
        }
        if (database == null) {
            InfoCard(
                uiText("وضع اللعب الفردي", "Single-player mode"),
                uiText("الألعاب المدمجة شغالة. اربط Realtime Database لتفعيل لوحة المتصدرين وحفظ النقاط بين الأجهزة.", "Built-in games are ready. Connect Realtime Database to enable the leaderboard and cross-device score saving.")
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            NavButton(uiText("الرئيسية", "Home"), page == "home", Modifier.weight(1f)) { page = "home" }
            NavButton(uiText("الألعاب", "Games"), page == "games", Modifier.weight(1f)) { page = "games" }
            NavButton(uiText("الترتيب", "Ranks"), page == "rank", Modifier.weight(1f)) { page = "rank" }
            NavButton(uiText("حسابي", "Profile"), page == "profile", Modifier.weight(1f)) { page = "profile" }
            NavButton(uiText("الإعدادات", "Settings"), page == "settings", Modifier.weight(1f)) { page = "settings" }
        }

        when (page) {
            "rank" -> {
                SectionTitle(uiText("🏆 لوحة المتصدرين", "🏆 Leaderboard"))
                if (leaderboard.isEmpty()) InfoCard(uiText("لسه مفيش نتائج", "No results yet"), uiText("أول ما النقاط تتسجل، ترتيب الأبطال هيظهر هنا.", "Player rankings will appear here after the first scores are saved."))
                leaderboard.forEachIndexed { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = if (item.uid == user.uid) PanelAltColor else PanelColor)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(14.dp))
                            Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                            Text(uiText("${item.points} نقطة", "${item.points} pts"), color = Gold, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            "profile" -> {
                SectionTitle(uiText("👤 حساب اللاعب", "👤 Player profile"))
                InfoCard(user.displayName ?: uiText("لاعب Elbasha", "Elbasha player"), user.email ?: "")
                InfoCard(uiText("معرّف الحساب", "Account ID"), user.uid)
                Button(onClick = onSignOut, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(uiText("تسجيل الخروج", "Sign out")) }
            }
            "developer" -> {
                SectionTitle("⚙️ Developer Panel")
                if (isDeveloper) {
                    InfoCard("Mostafa Bek", uiText("صلاحية المطور مفعّلة. أدوات إدارة الأسئلة والأعضاء والغرف ما زالت تحتاج تنفيذًا.", "Developer access is enabled. Question, member and room management tools still need implementation."))
                } else {
                    InfoCard(uiText("غير مصرح", "Access denied"), uiText("لوحة المطور متاحة لحساب المطور المعتمد فقط.", "The developer panel is restricted to the configured developer account."))
                }
            }
            "settings" -> {
                SectionTitle(uiText("⚙️ إعدادات التطبيق", "⚙️ App settings"))
                InfoCard(uiText("المظهر", "Appearance"), uiText("اختار الشكل اللي يريح عينك.", "Choose the appearance you prefer."))
                Button(onClick = onToggleTheme, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (LocalAppUiSettings.current.darkTheme) uiText("☀️ تفعيل الوضع النهاري", "☀️ Switch to light mode") else uiText("🌙 تفعيل الوضع الليلي", "🌙 Switch to dark mode"))
                }
                InfoCard(uiText("اللغة", "Language"), uiText("تقدر تبدّل بين العربية والإنجليزية في أي وقت.", "Switch between Arabic and English at any time."))
                Button(onClick = onToggleLanguage, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                    Text(if (LocalAppUiSettings.current.english) "العربية" else "English")
                }
                InfoCard(uiText("الصوت والموسيقى", "Sound and music"), uiText("تقدر تتحكم في المؤثرات والموسيقى من أي شاشة لعبة.", "Control sound effects and music from any game screen."))
                InfoCard("Firebase", uiText("تسجيل الدخول والترتيب يحتاجوا إكمال إعدادات Firebase الموضحة في ملف README.", "Sign-in and leaderboard features require the Firebase setup described in README."))
            }
            else -> {
                SectionTitle(if (page == "games") uiText("🎮 مكتبة الألعاب", "🎮 Game library") else uiText("🔥 اختار لعبتك", "🔥 Choose your game"))
                games.forEach { game ->
                    GameCard(game) { if (game.ready) { sound.play(Sfx.Click); sound.vibrate(20); page = game.id } }
                }
                SectionTitle(uiText("🏆 أفضل اللاعبين", "🏆 Top players"))
                if (leaderboard.isEmpty()) InfoCard(uiText("المنافسة لسه بتبدأ", "Competition starts here"), uiText("أول لاعب يسجل نقاط هيحجز مكانه هنا.", "The first player to score will appear here."))
                leaderboard.take(3).forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(listOf("🥇", "🥈", "🥉").getOrElse(index) { "🏅" }, fontSize = 21.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                        Text("${item.points}", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
                Text("DEVELOPED BY MOSTAFA BEK", color = Gold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (isDeveloper && page != "developer") {
            TextButton(onClick = { page = "developer" }, modifier = Modifier.fillMaxWidth()) { Text(uiText("⚙️ فتح لوحة المطور", "⚙️ Open developer panel"), color = Gold) }
        }
    }
}

@Composable
private fun SmallStat(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(PanelAltColor, RoundedCornerShape(14.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 11.sp)
        Text(value, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavButton(title: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected) Gold else PanelColor, contentColor = if (selected) DeepWine else Cream)) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun GameCard(game: GameItem, onClick: () -> Unit) {
    Card(onClick = onClick, enabled = game.ready, colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(game.emoji, fontSize = 31.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(uiText(game.titleAr, game.titleEn), color = Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(uiText(game.subtitleAr, game.subtitleEn), color = Muted, fontSize = 12.sp)
            }
            Text(if (game.ready) uiText("العب الآن ▶", "Play now ▶") else uiText("تحت التطوير", "In development"), color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(title, color = Cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SetupRequiredScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = DeepWine, surface = Wine)) {
        Surface(Modifier.fillMaxSize(), color = DeepWine) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(220.dp))
                Text("ELBASHA GAMES", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                Text(message, color = Cream, textAlign = TextAlign.Center)
            }
        }
    }
}
