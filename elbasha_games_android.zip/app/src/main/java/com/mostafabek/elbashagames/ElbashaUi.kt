package com.mostafabek.elbashagames

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.core.view.WindowInsetsControllerCompat
import android.util.Base64
import android.provider.OpenableColumns
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ElbashaApp(
    auth: FirebaseAuth,
    sound: SoundManager,
    databaseUrl: String,
    onGoogleSignIn: ((String?) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val settingsPrefs = remember { context.getSharedPreferences("elbasha_ui", android.content.Context.MODE_PRIVATE) }
    var english by remember { mutableStateOf(settingsPrefs.getBoolean("english", false)) }
    var darkTheme by remember { mutableStateOf(settingsPrefs.getBoolean("dark_theme", true)) }
    val settings = AppUiSettings(english = english, darkTheme = darkTheme)
    val palette = paletteFor(darkTheme)
    val database = remember(databaseUrl) {
        val candidate = databaseUrl.trim().trimEnd('/')
        val host = candidate.removePrefix("https://").substringBefore('/')
        val looksLikeRealtimeDatabaseUrl = candidate.startsWith("https://") &&
            (host.endsWith(".firebaseio.com") || host.endsWith(".firebasedatabase.app"))
        if (looksLikeRealtimeDatabaseUrl) runCatching { FirebaseDatabase.getInstance(candidate) }.getOrNull() else null
    }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var isDeveloper by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf<String?>(null) }

    val toggleLanguage = {
        english = !english
        settingsPrefs.edit().putBoolean("english", english).apply()
    }
    val toggleTheme = {
        darkTheme = !darkTheme
        settingsPrefs.edit().putBoolean("dark_theme", darkTheme).apply()
    }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(currentUser?.uid) {
        val user = currentUser
        if (user == null) {
            isDeveloper = false
        } else {
            saveUserProfile(database, user)
            // The developer panel is intentionally bound to the configured developer UID only.
            // A database-side boolean must never promote another account to developer access.
            isDeveloper = ElbashaAccess.isDeveloper(user.uid)
        }
    }

    val colorScheme = if (darkTheme) darkColorScheme(
        primary = palette.gold,
        onPrimary = palette.deepWine,
        secondary = Color(0xFFCF8A3C),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    ) else lightColorScheme(
        primary = palette.gold,
        onPrimary = Color.White,
        secondary = Color(0xFFB56A19),
        background = palette.deepWine,
        surface = palette.panel,
        onSurface = palette.cream
    )

    SideEffect {
        context.findActivity()?.window?.let { window ->
            WindowInsetsControllerCompat(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalAppUiSettings provides settings,
        LocalElbashaPalette provides palette,
        LocalLayoutDirection provides if (english) LayoutDirection.Ltr else LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = colorScheme) {
            Box(Modifier.fillMaxSize().elbashaAtmosphere()) {
                Surface(
                    modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
                    color = Color.Transparent
                ) {
                if (currentUser == null) {
                    AuthScreen(
                        auth = auth,
                        database = database,
                        message = authMessage,
                        onMessage = { authMessage = it },
                        onGoogleSignIn = {
                            onGoogleSignIn { error -> authMessage = error ?: if (english) "Signed in with Google" else "تم تسجيل الدخول بحساب Google" }
                        },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                } else {
                    MainHub(
                        user = currentUser!!,
                        database = database,
                        sound = sound,
                        isDeveloper = isDeveloper,
                        onSignOut = { auth.signOut() },
                        onToggleTheme = toggleTheme,
                        onToggleLanguage = toggleLanguage
                    )
                }
                }
            }
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun saveUserProfile(database: FirebaseDatabase?, user: FirebaseUser) {
    if (database == null) return
    val displayName = (user.displayName?.takeIf { it.isNotBlank() }
        ?: user.email?.substringBefore("@")
        ?: "لاعب جديد").take(28)

    // Keep email in the private user node; only the public profile is readable by other players.
    val privateReference = database.reference.child("users").child(user.uid)
    privateReference.get().addOnSuccessListener { snapshot ->
        val privateUpdates = hashMapOf<String, Any>(
            "email" to (user.email ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) privateUpdates["createdAt"] = ServerValue.TIMESTAMP
        privateReference.updateChildren(privateUpdates)
    }

    val publicReference = database.reference.child("publicProfiles").child(user.uid)
    publicReference.get().addOnSuccessListener { snapshot ->
        val publicUpdates = hashMapOf<String, Any>(
            "displayName" to displayName,
            "photoUrl" to (user.photoUrl?.toString() ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) publicUpdates["createdAt"] = ServerValue.TIMESTAMP
        publicReference.updateChildren(publicUpdates)
    }
}

@Composable
private fun AuthScreen(
    auth: FirebaseAuth,
    database: FirebaseDatabase?,
    message: String?,
    onMessage: (String?) -> Unit,
    onGoogleSignIn: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    var registerMode by remember { mutableStateOf(true) }
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val english = LocalAppUiSettings.current.english
    val contextText = if (registerMode) uiText("إنشاء حساب جديد", "Create account") else uiText("تسجيل الدخول", "Sign in")

    Box(
        modifier = Modifier.fillMaxSize().elbashaAtmosphere(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.elbasha_logo),
                contentDescription = "Elbasha Games logo",
                modifier = Modifier.size(220.dp),
                contentScale = ContentScale.Fit
            )
            Text("ELBASHA GAMES", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("THE FOOTBALL PLAYGROUND", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onToggleLanguage) { Text(if (LocalAppUiSettings.current.english) "العربية" else "English", color = Gold) }
                TextButton(onClick = onToggleTheme) { Text(if (LocalAppUiSettings.current.darkTheme) uiText("☀️ الوضع النهاري", "☀️ Light mode") else uiText("🌙 الوضع الليلي", "🌙 Dark mode"), color = Gold) }
            }
            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = PanelColor)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(contextText, color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (registerMode) {
                        OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text(uiText("اسم اللاعب", "Player name")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(uiText("البريد الإلكتروني", "Email address")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(uiText("كلمة المرور", "Password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            onMessage(null)
                            if (!email.contains("@") || password.length < 6 || (registerMode && displayName.trim().length !in 2..28)) {
                                onMessage(if (english) "Check your email, password (6+ characters), and player name (2-28 characters)." else "راجع البريد وكلمة المرور (6 أحرف على الأقل) واسم اللاعب (من حرفين إلى 28)")
                            } else {
                                busy = true
                                val task = if (registerMode) auth.createUserWithEmailAndPassword(email.trim(), password)
                                    else auth.signInWithEmailAndPassword(email.trim(), password)
                                task.addOnCompleteListener { result ->
                                    busy = false
                                    if (result.isSuccessful) {
                                        val signedUser = auth.currentUser
                                        if (registerMode && signedUser != null) {
                                            val request = UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
                                            signedUser.updateProfile(request).addOnCompleteListener {
                                                saveUserProfile(database, signedUser)
                                                signedUser.sendEmailVerification()
                                                onMessage(if (english) "Account created. Check your inbox to verify your email." else "تم إنشاء الحساب. راجع بريدك لتأكيده.")
                                            }
                                        } else {
                                            onMessage(if (english) "Signed in successfully" else "تم تسجيل الدخول بنجاح")
                                        }
                                    } else {
                                        onMessage(result.exception?.localizedMessage ?: "تعذر إكمال العملية")
                                    }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = DeepWine, strokeWidth = 2.dp)
                        else Text(if (registerMode) uiText("إنشاء الحساب", "Create account") else uiText("دخول", "Sign in"), fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onGoogleSignIn,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
                    ) { Text(uiText("الدخول باستخدام Google", "Continue with Google")) }
                    TextButton(onClick = { registerMode = !registerMode; onMessage(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (registerMode) uiText("عندك حساب؟ سجّل دخول", "Already have an account? Sign in") else uiText("لسه جديد؟ أنشئ حساب", "New here? Create an account"), color = Gold)
                    }
                    if (!registerMode) {
                        TextButton(onClick = {
                            if (!email.contains("@")) onMessage(if (english) "Enter your email address first" else "اكتب بريدك الإلكتروني الأول")
                            else auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { task ->
                                onMessage(if (task.isSuccessful) {
                                    if (english) "Password reset link sent" else "تم إرسال رابط استعادة كلمة المرور"
                                } else task.exception?.localizedMessage ?: if (english) "Could not send the link" else "تعذر إرسال الرابط")
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(uiText("نسيت كلمة المرور؟", "Forgot password?"), color = Muted) }
                    }
                    message?.let { Text(it, color = if (it.contains("نجاح") || it.contains("تم إنشاء") || it.contains("تم إرسال") || it.contains("successfully") || it.contains("created") || it.contains("sent")) Gold else LocalElbashaPalette.current.bad, fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("DEVELOPED BY MOSTAFA BEK", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class GameItem(val id: String, val titleAr: String, val titleEn: String, val subtitleAr: String, val subtitleEn: String, val emoji: String, val ready: Boolean = false)
private data class RankItem(val uid: String, val name: String, val points: Long)

@Composable
private fun MainHub(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    isDeveloper: Boolean,
    onSignOut: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit
) {
    val appContext = LocalContext.current
    val english = LocalAppUiSettings.current.english
    var page by remember { mutableStateOf("home") }
    var leaderboard by remember { mutableStateOf<List<RankItem>>(emptyList()) }
    var firebaseConnected by remember { mutableStateOf<Boolean?>(null) }
    var photoCacheRevision by remember { mutableIntStateOf(0) }
    var isLoadingAllPhotos by remember { mutableStateOf(false) }
    var photoLoadProgress by remember { mutableStateOf(0f) }
    var photoLoadStatus by remember { mutableStateOf("") }
    var photoLoadJob by remember { mutableStateOf<Job?>(null) }
    var sharedMusicName by remember { mutableStateOf("") }
    var musicUploadStatus by remember { mutableStateOf("") }
    var appliedMusicTimestamp by remember { mutableStateOf(0L) }
    val uiScope = rememberCoroutineScope()
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            musicUploadStatus = localizedText(english, "جاري قراءة الملف...", "Reading audio file...")
            uiScope.launch {
                try {
                    val (audioBytes, audioName) = withContext(Dispatchers.IO) {
                        val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف")
                        val displayName = appContext.contentResolver.query(
                            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                        val name = displayName?.take(100)?.ifBlank { "Elbasha Music" }
                            ?: uri.lastPathSegment?.substringAfterLast('/')?.take(100)?.ifBlank { "Elbasha Music" }
                            ?: "Elbasha Music"
                        bytes to name
                    }
                    if (audioBytes.isEmpty()) throw IllegalArgumentException("الملف فارغ")
                    val signedInUid = user.uid.takeIf { it.isNotBlank() }
                        ?: throw IllegalStateException(if (english) "Sign in again before uploading shared music." else "سجّل الدخول من جديد قبل رفع موسيقى الجروب.")
                    if (!ElbashaAccess.isDeveloper(signedInUid)) throw SecurityException(
                        if (english) "This account is not the developer account allowed to upload shared music." else "الحساب الحالي ليس حساب المطور المسموح له برفع موسيقى الجروب."
                    )
                    if (audioBytes.size > 5 * 1024 * 1024) throw IllegalArgumentException(
                        if (english) "Choose an audio file smaller than 5 MB." else "اختار ملف صوت أقل من 5 ميجابايت."
                    )
                    val encoded = withContext(Dispatchers.Default) {
                        Base64.encodeToString(audioBytes, Base64.NO_WRAP)
                    }
                    val reference = database?.reference?.child("sharedMusic")?.child("current")
                        ?: throw IllegalStateException(if (english) "Firebase is not configured." else "Firebase غير مهيأ.")
                    val payload = mapOf(
                        "name" to audioName,
                        "mimeType" to (appContext.contentResolver.getType(uri)
                            ?.takeIf { it.startsWith("audio/", ignoreCase = true) }
                            ?: when (audioName.substringAfterLast('.', "").lowercase()) {
                                "mp3" -> "audio/mpeg"
                                "m4a", "mp4" -> "audio/mp4"
                                "wav" -> "audio/wav"
                                "ogg" -> "audio/ogg"
                                else -> "audio/*"
                            }),
                        "data" to encoded,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    reference.setValue(payload).addOnCompleteListener { task ->
                        musicUploadStatus = if (task.isSuccessful) {
                            if (english) "Uploaded. The new track is syncing to everyone." else "تم الرفع. الأغنية الجديدة بتتزامن مع كل اللاعبين."
                        } else {
                            val detail = task.exception?.localizedMessage.orEmpty()
                            if (detail.contains("Permission denied", ignoreCase = true)) {
                                if (english) "Firebase denied this upload. Publish the latest Realtime Database rules and confirm sharedMusic/current is writable by the developer account." else "Firebase رفض الرفع. انشر آخر نسخة من قواعد Realtime Database وتأكد أن حساب المطور لديه صلاحية الكتابة إلى sharedMusic/current."
                            } else detail.ifBlank { if (english) "Upload failed." else "فشل رفع الأغنية." }
                        }
                    }
                } catch (error: Exception) {
                    musicUploadStatus = error.localizedMessage ?: if (english) "Could not upload this audio file." else "تعذر رفع الملف الصوتي."
                }
            }
        }
    }
    val cachedPlayerPhotos = remember(page, photoCacheRevision) { PlayerImageRepository.cachedCount(appContext) }
    val bundledPlayerPhotos = remember(page, photoCacheRevision) { PlayerImageRepository.bundledCount(appContext) }
    val cachedPhotoBytes = remember(page, photoCacheRevision) { PlayerImageRepository.cachedBytes(appContext) }
    val games = listOf(
        GameItem("auction", "المزاد الكروي", "Football Auction", "زايد على النجوم وابنِ فريقك", "Bid for stars and build your squad", "🔨", ready = true),
        GameItem("deal", "صندوق الحظ", "Deal or No Deal", "افتح الصناديق واختبر حظك", "Open the boxes and test your luck", "🎁", ready = true),
        GameItem("build", "كون فريق", "Build Your Team", "اختار فلتر وإحصائية واجمع نقاط", "Choose a filter, stat and score points", "🧩", ready = true)
    )
    // All Build Team modes now live in one screen: AI or 2-4 players passing one phone.
    val localGames = emptyList<GameItem>()
DisposableEffect(database, isDeveloper) {
        val reference = if (isDeveloper) database?.reference?.child(".info/connected") else null
        if (reference == null) {
            firebaseConnected = null
            onDispose { }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    firebaseConnected = snapshot.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(error: DatabaseError) { firebaseConnected = false }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
            }
        }
    }

DisposableEffect(database) {
        val reference = database?.reference?.child("leaderboard")
        if (reference == null) {
            leaderboard = emptyList()
            onDispose { }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    leaderboard = snapshot.children
                        .filter { child -> child.key != ElbashaAccess.DeveloperUid }
                        .map { child ->
                        RankItem(
                            uid = child.key ?: "",
                            name = child.child("displayName").getValue(String::class.java) ?: "لاعب",
                            points = child.child("totalPoints").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedByDescending { it.points }.take(50)
                }
                override fun onCancelled(error: DatabaseError) { }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
            }
        }
    }

    DisposableEffect(database, sound) {
        val reference = database?.reference?.child("sharedMusic")?.child("current")
        if (reference == null) {
            sharedMusicName = ""
            onDispose { sound.clearSharedMusic() }
        } else {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val encoded = snapshot.child("data").getValue(String::class.java)
                    val timestamp = (snapshot.child("updatedAt").value as? Number)?.toLong() ?: 0L
                    val trackName = snapshot.child("name").getValue(String::class.java).orEmpty()
                    val mimeType = snapshot.child("mimeType").getValue(String::class.java).orEmpty()
                    if (encoded.isNullOrBlank() || timestamp <= 0L) {
                        sharedMusicName = ""
                        sound.clearSharedMusic()
                        return
                    }
                    sharedMusicName = trackName
                    if (timestamp != appliedMusicTimestamp) {
                        appliedMusicTimestamp = timestamp
                        uiScope.launch(Dispatchers.IO) {
                            val safeExtension = when {
                                mimeType.contains("mpeg", ignoreCase = true) || trackName.endsWith(".mp3", true) -> ".mp3"
                                mimeType.contains("mp4", ignoreCase = true) || trackName.endsWith(".m4a", true) -> ".m4a"
                                mimeType.contains("wav", ignoreCase = true) || trackName.endsWith(".wav", true) -> ".wav"
                                mimeType.contains("ogg", ignoreCase = true) || trackName.endsWith(".ogg", true) -> ".ogg"
                                else -> ".audio"
                            }
                            val cachedFile = File(appContext.cacheDir, "elbasha_shared_music_$timestamp$safeExtension")
                            val saved = runCatching {
                                val bytes = Base64.decode(encoded, Base64.DEFAULT)
                                require(bytes.isNotEmpty() && bytes.size <= 5 * 1024 * 1024)
                                cachedFile.writeBytes(bytes)
                                cachedFile
                            }.getOrNull()
                            withContext(Dispatchers.Main) {
                                if (saved != null) {
                                    sound.setSharedMusic(saved)
                                    appContext.cacheDir.listFiles()?.filter {
                                        it.name.startsWith("elbasha_shared_music_") && it != saved
                                    }?.forEach { it.delete() }
                                } else musicUploadStatus = if (english) "The shared track could not be decoded." else "تعذر قراءة الأغنية المشتركة."
                            }
                        }
                    }
                }
                override fun onCancelled(error: DatabaseError) {
                    sharedMusicName = ""
                    sound.clearSharedMusic()
                    musicUploadStatus = if (english) "Shared music read failed: ${error.message}. Publish the public sharedMusic rule." else "فشل قراءة موسيقى الجروب: ${error.message}. انشر قاعدة القراءة العامة sharedMusic."
                }
            }
            reference.addValueEventListener(listener)
            onDispose {
                reference.removeEventListener(listener)
                sound.clearSharedMusic()
            }
        }
    }

    when (page) {
        "trivia" -> { TriviaScreen(user, database, sound) { page = "home" }; return }
        "guess" -> { GuessPlayerScreen(user, database, sound) { page = "home" }; return }
        "stats" -> { StatsChallengeScreen(user, database, sound) { page = "home" }; return }
        "build", "build_local" -> { BuildTeamStatScreen(user, database, sound) { page = "home" }; return }
        "auction" -> { AuctionGameScreen(user, database, sound) { page = "home" }; return }
        "deal" -> { DealOrNoDealScreen(user, database, sound) { page = "home" }; return }
        "penalty" -> { PenaltyShootoutScreen(user, database, sound) { page = "home" }; return }
        "rooms" -> { OnlineRoomsScreen(user, database) { page = "home" }; return }
    }

    Column(Modifier.fillMaxSize().elbashaAtmosphere()) {
        Crossfade(
            targetState = page,
            animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing),
            label = "elbasha-main-navigation",
            modifier = Modifier.weight(1f)
        ) { screen ->
            when (screen) {
                "home" -> HomeDashboard(
                    userName = user.displayName ?: user.email?.substringBefore("@") ?: "باشا",
                    leaderboard = leaderboard,
                    userUid = user.uid,
                    games = games,
                    onProfile = { page = "profile" },
                    onPlay = { page = "games" },
                    onRooms = { page = "rooms" },
                    onGame = { game -> if (game.ready) { sound.play(Sfx.Click); sound.vibrate(20); page = game.id } },
                    onLeaderboard = { page = "rank" }
                )
                "games" -> GameLibraryDashboard(
                    games = games,
                    localGames = localGames,
                    onGame = { game -> if (game.ready) { sound.play(Sfx.Click); sound.vibrate(20); page = game.id } },
                    onRooms = { page = "rooms" }
                )
                "honors" -> HonorsDashboard(
                    leaderboard = leaderboard,
                    onLeaderboard = { page = "rank" }
                )
                "rank" -> LeaderboardDashboard(leaderboard, user.uid)
                "profile" -> ProfileDashboard(user.displayName ?: "Elbasha Player", user.email.orEmpty(), user.uid, onSignOut)
                "settings" -> SettingsDashboard(
                    userName = user.displayName ?: user.email?.substringBefore("@") ?: "باشا",
                    email = user.email.orEmpty(),
                    sound = sound,
                    sharedMusicName = sharedMusicName,
                    onToggleTheme = onToggleTheme,
                    onToggleLanguage = onToggleLanguage,
                    onSignOut = onSignOut,
                    onProfile = { page = "profile" },
                    onDeveloper = { page = "developer" },
                    isDeveloper = isDeveloper
                )
                "developer" -> {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitle("Developer Panel")
                        if (isDeveloper) {
                            InfoCard("Mostafa Bek", uiText("صلاحية المطور مفعّلة. دي لوحة تشخيص لحالة المحتوى الحالي.", "Developer access is enabled. This panel reports the current content state."))
                            InfoCard(uiText("قاعدة اللاعبين", "Player database"), "${PlayerDatabase.players.size} ${uiText("لاعبًا", "players")} • ${PlayerDatabase.players.map { it.nationalityEn }.distinct().size} ${uiText("جنسيات", "nationalities")}")
                            InfoCard(uiText("نطاق التقييمات", "Rating range"), "${PlayerDatabase.players.minOf { it.rating }} – ${PlayerDatabase.players.maxOf { it.rating }} OVR • ${PlayerDatabase.players.count { it.rating < 75 }} ${uiText("أقل من 75", "below 75")}")
                            InfoCard(uiText("المراكز المعتمدة", "Canonical positions"), ElbashaPositions.rosterOrder.joinToString("  ›  "))
                            InfoCard(uiText("الأسئلة", "Question bank"), "${QuestionRepository.sample.size} ${uiText("سؤالًا مدمجًا", "built-in questions")}")
                            InfoCard(uiText("صور اللاعبين", "Player photos"), uiText("$bundledPlayerPhotos صورة داخل APK، و$cachedPlayerPhotos صورة في الكاش المحلي (${cachedPhotoBytes / 1024} KB).", "$bundledPlayerPhotos portraits bundled in APK; $cachedPlayerPhotos cached locally (${cachedPhotoBytes / 1024} KB)."))
                            Button(onClick = { PlayerImageRepository.clearCache(appContext); photoCacheRevision++; photoLoadStatus = localizedText(english, "تم مسح الكاش المحلي للصور.", "Local portrait cache cleared.") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)) {
                                Text(uiText("مسح الصور المخزنة مؤقتًا", "Clear cached player photos"))
                            }
                            Button(enabled = !isLoadingAllPhotos, onClick = {
                                photoLoadJob = uiScope.launch {
                                    isLoadingAllPhotos = true; photoLoadProgress = 0f
                                    photoLoadStatus = localizedText(english, "بدأ تحميل الصور تدريجيًا...", "Portrait download started...")
                                    var found = 0
                                    try {
                                        PlayerDatabase.players.forEachIndexed { index, player ->
                                            val bitmap = runCatching { PlayerImageRepository.load(appContext, player.nameEn) }.getOrNull()
                                            if (bitmap != null) found++
                                            photoLoadProgress = (index + 1).toFloat() / PlayerDatabase.players.size.toFloat()
                                            photoLoadStatus = if (english) "${index + 1}/${PlayerDatabase.players.size} checked • $found photos found" else "تم فحص ${index + 1}/${PlayerDatabase.players.size} • تم العثور على $found صورة"
                                            if (index < PlayerDatabase.players.lastIndex) delay(220)
                                        }
                                        photoLoadStatus = if (english) "Finished: $found usable portraits cached." else "اكتمل الفحص: تم تخزين $found صورة متاحة."
                                    } catch (cancelled: CancellationException) {
                                        photoLoadStatus = localizedText(english, "تم إيقاف تحميل الصور.", "Portrait download cancelled.")
                                    } finally { photoCacheRevision++; isLoadingAllPhotos = false; photoLoadJob = null }
                                }
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                                Text(if (isLoadingAllPhotos) uiText("جاري تحميل الصور...", "Loading portraits...") else uiText("تحميل صور اللاعبين (${PlayerDatabase.players.size})", "Download all ${PlayerDatabase.players.size} player portraits"))
                            }
                            if (isLoadingAllPhotos) {
                                LinearProgressIndicator(progress = { photoLoadProgress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor)
                                TextButton(onClick = { photoLoadJob?.cancel() }, modifier = Modifier.fillMaxWidth()) { Text(uiText("إيقاف التحميل", "Cancel photo download"), color = Gold) }
                            }
                            if (photoLoadStatus.isNotBlank()) Text(photoLoadStatus, color = Gold, fontSize = 11.sp)
                            SectionTitle(uiText("الموسيقى المخصصة مستقبلًا", "Future custom music"))
                            InfoCard(uiText("المقطع الحالي", "Current track"), sharedMusicName.ifBlank { localizedText(english, "لا توجد أغنية مفعّلة حاليًا.", "No active shared track.") })
                            Button(onClick = { musicPicker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(uiText("إدارة موسيقى المطور", "Manage developer music")) }
                            if (musicUploadStatus.isNotBlank()) Text(musicUploadStatus, color = Gold, fontSize = 11.sp)
                            InfoCard(uiText("اتصال Firebase", "Firebase connection"), when (firebaseConnected) { true -> uiText("متصل", "Connected"); false -> uiText("غير متصل", "Disconnected"); null -> uiText("غير مهيأ أو جارٍ الفحص", "Not configured or checking") })
                            InfoCard(uiText("نسخة التطبيق", "App build"), "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                        } else InfoCard(uiText("غير مصرح", "Access denied"), uiText("لوحة المطور متاحة لحساب المطور المعتمد فقط.", "Developer access is restricted to the configured account."))
                    }
                }
                else -> HomeDashboard(user.displayName ?: "باشا", leaderboard, user.uid, games, { page = "profile" }, { page = "games" }, { page = "rooms" }, { game -> page = game.id }, { page = "rank" })
            }
        }
        ElbashaBottomBar(currentPage = page, onSelect = { page = it })
    }
}

@Composable
private fun HomeDashboard(
    userName: String,
    leaderboard: List<RankItem>,
    userUid: String,
    games: List<GameItem>,
    onProfile: () -> Unit,
    onPlay: () -> Unit,
    onRooms: () -> Unit,
    onGame: (GameItem) -> Unit,
    onLeaderboard: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    val infinite = rememberInfiniteTransition(label = "elbasha-hero-motion")
    val logoScale by infinite.animateFloat(
        initialValue = 0.985f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "logo-breathe"
    )
    val glowAlpha by infinite.animateFloat(
        initialValue = 0.16f,
        targetValue = 0.34f,
        animationSpec = infiniteRepeatable(tween(2300, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "hero-glow"
    )
    val userRank = leaderboard.indexOfFirst { it.uid == userUid }.takeIf { it >= 0 }?.plus(1)?.toString() ?: "—"
    val points = leaderboard.firstOrNull { it.uid == userUid }?.points?.toString() ?: "0"

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AnimatedVisibility(visible = true, enter = fadeIn(tween(420)) + slideInVertically(tween(420)) { it / 7 }) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(palette.gold, Color(0xFF9B5C18))))
                        .border(2.dp, palette.gold.copy(alpha = 0.65f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(userName.trim().firstOrNull()?.uppercase() ?: "ب", color = palette.deepWine, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(uiText("أهلاً يا $userName", "Welcome, $userName"), color = palette.cream, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(uiText("حساب الباشا", "ELBASHA PLAYER"), color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("♛", color = palette.gold, fontSize = 23.sp, lineHeight = 24.sp)
                    Text(uiText("ملفك الشخصي", "PROFILE"), color = palette.muted, fontSize = 9.sp)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.62f), RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF5A1026), palette.panel, Color(0xFF1D0710))))
                    .padding(16.dp)
            ) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(170.dp).graphicsLayer { alpha = glowAlpha }
                        .background(Brush.radialGradient(listOf(palette.gold.copy(alpha = 0.42f), Color.Transparent)), CircleShape)
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(uiText("مملكة الباشا", "THE PASHA KINGDOM"), color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text(uiText("العرش مستنيك", "YOUR THRONE AWAITS"), color = palette.cream, fontSize = 25.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp)
                            Text(uiText("العبها بدماغك.. واكسبها بشطارتك.", "Play smart. Win with style."), color = palette.muted, fontSize = 12.sp)
                        }
                        Image(
                            painter = painterResource(R.drawable.elbasha_logo),
                            contentDescription = uiText("شعار الباشا جيمز", "Elbasha Games crest"),
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(132.dp).graphicsLayer { scaleX = logoScale; scaleY = logoScale }
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        HeroChip(uiText("3 ألعاب أساسية", "3 CORE GAMES"), palette)
                        HeroChip(uiText("منافسة وتحدي", "COMPETE"), palette)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onPlay,
                modifier = Modifier.weight(1.15f).height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp, pressedElevation = 1.dp)
            ) {
                Text(uiText("ابدأ اللعب", "PLAY NOW"), fontWeight = FontWeight.Black, fontSize = 15.sp)
                Spacer(Modifier.width(6.dp))
                Text("›", fontSize = 25.sp, fontWeight = FontWeight.Black)
            }
            Button(
                onClick = onRooms,
                modifier = Modifier.weight(0.95f).height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Text(uiText("غرف الأصدقاء", "FRIENDS"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MiniMetric(uiText("نقاطك", "POINTS"), points, Modifier.weight(1f), palette)
            MiniMetric(uiText("ترتيبك", "RANK"), userRank, Modifier.weight(1f), palette)
            MiniMetric(uiText("الأبطال", "PLAYERS"), leaderboard.size.toString(), Modifier.weight(1f), palette)
        }

        SectionHeading(
            title = uiText("اختار تحديك", "CHOOSE YOUR CHALLENGE"),
            action = uiText("كل الألعاب", "VIEW ALL"),
            onAction = onPlay
        )
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            games.forEachIndexed { index, game -> CompactGameCard(game, palette, index) { onGame(game) } }
        }

        Card(
            onClick = onRooms,
            modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.28f), RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = palette.panel)
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(palette.gold.copy(alpha = 0.13f)), contentAlignment = Alignment.Center) {
                    Text("10", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(uiText("اجمع الشلة", "BRING THE CREW"), color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(uiText("أنشئ غرفة أو ادخل بكود دعوة", "Create a room or join with a code"), color = palette.muted, fontSize = 11.sp)
                }
                Text("‹", color = palette.gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
        }

        SectionHeading(uiText("سجل الأبطال", "HALL OF CHAMPIONS"), uiText("عرض الكل", "SEE ALL"), onLeaderboard)
        if (leaderboard.isEmpty()) {
            Text(uiText("لسه مفيش أبطال.. أول نتيجة هتبدأ الحكاية.", "No champions yet. The first score starts the story."), color = palette.muted, fontSize = 12.sp)
        } else {
            leaderboard.take(3).forEachIndexed { index, item -> LeaderMiniRow(index, item, palette) }
        }
        Text("ELBASHA GAMES  •  DEVELOPED BY MOSTAFA BEK", color = palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp), textAlign = TextAlign.Center)
    }
}

@Composable
private fun GameLibraryDashboard(
    games: List<GameItem>,
    localGames: List<GameItem>,
    onGame: (GameItem) -> Unit,
    onRooms: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        DashboardHeading(uiText("ساحة الألعاب", "THE GAME ARENA"), uiText("اختار اللعبة وابدأ المنافسة", "Pick a game and enter the arena"))
        games.forEachIndexed { index, game -> CompactGameCard(game, palette, index) { onGame(game) } }
        SectionTitle(uiText("اللعب على نفس الجهاز", "SAME-DEVICE PLAY"))
        localGames.forEachIndexed { index, game -> CompactGameCard(game, palette, index + games.size) { onGame(game) } }
        Card(onClick = onRooms, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = palette.panelAlt)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("⌁", color = palette.gold, fontSize = 26.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(uiText("غرف الأصدقاء", "FRIENDS ROOMS"), color = palette.cream, fontWeight = FontWeight.Bold)
                    Text(uiText("كود دعوة وقائمة أعضاء حتى 10", "Invite code and up to 10 members"), color = palette.muted, fontSize = 11.sp)
                }
                Text("‹", color = palette.gold, fontSize = 24.sp)
            }
        }
    }
}

@Composable
private fun HonorsDashboard(leaderboard: List<RankItem>, onLeaderboard: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        DashboardHeading(uiText("قاعة الشرف", "HALL OF FAME"), uiText("أسماء بتكتب تاريخ الباشا", "The names writing Elbasha history"))
        Card(modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.55f), RoundedCornerShape(24.dp)), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(palette.panelAlt, palette.panel))).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("♛", color = palette.gold, fontSize = 42.sp)
                Text(uiText("عرش الأبطال", "CHAMPIONS' THRONE"), color = palette.gold, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text(uiText("كل نقطة بتقربك من القمة.", "Every point takes you closer to the top."), color = palette.muted, fontSize = 12.sp)
                Text("${leaderboard.size} ${uiText("لاعب في السجل", "players on the board")}", color = palette.cream, fontWeight = FontWeight.Bold)
            }
        }
        SectionTitle(uiText("ضيوف الشرف", "HONORED GUESTS"))
        HonoredGuestCard("ياسين حسام", "ي", palette)
        HonoredGuestCard("عيسوي", "ع", palette)
        Text(
            uiText("أعضاء مميزون من مجتمع Top10Bitches", "Featured members of the Top10Bitches community"),
            color = palette.muted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 3.dp)
        )
        SectionHeading(uiText("المتصدرون", "LEADERBOARD"), uiText("تفاصيل", "DETAILS"), onLeaderboard)
        if (leaderboard.isEmpty()) {
            InfoCard(uiText("السجل لسه فاضي", "The hall is waiting"), uiText("أول لاعب يسجل نقاط هياخد مكانه هنا.", "The first player to score will appear here."))
        } else leaderboard.take(10).forEachIndexed { index, item -> LeaderMiniRow(index, item, palette, large = true) }
    }
}

@Composable
private fun LeaderboardDashboard(leaderboard: List<RankItem>, userUid: String) {
    val palette = LocalElbashaPalette.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        DashboardHeading(uiText("ترتيب الأبطال", "CHAMPION RANKING"), uiText("المطور خارج المنافسة", "Developer account excluded"))
        if (leaderboard.isEmpty()) InfoCard(uiText("لسه مفيش نتائج", "No results yet"), uiText("أول ما النقاط تتسجل، الترتيب هيظهر هنا.", "Rankings appear after the first scores are saved."))
        leaderboard.forEachIndexed { index, item -> LeaderMiniRow(index, item, palette, large = true, highlighted = item.uid == userUid) }
    }
}

@Composable
private fun ProfileDashboard(name: String, email: String, uid: String, onSignOut: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DashboardHeading(uiText("حساب الباشا", "PLAYER PROFILE"), uiText("بيانات حسابك", "Your account details"))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(74.dp).clip(CircleShape).background(Brush.linearGradient(listOf(palette.gold, Color(0xFF925016)))), contentAlignment = Alignment.Center) {
                    Text(name.firstOrNull()?.uppercase() ?: "ب", color = palette.deepWine, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
                Text(name, color = palette.cream, fontSize = 19.sp, fontWeight = FontWeight.Black)
                Text(email, color = palette.muted, fontSize = 12.sp)
            }
        }
        InfoCard(uiText("معرّف الحساب", "ACCOUNT ID"), uid)
        Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.bad, contentColor = Color.White)) { Text(uiText("تسجيل الخروج", "SIGN OUT"), fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun SettingsDashboard(
    userName: String,
    email: String,
    sound: SoundManager,
    sharedMusicName: String,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit,
    onSignOut: () -> Unit,
    onProfile: () -> Unit,
    onDeveloper: () -> Unit,
    isDeveloper: Boolean
) {
    val palette = LocalElbashaPalette.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        DashboardHeading(uiText("إعدادات الباشا", "PASHA SETTINGS"), uiText("كل حاجة في مكانها", "Everything in its place"))
        Card(onClick = onProfile, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(CircleShape).background(palette.gold.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { Text("♙", color = palette.gold, fontSize = 25.sp) }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(userName, color = palette.cream, fontWeight = FontWeight.Bold)
                    Text(email, color = palette.muted, fontSize = 11.sp)
                }
                Text("‹", color = palette.gold, fontSize = 24.sp)
            }
        }
        SettingsGroupTitle(uiText("التخصيص", "PERSONALIZATION"), palette)
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Button(onClick = onToggleTheme, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)) {
                Text(if (LocalAppUiSettings.current.darkTheme) uiText("الوضع النهاري", "LIGHT MODE") else uiText("الوضع الليلي", "DARK MODE"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Button(onClick = onToggleLanguage, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)) {
                Text(if (LocalAppUiSettings.current.english) "العربية" else "English", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        SettingsGroupTitle(uiText("الصوت", "AUDIO"), palette)
        Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(uiText("موسيقى الجروب", "Shared music"), color = palette.cream, fontWeight = FontWeight.Bold)
                    val playbackLabel = when (sound.musicPlaybackStatus) {
                        "playing" -> uiText("بتشتغل على الجهاز ده", "Playing on this device")
                        "muted" -> uiText("الأغنية وصلت، لكن الصوت مكتوم", "Track synced, but music is muted")
                        "paused" -> uiText("متوقفة مؤقتًا", "Paused")
                        "preparing", "waiting_for_track" -> uiText("جاري تجهيز الأغنية أو انتظار المزامنة", "Preparing track or waiting for sync")
                        "no_track" -> uiText("مفيش أغنية مشتركة متزامنة حاليًا", "No shared track has synced yet")
                        else -> uiText("تعذر تشغيل الملف الصوتي: ${sound.musicPlaybackStatus}", "Audio playback error: ${sound.musicPlaybackStatus}")
                    }
                    Text(
                        (if (sharedMusicName.isNotBlank()) uiText("الأغنية: $sharedMusicName", "Track: $sharedMusicName") else "") + "\n" + playbackLabel,
                        color = palette.muted, fontSize = 11.sp, maxLines = 3
                    )
                }
                Button(onClick = { sound.toggleMusic() }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = if (sound.musicOn) palette.good else palette.panelAlt, contentColor = Color.White)) {
                    Text(if (sound.musicOn) uiText("مفعّلة", "ON") else uiText("مكتومة", "OFF"), fontWeight = FontWeight.Bold)
                }
            }
        }
        Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(uiText("المؤثرات الصوتية", "Sound effects"), color = palette.cream, fontWeight = FontWeight.Bold)
                    Text(uiText("أصوات اللعب والفوز والخسارة", "Gameplay, win and loss effects"), color = palette.muted, fontSize = 11.sp)
                }
                Button(onClick = { sound.toggleSound() }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = if (sound.soundOn) palette.good else palette.panelAlt, contentColor = Color.White)) {
                    Text(if (sound.soundOn) uiText("مفعّلة", "ON") else uiText("مكتومة", "OFF"), fontWeight = FontWeight.Bold)
                }
            }
        }
        SettingsGroupTitle(uiText("التطبيق", "APPLICATION"), palette)
        AppUpdaterCard()
        InfoCard(uiText("حسابك", "Your account"), uiText("بياناتك ونتائجك مرتبطة بحسابك. استخدم تسجيل الخروج لو هتبدّل الحساب.", "Your profile and results are linked to your account. Sign out before switching accounts."))
        if (isDeveloper) {
            Button(onClick = onDeveloper, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(uiText("لوحة المطور", "DEVELOPER PANEL"), fontWeight = FontWeight.Black) }
        }
        Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = palette.bad, contentColor = Color.White)) { Text(uiText("تسجيل الخروج", "SIGN OUT"), fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ElbashaBottomBar(currentPage: String, onSelect: (String) -> Unit) {
    val palette = LocalElbashaPalette.current
    val selectedPage = when (currentPage) {
        "games" -> "games"
        "honors", "rank" -> "honors"
        "settings", "developer", "profile" -> "settings"
        else -> "home"
    }
    NavigationBar(containerColor = palette.deepWine.copy(alpha = 0.98f), contentColor = palette.cream, tonalElevation = 10.dp) {
        NavigationBarItem(
            selected = selectedPage == "games", onClick = { onSelect("games") },
            icon = { Text("⚽", fontSize = 20.sp) },
            label = { Text(uiText("الألعاب", "PLAY"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = palette.deepWine, selectedTextColor = palette.gold, indicatorColor = palette.gold.copy(alpha = 0.95f), unselectedIconColor = palette.muted, unselectedTextColor = palette.muted)
        )
        NavigationBarItem(
            selected = selectedPage == "home", onClick = { onSelect("home") },
            icon = { Text("♛", fontSize = 22.sp) },
            label = { Text(uiText("الرئيسية", "HOME"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = palette.deepWine, selectedTextColor = palette.gold, indicatorColor = palette.gold.copy(alpha = 0.95f), unselectedIconColor = palette.muted, unselectedTextColor = palette.muted)
        )
        NavigationBarItem(
            selected = selectedPage == "honors", onClick = { onSelect("honors") },
            icon = { Text("✦", fontSize = 21.sp) },
            label = { Text(uiText("الشرف", "HONORS"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = palette.deepWine, selectedTextColor = palette.gold, indicatorColor = palette.gold.copy(alpha = 0.95f), unselectedIconColor = palette.muted, unselectedTextColor = palette.muted)
        )
        NavigationBarItem(
            selected = selectedPage == "settings", onClick = { onSelect("settings") },
            icon = { Text("⚙", fontSize = 21.sp) },
            label = { Text(uiText("الإعدادات", "SETTINGS"), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = palette.deepWine, selectedTextColor = palette.gold, indicatorColor = palette.gold.copy(alpha = 0.95f), unselectedIconColor = palette.muted, unselectedTextColor = palette.muted)
        )
    }
}

@Composable
private fun CompactGameCard(
    game: GameItem,
    palette: ElbashaPalette,
    animationIndex: Int = 0,
    onClick: () -> Unit
) {
    var visible by remember(game.id) { mutableStateOf(false) }
    LaunchedEffect(game.id, animationIndex) {
        delay((animationIndex.coerceIn(0, 7) * 55L))
        visible = true
    }
    val interaction = remember(game.id) { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && game.ready) 0.975f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "game-card-press-${game.id}"
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(280)) + slideInVertically(tween(280)) { it / 5 }
    ) {
    Card(
        modifier = Modifier.fillMaxWidth().height(94.dp)
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = game.ready,
                onClick = onClick
            )
            .animateContentSize()
            .border(1.dp, palette.gold.copy(alpha = 0.24f), RoundedCornerShape(19.dp)),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = palette.panel)
    ) {
        Row(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(palette.panelAlt.copy(alpha = 0.88f), palette.panel))).padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(palette.gold.copy(alpha = 0.24f), palette.gold.copy(alpha = 0.07f)))), contentAlignment = Alignment.Center) {
                Text(game.emoji, fontSize = 29.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(uiText(game.titleAr, game.titleEn), color = palette.cream, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text(uiText(game.subtitleAr, game.subtitleEn), color = palette.muted, fontSize = 10.sp, maxLines = 1)
                Text(if (game.ready) uiText("متاحة للعب", "READY TO PLAY") else uiText("قريبًا", "COMING SOON"), color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Text("‹", color = palette.gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
    }
    }
}

@Composable
private fun HonoredGuestCard(name: String, initial: String, palette: ElbashaPalette) {
    Card(
        modifier = Modifier.fillMaxWidth()
            .border(1.dp, palette.gold.copy(alpha = 0.28f), RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = palette.panel)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(palette.gold.copy(alpha = 0.30f), palette.gold.copy(alpha = 0.10f))))
                    .border(1.dp, palette.gold.copy(alpha = 0.50f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(initial, color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(name, color = palette.cream, fontSize = 15.sp, fontWeight = FontWeight.Black)
                Text("TOP10BITCHES", color = palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Text("♛", color = palette.gold, fontSize = 23.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    val palette = LocalElbashaPalette.current
    Text(title, color = palette.gold, fontSize = 16.sp, fontWeight = FontWeight.Black)
}

@Composable
private fun DashboardHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SectionHeading(title: String, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        TextButton(onClick = onAction, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
            Text(action, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingsGroupTitle(title: String, palette: ElbashaPalette) {
    Text(title, color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.0.sp)
}

@Composable
private fun HeroChip(text: String, palette: ElbashaPalette) {
    Text(text, color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(palette.gold.copy(alpha = 0.12f), RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
}

@Composable
private fun MiniMetric(title: String, value: String, modifier: Modifier, palette: ElbashaPalette) {
    Column(modifier.clip(RoundedCornerShape(15.dp)).background(palette.panel.copy(alpha = 0.92f)).border(1.dp, palette.gold.copy(alpha = 0.12f), RoundedCornerShape(15.dp)).padding(vertical = 10.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value, color = palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text(title, color = palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun LeaderMiniRow(index: Int, item: RankItem, palette: ElbashaPalette, large: Boolean = false, highlighted: Boolean = false) {
    val medal = when (index) { 0 -> "I"; 1 -> "II"; 2 -> "III"; else -> "${index + 1}" }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(if (highlighted) palette.gold.copy(alpha = 0.15f) else palette.panel)
            .border(1.dp, if (index == 0) palette.gold.copy(alpha = 0.35f) else palette.gold.copy(alpha = 0.10f), RoundedCornerShape(15.dp))
            .padding(horizontal = 13.dp, vertical = if (large) 13.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(if (large) 35.dp else 30.dp).clip(CircleShape).background(palette.gold.copy(alpha = if (index == 0) 0.24f else 0.10f)), contentAlignment = Alignment.Center) {
            Text(medal, color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(11.dp))
        Text(item.name, color = palette.cream, fontWeight = FontWeight.Bold, fontSize = if (large) 13.sp else 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
        Text("${item.points}", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String) {
    val palette = LocalElbashaPalette.current
    Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(title, color = palette.cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = palette.muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SetupRequiredScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = DeepWine, surface = Wine)) {
        Surface(Modifier.fillMaxSize(), color = DeepWine) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(220.dp))
                Text("ELBASHA GAMES", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                Text(message, color = Cream, textAlign = TextAlign.Center)
            }
        }
    }
}
