package com.mostafabek.elbashagames

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

private val Wine = Color(0xFF500014)
private val DeepWine = Color(0xFF210009)
private val Gold = Color(0xFFE8B64E)
private val Cream = Color(0xFFFFF0D2)
private val Muted = Color(0xFFCABBAA)

@Composable
fun ElbashaApp(
    auth: FirebaseAuth,
    databaseUrl: String,
    onGoogleSignIn: ((String?) -> Unit) -> Unit
) {
    val database = remember(databaseUrl) { FirebaseDatabase.getInstance(databaseUrl) }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var isDeveloper by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf<String?>(null) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(currentUser?.uid) {
        val user = currentUser
        if (user == null) {
            isDeveloper = false
        } else {
            saveUserProfile(database, user)
            database.reference.child("admins").child(user.uid).get()
                .addOnSuccessListener { isDeveloper = it.getValue(Boolean::class.java) == true }
                .addOnFailureListener { isDeveloper = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold,
        onPrimary = DeepWine,
        secondary = Color(0xFFCF8A3C),
        background = DeepWine,
        surface = Color(0xFF35101B),
        onSurface = Cream
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = DeepWine) {
            if (currentUser == null) {
                AuthScreen(
                    auth = auth,
                    database = database,
                    message = authMessage,
                    onMessage = { authMessage = it },
                    onGoogleSignIn = {
                        onGoogleSignIn { error -> authMessage = error ?: "تم تسجيل الدخول بحساب Google" }
                    }
                )
            } else {
                MainHub(
                    user = currentUser!!,
                    database = database,
                    isDeveloper = isDeveloper,
                    onSignOut = { auth.signOut() }
                )
            }
        }
    }
}

private fun saveUserProfile(database: FirebaseDatabase, user: FirebaseUser) {
    val displayName = user.displayName?.takeIf { it.isNotBlank() }
        ?: user.email?.substringBefore("@")
        ?: "لاعب جديد"

    // Keep email in the private user node; only the public profile is readable by other players.
    val privateReference = database.reference.child("users").child(user.uid)
    privateReference.get().addOnSuccessListener { snapshot ->
        val privateUpdates = hashMapOf<String, Any>(
            "email" to (user.email ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) privateUpdates["createdAt"] = ServerValue.TIMESTAMP
        privateReference.updateChildren(privateUpdates)
    }

    val publicReference = database.reference.child("publicProfiles").child(user.uid)
    publicReference.get().addOnSuccessListener { snapshot ->
        val publicUpdates = hashMapOf<String, Any>(
            "displayName" to displayName,
            "photoUrl" to (user.photoUrl?.toString() ?: ""),
            "updatedAt" to ServerValue.TIMESTAMP
        )
        if (!snapshot.child("createdAt").exists()) publicUpdates["createdAt"] = ServerValue.TIMESTAMP
        publicReference.updateChildren(publicUpdates)
    }
}

@Composable
private fun AuthScreen(
    auth: FirebaseAuth,
    database: FirebaseDatabase,
    message: String?,
    onMessage: (String?) -> Unit,
    onGoogleSignIn: () -> Unit
) {
    var registerMode by remember { mutableStateOf(true) }
    var displayName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val contextText = if (registerMode) "إنشاء حساب جديد" else "تسجيل الدخول"

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.elbasha_logo),
                contentDescription = "Elbasha Games logo",
                modifier = Modifier.size(220.dp),
                contentScale = ContentScale.Fit
            )
            Text("ELBASHA GAMES", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("THE FOOTBALL PLAYGROUND", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF35101B))
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(contextText, color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (registerMode) {
                        OutlinedTextField(value = displayName, onValueChange = { displayName = it }, label = { Text("اسم اللاعب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("البريد الإلكتروني") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("كلمة المرور") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            onMessage(null)
                            if (!email.contains("@") || password.length < 6 || (registerMode && displayName.isBlank())) {
                                onMessage("راجع البريد وكلمة المرور (6 أحرف على الأقل) واسم اللاعب")
                            } else {
                                busy = true
                                val task = if (registerMode) auth.createUserWithEmailAndPassword(email.trim(), password)
                                    else auth.signInWithEmailAndPassword(email.trim(), password)
                                task.addOnCompleteListener { result ->
                                    busy = false
                                    if (result.isSuccessful) {
                                        val signedUser = auth.currentUser
                                        if (registerMode && signedUser != null) {
                                            val request = UserProfileChangeRequest.Builder().setDisplayName(displayName.trim()).build()
                                            signedUser.updateProfile(request).addOnCompleteListener {
                                                saveUserProfile(database, signedUser)
                                                signedUser.sendEmailVerification()
                                                onMessage("تم إنشاء الحساب. راجع بريدك لتأكيده.")
                                            }
                                        } else {
                                            onMessage("تم تسجيل الدخول بنجاح")
                                        }
                                    } else {
                                        onMessage(result.exception?.localizedMessage ?: "تعذر إكمال العملية")
                                    }
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = DeepWine, strokeWidth = 2.dp)
                        else Text(if (registerMode) "إنشاء الحساب" else "دخول", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = onGoogleSignIn,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B2630), contentColor = Cream)
                    ) { Text("الدخول باستخدام Google") }
                    TextButton(onClick = { registerMode = !registerMode; onMessage(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (registerMode) "عندك حساب؟ سجّل دخول" else "لسه جديد؟ أنشئ حساب", color = Gold)
                    }
                    if (!registerMode) {
                        TextButton(onClick = {
                            if (!email.contains("@")) onMessage("اكتب بريدك الإلكتروني الأول")
                            else auth.sendPasswordResetEmail(email.trim()).addOnCompleteListener { task ->
                                onMessage(if (task.isSuccessful) "تم إرسال رابط استعادة كلمة المرور" else task.exception?.localizedMessage ?: "تعذر إرسال الرابط")
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("نسيت كلمة المرور؟", color = Muted) }
                    }
                    message?.let { Text(it, color = if (it.contains("نجاح") || it.contains("تم إنشاء") || it.contains("تم إرسال")) Gold else Color(0xFFFFA9A9), fontSize = 13.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("DEVELOPED BY MOSTAFA BEK", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class GameItem(val title: String, val subtitle: String, val emoji: String)
private data class RankItem(val uid: String, val name: String, val points: Long)

@Composable
private fun MainHub(user: FirebaseUser, database: FirebaseDatabase, isDeveloper: Boolean, onSignOut: () -> Unit) {
    var page by remember { mutableStateOf("home") }
    var leaderboard by remember { mutableStateOf<List<RankItem>>(emptyList()) }
    val games = listOf(
        GameItem("المزاد الكروي", "زايد على النجوم وابنِ فريقك", "🔨"),
        GameItem("Deal or No Deal", "افتح الصناديق واختبر حظك", "🎁"),
        GameItem("Build a Team", "كوّن تشكيلة حسب شروط التحدي", "🧩"),
        GameItem("خمن اللاعب", "صور وتلميحات ومسيرات", "🕵️"),
        GameItem("تحدي المعلومات", "مكتبة أسئلة كروية كبيرة", "🧠"),
        GameItem("تحدي الإحصائيات", "مين رقمه أحسن؟", "📊")
    )

    DisposableEffect(database) {
        val reference = database.reference.child("leaderboard")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                leaderboard = snapshot.children.map { child ->
                    RankItem(
                        uid = child.key ?: "",
                        name = child.child("displayName").getValue(String::class.java) ?: "لاعب",
                        points = child.child("totalPoints").getValue(Long::class.java) ?: 0L
                    )
                }.sortedByDescending { it.points }.take(50)
            }
            override fun onCancelled(error: DatabaseError) { }
        }
        reference.addValueEventListener(listener)
        onDispose { reference.removeEventListener(listener) }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine)))
            .verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(76.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("ELBASHA GAMES", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("أهلاً يا ${user.displayName ?: user.email?.substringBefore("@") ?: "باشا"}", color = Cream, fontSize = 15.sp)
            }
            Text("👑", fontSize = 28.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF35101B)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("الملعب تحت أمرك", color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("اجمع نقاطك، نافس أصحابك، واثبت إنك مش حافظ ويكيبيديا بس.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallStat("الألعاب", "${games.size}", Modifier.weight(1f))
                    SmallStat("المتصدرون", "${leaderboard.size}", Modifier.weight(1f))
                    SmallStat("الرتبة", if (leaderboard.any { it.uid == user.uid }) "${leaderboard.indexOfFirst { it.uid == user.uid } + 1}" else "—", Modifier.weight(1f))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            NavButton("الرئيسية", page == "home", Modifier.weight(1f)) { page = "home" }
            NavButton("الألعاب", page == "games", Modifier.weight(1f)) { page = "games" }
            NavButton("الترتيب", page == "rank", Modifier.weight(1f)) { page = "rank" }
            NavButton("حسابي", page == "profile", Modifier.weight(1f)) { page = "profile" }
        }

        when (page) {
            "rank" -> {
                SectionTitle("🏆 لوحة المتصدرين")
                if (leaderboard.isEmpty()) InfoCard("لسه مفيش نتائج", "أول ما النقاط تتسجل، ترتيب الأبطال هيظهر هنا.")
                leaderboard.forEachIndexed { index, item ->
                    Card(colors = CardDefaults.cardColors(containerColor = if (item.uid == user.uid) Color(0xFF62401A) else Color(0xFF35101B))) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${index + 1}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(14.dp))
                            Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                            Text("${item.points} نقطة", color = Gold, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            "profile" -> {
                SectionTitle("👤 حساب اللاعب")
                InfoCard(user.displayName ?: "لاعب Elbasha", user.email ?: "")
                InfoCard("معرّف الحساب", user.uid)
                Button(onClick = onSignOut, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text("تسجيل الخروج") }
            }
            "developer" -> {
                SectionTitle("⚙️ Developer Panel")
                if (isDeveloper) {
                    InfoCard("مرحبًا Mostafa Bek", "صلاحية المطور مفعّلة. إدارة مكتبة الأسئلة والأعضاء والغرف والنقاط هتتضاف في المرحلة التالية.")
                } else {
                    InfoCard("غير مصرح", "لوحة المطور متاحة لحساب المطور المعتمد فقط.")
                }
            }
            else -> {
                SectionTitle(if (page == "games") "🎮 مكتبة الألعاب" else "🔥 اختار لعبتك")
                games.forEach { game -> GameCard(game) }
                SectionTitle("🏆 أفضل اللاعبين")
                if (leaderboard.isEmpty()) InfoCard("المنافسة لسه بتبدأ", "أول لاعب يسجل نقاط هيحجز مكانه هنا.")
                leaderboard.take(3).forEachIndexed { index, item ->
                    Row(Modifier.fillMaxWidth().background(Color(0xFF35101B), RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(listOf("🥇", "🥈", "🥉").getOrElse(index) { "🏅" }, fontSize = 21.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(item.name, color = Cream, modifier = Modifier.weight(1f))
                        Text("${item.points}", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
                Text("DEVELOPED BY MOSTAFA BEK", color = Gold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        if (isDeveloper && page != "developer") {
            TextButton(onClick = { page = "developer" }, modifier = Modifier.fillMaxWidth()) { Text("⚙️ فتح لوحة المطور", color = Gold) }
        }
    }
}

@Composable
private fun SmallStat(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF4A1B28), RoundedCornerShape(14.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 11.sp)
        Text(value, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavButton(title: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected) Gold else Color(0xFF35101B), contentColor = if (selected) DeepWine else Cream)) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun GameCard(game: GameItem) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF35101B)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(game.emoji, fontSize = 31.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(game.title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(game.subtitle, color = Muted, fontSize = 12.sp)
            }
            Text("قريبًا", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF35101B)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) {
            Text(title, color = Cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SetupRequiredScreen(message: String) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = DeepWine, surface = Wine)) {
        Surface(Modifier.fillMaxSize(), color = DeepWine) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Image(painterResource(R.drawable.elbasha_logo), contentDescription = null, modifier = Modifier.size(220.dp))
                Text("ELBASHA GAMES", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                Text(message, color = Cream, textAlign = TextAlign.Center)
            }
        }
    }
}
