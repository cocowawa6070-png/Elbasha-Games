package com.mostafabek.elbashagames

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

/** The whole simulated match lasts this many real seconds: 1 second = 1 match minute. */
const val LIVE_MATCH_SECONDS = 90

enum class MatchEventType { KICKOFF, GOAL, PENALTY_GOAL, PENALTY_MISSED, YELLOW, RED, SAVE, POST, HALF_TIME, FULL_TIME }

/** [side] is 0 for the user's team, 1 for the opponent, -1 for neutral markers. */
data class MatchEvent(val minute: Int, val type: MatchEventType, val side: Int, val player: PlayerCard?)

/**
 * Builds a believable list of match events around an already-decided [MatchScore], so the live
 * view always ends on exactly the score that the rest of the game (points, saving) uses.
 */
object MatchTimelineEngine {
    fun build(
        userTeam: List<PlayerCard>,
        opponentTeam: List<PlayerCard>,
        score: MatchScore,
        random: Random = Random.Default
    ): List<MatchEvent> {
        val teams = listOf(userTeam, opponentTeam)
        val taken = mutableSetOf(45, 90)
        val events = mutableListOf<MatchEvent>()

        fun freeMinute(from: Int = 2, until: Int = 90): Int {
            repeat(30) {
                val minute = random.nextInt(from, until)
                if (taken.add(minute)) return minute
            }
            var fallback = from
            while (fallback < until && fallback in taken) fallback++
            taken.add(fallback)
            return fallback
        }

        fun attacker(team: List<PlayerCard>): PlayerCard? = pickWeighted(team, random) { player ->
            val role = ElbashaPositions.poolRole(player.position)
            player.rating * when (role) { "ST" -> 3.0; "WG" -> 2.2; "MF" -> 1.2; "DF" -> 0.35; else -> 0.0 }
        }

        fun fieldPlayer(team: List<PlayerCard>): PlayerCard? = pickWeighted(team, random) { player ->
            when (ElbashaPositions.poolRole(player.position)) { "GK" -> 0.0; "DF" -> 2.0; "MF" -> 1.5; else -> 1.0 }
        }

        fun keeper(team: List<PlayerCard>): PlayerCard? =
            team.firstOrNull { ElbashaPositions.poolRole(it.position) == "GK" } ?: team.firstOrNull()

        events += MatchEvent(0, MatchEventType.KICKOFF, -1, null)

        // Goals (the real score).
        listOf(score.userGoals, score.opponentGoals).forEachIndexed { side, goals ->
            repeat(goals) {
                val type = if (random.nextDouble() < 0.12) MatchEventType.PENALTY_GOAL else MatchEventType.GOAL
                events += MatchEvent(freeMinute(3, 90), type, side, attacker(teams[side]))
            }
        }

        // Cards.
        repeat(random.nextInt(2, 5)) {
            val side = random.nextInt(2)
            events += MatchEvent(freeMinute(8, 90), MatchEventType.YELLOW, side, fieldPlayer(teams[side]))
        }
        if (random.nextDouble() < 0.16) {
            val side = random.nextInt(2)
            events += MatchEvent(freeMinute(25, 90), MatchEventType.RED, side, fieldPlayer(teams[side]))
        }

        // Drama: a missed penalty, saves and shots off the woodwork.
        if (random.nextDouble() < 0.30) {
            val side = random.nextInt(2)
            events += MatchEvent(freeMinute(10, 88), MatchEventType.PENALTY_MISSED, side, attacker(teams[side]))
        }
        repeat(random.nextInt(2, 5)) {
            val defendingSide = random.nextInt(2)
            events += MatchEvent(freeMinute(5, 89), MatchEventType.SAVE, defendingSide, keeper(teams[defendingSide]))
        }
        repeat(random.nextInt(1, 3)) {
            val side = random.nextInt(2)
            events += MatchEvent(freeMinute(5, 89), MatchEventType.POST, side, attacker(teams[side]))
        }

        events += MatchEvent(45, MatchEventType.HALF_TIME, -1, null)
        events += MatchEvent(90, MatchEventType.FULL_TIME, -1, null)
        return events.sortedBy { it.minute }
    }

    private fun pickWeighted(team: List<PlayerCard>, random: Random, weightOf: (PlayerCard) -> Double): PlayerCard? {
        if (team.isEmpty()) return null
        val weights = team.map { weightOf(it).coerceAtLeast(0.0) }
        val total = weights.sum()
        if (total <= 0.0) return team[random.nextInt(team.size)]
        var roll = random.nextDouble() * total
        for (index in team.indices) {
            roll -= weights[index]
            if (roll <= 0.0) return team[index]
        }
        return team.last()
    }
}

private fun isGoal(event: MatchEvent): Boolean =
    event.type == MatchEventType.GOAL || event.type == MatchEventType.PENALTY_GOAL

private fun eventEmoji(type: MatchEventType): String = when (type) {
    MatchEventType.KICKOFF -> "🟢"
    MatchEventType.GOAL -> "⚽"
    MatchEventType.PENALTY_GOAL -> "🎯"
    MatchEventType.PENALTY_MISSED -> "❌"
    MatchEventType.YELLOW -> "🟨"
    MatchEventType.RED -> "🟥"
    MatchEventType.SAVE -> "🧤"
    MatchEventType.POST -> "💥"
    MatchEventType.HALF_TIME -> "⏸"
    MatchEventType.FULL_TIME -> "🏁"
}

private fun describe(event: MatchEvent, english: Boolean, userName: String, opponentName: String): String {
    val team = when (event.side) { 0 -> userName; 1 -> opponentName; else -> "" }
    val player = event.player?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) }
        ?: if (english) "A player" else "لاعب"
    return when (event.type) {
        MatchEventType.KICKOFF -> if (english) "Kick-off! The match is underway." else "صافرة البداية! المباراة بدأت."
        MatchEventType.GOAL -> if (english) "GOOOAL! $player scores for $team!" else "جوووون! $player يسجل لـ$team!"
        MatchEventType.PENALTY_GOAL -> if (english) "Penalty scored! $player is cool as ice for $team." else "ضربة جزاء… جوووون! $player يسجلها لـ$team."
        MatchEventType.PENALTY_MISSED -> if (english) "Penalty MISSED! $player fires it away for $team." else "ضربة جزاء ضائعة! $player يهدرها لـ$team."
        MatchEventType.YELLOW -> if (english) "Yellow card for $player ($team)." else "كرت أصفر لـ$player ($team)."
        MatchEventType.RED -> if (english) "RED CARD! $player ($team) is sent off!" else "كرت أحمر! $player ($team) يُطرد من الملعب!"
        MatchEventType.SAVE -> if (english) "What a save by $player! $team deny a certain goal." else "تصدي خرافي من $player! $team ينقذ هدف محقق."
        MatchEventType.POST -> if (english) "$player hits the post for $team!" else "$player يسدد وتصطدم بالعارضة لصالح $team!"
        MatchEventType.HALF_TIME -> if (english) "Half-time whistle." else "نهاية الشوط الأول."
        MatchEventType.FULL_TIME -> if (english) "Full-time whistle!" else "صافرة النهاية!"
    }
}

/**
 * Live 90-second match view: a progress bar that fills with the match clock, a running
 * scoreboard, and an event feed (goals, cards, saves, missed penalties...) that appears one
 * item at a time. [onFinished] fires when the player taps the result button after full time.
 */
@Composable
fun LiveMatchSimulation(
    userName: String,
    opponentName: String,
    userSquad: List<PlayerCard>,
    opponentSquad: List<PlayerCard>,
    score: MatchScore,
    english: Boolean,
    sound: SoundManager,
    onFinished: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    val events = remember(score, userSquad, opponentSquad) {
        MatchTimelineEngine.build(userSquad, opponentSquad, score)
    }
    var minute by remember(events) { mutableIntStateOf(0) }
    val finished = minute >= LIVE_MATCH_SECONDS

    LaunchedEffect(events) {
        sound.play(Sfx.HiddenReveal)
        while (minute < LIVE_MATCH_SECONDS) {
            delay(1_000)
            minute += 1
        }
    }

    // Sound + haptic-style cue for every event that happens in the current minute.
    LaunchedEffect(minute) {
        events.filter { it.minute == minute && minute > 0 }.forEach { event ->
            when (event.type) {
                MatchEventType.GOAL, MatchEventType.PENALTY_GOAL ->
                    sound.play(if (event.side == 0) Sfx.Correct else Sfx.Wrong)
                MatchEventType.RED, MatchEventType.PENALTY_MISSED -> sound.play(Sfx.Wrong)
                MatchEventType.FULL_TIME -> sound.play(if (score.userWon) Sfx.Win else if (score.opponentWon) Sfx.Loss else Sfx.Click)
                else -> sound.play(Sfx.Click)
            }
        }
    }

    val visible = events.filter { it.minute <= minute }
    val userGoals = visible.count { isGoal(it) && it.side == 0 }
    val opponentGoals = visible.count { isGoal(it) && it.side == 1 }
    val fill by animateFloatAsState(
        targetValue = (minute.toFloat() / LIVE_MATCH_SECONDS).coerceIn(0f, 1f),
        animationSpec = tween(1_000, easing = LinearEasing),
        label = "match-clock-fill"
    )
    val pulse = rememberInfiniteTransition(label = "live-dot")
    val dotAlpha by pulse.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "live-dot-alpha"
    )

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!finished) Box(Modifier.size(10.dp).alpha(dotAlpha).background(palette.bad, CircleShape))
                Text(
                    if (finished) (if (english) "FULL TIME" else "انتهت المباراة") else (if (english) "LIVE" else "مباشر"),
                    color = if (finished) palette.gold else palette.bad,
                    fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 1.2.sp
                )
            }
            Text("${minute.coerceAtMost(LIVE_MATCH_SECONDS)}'", color = palette.cream, fontWeight = FontWeight.Black, fontSize = 20.sp)
        }

        Card(
            Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.5f), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(userName, color = palette.cream, fontWeight = FontWeight.Black, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Text("$userGoals - $opponentGoals", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 38.sp, modifier = Modifier.padding(horizontal = 10.dp))
                Text(opponentName, color = palette.cream, fontWeight = FontWeight.Black, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }

        // Long bar that fills as the match clock runs from 0' to 90'.
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp))
                    .background(palette.panel)
                    .border(1.dp, palette.gold.copy(alpha = 0.4f), RoundedCornerShape(9.dp))
            ) {
                Box(
                    Modifier.fillMaxWidth(fill).fillMaxHeight()
                        .background(Brush.horizontalGradient(listOf(palette.good, palette.gold)))
                )
                Box(Modifier.align(Alignment.Center).width(2.dp).fillMaxHeight().background(palette.cream.copy(alpha = 0.55f)))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0'", color = palette.muted, fontSize = 10.sp)
                Text(if (english) "HT 45'" else "الاستراحة 45'", color = palette.muted, fontSize = 10.sp)
                Text("90'", color = palette.muted, fontSize = 10.sp)
            }
        }

        // Events appear one by one, newest first.
        visible.asReversed().forEach { event ->
            key(event.minute, event.type, event.side) {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { -it / 2 }
                ) {
                    val tint = when {
                        isGoal(event) -> palette.gold.copy(alpha = 0.20f)
                        event.type == MatchEventType.RED -> palette.bad.copy(alpha = 0.22f)
                        else -> palette.panel
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(tint).padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("${event.minute}'", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 13.sp, modifier = Modifier.width(34.dp))
                        Text(eventEmoji(event.type), fontSize = 20.sp)
                        Text(
                            describe(event, english, userName, opponentName),
                            color = palette.cream,
                            fontSize = 12.sp,
                            fontWeight = if (isGoal(event) || event.type == MatchEventType.RED) FontWeight.Black else FontWeight.Medium,
                            lineHeight = 17.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        if (!finished) {
            OutlinedButton(onClick = { minute = LIVE_MATCH_SECONDS }, modifier = Modifier.fillMaxWidth()) {
                Text(if (english) "Skip to full time" else "تخطي لنهاية المباراة", color = palette.cream)
            }
        } else {
            Button(
                onClick = onFinished,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
            ) {
                Text(if (english) "See the result" else "شوف النتيجة", fontWeight = FontWeight.Black)
            }
        }
    }
}
