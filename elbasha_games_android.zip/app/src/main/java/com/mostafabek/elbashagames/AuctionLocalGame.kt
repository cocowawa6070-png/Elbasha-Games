package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Two human players share one device. Each bid/pass hands the phone to the other player. */
@Composable
fun AuctionLocalGameScreen(sound: SoundManager, english: Boolean, onExit: () -> Unit) {
    var phase by remember { mutableStateOf("setup") }
    var pro by remember { mutableStateOf(false) }
    var cardsMode by remember { mutableStateOf(true) }
    var names by remember { mutableStateOf(listOf("", "")) }
    var round by remember { mutableIntStateOf(0) }
    var turn by remember { mutableIntStateOf(0) }
    var leader by remember { mutableIntStateOf(-1) }
    var passesWithoutBid by remember { mutableIntStateOf(0) }
    var currentBid by remember { mutableIntStateOf(0) }
    var bidDraft by remember { mutableIntStateOf(0) }
    var budgets by remember { mutableStateOf(listOf(100, 100)) }
    var squads by remember { mutableStateOf(listOf<List<Pair<PlayerCard, Int>>>(emptyList(), emptyList())) }
    var queue by remember { mutableStateOf(emptyList<PlayerCard>()) }
    var message by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("") }
    var protectedNames by remember { mutableStateOf(listOf<String?>(null, null)) }
    var coachLot by remember { mutableStateOf<CoachCard?>(null) }
    // Round 0 = visible coach lot, round 1 = hidden (mystery) coach lot.
    var coachRound by remember { mutableIntStateOf(0) }
    var firstCoachName by remember { mutableStateOf<String?>(null) }
    var coachWinners by remember { mutableStateOf(listOf<CoachCard?>(null, null)) }
    var coachPrice by remember { mutableIntStateOf(0) }
    var cardActor by remember { mutableIntStateOf(0) }
    var cardStep by remember { mutableIntStateOf(0) }
    var selectedStealTarget by remember { mutableStateOf<PlayerCard?>(null) }
    var revealedPlayers by remember { mutableStateOf(emptyList<Pair<Int, PlayerCard>>()) }
    var liveMatchDone by remember { mutableStateOf(false) }
    var hiddenRevealCountdownActive by remember { mutableStateOf(false) }
    var hiddenRevealCountdown by remember { mutableIntStateOf(3) }
    val targetCount = if (pro) 11 else 5
    val opening = queue.firstOrNull()?.let { AuctionRules.openingPrice(it.rating) } ?: 0
    val activeBudget = budgets[turn]
    val cleanNames = PassAndPlayRules.normalizeNames(names, 2) { if (english) "Player $it" else "لاعب $it" }
    val squadsOnly = squads.map { it.map { entry -> entry.first } }

    fun reset() {
        liveMatchDone = false
        round = 0; turn = 0; leader = -1; passesWithoutBid = 0
        budgets = listOf(if (pro) 200 else 100, if (pro) 200 else 100)
        squads = listOf(emptyList(), emptyList())
        queue = ElbashaPositions.auctionPool(if (pro) 11 else 5, if (pro) 42 else 24)
        currentBid = 0; bidDraft = 0; protectedNames = listOf(null, null)
        cardActor = 0; cardStep = 0; selectedStealTarget = null; revealedPlayers = emptyList(); hiddenRevealCountdownActive = false; hiddenRevealCountdown = 3; coachLot = null; coachRound = 0; firstCoachName = null; coachWinners = listOf(null, null); coachPrice = 0; message = ""; resultText = ""
        if (queue.isEmpty()) message = if (english) "No player lots are available." else "مفيش لاعبين متاحين للمزاد."
        else {
            currentBid = AuctionRules.openingPrice(queue.first().rating) - 1
            bidDraft = currentBid + 1
            phase = "bidding"
        }
    }

    fun takeHidden(position: String, used: Set<String>): PlayerCard? = PlayerDatabase.players
        .filter { ElbashaPositions.supports(it, position) && it.nameEn !in used }
        .randomOrNull()?.copy(position = position)

    fun beginCoachAuction() {
        val candidate = CoachDatabase.randomCoach(excludedNames = setOfNotNull(firstCoachName))
        if (candidate == null) {
            phase = if (cardsMode) "shield" else "result"
            return
        }
        if (coachRound == 0) firstCoachName = candidate.nameEn
        coachLot = candidate
        leader = -1; passesWithoutBid = 0; turn = 0
        currentBid = CoachAuctionRules.openingPrice(candidate) - 1
        bidDraft = currentBid + 1
        phase = "coachBidding"
        message = if (coachRound == 0) {
            if (english) "Player lots are complete. The visible coach is now on the block." else "مزاد اللاعبين خلص. بدأ مزاد المدرب الظاهر."
        } else {
            if (english) "Now the hidden coach. Bid without knowing who it is!" else "دلوقتي مزاد المدرب الخفي. زايد من غير ما تعرف مين هو!"
        }
    }

    fun finishCoachAuction(winner: Int?) {
        val coach = coachLot
        if (winner != null && coach != null) {
            coachWinners = coachWinners.toMutableList().also { it[winner] = listOfNotNull(it[winner], coach).maxByOrNull { c -> c.rating } }
            budgets = budgets.toMutableList().also { it[winner] = (it[winner] - coachPrice).coerceAtLeast(0) }
            resultText = if (english) "${cleanNames[winner]} won ${coach.nameEn} for ${coachPrice}M." else "${cleanNames[winner]} كسب ${coach.nameAr} بـ${coachPrice} مليون."
        } else {
            resultText = if (coachRound == 0) {
                if (english) "The visible coach went unsold." else "المدرب الظاهر لم يتم بيعه."
            } else {
                if (english) "The hidden coach went unsold." else "المدرب الخفي لم يتم بيعه."
            }
        }
        coachLot = null
        if (coachRound == 0) {
            // Visible coach is done: put the hidden coach on the block next.
            coachRound = 1
            val summary = resultText
            sound.play(Sfx.Gavel)
            beginCoachAuction()
            message = summary + "\n" + message
            return
        }
        phase = if (cardsMode) "shield" else "result"
        cardStep = 0
        selectedStealTarget = null
        message = resultText
        sound.play(Sfx.Gavel)
    }

    fun placeCoachBid() {
        val coach = coachLot ?: return
        val minBid = maxOf(CoachAuctionRules.openingPrice(coach), currentBid + 1)
        if (!CoachAuctionRules.canPay(bidDraft, budgets[turn]) || bidDraft < minBid) {
            message = if (english) "Invalid coach bid or insufficient budget." else "مزايدة المدرب غير صالحة أو الميزانية غير كافية."
            return
        }
        currentBid = bidDraft
        coachPrice = currentBid
        leader = turn
        passesWithoutBid = 0
        turn = 1 - turn
        bidDraft = (currentBid + 1).coerceAtMost(budgets[turn])
        message = if (english) "${cleanNames[1 - turn]} leads the coach auction at ${currentBid}M. Pass the phone to ${cleanNames[turn]}." else "${cleanNames[1 - turn]} متصدر مزاد المدرب بـ${currentBid} مليون. سلّم الجهاز لـ${cleanNames[turn]}."
        sound.play(Sfx.Coin)
    }

    fun passCoach() {
        if (leader >= 0) finishCoachAuction(leader)
        else if (++passesWithoutBid >= 2) finishCoachAuction(null)
        else {
            turn = 1 - turn
            val coach = coachLot ?: return
            bidDraft = CoachAuctionRules.openingPrice(coach).coerceAtMost(budgets[turn])
            message = if (english) "No coach bid yet. ${cleanNames[turn]} may open the bidding." else "لسه مفيش مزايدة على المدرب. دور ${cleanNames[turn]} يبدأ."
        }
    }

    fun settle(winner: Int?) {
        val lot = queue.firstOrNull() ?: return
        val used = squads.flatten().map { it.first.nameEn }.toSet() + queue.map { it.nameEn }
        val nextSquads = squads.toMutableList()
        val newlyRevealed = mutableListOf<Pair<Int, PlayerCard>>()
        if (winner == null) {
            val firstGift = takeHidden(lot.position, used)
            val secondGift = firstGift?.let { takeHidden(lot.position, used + it.nameEn) }
            if (firstGift != null) {
                nextSquads[0] = nextSquads[0] + (firstGift to 0)
                newlyRevealed += 0 to firstGift
            }
            if (secondGift != null) {
                nextSquads[1] = nextSquads[1] + (secondGift to 0)
                newlyRevealed += 1 to secondGift
            }
            resultText = if (english) "Both players passed. Two hidden players were dealt." else "اللاعبان انسحبوا. اتوزع لاعبان مخفيان."
        } else {
            val price = currentBid.coerceAtLeast(opening)
            nextSquads[winner] = nextSquads[winner] + (lot to price)
            val loser = 1 - winner
            budgets = budgets.toMutableList().also { it[winner] = (it[winner] - price).coerceAtLeast(0) }
            takeHidden(lot.position, used + lot.nameEn)?.let { hidden ->
                nextSquads[loser] = nextSquads[loser] + (hidden to 0)
                newlyRevealed += loser to hidden
            }
            resultText = if (english) "${cleanNames[winner]} won ${lot.nameEn} for ${price}M. ${cleanNames[loser]} received a hidden player." else "${cleanNames[winner]} كسب ${lot.nameAr} بـ${price} مليون، و${cleanNames[loser]} أخذ لاعبًا مخفيًا."
        }
        squads = nextSquads
        revealedPlayers = newlyRevealed
        hiddenRevealCountdownActive = newlyRevealed.isNotEmpty()
        hiddenRevealCountdown = 3
        round++
        if (round >= targetCount || queue.drop(1).isEmpty()) {
            beginCoachAuction()
        } else {
            queue = queue.drop(1)
            leader = -1; passesWithoutBid = 0; turn = 0
            currentBid = AuctionRules.openingPrice(queue.first().rating) - 1
            bidDraft = currentBid + 1
            message = resultText
        }
        sound.play(Sfx.Gavel)
    }

    fun placeBid() {
        val minBid = maxOf(opening, currentBid + 1)
        if (bidDraft < minBid || bidDraft > activeBudget) {
            message = if (english) "Invalid bid or insufficient budget." else "المزايدة غير صالحة أو الميزانية مش مكفية."
            return
        }
        currentBid = bidDraft
        leader = turn
        passesWithoutBid = 0
        turn = 1 - turn
        bidDraft = (currentBid + 1).coerceAtMost(budgets[turn])
        message = if (english) "${cleanNames[1 - turn]} is leading at ${currentBid}M. Pass the phone to ${cleanNames[turn]}." else "${cleanNames[1 - turn]} متصدر بـ${currentBid} مليون. سلّم الجهاز لـ${cleanNames[turn]}."
        sound.play(Sfx.Coin)
    }

    fun pass() {
        if (leader >= 0) {
            settle(leader)
        } else {
            passesWithoutBid++
            if (passesWithoutBid >= 2) settle(null)
            else {
                turn = 1 - turn
                bidDraft = maxOf(opening, currentBid + 1).coerceAtMost(budgets[turn])
                message = if (english) "No bid yet. ${cleanNames[turn]} gets the opening chance." else "لسه مفيش مزايدة. دور ${cleanNames[turn]} يبدأ من سعر الافتتاح."
            }
        }
    }

    fun handleCardChoice(player: PlayerCard) {
        when (cardStep) {
            0 -> {
                protectedNames = protectedNames.toMutableList().also { it[0] = player.nameEn }
                cardStep = 1
                message = if (english) "Pass the phone to ${cleanNames[1]}. Choose their shield." else "سلّم الجهاز لـ${cleanNames[1]} عشان يختار الحماية."
                sound.play(Sfx.Correct)
            }
            1 -> {
                protectedNames = protectedNames.toMutableList().also { it[1] = player.nameEn }
                cardStep = 2
                message = if (english) "${cleanNames[0]}: choose a rival player to steal. You must exchange a player in the same position." else "${cleanNames[0]}: اختار لاعبًا من الخصم. لازم تبدّله بلاعب من نفس المركز."
                sound.play(Sfx.Correct)
            }
            2, 4 -> {
                val attacker = if (cardStep == 2) 0 else 1
                val defender = 1 - attacker
                val targetEntry = squads[defender].firstOrNull { it.first.nameEn == player.nameEn } ?: return
                if (targetEntry.first.nameEn == protectedNames[defender]) {
                    selectedStealTarget = null
                    message = if (english) "SHIELD BLOCKED THE STEAL. The target stays, and ${cleanNames[attacker]}'s Steal card is wasted." else "الحماية صدّت السرقة. اللاعب فضل مكانه وكارت السرقة بتاع ${cleanNames[attacker]} ضاع."
                    sound.play(Sfx.Wrong)
                    if (cardStep == 2) cardStep = 4 else {
                        cardStep = 6
                        phase = "result"
                    }
                    return
                }
                val replacements = PostAuctionCardRules.eligibleReplacements(squads[attacker].map { it.first }, targetEntry.first)
                if (replacements.isEmpty()) {
                    message = if (english) "No player in the same position is available to exchange." else "مفيش عندك لاعب في نفس المركز عشان تبدّله."
                    sound.play(Sfx.Wrong)
                    return
                }
                selectedStealTarget = targetEntry.first
                cardStep = if (attacker == 0) 3 else 5
                message = if (english) "Choose the player ${cleanNames[attacker]} will give away in ${targetEntry.first.position}." else "اختار اللاعب اللي ${cleanNames[attacker]} هيده للخصم من مركز ${targetEntry.first.position}."
                sound.play(Sfx.Click)
            }
            3, 5 -> {
                val attacker = if (cardStep == 3) 0 else 1
                val defender = 1 - attacker
                val target = selectedStealTarget ?: return
                if (!PostAuctionCardRules.canExchange(target, player)) {
                    message = if (english) "The exchange must use the exact same position." else "التبديل لازم يكون في نفس المركز بالضبط."
                    return
                }
                val updated = squads.toMutableList()
                val outgoing = updated[attacker].firstOrNull { it.first.nameEn == player.nameEn } ?: return
                val incoming = updated[defender].firstOrNull { it.first.nameEn == target.nameEn } ?: return
                updated[attacker] = updated[attacker].filterNot { it.first.nameEn == player.nameEn } + incoming
                updated[defender] = updated[defender].filterNot { it.first.nameEn == target.nameEn } + outgoing
                squads = updated
                selectedStealTarget = null
                sound.play(Sfx.Correct)
                if (attacker == 0) {
                    cardStep = 4
                    message = if (english) "Swap complete. Pass the phone to ${cleanNames[1]} for their Steal card." else "تم التبديل. سلّم الجهاز لـ${cleanNames[1]} عشان يستخدم كارت السرقة."
                } else {
                    cardStep = 6
                    phase = "result"
                    message = if (english) "Both players have completed their cards. The final match is ready." else "الفريقان خلصوا الكروت. النتيجة النهائية جاهزة."
                }
            }
        }
    }

    val finalMatch = remember(phase, squads, coachWinners) {
        if (phase == "result") MatchEngine.simulate(
            squadsOnly[0], squadsOnly[1],
            coachWinners[0]?.matchBonus ?: 0.0,
            coachWinners[1]?.matchBonus ?: 0.0,
            targetSquadSize = targetCount
        ) else null
    }

    LaunchedEffect(hiddenRevealCountdownActive) {
        if (hiddenRevealCountdownActive) {
            for (number in 3 downTo 1) {
                hiddenRevealCountdown = number
                sound.play(Sfx.Beep)
                delay(850)
                if (!hiddenRevealCountdownActive) return@LaunchedEffect
            }
            hiddenRevealCountdownActive = false
            sound.play(Sfx.Go)
        }
    }

    LaunchedEffect(revealedPlayers, hiddenRevealCountdownActive) {
        if (revealedPlayers.isNotEmpty() && !hiddenRevealCountdownActive) {
            val currentReveal = revealedPlayers
            delay(5_400)
            if (revealedPlayers == currentReveal && !hiddenRevealCountdownActive) revealedPlayers = emptyList()
        }
    }

    BackHandler { onExit() }
    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onExit) { Text(if (english) "← Back" else "→ رجوع", color = Gold) }
        Text(if (english) "AUCTION • PASS & PLAY" else "المزاد • جهاز واحد", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        AnimatedVisibility(
            visible = revealedPlayers.isNotEmpty() && !hiddenRevealCountdownActive,
            enter = fadeIn(tween(260)) + scaleIn(tween(320), initialScale = 0.94f)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth().border(1.dp, Gold.copy(alpha = 0.65f), RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PanelAltColor)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (english) "HIDDEN PLAYER REVEALED" else "كشف اللاعب المخفي", color = Gold, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    revealedPlayers.forEach { (owner, player) ->
                        key(owner, player.nameEn) {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    if (english) cleanNames[owner] else "مكافأة ${cleanNames[owner]}",
                                    color = Gold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                FlipRevealCard(
                                    player = player,
                                    english = english,
                                    size = if (revealedPlayers.size > 1) FifaCardSize.Medium else FifaCardSize.Large,
                                    startDelayMillis = 180 + owner * 220,
                                    flipMillis = 1_700
                                )
                                Text("${player.position}  •  OVR ${player.rating}", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
        if (hiddenRevealCountdownActive) {
            Card(
                modifier = Modifier.fillMaxWidth().border(1.5.dp, Gold.copy(alpha = 0.85f), RoundedCornerShape(22.dp)),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PanelAltColor)
            ) {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (english) "HIDDEN PLAYER REVEAL" else "اللاعب المخفي هيظهر دلوقتي", color = Gold, fontWeight = FontWeight.Black)
                    Crossfade(targetState = hiddenRevealCountdown, animationSpec = tween(260), label = "local-hidden-reveal-countdown") { number ->
                        Text(number.toString(), color = Gold, fontSize = 88.sp, fontWeight = FontWeight.Black)
                    }
                    Text("3 • 2 • 1", color = Cream, fontWeight = FontWeight.Bold)
                }
            }
        } else when (phase) {
            "setup" -> {
                Text(if (english) "Two human players, one phone. Bidding alternates after every raise or pass." else "لاعبان حقيقيان على نفس الجهاز. المزايدة بتتنقل بينكم بعد كل زيادة أو انسحاب.", color = Cream)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(false, true).forEach { mode ->
                        Card(Modifier.weight(1f).clickable { pro = mode }, colors = CardDefaults.cardColors(containerColor = if (pro == mode) Gold else PanelColor)) {
                            Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (mode) "PRO MAX" else "CLASSIC", color = if (pro == mode) DeepWine else Cream, fontWeight = FontWeight.Black)
                                Text(if (mode) "11 players • 200M" else "5 players • 100M", color = if (pro == mode) DeepWine else Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
                repeat(2) { index ->
                    OutlinedTextField(value = names[index], onValueChange = { value -> names = names.toMutableList().also { it[index] = value.take(20) } }, label = { Text(if (english) "Player ${index + 1}" else "اسم اللاعب ${index + 1}") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(false, true).forEach { enabled ->
                        Card(Modifier.weight(1f).clickable { cardsMode = enabled }, colors = CardDefaults.cardColors(containerColor = if (cardsMode == enabled) Gold else PanelColor)) {
                            Text(if (enabled) if (english) "Cards" else "مود الكروت" else if (english) "Normal" else "طبيعي", color = if (cardsMode == enabled) DeepWine else Cream, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Button(onClick = { reset() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(if (english) "Start auction" else "ابدأ المزاد") }
            }
            "bidding" -> {
                val lot = queue.first()
                Text(if (english) "ROUND ${round + 1} / $targetCount" else "الجولة ${round + 1} من $targetCount", color = Cream, fontWeight = FontWeight.Bold)
                Text("${cleanNames[turn]} • ${if (english) "YOUR TURN" else "دورك"}", color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${cleanNames[0]}: ${budgets[0]}M", color = Cream)
                    Text("${cleanNames[1]}: ${budgets[1]}M", color = Cream)
                }
                PremiumPlayerCard(player = lot, detail = if (english) "Opening bid ${opening}M" else "سعر الافتتاح ${opening} مليون", eyebrow = if (english) "PLAYER ON THE BLOCK" else "اللاعب المعروض")
                if (leader >= 0) {
                    Crossfade(targetState = currentBid, animationSpec = tween(220), label = "local-auction-current-bid") { animatedBid ->
                        Text(if (english) "Current bid: ${animatedBid}M • Leader: ${cleanNames[leader]}" else "السعر الحالي: $animatedBid مليون • المتصدر: ${cleanNames[leader]}", color = Gold, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(if (english) "Opening price: ${opening}M" else "سعر الافتتاح: $opening مليون", color = Gold, fontWeight = FontWeight.Bold)
                }
                Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (english) "YOUR BID" else "مزايدتك", color = Muted, fontWeight = FontWeight.Bold)
                        Crossfade(targetState = bidDraft, animationSpec = tween(220), label = "local-auction-bid-draft") { animatedBid ->
                            Text("$animatedBid M", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { bidDraft = (bidDraft - 1).coerceAtLeast(maxOf(opening, currentBid + 1)) }, enabled = bidDraft > maxOf(opening, currentBid + 1), modifier = Modifier.weight(1f)) { Text("−1") }
                            listOf(1, 5, 10).forEach { step -> OutlinedButton(onClick = { bidDraft = (bidDraft + step).coerceAtMost(activeBudget) }, enabled = bidDraft + step <= activeBudget, modifier = Modifier.weight(1f)) { Text("+$step") } }
                        }
                    }
                }
                Button(onClick = { placeBid() }, enabled = bidDraft >= maxOf(opening, currentBid + 1) && bidDraft <= activeBudget, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(if (english) "Confirm bid" else "زايد وثبّت السعر") }
                OutlinedButton(onClick = { pass() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Pass / Withdraw" else "انسحاب / Pass", color = Cream) }
                Text(message, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text(if (english) "Hide the phone from the other player during your turn." else "خلي اللاعب التاني بعيد عن الشاشة وقت اختيارك.", color = Muted, fontSize = 10.sp)
            }
            "coachBidding" -> {
                val coach = coachLot
                if (coach != null) {
                    Text(
                        if (coachRound == 0) (if (english) "VISIBLE COACH AUCTION" else "مزاد المدرب الظاهر")
                        else (if (english) "MYSTERY COACH AUCTION" else "مزاد المدرب الخفي"),
                        color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black
                    )
                    Text("${cleanNames[turn]} • ${if (english) "YOUR TURN" else "دورك"}", color = Cream, fontWeight = FontWeight.Bold)
                    if (coachRound == 0) CoachAuctionCard(coach, english, CoachAuctionRules.openingPrice(coach))
                    else HiddenCoachAuctionCard(english, CoachAuctionRules.openingPrice(coach))
                    Text(if (leader >= 0) (if (english) "Current bid: ${currentBid}M • ${cleanNames[leader]} leads" else "السعر الحالي: $currentBid مليون • ${cleanNames[leader]} متصدر") else (if (english) "Opening bid: ${CoachAuctionRules.openingPrice(coach)}M" else "سعر البداية: ${CoachAuctionRules.openingPrice(coach)} مليون"), color = Gold, fontWeight = FontWeight.Bold)
                    Text("${cleanNames[0]}: ${budgets[0]}M     ${cleanNames[1]}: ${budgets[1]}M", color = Muted)
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(15.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Crossfade(targetState = bidDraft, animationSpec = tween(220), label = "local-coach-bid-draft") { animatedBid ->
                                Text("$animatedBid M", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = { bidDraft = (bidDraft - 1).coerceAtLeast(maxOf(CoachAuctionRules.openingPrice(coach), currentBid + 1)) }, enabled = bidDraft > maxOf(CoachAuctionRules.openingPrice(coach), currentBid + 1), modifier = Modifier.weight(1f)) { Text("−1") }
                                listOf(1, 5, 10).forEach { step -> OutlinedButton(onClick = { bidDraft = (bidDraft + step).coerceAtMost(budgets[turn]) }, enabled = bidDraft + step <= budgets[turn], modifier = Modifier.weight(1f)) { Text("+$step") } }
                            }
                        }
                    }
                    Button(onClick = { placeCoachBid() }, enabled = bidDraft >= maxOf(CoachAuctionRules.openingPrice(coach), currentBid + 1) && bidDraft <= budgets[turn], modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(if (english) "Confirm coach bid" else "ثبّت مزايدة المدرب") }
                    OutlinedButton(onClick = { passCoach() }, modifier = Modifier.fillMaxWidth()) { Text(if (english) "Pass" else "انسحاب", color = Cream) }
                    Text(message, color = Muted, textAlign = TextAlign.Center)
                }
            }
            "shield", "steal" -> {
                Text(if (cardStep < 2) (if (english) "SHIELD CARD" else "كارت الحماية") else (if (english) "STEAL CARD" else "كارت السرقة"), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text(message.ifBlank { if (english) "${cleanNames[cardActor]}: select one player." else "${cleanNames[cardActor]}: اختار لاعبًا." }, color = Cream)
                val attacker = when (cardStep) { 2, 3 -> 0; 4, 5 -> 1; else -> -1 }
                val defender = if (attacker >= 0) 1 - attacker else -1
                val choices = when (cardStep) {
                    0 -> squads[0].map { it.first }
                    1 -> squads[1].map { it.first }
                    2, 4 -> squads[defender].map { it.first }.filter { target ->
                        target.nameEn == protectedNames[defender] || squads[attacker].any { it.first.position == target.position }
                    }
                    3, 5 -> {
                        val requiredPosition = selectedStealTarget?.position
                        squads[attacker].map { it.first }.filter { it.position == requiredPosition }
                    }
                    else -> emptyList()
                }
                if (cardStep in setOf(2, 4)) {
                    Text(if (english) "A shielded target remains selectable, but choosing it wastes this Steal card." else "اللاعب المحمي تقدر تختاره، لكن المحاولة هتضيع كارت السرقة." , color = Gold, fontSize = 11.sp)
                }
                selectedStealTarget?.let { target ->
                    Text(if (english) "Target: ${target.nameEn} (${target.position})" else "الهدف: ${target.nameAr} (${target.position})", color = Gold, fontWeight = FontWeight.Bold)
                }
                choices.forEach { candidate ->
                    Column {
                        if (candidate.nameEn in protectedNames) Text(if (english) "SHIELDED" else "محمي بالحماية", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        PremiumPlayerChoiceCard(candidate, english) { handleCardChoice(candidate) }
                    }
                }
                Text(if (english) "Pass the phone only after the current player finishes." else "سلّم الجهاز بعد ما اللاعب الحالي يخلص اختياره.", color = Muted, fontSize = 11.sp)
            }
            "result" -> if (!liveMatchDone && finalMatch != null) {
                Text(if (english) "⚽ THE FINAL MATCH" else "⚽ المباراة النهائية", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                LiveMatchSimulation(
                    userName = cleanNames[0],
                    opponentName = cleanNames[1],
                    userSquad = squadsOnly[0],
                    opponentSquad = squadsOnly[1],
                    score = finalMatch,
                    english = english,
                    sound = sound,
                    onFinished = { liveMatchDone = true; sound.play(Sfx.Win) }
                )
            } else {
                val ratings = squadsOnly.map { list -> list.sumOf { it.rating } }
                val winner = ratings.indices.maxByOrNull { ratings[it] } ?: 0
                Text(if (english) "AUCTION RESULT" else "نتيجة المزاد", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    squads.indices.forEach { index ->
                        Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                            Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(cleanNames[index], color = Cream, fontWeight = FontWeight.Bold)
                                Text(ratings[index].toString(), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                                Text("${squads[index].size}/$targetCount", color = Muted)
                                Text("${budgets[index]}M", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
                Text(if (ratings[0] == ratings[1]) if (english) "Draw" else "تعادل" else if (english) "Winner: ${cleanNames[winner]}" else "الفائز: ${cleanNames[winner]}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text(finalMatch?.let { "${cleanNames[0]} ${it.userGoals} - ${it.opponentGoals} ${cleanNames[1]}" }.orEmpty(), color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
                coachWinners.forEachIndexed { index, coach ->
                    coach?.let { CoachAuctionCard(it, english, CoachAuctionRules.openingPrice(it)) }
                        ?: Text(if (english) "${cleanNames[index]}: no coach" else "${cleanNames[index]}: بدون مدرب", color = Muted)
                }
                Text(
                    when {
                        finalMatch == null -> ""
                        finalMatch.userWon -> if (english) "Match winner: ${cleanNames[0]}" else "فائز المباراة: ${cleanNames[0]}"
                        finalMatch.opponentWon -> if (english) "Match winner: ${cleanNames[1]}" else "فائز المباراة: ${cleanNames[1]}"
                        else -> if (english) "Match draw" else "تعادل المباراة"
                    }, color = Gold, fontWeight = FontWeight.Bold
                )
                squads.forEachIndexed { index, entries ->
                    SquadFormationPitch(title = cleanNames[index], players = entries.map { it.first }, slotCount = targetCount, detailFor = { player -> entries.firstOrNull { it.first.nameEn == player.nameEn }?.let { if (it.second > 0) "${it.second}M" else "BONUS" } ?: "" })
                }
                Button(onClick = { phase = "setup" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(if (english) "New auction" else "مزاد جديد") }
            }
        }
    }
}
