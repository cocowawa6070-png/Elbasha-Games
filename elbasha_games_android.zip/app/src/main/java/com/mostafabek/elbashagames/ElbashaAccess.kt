package com.mostafabek.elbashagames

/** Account-level access rules for the private ELBASHA GAMES group. */
object ElbashaAccess {
    const val DeveloperUid = "8Rs2HFEKfYYTNT2Elzj90oVuZ4k1"

    fun isDeveloper(uid: String?): Boolean = uid == DeveloperUid
}
