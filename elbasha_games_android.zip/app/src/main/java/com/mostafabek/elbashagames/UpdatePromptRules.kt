package com.mostafabek.elbashagames

/** Pure state rule for avoiding repeated system prompts for one DownloadManager job. */
object UpdatePromptRules {
    fun shouldPrompt(downloadId: Long, alreadyPromptedDownloadId: Long): Boolean =
        downloadId > 0L && downloadId != alreadyPromptedDownloadId
}
