package com.mostafabek.elbashagames

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * One song in the album.
 * [builtIn] songs ship inside the APK (app/src/main/assets/music/) and exist for every player;
 * the others were added by the player on this device and live in the app's private files.
 */
data class AlbumTrack(
    val id: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val builtIn: Boolean,
    /** Asset path (built-in) or file name inside filesDir/music (added by the player). */
    val location: String
)

data class AlbumAddResult(val added: Int, val skipped: List<String>)

/**
 * The music album. Two sources, merged in one list:
 *  1. every audio file dropped into app/src/main/assets/music/ (built-in, for everyone, no network);
 *  2. songs the player adds from the phone; they are copied into app storage, so they keep
 *     playing even if the original file is moved or deleted.
 * Nothing here needs Firebase or the internet.
 */
class MusicAlbum(context: Context) {
    private val app = context.applicationContext
    private val dir = File(app.filesDir, "music").apply { mkdirs() }
    private val indexFile = File(app.filesDir, "music_album.json")
    private var builtInTracks: List<AlbumTrack> = emptyList()

    var tracks by mutableStateOf<List<AlbumTrack>>(emptyList())
        private set

    init { reload() }

    fun reload() {
        builtInTracks = runCatching { app.assets.list(ASSET_DIR).orEmpty().toList() }
            .getOrDefault(emptyList())
            .filter { isAudioName(it) }
            .sortedBy { it.lowercase() }
            .map { name -> AlbumTrack("builtin:$name", prettyTitle(name), "", 0L, true, "$ASSET_DIR/$name") }
        tracks = builtInTracks + readPersonal()
    }

    /** Points [player] at the song's audio (built-in songs are unpacked once into the cache). */
    fun attach(player: MediaPlayer, track: AlbumTrack) {
        val file = if (track.builtIn) materialize(track) else File(dir, track.location)
        player.setDataSource(file.absolutePath)
    }

    private fun materialize(track: AlbumTrack): File {
        val folder = File(app.cacheDir, "album_builtin_${BuildConfig.VERSION_CODE}").apply { mkdirs() }
        val target = File(folder, File(track.location).name)
        if (!target.isFile || target.length() == 0L) {
            app.assets.open(track.location).use { input -> target.outputStream().use { input.copyTo(it) } }
        }
        return target
    }

    /** Copies the chosen songs into app storage. Runs on a background thread. */
    suspend fun addFromUris(uris: List<Uri>): AlbumAddResult = withContext(Dispatchers.IO) {
        val personal = readPersonal().toMutableList()
        var added = 0
        val skipped = mutableListOf<String>()
        uris.forEachIndexed { index, uri ->
            val displayName = queryName(uri) ?: "song_${System.currentTimeMillis()}"
            var partial: File? = null
            try {
                val extension = displayName.substringAfterLast('.', "").lowercase().takeIf { it in AUDIO_EXTENSIONS }
                    ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(app.contentResolver.getType(uri))
                    ?: "mp3"
                val id = "u${System.currentTimeMillis()}_$index"
                val target = File(dir, "$id.$extension")
                partial = target
                var total = 0L
                app.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            total += read
                            if (total > MAX_FILE_BYTES) throw IllegalStateException("too_big")
                            output.write(buffer, 0, read)
                        }
                    }
                } ?: throw IllegalStateException("unreadable")

                var title: String? = null
                var artist: String? = null
                var duration = 0L
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(target.absolutePath)
                    title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } finally {
                    runCatching { retriever.release() }
                }
                if (duration <= 0L) {
                    target.delete()
                    skipped += "$displayName (ليس ملف صوت صالح)"
                    return@forEachIndexed
                }
                val cleanTitle = title?.trim()?.takeIf { it.isNotEmpty() } ?: prettyTitle(displayName)
                if (personal.any { it.title == cleanTitle && it.durationMs == duration }) {
                    target.delete()
                    skipped += "$displayName (موجودة بالفعل)"
                    return@forEachIndexed
                }
                personal += AlbumTrack(id, cleanTitle, artist?.trim().orEmpty(), duration, false, target.name)
                added++
            } catch (error: Exception) {
                partial?.delete()
                skipped += if (error.message == "too_big") "$displayName (أكبر من 60 ميجا)" else "$displayName (تعذر النسخ)"
            }
        }
        writePersonal(personal)
        withContext(Dispatchers.Main) { tracks = builtInTracks + personal }
        AlbumAddResult(added, skipped)
    }

    fun remove(id: String) {
        val personal = readPersonal().toMutableList()
        val track = personal.firstOrNull { it.id == id } ?: return
        File(dir, track.location).delete()
        personal.remove(track)
        writePersonal(personal)
        tracks = builtInTracks + personal
    }

    /** Moves a player-added song up (-1) or down (+1) among the player-added songs. */
    fun move(id: String, delta: Int) {
        val personal = readPersonal().toMutableList()
        val from = personal.indexOfFirst { it.id == id }
        val to = from + delta
        if (from < 0 || to !in personal.indices) return
        personal.add(to, personal.removeAt(from))
        writePersonal(personal)
        tracks = builtInTracks + personal
    }

    private fun queryName(uri: Uri): String? = runCatching {
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    private fun readPersonal(): List<AlbumTrack> {
        if (!indexFile.isFile) return emptyList()
        return runCatching {
            val array = JSONArray(indexFile.readText())
            (0 until array.length()).mapNotNull { index ->
                val item = array.getJSONObject(index)
                val file = item.getString("file")
                if (!File(dir, file).isFile) null
                else AlbumTrack(item.getString("id"), item.getString("title"), item.optString("artist"), item.optLong("durationMs"), false, file)
            }
        }.getOrDefault(emptyList())
    }

    private fun writePersonal(list: List<AlbumTrack>) {
        val array = JSONArray()
        list.forEach { track ->
            array.put(JSONObject().put("id", track.id).put("title", track.title).put("artist", track.artist)
                .put("durationMs", track.durationMs).put("file", track.location))
        }
        val temporary = File(indexFile.parentFile, "music_album.json.tmp")
        temporary.writeText(array.toString())
        if (!temporary.renameTo(indexFile)) { indexFile.writeText(array.toString()); temporary.delete() }
    }

    companion object {
        const val ASSET_DIR = "music"
        const val MAX_FILE_BYTES = 60L * 1024L * 1024L
        val AUDIO_EXTENSIONS = setOf("mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "mp4", "3gp")

        fun isAudioName(name: String) = name.substringAfterLast('.', "").lowercase() in AUDIO_EXTENSIONS

        fun prettyTitle(fileName: String): String =
            fileName.substringBeforeLast('.').replace('_', ' ').replace(Regex("\\s+"), " ").trim().ifEmpty { fileName }
    }
}

private fun formatTime(ms: Int): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

/** Settings card: now playing, controls (shuffle / previous / play / next / repeat) and the song list. */
@Composable
fun MusicAlbumPanel(sound: SoundManager) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    val album = sound.album
    val scope = rememberCoroutineScope()
    var statusMessage by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var pendingRemoval by remember { mutableStateOf<AlbumTrack?>(null) }
    var dragPosition by remember { mutableStateOf<Float?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            adding = true
            statusMessage = localizedText(english, "جاري إضافة ${uris.size} أغنية…", "Adding ${uris.size} song(s)…")
            scope.launch {
                val result = album.addFromUris(uris)
                sound.onAlbumChanged()
                adding = false
                statusMessage = buildString {
                    append(localizedText(english, "اتضافت ${result.added} أغنية.", "Added ${result.added} song(s)."))
                    if (result.skipped.isNotEmpty()) append("\n" + result.skipped.joinToString("\n"))
                }
            }
        }
    }

    val tracks = album.tracks
    val current = tracks.firstOrNull { it.id == sound.currentTrackId }

    Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = palette.panel)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(localizedText(english, "ألبوم الأغاني", "Music album"), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text(
                        localizedText(english, "${tracks.size} أغنية • بتشتغل في القوائم وبتتوقف أثناء اللعب", "${tracks.size} songs • plays in menus, pauses during games"),
                        color = palette.muted, fontSize = 11.sp
                    )
                }
                Button(
                    onClick = { sound.toggleMusic() },
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (sound.musicOn) palette.gold else palette.panelAlt,
                        contentColor = if (sound.musicOn) palette.deepWine else palette.cream
                    )
                ) { Text(if (sound.musicOn) localizedText(english, "مفعّلة", "ON") else localizedText(english, "مكتومة", "OFF"), fontWeight = FontWeight.Bold) }
            }

            // Now playing.
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(palette.panelAlt).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    current?.title ?: localizedText(english, "مفيش أغنية في الألبوم لسه", "No songs in the album yet"),
                    color = palette.gold, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    when {
                        current != null && current.artist.isNotBlank() -> current.artist
                        else -> statusLabel(sound.musicPlaybackStatus, english)
                    },
                    color = palette.muted, fontSize = 11.sp, maxLines = 2
                )
                val duration = sound.durationMs.coerceAtLeast(1)
                val shown = dragPosition ?: sound.positionMs.toFloat().coerceIn(0f, duration.toFloat())
                Slider(
                    value = shown,
                    onValueChange = { dragPosition = it },
                    onValueChangeFinished = { dragPosition?.let { sound.seekTo(it.toInt()) }; dragPosition = null },
                    valueRange = 0f..duration.toFloat(),
                    enabled = current != null,
                    colors = SliderDefaults.colors(thumbColor = palette.gold, activeTrackColor = palette.gold, inactiveTrackColor = palette.panel)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(shown.toInt()), color = palette.muted, fontSize = 10.sp)
                    Text(formatTime(duration), color = palette.muted, fontSize = 10.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    ControlButton("🔀", active = sound.shuffleOn) { sound.toggleShuffle() }
                    ControlButton("⏮") { sound.previous() }
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(palette.gold).clickable(enabled = tracks.isNotEmpty()) { sound.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) { Text(if (sound.isPlaying) "⏸" else "▶", color = palette.deepWine, fontSize = 22.sp, fontWeight = FontWeight.Black) }
                    ControlButton("⏭") { sound.next() }
                    ControlButton(
                        when (sound.repeatMode) { 2 -> "🔂"; 1 -> "🔁"; else -> "➡" },
                        active = sound.repeatMode != 0
                    ) { sound.cycleRepeat() }
                }
            }

            // Song list.
            if (tracks.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    tracks.forEachIndexed { index, track ->
                        val isCurrent = track.id == sound.currentTrackId
                        val personalCount = tracks.count { !it.builtIn }
                        val personalIndex = tracks.filter { !it.builtIn }.indexOfFirst { it.id == track.id }
                        Row(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isCurrent) palette.panelAlt else palette.panel)
                                .border(1.dp, if (isCurrent) palette.gold.copy(alpha = 0.7f) else palette.gold.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                .clickable { sound.playTrack(track.id) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(if (isCurrent && sound.isPlaying) "🎵" else "${index + 1}", color = if (isCurrent) palette.gold else palette.muted, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp), fontSize = 12.sp)
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = if (isCurrent) palette.gold else palette.cream, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    listOfNotNull(
                                        track.artist.takeIf { it.isNotBlank() },
                                        if (track.durationMs > 0) formatTime(track.durationMs.toInt()) else null,
                                        if (track.builtIn) localizedText(english, "مدمجة", "built-in") else null
                                    ).joinToString(" • "),
                                    color = palette.muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (!track.builtIn) {
                                if (personalIndex > 0) Text("▲", color = palette.gold, modifier = Modifier.clickable { album.move(track.id, -1) }.padding(6.dp), fontSize = 13.sp)
                                if (personalIndex < personalCount - 1) Text("▼", color = palette.gold, modifier = Modifier.clickable { album.move(track.id, 1) }.padding(6.dp), fontSize = 13.sp)
                                Text("✕", color = palette.bad, modifier = Modifier.clickable { pendingRemoval = track }.padding(6.dp), fontWeight = FontWeight.Black, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = { picker.launch(arrayOf("audio/*")) },
                enabled = !adding,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
            ) {
                Text(
                    if (adding) localizedText(english, "جاري الإضافة…", "Adding…") else localizedText(english, "➕ إضافة أغاني من الموبايل", "➕ Add songs from your phone"),
                    fontWeight = FontWeight.Black
                )
            }
            if (statusMessage.isNotBlank()) Text(statusMessage, color = palette.gold, fontSize = 11.sp)
            Text(
                localizedText(
                    english,
                    "تقدر تختار أكتر من أغنية مرة واحدة. الأغاني بتتنسخ جوا التطبيق فمش هتضيع لو مسحت الملف الأصلي.",
                    "Pick as many songs as you like at once. They are copied into the app, so they keep working if the original file is deleted."
                ),
                color = palette.muted, fontSize = 10.sp, lineHeight = 14.sp
            )
        }
    }

    pendingRemoval?.let { track ->
        AlertDialog(
            onDismissRequest = { pendingRemoval = null },
            title = { Text(localizedText(english, "حذف الأغنية؟", "Remove this song?"), color = palette.cream, fontWeight = FontWeight.Black) },
            text = { Text(localizedText(english, "${track.title} هتتشال من الألبوم وملفها هيتمسح من التطبيق.", "${track.title} will be removed from the album and its file deleted from the app."), color = palette.muted) },
            confirmButton = {
                TextButton(onClick = {
                    album.remove(track.id)
                    sound.onAlbumChanged()
                    pendingRemoval = null
                }) { Text(localizedText(english, "حذف", "Remove"), color = palette.bad, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { pendingRemoval = null }) { Text(localizedText(english, "إلغاء", "Cancel"), color = palette.gold) } },
            containerColor = palette.panel
        )
    }
}

@Composable
private fun ControlButton(label: String, active: Boolean = false, onClick: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (active) palette.gold.copy(alpha = 0.28f) else palette.panel)
            .border(1.dp, if (active) palette.gold else palette.gold.copy(alpha = 0.2f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 17.sp) }
}

private fun statusLabel(status: String, english: Boolean): String = when {
    status == "playing" -> localizedText(english, "بتشتغل دلوقتي", "Playing now")
    status == "paused" -> localizedText(english, "متوقفة مؤقتًا", "Paused")
    status == "muted" -> localizedText(english, "الموسيقى مكتومة", "Music is muted")
    status == "in_game" -> localizedText(english, "متوقفة أثناء اللعب وهترجع في القوائم", "Paused during games, resumes in the menus")
    status == "preparing" -> localizedText(english, "جاري تجهيز الأغنية…", "Preparing the song…")
    status == "ended" -> localizedText(english, "الألبوم خلص", "The album has finished")
    status == "no_track" -> localizedText(english, "ضيف أغاني من الزرار تحت", "Add songs with the button below")
    status.startsWith("error") -> localizedText(english, "تعذر تشغيل الأغنية: $status", "Could not play the song: $status")
    else -> status
}
