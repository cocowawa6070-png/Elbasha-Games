package com.mostafabek.elbashagames

/**
 * Shared ELBASHA player pool. Ratings are curated relative in-app values, not copied EA ratings.
 * Current-player tiers use EA SPORTS FC 27's relative ranking as one reference; legends are
 * judged by peak legacy. Session 7 uses a wider in-app scale with no 75-point floor;
 * Messi and Cristiano Ronaldo are the only 99-rated players.
 */
data class PlayerCard(
    val nameEn: String, val nameAr: String, val position: String,
    val rating: Int, val price: Int, val flag: String,
    val nationalityAr: String = "", val nationalityEn: String = ""
)

object PlayerDatabase {
    val players: List<PlayerCard> = listOf(
        PlayerCard("Manuel Neuer", "مانويل نوير", "GK", 86, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Iker Casillas", "إيكر كاسياس", "GK", 83, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Gianluigi Buffon", "جانلويجي بوفون", "GK", 86, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Petr Cech", "بيتر تشيك", "GK", 74, 8, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Thibaut Courtois", "تيبو كورتوا", "GK", 92, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Alisson Becker", "أليسون بيكر", "GK", 83, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ederson", "إيدرسون", "GK", 77, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jan Oblak", "يان أوبلاك", "GK", 83, 9, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Marc-Andre ter Stegen", "مارك أندريه تير شتيجن", "GK", 80, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Emiliano Martinez", "إيميليانو مارتينيز", "GK", 71, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("David de Gea", "دافيد دي خيا", "GK", 69, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Keylor Navas", "كيلور نافاس", "GK", 71, 7, "🇨🇷", "كوستاريكا", "Costa Rica"),
        PlayerCard("Hugo Lloris", "هوجو لوريس", "GK", 67, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Oliver Kahn", "أوليفر كان", "GK", 80, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Peter Schmeichel", "بيتر شمايكل", "GK", 80, 9, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Dida", "ديدا", "GK", 71, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jose Luis Chilavert", "خوسيه لويس تشيلافيرت", "GK", 65, 6, "🇵🇾", "باراغواي", "Paraguay"),
        PlayerCard("Rene Higuita", "رينيه هيجيتا", "GK", 63, 6, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Mohamed El Shenawy", "محمد الشناوي", "GK", 63, 6, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Essam El Hadary", "عصام الحضري", "GK", 67, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Yassine Bounou", "ياسين بونو", "GK", 69, 7, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Mike Maignan", "مايك مانيان", "GK", 74, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gianluigi Donnarumma", "جيانلويجي دوناروما", "GK", 89, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Unai Simon", "أوناي سيمون", "GK", 67, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jordan Pickford", "جوردان بيكفورد", "GK", 65, 6, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Andre Onana", "أندريه أونانا", "GK", 61, 6, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Samir Handanovic", "سمير هاندانوفيتش", "GK", 67, 7, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Edwin van der Sar", "إدوين فان دير سار", "GK", 83, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Claudio Bravo", "كلاوديو برافو", "GK", 65, 6, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Walter Zenga", "والتر زينجا", "GK", 67, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jorge Campos", "خورخي كامبوس", "GK", 75, 8, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("David Seaman", "ديفيد سيمان", "GK", 79, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Victor Valdes", "فيكتور فالديس", "GK", 80, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Shaka Hislop", "شاكا هيسلوب", "GK", 61, 6, "🇹🇹", "ترينيداد وتوباغو", "Trinidad and Tobago"),
        PlayerCard("Paolo Maldini", "باولو مالديني", "DF", 95, 11, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Sergio Ramos", "سيرخيو راموس", "DF", 89, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Virgil van Dijk", "فيرجيل فان دايك", "DF", 86, 10, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franco Baresi", "فرانكو باريزي", "DF", 89, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Alessandro Nesta", "أليساندرو نيستا", "DF", 86, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Fabio Cannavaro", "فابيو كانافارو", "DF", 86, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Carles Puyol", "كارليس بويول", "DF", 86, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rio Ferdinand", "ريو فرديناند", "DF", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Nemanja Vidic", "نيمانيا فيديتش", "DF", 77, 8, "🇷🇸", "صربيا", "Serbia"),
        PlayerCard("John Terry", "جون تيري", "DF", 80, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Gerard Pique", "جيرارد بيكيه", "DF", 74, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Thiago Silva", "تياغو سيلفا", "DF", 77, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ruben Dias", "روبن دياز", "DF", 74, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antonio Rudiger", "أنطونيو روديجر", "DF", 71, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Achraf Hakimi", "أشرف حكيمي", "DF", 86, 10, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Trent Alexander-Arnold", "ترنت ألكسندر أرنولد", "DF", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Dani Alves", "داني ألفيش", "DF", 83, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Cafu", "كافو", "DF", 83, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Carlos", "روبرتو كارلوس", "DF", 89, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marcelo", "مارسيلو", "DF", 74, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ashley Cole", "آشلي كول", "DF", 77, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Philipp Lahm", "فيليب لام", "DF", 86, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Javier Zanetti", "خافيير زانيتي", "DF", 80, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Raphael Varane", "رافاييل فاران", "DF", 71, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("William Saliba", "ويليام ساليبا", "DF", 86, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Alessandro Bastoni", "أليساندرو باستوني", "DF", 69, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Kim Min-jae", "كيم مين جاي", "DF", 65, 6, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Ronald Araujo", "رونالد أراوخو", "DF", 67, 7, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("John Stones", "جون ستونز", "DF", 67, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Kyle Walker", "كايل ووكر", "DF", 67, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Theo Hernandez", "ثيو هيرنانديز", "DF", 71, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andrew Robertson", "أندرو روبرتسون", "DF", 71, 7, "🇬🇧", "اسكتلندا", "Scotland"),
        PlayerCard("Giorgio Chiellini", "جورجيو كيليني", "DF", 80, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Leonardo Bonucci", "ليوناردو بونوتشي", "DF", 74, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jaap Stam", "ياب ستام", "DF", 74, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Nuno Mendes", "نونو مينديز", "DF", 89, 10, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Gabriel Magalhaes", "جابرييل ماجالهايس", "DF", 89, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Willian Pacho", "ويليان باتشو", "DF", 89, 10, "🇪🇨", "الإكوادور", "Ecuador"),
        PlayerCard("Lilian Thuram", "ليليان تورام", "DF", 90, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Marcel Desailly", "مارسيل ديسايي", "DF", 88, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sol Campbell", "سول كامبل", "DF", 82, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Wael Gomaa", "وائل جمعة", "DF", 79, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Ahmed Hegazi", "أحمد حجازي", "DF", 63, 6, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Mohamed Hany", "محمد هاني", "DF", 60, 6, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Zinedine Zidane", "زين الدين زيدان", "MF", 95, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andres Iniesta", "أندريس إنييستا", "MF", 92, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Xavi Hernandez", "تشافي هيرنانديز", "MF", 92, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Luka Modric", "لوكا مودريتش", "MF", 83, 9, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Toni Kroos", "توني كروس", "MF", 86, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Andrea Pirlo", "أندريا بيرلو", "MF", 86, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Steven Gerrard", "ستيفن جيرارد", "MF", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Frank Lampard", "فرانك لامبارد", "MF", 80, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Paul Scholes", "بول سكولز", "MF", 80, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Patrick Vieira", "باتريك فييرا", "MF", 83, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Claude Makelele", "كلود ماكيليلي", "MF", 74, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sergio Busquets", "سيرجيو بوسكيتس", "MF", 80, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rodri", "رودري", "MF", 92, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kevin De Bruyne", "كيفن دي بروين", "MF", 89, 10, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Jude Bellingham", "جود بيلينجهام", "MF", 92, 11, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Pedri", "بيدري", "MF", 92, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jamal Musiala", "جمال موسيالا", "MF", 83, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Federico Valverde", "فيديريكو فالفيردي", "MF", 83, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Declan Rice", "ديكلان رايس", "MF", 86, 10, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Bruno Fernandes", "برونو فيرنانديز", "MF", 89, 10, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Yaya Toure", "يايا توريه", "MF", 83, 9, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Clarence Seedorf", "كلارنس سيدورف", "MF", 80, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Kaka", "كاكا", "MF", 86, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ronaldinho", "رونالدينيو", "MF", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Rivaldo", "ريفالدو", "MF", 86, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Michel Platini", "ميشيل بلاتيني", "MF", 92, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Lothar Matthaus", "لوثار ماتيوس", "MF", 89, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Roy Keane", "روي كين", "MF", 77, 8, "🇮🇪", "أيرلندا", "Ireland"),
        PlayerCard("Cesc Fabregas", "سيسك فابريجاس", "MF", 74, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mesut Ozil", "مسعود أوزيل", "MF", 71, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("David Silva", "دافيد سيلفا", "MF", 77, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bastian Schweinsteiger", "باستيان شفاينشتايجر", "MF", 80, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Mohamed Aboutrika", "محمد أبو تريكة", "MF", 71, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Hossam Ghaly", "حسام غالي", "MF", 59, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Mohamed Elneny", "محمد النني", "MF", 55, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Vitinha", "فيتينيا", "MF", 92, 11, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joao Neves", "جواو نيفيز", "MF", 86, 10, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joshua Kimmich", "جوشوا كيميش", "MF", 86, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Florian Wirtz", "فلوريان فيرتز", "MF", 80, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Martin Odegaard", "مارتن أوديجارد", "MF", 80, 9, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Enzo Fernandez", "إنزو فيرنانديز", "MF", 80, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jay-Jay Okocha", "جاي جاي أوكوشا", "MF", 86, 10, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Michael Essien", "مايكل إيسيان", "MF", 85, 10, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("N'Golo Kante", "نجولو كانتي", "MF", 90, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gennaro Gattuso", "جينارو جاتوزو", "MF", 82, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Park Ji-sung", "بارك جي سونغ", "MF", 77, 8, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Shinji Kagawa", "شينجي كاغاوا", "MF", 72, 8, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Ahmed Hassan", "أحمد حسن", "MF", 78, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Lionel Messi", "ليونيل ميسي", "WG", 99, 12, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Cristiano Ronaldo", "كريستيانو رونالدو", "WG", 99, 12, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Mohamed Salah", "محمد صلاح", "WG", 83, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Neymar Jr", "نيمار", "WG", 89, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Riyad Mahrez", "رياض محرز", "WG", 71, 7, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Kylian Mbappe", "كيليان مبابي", "WG", 95, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Vinicius Junior", "فينيسيوس جونيور", "WG", 89, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Lamine Yamal", "لامين يامال", "WG", 92, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bukayo Saka", "بوكايو ساكا", "WG", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Son Heung-min", "سون هيونج مين", "WG", 80, 9, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Arjen Robben", "أريين روبن", "WG", 83, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franck Ribery", "فرانك ريبيري", "WG", 83, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gareth Bale", "جاريث بيل", "WG", 80, 9, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Eden Hazard", "إيدين هازارد", "WG", 80, 9, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Luis Figo", "لويس فيجو", "WG", 86, 10, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("George Best", "جورج بست", "WG", 89, 10, "🇬🇧", "أيرلندا الشمالية", "Northern Ireland"),
        PlayerCard("Ryan Giggs", "ريان جيجز", "WG", 80, 9, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Luis Suarez", "لويس سواريز", "WG", 86, 10, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Sadio Mane", "ساديو ماني", "WG", 77, 8, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Raphinha", "رافينيا", "WG", 86, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ousmane Dembele", "عثمان ديمبيلي", "WG", 92, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Khvicha Kvaratskhelia", "خفيتشا كفاراتسخيليا", "WG", 89, 10, "🇬🇪", "جورجيا", "Georgia"),
        PlayerCard("Angel Di Maria", "أنخيل دي ماريا", "WG", 77, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alexis Sanchez", "أليكسيس سانشيز", "WG", 71, 7, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("David Beckham", "ديفيد بيكهام", "WG", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Stanley Matthews", "ستانلي ماثيوز", "WG", 71, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Hristo Stoichkov", "خريستو ستويتشكوف", "WG", 86, 10, "🇧🇬", "بلغاريا", "Bulgaria"),
        PlayerCard("Robert Pires", "روبير بيريس", "WG", 74, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Pierre-Emerick Aubameyang", "بيير إيمريك أوباميانج", "WG", 69, 7, "🇬🇦", "الغابون", "Gabon"),
        PlayerCard("Raheem Sterling", "رحيم سترلينج", "WG", 67, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Michael Olise", "مايكل أوليسيه", "WG", 92, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Luis Diaz", "لويس دياز", "WG", 86, 10, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Rayan Cherki", "ريان شرقي", "WG", 80, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Nani", "ناني", "WG", 79, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Pedro Rodriguez", "بيدرو رودريغيز", "WG", 80, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mohamed Zidan", "محمد زيدان", "WG", 68, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Angel Correa", "أنخيل كوريا", "WG", 74, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Pele", "بيليه", "ST", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Diego Maradona", "دييجو مارادونا", "ST", 95, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Ronaldo Nazario", "رونالدو نازاريو", "ST", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Thierry Henry", "تييري هنري", "ST", 92, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Didier Drogba", "ديدييه دروجبا", "ST", 83, 9, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Samuel Eto'o", "صامويل إيتو", "ST", 86, 10, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Robert Lewandowski", "روبرت ليفاندوفسكي", "ST", 83, 9, "🇵🇱", "بولندا", "Poland"),
        PlayerCard("Karim Benzema", "كريم بنزيما", "ST", 89, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Erling Haaland", "إيرلينج هالاند", "ST", 95, 11, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Harry Kane", "هاري كين", "ST", 92, 11, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Zlatan Ibrahimovic", "زلاتان إبراهيموفيتش", "ST", 89, 10, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Wayne Rooney", "واين روني", "ST", 83, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ruud van Nistelrooy", "رود فان نيستلروي", "ST", 80, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Marco van Basten", "ماركو فان باستن", "ST", 89, 10, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Gerd Muller", "جيرد مولر", "ST", 89, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Eusebio", "يوزيبيو", "ST", 89, 10, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Ferenc Puskas", "فيرينتس بوشكاش", "ST", 92, 11, "🇭🇺", "المجر", "Hungary"),
        PlayerCard("Romario", "روماريو", "ST", 86, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Gabriel Batistuta", "جابرييل باتيستوتا", "ST", 80, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alan Shearer", "آلان شيرر", "ST", 77, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Sergio Aguero", "سيرخيو أجويرو", "ST", 83, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Viktor Gyokeres", "فيكتور جيوكيريس", "ST", 80, 9, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Alexander Isak", "ألكسندر إيزاك", "ST", 80, 9, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Hossam Hassan", "حسام حسن", "ST", 81, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Miroslav Klose", "ميروسلاف كلوزه", "ST", 88, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Robin van Persie", "روبن فان بيرسي", "ST", 87, 10, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Filippo Inzaghi", "فيليبو إنزاغي", "ST", 84, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Edinson Cavani", "إدينسون كافاني", "ST", 85, 10, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Hernan Crespo", "هرنان كريسبو", "ST", 85, 10, "🇦🇷", "الأرجنتين", "Argentina"),
    )

    init {
        require(players.size == 192)
        require(players.filter { it.nameEn !in setOf("Lionel Messi", "Cristiano Ronaldo") }.all { it.rating in 55..97 })
        require(players.filter { it.nameEn in setOf("Lionel Messi", "Cristiano Ronaldo") }.all { it.rating == 99 })
        require(players.count { it.rating == 99 } == 2)
    }
}


/** Canonical squad order shared by all player-picking games. */
object ElbashaPositions {
    val rosterOrder = listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "CAM", "RW", "LW", "ST")

    /** Legacy database roles are broad; map them to the requested tactical slot family. */
    fun poolRole(slot: String): String = when (slot) {
        "GK" -> "GK"
        "RB", "CB", "LB" -> "DF"
        "CDM", "CM", "CAM" -> "MF"
        "RW", "LW" -> "WG"
        "ST" -> "ST"
        else -> ""
    }

    fun supports(player: PlayerCard, slot: String): Boolean = player.position == poolRole(slot)

    /** Creates a position-ordered auction lot pool, without repeating a player. */
    fun auctionPool(size: Int, total: Int): List<PlayerCard> {
        val used = mutableSetOf<String>()
        val ordered = mutableListOf<PlayerCard>()
        rosterOrder.take(size.coerceIn(1, rosterOrder.size)).forEach { slot ->
            val candidates = PlayerDatabase.players
                .filter { supports(it, slot) && it.nameEn !in used }
                .shuffled()
                .take(1)
            candidates.forEach { player ->
                if (used.add(player.nameEn)) ordered.add(player.copy(position = slot))
            }
        }
        return ordered.take(minOf(size, total))
    }
}
