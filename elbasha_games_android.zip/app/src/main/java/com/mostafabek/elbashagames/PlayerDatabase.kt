package com.mostafabek.elbashagames

/**
 * Shared ELBASHA player pool. Ratings represent each player's prime, not current age/current form.
 * Ratings use an EA FC-style relative scale, without copying live card values. Only Messi and
 * Cristiano Ronaldo carry 99; lower-rated legends and role players remain intentionally represented.
 */
data class PlayerCard(
    val nameEn: String, val nameAr: String, val position: String,
    val rating: Int, val price: Int, val flag: String,
    val nationalityAr: String = "", val nationalityEn: String = ""
)

object PlayerDatabase {
    val players: List<PlayerCard> = listOf(
        PlayerCard("Manuel Neuer", "مانويل نوير", "GK", 96, 11, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Iker Casillas", "إيكر كاسياس", "GK", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Gianluigi Buffon", "جانلويجي بوفون", "GK", 98, 11, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Petr Cech", "بيتر تشيك", "GK", 78, 5, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Thibaut Courtois", "تيبو كورتوا", "GK", 95, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Alisson Becker", "أليسون بيكر", "GK", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ederson", "إيدرسون", "GK", 85, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jan Oblak", "يان أوبلاك", "GK", 93, 10, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Marc-Andre ter Stegen", "مارك أندريه تير شتيجن", "GK", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Emiliano Martinez", "إيميليانو مارتينيز", "GK", 85, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("David de Gea", "دافيد دي خيا", "GK", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Keylor Navas", "كيلور نافاس", "GK", 87, 8, "🇨🇷", "كوستاريكا", "Costa Rica"),
        PlayerCard("Hugo Lloris", "هوجو لوريس", "GK", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Oliver Kahn", "أوليفر كان", "GK", 92, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Peter Schmeichel", "بيتر شمايكل", "GK", 83, 6, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Dida", "ديدا", "GK", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jose Luis Chilavert", "خوسيه لويس تشيلافيرت", "GK", 79, 5, "🇵🇾", "باراغواي", "Paraguay"),
        PlayerCard("Rene Higuita", "رينيه هيجيتا", "GK", 71, 5, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("David Raya", "دافيد رايا", "GK", 81, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Essam El Hadary", "عصام الحضري", "GK", 70, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Yassine Bounou", "ياسين بونو", "GK", 76, 5, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Mike Maignan", "مايك مانيان", "GK", 84, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gianluigi Donnarumma", "جيانلويجي دوناروما", "GK", 97, 11, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Unai Simon", "أوناي سيمون", "GK", 83, 6, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jordan Pickford", "جوردان بيكفورد", "GK", 80, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Andre Onana", "أندريه أونانا", "GK", 75, 5, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Samir Handanovic", "سمير هاندانوفيتش", "GK", 91, 9, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Edwin van der Sar", "إدوين فان دير سار", "GK", 81, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Claudio Bravo", "كلاوديو برافو", "GK", 82, 6, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Walter Zenga", "والتر زينجا", "GK", 86, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jorge Campos", "خورخي كامبوس", "GK", 73, 5, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("David Seaman", "ديفيد سيمان", "GK", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Victor Valdes", "فيكتور فالديس", "GK", 82, 6, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Shaka Hislop", "شاكا هيسلوب", "GK", 65, 5, "🇹🇹", "ترينيداد وتوباغو", "Trinidad and Tobago"),
        PlayerCard("Paolo Maldini", "باولو مالديني", "DF", 98, 11, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Sergio Ramos", "سيرخيو راموس", "DF", 97, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Virgil van Dijk", "فيرجيل فان دايك", "DF", 92, 10, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franco Baresi", "فرانكو باريزي", "DF", 94, 11, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Alessandro Nesta", "أليساندرو نيستا", "DF", 86, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Fabio Cannavaro", "فابيو كانافارو", "DF", 86, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Carles Puyol", "كارليس بويول", "DF", 86, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rio Ferdinand", "ريو فرديناند", "DF", 81, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Nemanja Vidic", "نيمانيا فيديتش", "DF", 74, 5, "🇷🇸", "صربيا", "Serbia"),
        PlayerCard("John Terry", "جون تيري", "DF", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Gerard Pique", "جيرارد بيكيه", "DF", 93, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Thiago Silva", "تياغو سيلفا", "DF", 87, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ruben Dias", "روبن دياز", "DF", 80, 5, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antonio Rudiger", "أنطونيو روديجر", "DF", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Achraf Hakimi", "أشرف حكيمي", "DF", 96, 11, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Trent Alexander-Arnold", "ترنت ألكسندر أرنولد", "DF", 87, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Dani Alves", "داني ألفيش", "DF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Cafu", "كافو", "DF", 96, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Carlos", "روبرتو كارلوس", "DF", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marcelo", "مارسيلو", "DF", 83, 6, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ashley Cole", "آشلي كول", "DF", 78, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Philipp Lahm", "فيليب لام", "DF", 82, 6, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Javier Zanetti", "خافيير زانيتي", "DF", 85, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Raphael Varane", "رافاييل فاران", "DF", 81, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("William Saliba", "ويليام ساليبا", "DF", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Alessandro Bastoni", "أليساندرو باستوني", "DF", 79, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Kim Min-jae", "كيم مين جاي", "DF", 70, 5, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Ronald Araujo", "رونالد أراوخو", "DF", 81, 5, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("John Stones", "جون ستونز", "DF", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Kyle Walker", "كايل ووكر", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Theo Hernandez", "ثيو هيرنانديز", "DF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andrew Robertson", "أندرو روبرتسون", "DF", 92, 10, "🇬🇧", "اسكتلندا", "Scotland"),
        PlayerCard("Giorgio Chiellini", "جورجيو كيليني", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Leonardo Bonucci", "ليوناردو بونوتشي", "DF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jaap Stam", "ياب ستام", "DF", 71, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Nuno Mendes", "نونو مينديز", "DF", 82, 6, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Gabriel Magalhaes", "جابرييل ماجالهايس", "DF", 85, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Willian Pacho", "ويليان باتشو", "DF", 72, 5, "🇪🇨", "الإكوادور", "Ecuador"),
        PlayerCard("Lilian Thuram", "ليليان تورام", "DF", 84, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Marcel Desailly", "مارسيل ديسايي", "DF", 83, 6, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sol Campbell", "سول كامبل", "DF", 73, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Wael Gomaa", "وائل جمعة", "DF", 67, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Lucio", "لوسيو", "DF", 83, 6, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Carlos Alberto", "كارلوس ألبرتو", "DF", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Zinedine Zidane", "زين الدين زيدان", "MF", 97, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andres Iniesta", "أندريس إنييستا", "MF", 95, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Xavi Hernandez", "تشافي هيرنانديز", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Luka Modric", "لوكا مودريتش", "MF", 94, 11, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Toni Kroos", "توني كروس", "MF", 82, 6, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Andrea Pirlo", "أندريا بيرلو", "MF", 93, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Steven Gerrard", "ستيفن جيرارد", "MF", 79, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Frank Lampard", "فرانك لامبارد", "MF", 81, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Paul Scholes", "بول سكولز", "MF", 80, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Patrick Vieira", "باتريك فييرا", "MF", 70, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Claude Makelele", "كلود ماكيليلي", "MF", 76, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sergio Busquets", "سيرجيو بوسكيتس", "MF", 83, 6, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rodri", "رودري", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kevin De Bruyne", "كيفن دي بروين", "MF", 98, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Jude Bellingham", "جود بيلينجهام", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Pedri", "بيدري", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jamal Musiala", "جمال موسيالا", "MF", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Federico Valverde", "فيديريكو فالفيردي", "MF", 86, 7, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Declan Rice", "ديكلان رايس", "MF", 82, 6, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Bruno Fernandes", "برونو فيرنانديز", "MF", 91, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Yaya Toure", "يايا توريه", "MF", 68, 5, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Clarence Seedorf", "كلارنس سيدورف", "MF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Kaka", "كاكا", "MF", 85, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ronaldinho", "رونالدينيو", "MF", 96, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Rivaldo", "ريفالدو", "MF", 83, 6, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Michel Platini", "ميشيل بلاتيني", "MF", 97, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Lothar Matthaus", "لوثار ماتيوس", "MF", 85, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Roy Keane", "روي كين", "MF", 83, 6, "🇮🇪", "أيرلندا", "Ireland"),
        PlayerCard("Cesc Fabregas", "سيسك فابريجاس", "MF", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mesut Ozil", "مسعود أوزيل", "MF", 84, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("David Silva", "دافيد سيلفا", "MF", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bastian Schweinsteiger", "باستيان شفاينشتايجر", "MF", 92, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Mohamed Aboutrika", "محمد أبو تريكة", "MF", 71, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Xabi Alonso", "تشابي ألونسو", "MF", 68, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bobby Charlton", "بوبي تشارلتون", "MF", 94, 11, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Vitinha", "فيتينيا", "MF", 82, 6, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joao Neves", "جواو نيفيز", "MF", 74, 5, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joshua Kimmich", "جوشوا كيميش", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Florian Wirtz", "فلوريان فيرتز", "MF", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Martin Odegaard", "مارتن أوديجارد", "MF", 85, 7, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Enzo Fernandez", "إنزو فيرنانديز", "MF", 81, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jay-Jay Okocha", "جاي جاي أوكوشا", "MF", 86, 7, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Michael Essien", "مايكل إيسيان", "MF", 72, 5, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("N'Golo Kante", "نجولو كانتي", "MF", 84, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gennaro Gattuso", "جينارو جاتوزو", "MF", 75, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Park Ji-sung", "بارك جي سونغ", "MF", 66, 5, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Shinji Kagawa", "شينجي كاغاوا", "MF", 69, 5, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Frank Rijkaard", "فرانك ريكارد", "MF", 76, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Lionel Messi", "ليونيل ميسي", "WG", 99, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Cristiano Ronaldo", "كريستيانو رونالدو", "WG", 99, 11, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Mohamed Salah", "محمد صلاح", "WG", 90, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Neymar Jr", "نيمار", "WG", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Riyad Mahrez", "رياض محرز", "WG", 81, 5, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Kylian Mbappe", "كيليان مبابي", "WG", 96, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Vinicius Junior", "فينيسيوس جونيور", "WG", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Lamine Yamal", "لامين يامال", "WG", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bukayo Saka", "بوكايو ساكا", "WG", 87, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Son Heung-min", "سون هيونج مين", "WG", 89, 9, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Arjen Robben", "أريين روبن", "WG", 94, 11, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franck Ribery", "فرانك ريبيري", "WG", 79, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gareth Bale", "جاريث بيل", "WG", 78, 5, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Eden Hazard", "إيدين هازارد", "WG", 91, 9, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Luis Figo", "لويس فيجو", "WG", 86, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("George Best", "جورج بست", "WG", 87, 8, "🇬🇧", "أيرلندا الشمالية", "Northern Ireland"),
        PlayerCard("Ryan Giggs", "ريان جيجز", "WG", 84, 7, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Luis Suarez", "لويس سواريز", "WG", 93, 10, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Sadio Mane", "ساديو ماني", "WG", 89, 9, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Raphinha", "رافينيا", "WG", 81, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ousmane Dembele", "عثمان ديمبيلي", "WG", 85, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Khvicha Kvaratskhelia", "خفيتشا كفاراتسخيليا", "WG", 82, 6, "🇬🇪", "جورجيا", "Georgia"),
        PlayerCard("Angel Di Maria", "أنخيل دي ماريا", "WG", 88, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alexis Sanchez", "أليكسيس سانشيز", "WG", 83, 6, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("David Beckham", "ديفيد بيكهام", "WG", 80, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Stanley Matthews", "ستانلي ماثيوز", "WG", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Hristo Stoichkov", "خريستو ستويتشكوف", "WG", 83, 6, "🇧🇬", "بلغاريا", "Bulgaria"),
        PlayerCard("Robert Pires", "روبير بيريس", "WG", 74, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Pierre-Emerick Aubameyang", "بيير إيمريك أوباميانج", "WG", 85, 7, "🇬🇦", "الغابون", "Gabon"),
        PlayerCard("Raheem Sterling", "رحيم سترلينج", "WG", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Michael Olise", "مايكل أوليسيه", "WG", 86, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Luis Diaz", "لويس دياز", "WG", 82, 6, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Rayan Cherki", "ريان شرقي", "WG", 76, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Nani", "ناني", "WG", 82, 6, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Pedro Rodriguez", "بيدرو رودريغيز", "WG", 77, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mohamed Zidan", "محمد زيدان", "WG", 70, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Angel Correa", "أنخيل كوريا", "WG", 80, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Pele", "بيليه", "ST", 97, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Diego Maradona", "دييجو مارادونا", "ST", 98, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Ronaldo Nazario", "رونالدو نازاريو", "ST", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Thierry Henry", "تييري هنري", "ST", 86, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Didier Drogba", "ديدييه دروجبا", "ST", 81, 5, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Samuel Eto'o", "صامويل إيتو", "ST", 77, 5, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Robert Lewandowski", "روبرت ليفاندوفسكي", "ST", 90, 9, "🇵🇱", "بولندا", "Poland"),
        PlayerCard("Karim Benzema", "كريم بنزيما", "ST", 91, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Erling Haaland", "إيرلينج هالاند", "ST", 88, 8, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Harry Kane", "هاري كين", "ST", 87, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Zlatan Ibrahimovic", "زلاتان إبراهيموفيتش", "ST", 89, 9, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Wayne Rooney", "واين روني", "ST", 83, 6, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ruud van Nistelrooy", "رود فان نيستلروي", "ST", 78, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Marco van Basten", "ماركو فان باستن", "ST", 86, 7, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Gerd Muller", "جيرد مولر", "ST", 93, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Eusebio", "يوزيبيو", "ST", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Ferenc Puskas", "فيرينتس بوشكاش", "ST", 94, 11, "🇭🇺", "المجر", "Hungary"),
        PlayerCard("Romario", "روماريو", "ST", 79, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Gabriel Batistuta", "جابرييل باتيستوتا", "ST", 80, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alan Shearer", "آلان شيرر", "ST", 82, 6, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Sergio Aguero", "سيرخيو أجويرو", "ST", 84, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Viktor Gyokeres", "فيكتور جيوكيريس", "ST", 66, 5, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Alexander Isak", "ألكسندر إيزاك", "ST", 76, 5, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Hossam Hassan", "حسام حسن", "ST", 73, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Miroslav Klose", "ميروسلاف كلوزه", "ST", 70, 5, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Robin van Persie", "روبن فان بيرسي", "ST", 67, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Filippo Inzaghi", "فيليبو إنزاغي", "ST", 80, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Edinson Cavani", "إدينسون كافاني", "ST", 86, 7, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Hernan Crespo", "هرنان كريسبو", "ST", 74, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jens Lehmann", "ينس ليمان", "GK", 84, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Fabien Barthez", "فابيان بارتيز", "GK", 80, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Tim Howard", "تيم هاورد", "GK", 68, 5, "🇺🇸", "الولايات المتحدة", "United States"),
        PlayerCard("Brad Friedel", "براد فريدل", "GK", 66, 5, "🇺🇸", "الولايات المتحدة", "United States"),
        PlayerCard("Claudio Taffarel", "كلاوديو تافاريل", "GK", 74, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Mark Schwarzer", "مارك شوارزر", "GK", 69, 5, "🇦🇺", "أستراليا", "Australia"),
        PlayerCard("Pepe", "بيبي", "DF", 82, 6, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Vincent Kompany", "فنسنت كومباني", "DF", 80, 5, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Mats Hummels", "ماتس هوملز", "DF", 75, 5, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Bixente Lizarazu", "بيكسنت ليزارازو", "DF", 69, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Patrice Evra", "باتريس إيفرا", "DF", 68, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Eric Abidal", "إيريك أبيدال", "DF", 66, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Dani Carvajal", "داني كارفاخال", "DF", 72, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kieran Trippier", "كيران تريبيير", "DF", 65, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Giuseppe Bergomi", "جوزيبي بيرغومي", "DF", 76, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Frank de Boer", "فرانك دي بور", "DF", 77, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Michael Ballack", "مايكل بالاك", "MF", 84, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Juan Roman Riquelme", "خوان رومان ريكيلمي", "MF", 73, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Michael Laudrup", "مايكل لاودروب", "MF", 89, 9, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Pavel Nedved", "بافيل نيدفيد", "MF", 84, 7, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Gheorghe Hagi", "جورجي حاجي", "MF", 80, 5, "🇷🇴", "رومانيا", "Romania"),
        PlayerCard("Juan Sebastian Veron", "خوان سيباستيان فيرون", "MF", 67, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Thomas Muller", "توماس مولر", "MF", 78, 5, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Guti", "جوتي", "MF", 65, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Arturo Vidal", "أرتورو فيدال", "MF", 77, 5, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Deco", "ديكو", "MF", 81, 5, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antoine Griezmann", "أنطوان جريزمان", "WG", 92, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Juan Mata", "خوان ماتا", "WG", 71, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Hakim Ziyech", "حكيم زياش", "WG", 73, 5, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Willian", "ويليان", "WG", 72, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jesus Navas", "خيسوس نافاس", "WG", 66, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Ricardo Quaresma", "ريكاردو كواريزما", "WG", 68, 5, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Dirk Kuyt", "ديرك كاوت", "WG", 67, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Wilfried Zaha", "ويلفريد زاها", "WG", 65, 5, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Michael Owen", "مايكل أوين", "ST", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("David Villa", "دافيد فيا", "ST", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("George Weah", "جورج ويا", "ST", 85, 7, "🇱🇷", "ليبيريا", "Liberia"),
        PlayerCard("Carlos Tevez", "كارلوس تيفيز", "ST", 82, 6, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Edin Dzeko", "إدين دجيكو", "ST", 65, 5, "🇧🇦", "البوسنة والهرسك", "Bosnia and Herzegovina"),
        PlayerCard("Christian Vieri", "كريستيان فييري", "ST", 82, 6, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Robbie Fowler", "روبي فاولر", "ST", 68, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ian Wright", "إيان رايت", "ST", 72, 5, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Mario Gomez", "ماريو جوميز", "ST", 71, 5, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Gonzalo Higuain", "غونزالو هيغواين", "ST", 84, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Lev Yashin", "ليف ياشين", "GK", 96, 11, "🇷🇺", "روسيا", "Russia"),
        PlayerCard("Sepp Maier", "سيب ماير", "GK", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Gordon Banks", "جوردون بانكس", "GK", 85, 7, "🇬🇧", "إنجلترا", "England"),
        PlayerCard("Bruce Grobbelaar", "بروس جروبلار", "GK", 73, 5, "🇿🇼", "زيمبابوي", "Zimbabwe"),
        PlayerCard("Ronald Koeman", "رونالد كومان", "DF", 95, 11, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Fernando Hierro", "فرناندو هييرو", "DF", 92, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Alessandro Costacurta", "أليساندرو كوستاكورتا", "DF", 85, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Roberto Ayala", "روبرتو أيالا", "DF", 86, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Laurent Blanc", "لوران بلان", "DF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Walter Samuel", "والتر صامويل", "DF", 87, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Gary Neville", "جاري نيفيل", "DF", 78, 5, "🇬🇧", "إنجلترا", "England"),
        PlayerCard("Denis Irwin", "دينيس إروين", "DF", 77, 5, "🇮🇪", "أيرلندا", "Ireland"),
        PlayerCard("Willy Sagnol", "ويلي سانيول", "DF", 79, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Fabio Grosso", "فابيو جروسو", "DF", 76, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Zico", "زيكو", "MF", 97, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Socrates", "سقراط", "MF", 94, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Edgar Davids", "إدجار دافيدز", "MF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Rui Costa", "روي كوستا", "MF", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Wesley Sneijder", "ويسلي شنايدر", "MF", 89, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("David Pizarro", "دافيد بيزارو", "MF", 83, 6, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Juninho Pernambucano", "جونينيو بيرنامبوكانو", "MF", 78, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Shunsuke Nakamura", "شونسوكي ناكامورا", "MF", 79, 5, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Hidetoshi Nakata", "هيديتوشي ناكاتا", "MF", 77, 5, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Anderson", "أندرسون", "MF", 74, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jairzinho", "جاييرزينيو", "WG", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Garrincha", "جارينشا", "WG", 97, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marc Overmars", "مارك أوفرمارس", "WG", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Steve McManaman", "ستيف ماكمانامان", "WG", 84, 7, "🇬🇧", "إنجلترا", "England"),
        PlayerCard("Claudio Caniggia", "كلاوديو كانيجيا", "WG", 86, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Dries Mertens", "دريس ميرتينز", "WG", 87, 8, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("David Ginola", "دافيد جينولا", "WG", 85, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Finidi George", "فينيـدي جورج", "WG", 83, 6, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Jimmy Greaves", "جيمي جريفز", "ST", 95, 11, "🇬🇧", "إنجلترا", "England"),
        PlayerCard("Gary Lineker", "جاري لينيكر", "ST", 89, 9, "🇬🇧", "إنجلترا", "England"),
        PlayerCard("Fernando Torres", "فيرناندو توريس", "ST", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("David Trezeguet", "دافيد تريزيجيه", "ST", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Ian Rush", "إيان راش", "ST", 85, 7, "🏴", "ويلز", "Wales"),
        PlayerCard("Jan Koller", "يان كولر", "ST", 79, 5, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Salvatore Schillaci", "سلفاتوري سكيلاتشي", "ST", 78, 5, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Giuseppe Signori", "جوزيبي سينيوري", "ST", 76, 5, "🇮🇹", "إيطاليا", "Italy"),
    )

    init {
        require(players.size == 276)
        require(players.all { it.rating in 1..99 })
        require(players.map { it.nameEn }.distinct().size == players.size)
        require(players.count { it.rating >= 90 } == 55)
        require(players.count { it.rating in 80..89 } == 138)
        require(players.count { it.rating < 80 } == 83)
        require(players.filter { it.nameEn !in setOf("Lionel Messi", "Cristiano Ronaldo") }.none { it.rating == 99 })
    }
}


/** Canonical squad order shared by all player-picking games. */
object ElbashaPositions {
    val rosterOrder = listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "CAM", "RW", "LW", "ST")

    /** Balanced GK-to-ST formations for every supported squad size. */
    fun formationSlots(size: Int): List<String> {
        val formations = mapOf(
            4 to listOf("GK", "CB", "CM", "ST"),
            5 to listOf("GK", "CB", "CM", "RW", "ST"),
            6 to listOf("GK", "RB", "CB", "CM", "RW", "ST"),
            7 to listOf("GK", "RB", "CB", "CM", "CAM", "RW", "ST"),
            8 to listOf("GK", "RB", "CB", "CB", "CM", "CAM", "RW", "ST"),
            9 to listOf("GK", "RB", "CB", "CB", "LB", "CM", "CAM", "RW", "ST"),
            10 to listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "RW", "LW", "ST"),
            11 to rosterOrder
        )
        return formations[size.coerceIn(4, 11)] ?: rosterOrder
    }

    /** Legacy database roles are broad; map them to the requested tactical slot family. */
    fun poolRole(slot: String): String = when (slot) {
        "GK" -> "GK"
        "RB", "CB", "LB", "DF" -> "DF"
        "CDM", "CM", "CAM", "MF" -> "MF"
        "RW", "LW", "WG" -> "WG"
        "ST" -> "ST"
        else -> ""
    }

    fun supports(player: PlayerCard, slot: String): Boolean =
        poolRole(player.position) == poolRole(slot) && poolRole(slot).isNotEmpty()

    /**
     * Creates a larger auction queue while preserving the formation's GK-to-ST role ratio.
     * Each pass through the formation adds one unique eligible player per slot; this gives
     * Classic a 24-lot queue and Pro Max a 42-lot queue rather than silently truncating it
     * to only 5 or 11 players.
     */
    fun auctionPool(size: Int, total: Int): List<PlayerCard> {
        val slots = formationSlots(size.coerceIn(4, rosterOrder.size))
        val ordered = mutableListOf<PlayerCard>()
        val target = total.coerceAtLeast(size).coerceAtMost(PlayerDatabase.players.size)
        // Shuffle once, then consume a separate queue per broad role. This keeps every
        // selected player unique without repeatedly shuffling the full database per lot.
        val playersByRole = PlayerDatabase.players.shuffled()
            .groupBy { poolRole(it.position) }
            .mapValues { (_, players) -> players.toMutableList() }
        while (ordered.size < target) {
            val beforePass = ordered.size
            slots.forEach { slot ->
                if (ordered.size < target) {
                    val role = poolRole(slot)
                    val candidate = playersByRole[role]?.removeAt(0)
                    if (candidate != null && supports(candidate, slot)) {
                        ordered.add(candidate.copy(position = slot))
                    }
                }
            }
            if (ordered.size == beforePass) break
        }
        return ordered
    }
}
