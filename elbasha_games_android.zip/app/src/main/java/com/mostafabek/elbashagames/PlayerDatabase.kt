package com.mostafabek.elbashagames

/**
 * Shared ELBASHA player pool. Ratings represent each player's prime, not their current age/current form.
 * FC 27 Icon/Hero card OVR is preferred when an eligible special item exists; otherwise the
 * closest available peak standard FIFA/FC OVR is used as the historical reference.
 * Player OVRs are recalibrated against the FC 27 Icon/Hero reference table and prime-era records.
 * Per the game's agreed scale, Messi and Cristiano Ronaldo alone receive the 99 cap; no 75 floor is imposed.
 * Tiers: 89+ strong, 82-88 medium, below 82 weak (see [PlayerTier]). Ratings were restored to the
 * original calibration; only players who were clearly under-rated for their real level were raised.
 */
data class PlayerCard(
    val nameEn: String, val nameAr: String, val position: String,
    val rating: Int, val price: Int, val flag: String,
    val nationalityAr: String = "", val nationalityEn: String = ""
)

/**
 * Rating tiers used by the auction and Deal or No Deal draws:
 * 89+ is STRONG, 82-88 is MEDIUM, below 82 is WEAK.
 */
enum class PlayerTier {
    STRONG, MEDIUM, WEAK;

    companion object {
        const val STRONG_MIN = 89
        const val MEDIUM_MIN = 82
        fun of(rating: Int): PlayerTier = when {
            rating >= STRONG_MIN -> STRONG
            rating >= MEDIUM_MIN -> MEDIUM
            else -> WEAK
        }
    }
}

val PlayerCard.tier: PlayerTier get() = PlayerTier.of(rating)

object PlayerDatabase {
    val players: List<PlayerCard> = listOf(
        PlayerCard("Manuel Neuer", "مانويل نوير", "GK", 94, 11, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Iker Casillas", "إيكر كاسياس", "GK", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Gianluigi Buffon", "جانلويجي بوفون", "GK", 92, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Petr Cech", "بيتر تشيك", "GK", 88, 8, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Thibaut Courtois", "تيبو كورتوا", "GK", 94, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Alisson Becker", "أليسون بيكر", "GK", 92, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ederson", "إيدرسون", "GK", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jan Oblak", "يان أوبلاك", "GK", 92, 10, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Marc-Andre ter Stegen", "مارك أندريه تير شتيجن", "GK", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Emiliano Martinez", "إيميليانو مارتينيز", "GK", 87, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("David de Gea", "دافيد دي خيا", "GK", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Keylor Navas", "كيلور نافاس", "GK", 88, 8, "🇨🇷", "كوستاريكا", "Costa Rica"),
        PlayerCard("Hugo Lloris", "هوجو لوريس", "GK", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Oliver Kahn", "أوليفر كان", "GK", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Peter Schmeichel", "بيتر شمايكل", "GK", 89, 9, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Dida", "ديدا", "GK", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jose Luis Chilavert", "خوسيه لويس تشيلافيرت", "GK", 86, 7, "🇵🇾", "باراغواي", "Paraguay"),
        PlayerCard("Rene Higuita", "رينيه هيجيتا", "GK", 83, 6, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("David Raya", "دافيد رايا", "GK", 86, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Essam El Hadary", "عصام الحضري", "GK", 84, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Yassine Bounou", "ياسين بونو", "GK", 86, 7, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Mike Maignan", "مايك مانيان", "GK", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gianluigi Donnarumma", "جيانلويجي دوناروما", "GK", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Unai Simon", "أوناي سيمون", "GK", 83, 6, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jordan Pickford", "جوردان بيكفورد", "GK", 83, 6, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Andre Onana", "أندريه أونانا", "GK", 82, 6, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Samir Handanovic", "سمير هاندانوفيتش", "GK", 89, 9, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Edwin van der Sar", "إدوين فان دير سار", "GK", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Claudio Bravo", "كلاوديو برافو", "GK", 86, 7, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Walter Zenga", "والتر زينجا", "GK", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jorge Campos", "خورخي كامبوس", "GK", 82, 6, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("David Seaman", "ديفيد سيمان", "GK", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Victor Valdes", "فيكتور فالديس", "GK", 86, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Shaka Hislop", "شاكا هيسلوب", "GK", 65, 5, "🇹🇹", "ترينيداد وتوباغو", "Trinidad and Tobago"),
        PlayerCard("Paolo Maldini", "باولو مالديني", "DF", 93, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Sergio Ramos", "سيرخيو راموس", "DF", 94, 11, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Virgil van Dijk", "فيرجيل فان دايك", "DF", 94, 11, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franco Baresi", "فرانكو باريزي", "DF", 91, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Alessandro Nesta", "أليساندرو نيستا", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Fabio Cannavaro", "فابيو كانافارو", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Carles Puyol", "كارليس بويول", "DF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rio Ferdinand", "ريو فرديناند", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Nemanja Vidic", "نيمانيا فيديتش", "DF", 88, 8, "🇷🇸", "صربيا", "Serbia"),
        PlayerCard("John Terry", "جون تيري", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Gerard Pique", "جيرارد بيكيه", "DF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Thiago Silva", "تياغو سيلفا", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ruben Dias", "روبن دياز", "DF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antonio Rudiger", "أنطونيو روديجر", "DF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Achraf Hakimi", "أشرف حكيمي", "DF", 89, 9, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Trent Alexander-Arnold", "ترنت ألكسندر أرنولد", "DF", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Dani Alves", "داني ألفيش", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Cafu", "كافو", "DF", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Carlos", "روبرتو كارلوس", "DF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marcelo", "مارسيلو", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ashley Cole", "آشلي كول", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Philipp Lahm", "فيليب لام", "DF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Javier Zanetti", "خافيير زانيتي", "DF", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Raphael Varane", "رافاييل فاران", "DF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("William Saliba", "ويليام ساليبا", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Alessandro Bastoni", "أليساندرو باستوني", "DF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Kim Min-jae", "كيم مين جاي", "DF", 85, 7, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Ronald Araujo", "رونالد أراوخو", "DF", 87, 8, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("John Stones", "جون ستونز", "DF", 86, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Kyle Walker", "كايل ووكر", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Theo Hernandez", "ثيو هيرنانديز", "DF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andrew Robertson", "أندرو روبرتسون", "DF", 89, 9, "🇬🇧", "اسكتلندا", "Scotland"),
        PlayerCard("Giorgio Chiellini", "جورجيو كيليني", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Leonardo Bonucci", "ليوناردو بونوتشي", "DF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jaap Stam", "ياب ستام", "DF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Nuno Mendes", "نونو مينديز", "DF", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Gabriel Magalhaes", "جابرييل ماجالهايس", "DF", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Willian Pacho", "ويليان باتشو", "DF", 85, 7, "🇪🇨", "الإكوادور", "Ecuador"),
        PlayerCard("Lilian Thuram", "ليليان تورام", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Marcel Desailly", "مارسيل ديسايي", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sol Campbell", "سول كامبل", "DF", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Wael Gomaa", "وائل جمعة", "DF", 82, 6, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Lucio", "لوسيو", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Carlos Alberto", "كارلوس ألبرتو", "DF", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Zinedine Zidane", "زين الدين زيدان", "MF", 94, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andres Iniesta", "أندريس إنييستا", "MF", 92, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Xavi Hernandez", "تشافي هيرنانديز", "MF", 91, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Luka Modric", "لوكا مودريتش", "MF", 94, 11, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Toni Kroos", "توني كروس", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Andrea Pirlo", "أندريا بيرلو", "MF", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Steven Gerrard", "ستيفن جيرارد", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Frank Lampard", "فرانك لامبارد", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Paul Scholes", "بول سكولز", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Patrick Vieira", "باتريك فييرا", "MF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Claude Makelele", "كلود ماكيليلي", "MF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sergio Busquets", "سيرجيو بوسكيتس", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rodri", "رودري", "MF", 93, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kevin De Bruyne", "كيفن دي بروين", "MF", 94, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Jude Bellingham", "جود بيلينجهام", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Pedri", "بيدري", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jamal Musiala", "جمال موسيالا", "MF", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Federico Valverde", "فيديريكو فالفيردي", "MF", 89, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Declan Rice", "ديكلان رايس", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Bruno Fernandes", "برونو فيرنانديز", "MF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Yaya Toure", "يايا توريه", "MF", 88, 8, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Clarence Seedorf", "كلارنس سيدورف", "MF", 89, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Kaka", "كاكا", "MF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ronaldinho", "رونالدينيو", "MF", 93, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Rivaldo", "ريفالدو", "MF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Michel Platini", "ميشيل بلاتيني", "MF", 94, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Lothar Matthaus", "لوثار ماتيوس", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Roy Keane", "روي كين", "MF", 89, 9, "🇮🇪", "أيرلندا", "Ireland"),
        PlayerCard("Cesc Fabregas", "سيسك فابريجاس", "MF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mesut Ozil", "مسعود أوزيل", "MF", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("David Silva", "دافيد سيلفا", "MF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bastian Schweinsteiger", "باستيان شفاينشتايجر", "MF", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Mohamed Aboutrika", "محمد أبو تريكة", "MF", 88, 8, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Xabi Alonso", "تشابي ألونسو", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bobby Charlton", "بوبي تشارلتون", "MF", 92, 10, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Vitinha", "فيتينيا", "MF", 87, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joao Neves", "جواو نيفيز", "MF", 86, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joshua Kimmich", "جوشوا كيميش", "MF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Florian Wirtz", "فلوريان فيرتز", "MF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Martin Odegaard", "مارتن أوديجارد", "MF", 88, 8, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Enzo Fernandez", "إنزو فيرنانديز", "MF", 85, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jay-Jay Okocha", "جاي جاي أوكوشا", "MF", 89, 9, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Michael Essien", "مايكل إيسيان", "MF", 88, 8, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("N'Golo Kante", "نجولو كانتي", "MF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gennaro Gattuso", "جينارو جاتوزو", "MF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Park Ji-sung", "بارك جي سونغ", "MF", 86, 7, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Shinji Kagawa", "شينجي كاغاوا", "MF", 83, 6, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Frank Rijkaard", "فرانك ريكارد", "MF", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Lionel Messi", "ليونيل ميسي", "WG", 99, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Cristiano Ronaldo", "كريستيانو رونالدو", "WG", 99, 11, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Mohamed Salah", "محمد صلاح", "WG", 94, 11, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Neymar Jr", "نيمار", "WG", 94, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Riyad Mahrez", "رياض محرز", "WG", 89, 9, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Kylian Mbappe", "كيليان مبابي", "WG", 94, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Vinicius Junior", "فينيسيوس جونيور", "WG", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Lamine Yamal", "لامين يامال", "WG", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bukayo Saka", "بوكايو ساكا", "WG", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Son Heung-min", "سون هيونج مين", "WG", 89, 9, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Arjen Robben", "أريين روبن", "WG", 94, 11, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franck Ribery", "فرانك ريبيري", "WG", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gareth Bale", "جاريث بيل", "WG", 88, 8, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Eden Hazard", "إيدين هازارد", "WG", 93, 10, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Luis Figo", "لويس فيجو", "WG", 90, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("George Best", "جورج بست", "WG", 90, 9, "🇬🇧", "أيرلندا الشمالية", "Northern Ireland"),
        PlayerCard("Ryan Giggs", "ريان جيجز", "WG", 91, 9, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Luis Suarez", "لويس سواريز", "ST", 92, 10, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Sadio Mane", "ساديو ماني", "WG", 89, 9, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Raphinha", "رافينيا", "WG", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ousmane Dembele", "عثمان ديمبيلي", "WG", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Khvicha Kvaratskhelia", "خفيتشا كفاراتسخيليا", "WG", 88, 8, "🇬🇪", "جورجيا", "Georgia"),
        PlayerCard("Angel Di Maria", "أنخيل دي ماريا", "WG", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alexis Sanchez", "أليكسيس سانشيز", "WG", 88, 8, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("David Beckham", "ديفيد بيكهام", "WG", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Stanley Matthews", "ستانلي ماثيوز", "WG", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Hristo Stoichkov", "خريستو ستويتشكوف", "WG", 89, 9, "🇧🇬", "بلغاريا", "Bulgaria"),
        PlayerCard("Robert Pires", "روبير بيريس", "WG", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Pierre-Emerick Aubameyang", "بيير إيمريك أوباميانج", "WG", 88, 8, "🇬🇦", "الغابون", "Gabon"),
        PlayerCard("Raheem Sterling", "رحيم سترلينج", "WG", 87, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Michael Olise", "مايكل أوليسيه", "WG", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Luis Diaz", "لويس دياز", "WG", 86, 7, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Rayan Cherki", "ريان شرقي", "WG", 84, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Nani", "ناني", "WG", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Pedro Rodriguez", "بيدرو رودريغيز", "WG", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mohamed Zidan", "محمد زيدان", "ST", 77, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Angel Correa", "أنخيل كوريا", "WG", 85, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Pele", "بيليه", "ST", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Diego Maradona", "دييجو مارادونا", "ST", 95, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Ronaldo Nazario", "رونالدو نازاريو", "ST", 94, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Thierry Henry", "تييري هنري", "ST", 94, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Didier Drogba", "ديدييه دروجبا", "ST", 89, 9, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Samuel Eto'o", "صامويل إيتو", "ST", 89, 9, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Robert Lewandowski", "روبرت ليفاندوفسكي", "ST", 94, 11, "🇵🇱", "بولندا", "Poland"),
        PlayerCard("Karim Benzema", "كريم بنزيما", "ST", 93, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Erling Haaland", "إيرلينج هالاند", "ST", 91, 9, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Harry Kane", "هاري كين", "ST", 91, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Zlatan Ibrahimovic", "زلاتان إبراهيموفيتش", "ST", 91, 9, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Wayne Rooney", "واين روني", "ST", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ruud van Nistelrooy", "رود فان نيستلروي", "ST", 89, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Marco van Basten", "ماركو فان باستن", "ST", 91, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Gerd Muller", "جيرد مولر", "ST", 92, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Eusebio", "يوزيبيو", "ST", 91, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Ferenc Puskas", "فيرينتس بوشكاش", "ST", 92, 10, "🇭🇺", "المجر", "Hungary"),
        PlayerCard("Romario", "روماريو", "ST", 94, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Gabriel Batistuta", "جابرييل باتيستوتا", "ST", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alan Shearer", "آلان شيرر", "ST", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Sergio Aguero", "سيرخيو أجويرو", "ST", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Viktor Gyokeres", "فيكتور جيوكيريس", "ST", 87, 8, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Alexander Isak", "ألكسندر إيزاك", "ST", 88, 8, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Hossam Hassan", "حسام حسن", "ST", 88, 8, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Miroslav Klose", "ميروسلاف كلوزه", "ST", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Robin van Persie", "روبن فان بيرسي", "ST", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Filippo Inzaghi", "فيليبو إنزاغي", "ST", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Edinson Cavani", "إدينسون كافاني", "ST", 89, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Hernan Crespo", "هرنان كريسبو", "ST", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jens Lehmann", "ينس ليمان", "GK", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Fabien Barthez", "فابيان بارتيز", "GK", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Tim Howard", "تيم هاورد", "GK", 80, 5, "🇺🇸", "الولايات المتحدة", "United States"),
        PlayerCard("Brad Friedel", "براد فريدل", "GK", 81, 5, "🇺🇸", "الولايات المتحدة", "United States"),
        PlayerCard("Claudio Taffarel", "كلاوديو تافاريل", "GK", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Mark Schwarzer", "مارك شوارزر", "GK", 83, 6, "🇦🇺", "أستراليا", "Australia"),
        PlayerCard("Pepe", "بيبي", "DF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Vincent Kompany", "فنسنت كومباني", "DF", 89, 9, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Mats Hummels", "ماتس هوملز", "DF", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Bixente Lizarazu", "بيكسنت ليزارازو", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Patrice Evra", "باتريس إيفرا", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Eric Abidal", "إيريك أبيدال", "DF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Dani Carvajal", "داني كارفاخال", "DF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kieran Trippier", "كيران تريبيير", "DF", 84, 7, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Giuseppe Bergomi", "جوزيبي بيرغومي", "DF", 92, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Frank de Boer", "فرانك دي بور", "DF", 90, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Michael Ballack", "مايكل بالاك", "MF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Juan Roman Riquelme", "خوان رومان ريكيلمي", "MF", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Michael Laudrup", "مايكل لاودروب", "MF", 88, 8, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Pavel Nedved", "بافيل نيدفيد", "MF", 89, 9, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Gheorghe Hagi", "جورجي حاجي", "MF", 89, 9, "🇷🇴", "رومانيا", "Romania"),
        PlayerCard("Juan Sebastian Veron", "خوان سيباستيان فيرون", "MF", 85, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Thomas Muller", "توماس مولر", "MF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Guti", "جوتي", "MF", 85, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Arturo Vidal", "أرتورو فيدال", "MF", 89, 9, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Deco", "ديكو", "MF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antoine Griezmann", "أنطوان جريزمان", "ST", 92, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Juan Mata", "خوان ماتا", "WG", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Hakim Ziyech", "حكيم زياش", "WG", 86, 7, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Willian", "ويليان", "WG", 85, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jesus Navas", "خيسوس نافاس", "WG", 86, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Ricardo Quaresma", "ريكاردو كواريزما", "WG", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Dirk Kuyt", "ديرك كاوت", "WG", 83, 6, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Wilfried Zaha", "ويلفريد زاها", "WG", 78, 5, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Michael Owen", "مايكل أوين", "ST", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("David Villa", "دافيد فيا", "ST", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("George Weah", "جورج ويا", "ST", 89, 9, "🇱🇷", "ليبيريا", "Liberia"),
        PlayerCard("Carlos Tevez", "كارلوس تيفيز", "ST", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Edin Dzeko", "إدين دجيكو", "ST", 85, 7, "🇧🇦", "البوسنة والهرسك", "Bosnia and Herzegovina"),
        PlayerCard("Christian Vieri", "كريستيان فييري", "ST", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Robbie Fowler", "روبي فاولر", "ST", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ian Wright", "إيان رايت", "ST", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Mario Gomez", "ماريو جوميز", "ST", 84, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Gonzalo Higuain", "غونزالو هيغواين", "ST", 88, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        // ---- Expanded catalog (legends + current stars) ----
        PlayerCard("Lev Yashin", "ليف ياشين", "GK", 92, 10, "🇷🇺", "روسيا", "Russia"),
        PlayerCard("Dino Zoff", "دينو زوف", "GK", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Gordon Banks", "جوردون بانكس", "GK", 89, 9, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Pepe Reina", "بيبي رينا", "GK", 85, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kasper Schmeichel", "كاسبر شمايكل", "GK", 84, 7, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Diogo Costa", "ديوجو كوستا", "GK", 86, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Sepp Maier", "زيب ماير", "GK", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Franz Beckenbauer", "فرانتس بيكنباور", "DF", 94, 11, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Bobby Moore", "بوبي مور", "DF", 90, 9, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Gaetano Scirea", "جايتانو شيريا", "DF", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Fernando Hierro", "فرناندو هييرو", "DF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Laurent Blanc", "لوران بلان", "DF", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Ricardo Carvalho", "ريكاردو كارفاليو", "DF", 86, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Jerome Boateng", "جيروم بواتينج", "DF", 87, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Dayot Upamecano", "دايوت أوباميكانو", "DF", 84, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Pau Cubarsi", "باو كوبارسي", "DF", 85, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Josko Gvardiol", "يوشكو جفارديول", "DF", 86, 7, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Marquinhos", "ماركينيوس", "DF", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Milan Skriniar", "ميلان سكرينيار", "DF", 85, 7, "🇸🇰", "سلوفاكيا", "Slovakia"),
        PlayerCard("Matthijs de Ligt", "ماتياس دي ليخت", "DF", 84, 7, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Joao Cancelo", "جواو كانسيلو", "DF", 86, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Jordi Alba", "جوردي ألبا", "DF", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Alphonso Davies", "ألفونسو ديفيز", "DF", 85, 7, "🇨🇦", "كندا", "Canada"),
        PlayerCard("Federico Dimarco", "فيديريكو ديماركو", "DF", 85, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jules Kounde", "جول كوندي", "DF", 86, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Reece James", "ريس جيمس", "DF", 84, 7, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Gianluca Zambrotta", "جيانلوكا زامبروتا", "DF", 86, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Branislav Ivanovic", "برانيسلاف إيفانوفيتش", "DF", 83, 6, "🇷🇸", "صربيا", "Serbia"),
        PlayerCard("Johan Cruyff", "يوهان كرويف", "MF", 94, 11, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Zico", "زيكو", "MF", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Socrates", "سقراط", "MF", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Baggio", "روبرتو باجيو", "MF", 91, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Ruud Gullit", "رود خوليت", "MF", 90, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Dennis Bergkamp", "دينيس بيركامب", "MF", 90, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Francesco Totti", "فرانشيسكو توتي", "MF", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Alessandro Del Piero", "أليساندرو ديل بييرو", "MF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Paul Pogba", "بول بوجبا", "MF", 87, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Casemiro", "كاسيميرو", "MF", 88, 8, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ilkay Gundogan", "إيلكاي جوندوجان", "MF", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Marco Verratti", "ماركو فيراتي", "MF", 87, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Frenkie de Jong", "فرينكي دي يونج", "MF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Gavi", "جافي", "MF", 84, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Aurelien Tchouameni", "أوريلين تشواميني", "MF", 85, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Eduardo Camavinga", "إدواردو كامافينجا", "MF", 85, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Phil Foden", "فيل فودين", "MF", 88, 8, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Cole Palmer", "كول بالمر", "MF", 88, 8, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Bernardo Silva", "برناردو سيلفا", "MF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("James Rodriguez", "خاميس رودريجيز", "MF", 86, 7, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Thiago Alcantara", "تياجو ألكانتارا", "MF", 87, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Ivan Rakitic", "إيفان راكيتيتش", "MF", 85, 7, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Marek Hamsik", "ماريك همشيك", "MF", 84, 7, "🇸🇰", "سلوفاكيا", "Slovakia"),
        PlayerCard("Sami Khedira", "سامي خضيرة", "MF", 84, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Michael Carrick", "مايكل كاريك", "MF", 83, 6, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Edgar Davids", "إدجار دافيدز", "MF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Javier Mascherano", "خافيير ماسكيرانو", "MF", 87, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Garrincha", "جارينشا", "WG", 92, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jairzinho", "جايرزينيو", "WG", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marc Overmars", "مارك أوفرمارس", "WG", 86, 7, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Kingsley Coman", "كينجسلي كومان", "WG", 85, 7, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Leroy Sane", "ليروي ساني", "WG", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Marcus Rashford", "ماركوس راشفورد", "WG", 84, 7, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Rafael Leao", "رافائيل لياو", "WG", 87, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Jeremy Doku", "جيريمي دوكو", "WG", 83, 6, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Mohammed Kudus", "محمد قدوس", "WG", 84, 7, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("Gabriel Martinelli", "جابرييل مارتينيللي", "WG", 84, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jack Grealish", "جاك جريليش", "WG", 84, 7, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Mahmoud Trezeguet", "محمود تريزيجيه", "WG", 80, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Paulo Futre", "باولو فوتري", "WG", 85, 7, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Rodrygo", "رودريجو", "WG", 86, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Lautaro Martinez", "لاوتارو مارتينيز", "ST", 88, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Victor Osimhen", "فيكتور أوسيمين", "ST", 87, 8, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Jurgen Klinsmann", "يورجن كلينسمان", "ST", 87, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Gary Lineker", "جاري لينيكر", "ST", 88, 8, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Rudi Voller", "رودي فولر", "ST", 86, 7, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Hugo Sanchez", "هوجو سانشيز", "ST", 88, 8, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("Davor Suker", "دافور شوكر", "ST", 86, 7, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Andriy Shevchenko", "أندريه شيفتشينكو", "ST", 90, 9, "🇺🇦", "أوكرانيا", "Ukraine"),
        PlayerCard("Ian Rush", "إيان راش", "ST", 87, 8, "🏴󠁧󠁢󠁷󠁬󠁳󠁿", "ويلز", "Wales"),
        PlayerCard("Kenny Dalglish", "كيني دالجليش", "ST", 89, 9, "🏴󠁧󠁢󠁳󠁣󠁴󠁿", "اسكتلندا", "Scotland"),
        PlayerCard("Eric Cantona", "إريك كانتونا", "ST", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Fernando Torres", "فيرناندو توريس", "ST", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Diego Forlan", "دييجو فورلان", "ST", 86, 7, "🇺🇾", "الأوروغواي", "Uruguay"),
        PlayerCard("Mido", "ميدو", "ST", 80, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Omar Marmoush", "عمر مرموش", "ST", 85, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Darwin Nunez", "داروين نونيز", "ST", 82, 6, "🇺🇾", "الأوروغواي", "Uruguay"),
        PlayerCard("Gabriel Jesus", "جابرييل جيسوس", "ST", 83, 6, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Firmino", "روبرتو فيرمينو", "ST", 84, 7, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Olivier Giroud", "أوليفييه جيرو", "ST", 83, 6, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Ciro Immobile", "تشيرو إيموبيلي", "ST", 85, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jamie Vardy", "جيمي فاردي", "ST", 83, 6, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Mauro Icardi", "ماورو إيكاردي", "ST", 84, 7, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Radamel Falcao", "راداميل فالكاو", "ST", 87, 8, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Luca Toni", "لوكا توني", "ST", 84, 7, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Kepa Arrizabalaga", "كيبا أريثابالاجا", "GK", 80, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Robert Sanchez", "روبرت سانشيز", "GK", 78, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Nick Pope", "نيك بوب", "GK", 79, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Aaron Ramsdale", "آرون رامسديل", "GK", 79, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Bernd Leno", "بيرند لينو", "GK", 80, 5, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Alphonse Areola", "ألفونس أريولا", "GK", 79, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Mat Ryan", "مات رايان", "GK", 76, 5, "🇦🇺", "أستراليا", "Australia"),
        PlayerCard("Ali Maaloul", "علي معلول", "DF", 76, 5, "🇹🇳", "تونس", "Tunisia"),
        PlayerCard("Chris Smalling", "كريس سمولينج", "DF", 80, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Ben Chilwell", "بن تشيلويل", "DF", 80, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Lucas Digne", "لوكاس دين", "DF", 80, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Jan Vertonghen", "يان فيرتونين", "DF", 83, 6, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Toby Alderweireld", "توبي ألدرفايرلد", "DF", 83, 6, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Ezri Konsa", "إيزري كونسا", "DF", 79, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Joel Matip", "جويل ماتيب", "DF", 80, 5, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Nacho Fernandez", "ناتشو فرنانديز", "DF", 81, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Diego Godin", "دييجو جودين", "DF", 85, 7, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Sead Kolasinac", "سياد كولاشيناتش", "DF", 74, 5, "🇧🇦", "البوسنة والهرسك", "Bosnia and Herzegovina"),
        PlayerCard("Ruben Neves", "روبن نيفيز", "MF", 82, 6, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Wilfred Ndidi", "ويلفريد نديدي", "MF", 79, 5, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Jorginho", "جورجينيو", "MF", 82, 6, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Idrissa Gueye", "إدريسا جاي", "MF", 80, 5, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Mikel Arteta", "ميكيل أرتيتا", "MF", 80, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jordan Henderson", "جوردان هندرسون", "MF", 80, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("James Milner", "جيمس ميلنر", "MF", 79, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Jack Wilshere", "جاك ويلشير", "MF", 78, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Mateo Kovacic", "ماتيو كوفاسيتش", "MF", 83, 6, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Leandro Paredes", "لياندرو باريديس", "MF", 80, 5, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Rodrigo De Paul", "رودريجو دي باول", "MF", 83, 6, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Lucas Paqueta", "لوكاس باكيتا", "MF", 82, 6, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Dani Ceballos", "داني ثيبايوس", "MF", 80, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Saul Niguez", "ساؤول نيجيز", "MF", 81, 5, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Koke", "كوكي", "MF", 84, 7, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Thomas Partey", "توماس بارتي", "MF", 82, 6, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("Jarrod Bowen", "جارود بوين", "WG", 82, 6, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Ismaila Sarr", "إسماعيلا سار", "WG", 80, 5, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Allan Saint-Maximin", "ألان سان ماكسيمان", "WG", 78, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Nicolas Pepe", "نيكولا بيبي", "WG", 77, 5, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Said Benrahma", "سعيد بن رحمة", "WG", 77, 5, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Yannick Carrasco", "يانيك كاراسكو", "WG", 82, 6, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Ivan Perisic", "إيفان بيريشيتش", "WG", 83, 6, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Lucas Moura", "لوكاس مورا", "WG", 80, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Mostafa Mohamed", "مصطفى محمد", "ST", 77, 5, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Islam Slimani", "إسلام سليماني", "ST", 77, 5, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Wissam Ben Yedder", "وسام بن يدر", "ST", 80, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andre-Pierre Gignac", "أندريه بيير جينياك", "ST", 78, 5, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Danny Welbeck", "داني ويلبيك", "ST", 77, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Divock Origi", "ديفوك أوريجي", "ST", 76, 5, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Michy Batshuayi", "ميشي باتشواي", "ST", 77, 5, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Javier Hernandez", "خافيير هيرنانديز", "ST", 81, 5, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("Dominic Calvert-Lewin", "دومينيك كالفرت لوين", "ST", 78, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Callum Wilson", "كالوم ويلسون", "ST", 79, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Ivan Toney", "إيفان توني", "ST", 80, 5, "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "إنجلترا", "England"),
        PlayerCard("Richarlison", "ريتشارليسون", "ST", 81, 5, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Wout Weghorst", "فوت فيجهورست", "ST", 78, 5, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Memphis Depay", "ممفيس ديباي", "ST", 82, 6, "🇳🇱", "هولندا", "Netherlands"),
    )

    init {
        require(players.size >= 300)
        require(players.all { it.rating in 1..99 })
        require(players.map { it.nameEn }.distinct().size == players.size)
        require(players.filter { it.nameEn !in setOf("Lionel Messi", "Cristiano Ronaldo") }.none { it.rating == 99 })
        // Auction (50% medium / 30% weak / 20% strong) and Deal cases (2 medium + 1 strong + 1 weak)
        // need every role to have all three tiers available.
        listOf("GK", "DF", "MF", "WG", "ST").forEach { role ->
            PlayerTier.values().forEach { tier ->
                require(players.count { it.position == role && it.tier == tier } >= 6) { "Too few $tier $role players" }
            }
        }
    }
}


/** Canonical squad order shared by all player-picking games. */
object ElbashaPositions {
    val rosterOrder = listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "CAM", "RW", "LW", "ST")

    /** Balanced GK-to-ST formations for every supported squad size. */
    fun formationSlots(size: Int): List<String> {
        val formations = mapOf(
            4 to listOf("GK", "CB", "CM", "ST"),
            5 to listOf("GK", "CB", "CM", "RW", "ST"),
            6 to listOf("GK", "RB", "CB", "CM", "RW", "ST"),
            7 to listOf("GK", "RB", "CB", "CM", "CAM", "RW", "ST"),
            8 to listOf("GK", "RB", "CB", "CB", "CM", "CAM", "RW", "ST"),
            9 to listOf("GK", "RB", "CB", "CB", "LB", "CM", "CAM", "RW", "ST"),
            10 to listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "RW", "LW", "ST"),
            11 to rosterOrder
        )
        return formations[size.coerceIn(4, 11)] ?: rosterOrder
    }

    /** Legacy database roles are broad; map them to the requested tactical slot family. */
    fun poolRole(slot: String): String = when (slot) {
        "GK" -> "GK"
        "RB", "CB", "LB", "DF" -> "DF"
        "CDM", "CM", "CAM", "MF" -> "MF"
        "RW", "LW", "WG" -> "WG"
        "ST" -> "ST"
        else -> ""
    }

    fun supports(player: PlayerCard, slot: String): Boolean =
        poolRole(player.position) == poolRole(slot) && poolRole(slot).isNotEmpty()

    /**
     * Creates a larger auction queue while preserving the formation's GK-to-ST role ratio.
     * Each pass through the formation adds one unique eligible player per slot; this gives
     * Classic a 24-lot queue and Pro Max a 42-lot queue rather than silently truncating it
     * to only 5 or 11 players.
     */
    fun auctionPool(size: Int, total: Int, random: kotlin.random.Random = kotlin.random.Random.Default): List<PlayerCard> {
        val slots = formationSlots(size.coerceIn(4, rosterOrder.size))
        val ordered = mutableListOf<PlayerCard>()
        val target = total.coerceAtLeast(size).coerceAtMost(PlayerDatabase.players.size)
        // Appearance mix of the auction queue: 50% medium, 30% weak, 20% strong.
        val strongLots = Math.round(target * 0.20).toInt()
        val weakLots = Math.round(target * 0.30).toInt()
        val tierQuotas = linkedMapOf(
            PlayerTier.STRONG to strongLots,
            PlayerTier.WEAK to weakLots,
            PlayerTier.MEDIUM to (target - strongLots - weakLots).coerceAtLeast(0)
        )

        // Shuffle each role/tier queue once; players remain unique throughout the draft.
        val queues = PlayerDatabase.players.shuffled(random)
            .groupBy { poolRole(it.position) }
            .mapValues { (_, players) -> players.groupBy { it.tier }.mapValues { (_, list) -> list.toMutableList() } }

        // Allocate the exact global tier mix across position families before picking players.
        // A greedy per-slot fallback could consume a role's last weak player too early,
        // producing a different mix even when the catalog has enough players overall.
        data class FlowEdge(
            val to: Int,
            val reverseIndex: Int,
            var capacity: Int,
            val initialCapacity: Int
        )

        val slotRoles = (0 until target).map { index -> poolRole(slots[index % slots.size]) }
        val roles = slotRoles.distinct()
        val tiers = listOf(PlayerTier.STRONG, PlayerTier.WEAK, PlayerTier.MEDIUM)
        val source = 0
        val roleStart = 1
        val tierStart = roleStart + roles.size
        val sink = tierStart + tiers.size
        val graph = Array(sink + 1) { mutableListOf<FlowEdge>() }

        fun addEdge(from: Int, to: Int, capacity: Int): FlowEdge {
            val forward = FlowEdge(to, graph[to].size, capacity, capacity)
            val reverse = FlowEdge(from, graph[from].size, 0, 0)
            graph[from].add(forward)
            graph[to].add(reverse)
            return forward
        }

        roles.forEachIndexed { index, role ->
            addEdge(source, roleStart + index, slotRoles.count { it == role })
        }
        val roleTierEdges = mutableMapOf<Pair<String, PlayerTier>, FlowEdge>()
        roles.forEachIndexed { roleIndex, role ->
            tiers.forEachIndexed { tierIndex, tier ->
                val available = queues[role]?.get(tier)?.size ?: 0
                roleTierEdges[role to tier] = addEdge(
                    roleStart + roleIndex,
                    tierStart + tierIndex,
                    available
                )
            }
        }
        tiers.forEachIndexed { index, tier ->
            addEdge(tierStart + index, sink, tierQuotas.getValue(tier))
        }

        var allocated = 0
        while (true) {
            val parentNode = IntArray(graph.size) { -1 }
            val parentEdge = IntArray(graph.size) { -1 }
            val pending = java.util.ArrayDeque<Int>()
            parentNode[source] = source
            pending.addLast(source)

            while (pending.isNotEmpty() && parentNode[sink] == -1) {
                val node = pending.removeFirst()
                graph[node].forEachIndexed { edgeIndex, edge ->
                    if (edge.capacity > 0 && parentNode[edge.to] == -1) {
                        parentNode[edge.to] = node
                        parentEdge[edge.to] = edgeIndex
                        pending.addLast(edge.to)
                    }
                }
            }
            if (parentNode[sink] == -1) break

            var amount = Int.MAX_VALUE
            var node = sink
            while (node != source) {
                val previous = parentNode[node]
                amount = minOf(amount, graph[previous][parentEdge[node]].capacity)
                node = previous
            }
            node = sink
            while (node != source) {
                val previous = parentNode[node]
                val edge = graph[previous][parentEdge[node]]
                edge.capacity -= amount
                graph[node][edge.reverseIndex].capacity += amount
                node = previous
            }
            allocated += amount
        }

        val exactTierAllocation = if (allocated == target) {
            roles.associateWith { role ->
                buildList {
                    tiers.forEach { tier ->
                        repeat(roleTierEdges.getValue(role to tier).initialCapacity -
                            roleTierEdges.getValue(role to tier).capacity) {
                            add(tier)
                        }
                    }
                }.shuffled(random).toMutableList()
            }
        } else null

        // If the catalog cannot satisfy the requested mix for a future formation,
        // preserve the old best-effort fallback instead of returning an incomplete queue.
        val fallbackTierPlan = if (exactTierAllocation == null) {
            (List(strongLots) { PlayerTier.STRONG } +
                List(weakLots) { PlayerTier.WEAK } +
                List(tierQuotas.getValue(PlayerTier.MEDIUM)) { PlayerTier.MEDIUM }).shuffled(random)
        } else emptyList()

        for (index in 0 until target) {
            val slot = slots[index % slots.size]
            val role = poolRole(slot)
            val byTier = queues[role] ?: break
            val wantedTier = exactTierAllocation?.getValue(role)?.removeAt(0) ?: fallbackTierPlan[index]
            val bucket = if (exactTierAllocation != null) {
                byTier[wantedTier]?.takeIf { it.isNotEmpty() }
            } else {
                val fallbackOrder = when (wantedTier) {
                    PlayerTier.STRONG -> listOf(PlayerTier.STRONG, PlayerTier.MEDIUM, PlayerTier.WEAK)
                    PlayerTier.WEAK -> listOf(PlayerTier.WEAK, PlayerTier.MEDIUM, PlayerTier.STRONG)
                    PlayerTier.MEDIUM -> listOf(PlayerTier.MEDIUM, PlayerTier.WEAK, PlayerTier.STRONG)
                }
                fallbackOrder.mapNotNull { byTier[it] }.firstOrNull { it.isNotEmpty() }
            } ?: break

            // Inside the selected tier, prefer a player whose real position is this slot.
            val bestIndex = bucket.indices.minByOrNull {
                PlayerNaturalPositions.fitRank(bucket[it], slot) * 10_000 + it
            } ?: break
            val candidate = bucket.removeAt(bestIndex)
            if (supports(candidate, slot)) ordered.add(candidate.copy(position = slot))
        }
        return ordered
    }
}

/**
 * Real (natural) position of every catalog player. The broad `position` field (GK/DF/MF/WG/ST)
 * is only a role family; this map says whether a defender is really a CB, RB or LB, etc., so the
 * games can place each player in the slot he truly plays.
 */
object PlayerNaturalPositions {
    private val natural: Map<String, String> = mapOf(
        "Paolo Maldini" to "LB",
        "Roberto Carlos" to "LB",
        "Marcelo" to "LB",
        "Ashley Cole" to "LB",
        "Theo Hernandez" to "LB",
        "Andrew Robertson" to "LB",
        "Nuno Mendes" to "LB",
        "Bixente Lizarazu" to "LB",
        "Patrice Evra" to "LB",
        "Eric Abidal" to "LB",
        "Achraf Hakimi" to "RB",
        "Trent Alexander-Arnold" to "RB",
        "Dani Alves" to "RB",
        "Cafu" to "RB",
        "Philipp Lahm" to "RB",
        "Javier Zanetti" to "RB",
        "Kyle Walker" to "RB",
        "Carlos Alberto" to "RB",
        "Dani Carvajal" to "RB",
        "Kieran Trippier" to "RB",
        "Sergio Ramos" to "CB",
        "Virgil van Dijk" to "CB",
        "Franco Baresi" to "CB",
        "Alessandro Nesta" to "CB",
        "Fabio Cannavaro" to "CB",
        "Carles Puyol" to "CB",
        "Rio Ferdinand" to "CB",
        "Nemanja Vidic" to "CB",
        "John Terry" to "CB",
        "Gerard Pique" to "CB",
        "Thiago Silva" to "CB",
        "Ruben Dias" to "CB",
        "Antonio Rudiger" to "CB",
        "Raphael Varane" to "CB",
        "William Saliba" to "CB",
        "Alessandro Bastoni" to "CB",
        "Kim Min-jae" to "CB",
        "Ronald Araujo" to "CB",
        "John Stones" to "CB",
        "Giorgio Chiellini" to "CB",
        "Leonardo Bonucci" to "CB",
        "Jaap Stam" to "CB",
        "Gabriel Magalhaes" to "CB",
        "Willian Pacho" to "CB",
        "Lilian Thuram" to "CB",
        "Marcel Desailly" to "CB",
        "Sol Campbell" to "CB",
        "Wael Gomaa" to "CB",
        "Lucio" to "CB",
        "Pepe" to "CB",
        "Vincent Kompany" to "CB",
        "Mats Hummels" to "CB",
        "Giuseppe Bergomi" to "CB",
        "Frank de Boer" to "CB",
        "Claude Makelele" to "CDM",
        "Sergio Busquets" to "CDM",
        "Rodri" to "CDM",
        "N'Golo Kante" to "CDM",
        "Gennaro Gattuso" to "CDM",
        "Patrick Vieira" to "CDM",
        "Roy Keane" to "CDM",
        "Michael Essien" to "CDM",
        "Frank Rijkaard" to "CDM",
        "Declan Rice" to "CDM",
        "Yaya Toure" to "CDM",
        "Xabi Alonso" to "CDM",
        "Andres Iniesta" to "CM",
        "Xavi Hernandez" to "CM",
        "Luka Modric" to "CM",
        "Toni Kroos" to "CM",
        "Andrea Pirlo" to "CM",
        "Steven Gerrard" to "CM",
        "Frank Lampard" to "CM",
        "Paul Scholes" to "CM",
        "Kevin De Bruyne" to "CM",
        "Jude Bellingham" to "CM",
        "Pedri" to "CM",
        "Federico Valverde" to "CM",
        "Clarence Seedorf" to "CM",
        "Lothar Matthaus" to "CM",
        "Cesc Fabregas" to "CM",
        "Bastian Schweinsteiger" to "CM",
        "Bobby Charlton" to "CM",
        "Vitinha" to "CM",
        "Joao Neves" to "CM",
        "Joshua Kimmich" to "CM",
        "Enzo Fernandez" to "CM",
        "Park Ji-sung" to "CM",
        "Michael Ballack" to "CM",
        "Pavel Nedved" to "CM",
        "Juan Sebastian Veron" to "CM",
        "Guti" to "CM",
        "Arturo Vidal" to "CM",
        "Zinedine Zidane" to "CAM",
        "Jamal Musiala" to "CAM",
        "Bruno Fernandes" to "CAM",
        "Kaka" to "CAM",
        "Ronaldinho" to "CAM",
        "Rivaldo" to "CAM",
        "Michel Platini" to "CAM",
        "Mesut Ozil" to "CAM",
        "David Silva" to "CAM",
        "Mohamed Aboutrika" to "CAM",
        "Florian Wirtz" to "CAM",
        "Martin Odegaard" to "CAM",
        "Jay-Jay Okocha" to "CAM",
        "Shinji Kagawa" to "CAM",
        "Juan Roman Riquelme" to "CAM",
        "Michael Laudrup" to "CAM",
        "Gheorghe Hagi" to "CAM",
        "Thomas Muller" to "CAM",
        "Deco" to "CAM",
        "Lionel Messi" to "RW",
        "Mohamed Salah" to "RW",
        "Riyad Mahrez" to "RW",
        "Lamine Yamal" to "RW",
        "Bukayo Saka" to "RW",
        "Arjen Robben" to "RW",
        "Gareth Bale" to "RW",
        "Luis Figo" to "RW",
        "Raphinha" to "RW",
        "Ousmane Dembele" to "RW",
        "Angel Di Maria" to "RW",
        "David Beckham" to "RW",
        "Stanley Matthews" to "RW",
        "Michael Olise" to "RW",
        "Rayan Cherki" to "RW",
        "Nani" to "RW",
        "Pedro Rodriguez" to "RW",
        "Angel Correa" to "RW",
        "Juan Mata" to "RW",
        "Hakim Ziyech" to "RW",
        "Willian" to "RW",
        "Jesus Navas" to "RW",
        "Ricardo Quaresma" to "RW",
        "Dirk Kuyt" to "RW",
        "Cristiano Ronaldo" to "LW",
        "Neymar Jr" to "LW",
        "Kylian Mbappe" to "LW",
        "Vinicius Junior" to "LW",
        "Son Heung-min" to "LW",
        "Franck Ribery" to "LW",
        "Eden Hazard" to "LW",
        "George Best" to "LW",
        "Ryan Giggs" to "LW",
        "Sadio Mane" to "LW",
        "Khvicha Kvaratskhelia" to "LW",
        "Alexis Sanchez" to "LW",
        "Hristo Stoichkov" to "LW",
        "Robert Pires" to "LW",
        "Pierre-Emerick Aubameyang" to "LW",
        "Raheem Sterling" to "LW",
        "Luis Diaz" to "LW",
        "Wilfried Zaha" to "LW",
        "Pele" to "ST",
        "Diego Maradona" to "ST",
        "Ronaldo Nazario" to "ST",
        "Thierry Henry" to "ST",
        "Didier Drogba" to "ST",
        "Samuel Eto'o" to "ST",
        "Robert Lewandowski" to "ST",
        "Karim Benzema" to "ST",
        "Erling Haaland" to "ST",
        "Harry Kane" to "ST",
        "Zlatan Ibrahimovic" to "ST",
        "Wayne Rooney" to "ST",
        "Ruud van Nistelrooy" to "ST",
        "Marco van Basten" to "ST",
        "Gerd Muller" to "ST",
        "Eusebio" to "ST",
        "Ferenc Puskas" to "ST",
        "Romario" to "ST",
        "Gabriel Batistuta" to "ST",
        "Alan Shearer" to "ST",
        "Sergio Aguero" to "ST",
        "Viktor Gyokeres" to "ST",
        "Alexander Isak" to "ST",
        "Hossam Hassan" to "ST",
        "Miroslav Klose" to "ST",
        "Robin van Persie" to "ST",
        "Filippo Inzaghi" to "ST",
        "Edinson Cavani" to "ST",
        "Hernan Crespo" to "ST",
        "Michael Owen" to "ST",
        "David Villa" to "ST",
        "George Weah" to "ST",
        "Carlos Tevez" to "ST",
        "Edin Dzeko" to "ST",
        "Christian Vieri" to "ST",
        "Robbie Fowler" to "ST",
        "Ian Wright" to "ST",
        "Mario Gomez" to "ST",
        "Gonzalo Higuain" to "ST",
        "Luis Suarez" to "ST",
        "Antoine Griezmann" to "ST",
        "Mohamed Zidan" to "ST",
        "Lev Yashin" to "GK",
        "Dino Zoff" to "GK",
        "Gordon Banks" to "GK",
        "Pepe Reina" to "GK",
        "Kasper Schmeichel" to "GK",
        "Diogo Costa" to "GK",
        "Sepp Maier" to "GK",
        "Franz Beckenbauer" to "CB",
        "Bobby Moore" to "CB",
        "Gaetano Scirea" to "CB",
        "Fernando Hierro" to "CB",
        "Laurent Blanc" to "CB",
        "Ricardo Carvalho" to "CB",
        "Jerome Boateng" to "CB",
        "Dayot Upamecano" to "CB",
        "Pau Cubarsi" to "CB",
        "Josko Gvardiol" to "CB",
        "Marquinhos" to "CB",
        "Milan Skriniar" to "CB",
        "Matthijs de Ligt" to "CB",
        "Joao Cancelo" to "RB",
        "Jordi Alba" to "LB",
        "Alphonso Davies" to "LB",
        "Federico Dimarco" to "LB",
        "Jules Kounde" to "RB",
        "Reece James" to "RB",
        "Gianluca Zambrotta" to "RB",
        "Branislav Ivanovic" to "RB",
        "Johan Cruyff" to "CAM",
        "Zico" to "CAM",
        "Socrates" to "CM",
        "Roberto Baggio" to "CAM",
        "Ruud Gullit" to "CM",
        "Dennis Bergkamp" to "CAM",
        "Francesco Totti" to "CAM",
        "Alessandro Del Piero" to "CAM",
        "Paul Pogba" to "CM",
        "Casemiro" to "CDM",
        "Ilkay Gundogan" to "CM",
        "Marco Verratti" to "CM",
        "Frenkie de Jong" to "CM",
        "Gavi" to "CM",
        "Aurelien Tchouameni" to "CDM",
        "Eduardo Camavinga" to "CM",
        "Phil Foden" to "CAM",
        "Cole Palmer" to "CAM",
        "Bernardo Silva" to "CAM",
        "James Rodriguez" to "CAM",
        "Thiago Alcantara" to "CM",
        "Ivan Rakitic" to "CM",
        "Marek Hamsik" to "CM",
        "Sami Khedira" to "CDM",
        "Michael Carrick" to "CDM",
        "Edgar Davids" to "CDM",
        "Javier Mascherano" to "CDM",
        "Garrincha" to "RW",
        "Jairzinho" to "RW",
        "Marc Overmars" to "LW",
        "Kingsley Coman" to "LW",
        "Leroy Sane" to "LW",
        "Marcus Rashford" to "LW",
        "Rafael Leao" to "LW",
        "Jeremy Doku" to "LW",
        "Mohammed Kudus" to "RW",
        "Gabriel Martinelli" to "LW",
        "Jack Grealish" to "LW",
        "Mahmoud Trezeguet" to "LW",
        "Paulo Futre" to "RW",
        "Rodrygo" to "RW",
        "Lautaro Martinez" to "ST",
        "Victor Osimhen" to "ST",
        "Jurgen Klinsmann" to "ST",
        "Gary Lineker" to "ST",
        "Rudi Voller" to "ST",
        "Hugo Sanchez" to "ST",
        "Davor Suker" to "ST",
        "Andriy Shevchenko" to "ST",
        "Ian Rush" to "ST",
        "Kenny Dalglish" to "ST",
        "Eric Cantona" to "ST",
        "Fernando Torres" to "ST",
        "Diego Forlan" to "ST",
        "Mido" to "ST",
        "Omar Marmoush" to "ST",
        "Darwin Nunez" to "ST",
        "Gabriel Jesus" to "ST",
        "Roberto Firmino" to "ST",
        "Olivier Giroud" to "ST",
        "Ciro Immobile" to "ST",
        "Jamie Vardy" to "ST",
        "Mauro Icardi" to "ST",
        "Radamel Falcao" to "ST",
        "Luca Toni" to "ST",
        "Manuel Neuer" to "GK",
        "Iker Casillas" to "GK",
        "Gianluigi Buffon" to "GK",
        "Petr Cech" to "GK",
        "Thibaut Courtois" to "GK",
        "Alisson Becker" to "GK",
        "Ederson" to "GK",
        "Jan Oblak" to "GK",
        "Marc-Andre ter Stegen" to "GK",
        "Emiliano Martinez" to "GK",
        "David de Gea" to "GK",
        "Keylor Navas" to "GK",
        "Hugo Lloris" to "GK",
        "Oliver Kahn" to "GK",
        "Peter Schmeichel" to "GK",
        "Dida" to "GK",
        "Jose Luis Chilavert" to "GK",
        "Rene Higuita" to "GK",
        "David Raya" to "GK",
        "Essam El Hadary" to "GK",
        "Yassine Bounou" to "GK",
        "Mike Maignan" to "GK",
        "Gianluigi Donnarumma" to "GK",
        "Unai Simon" to "GK",
        "Jordan Pickford" to "GK",
        "Andre Onana" to "GK",
        "Samir Handanovic" to "GK",
        "Edwin van der Sar" to "GK",
        "Claudio Bravo" to "GK",
        "Walter Zenga" to "GK",
        "Jorge Campos" to "GK",
        "David Seaman" to "GK",
        "Victor Valdes" to "GK",
        "Shaka Hislop" to "GK",
        "Jens Lehmann" to "GK",
        "Fabien Barthez" to "GK",
        "Tim Howard" to "GK",
        "Brad Friedel" to "GK",
        "Claudio Taffarel" to "GK",
        "Mark Schwarzer" to "GK",
        "Kepa Arrizabalaga" to "GK",
        "Robert Sanchez" to "GK",
        "Nick Pope" to "GK",
        "Aaron Ramsdale" to "GK",
        "Bernd Leno" to "GK",
        "Alphonse Areola" to "GK",
        "Mat Ryan" to "GK",
        "Ali Maaloul" to "LB",
        "Chris Smalling" to "CB",
        "Ben Chilwell" to "LB",
        "Lucas Digne" to "LB",
        "Jan Vertonghen" to "CB",
        "Toby Alderweireld" to "CB",
        "Ezri Konsa" to "CB",
        "Joel Matip" to "CB",
        "Nacho Fernandez" to "CB",
        "Diego Godin" to "CB",
        "Sead Kolasinac" to "LB",
        "Ruben Neves" to "CDM",
        "Wilfred Ndidi" to "CDM",
        "Jorginho" to "CM",
        "Idrissa Gueye" to "CDM",
        "Mikel Arteta" to "CM",
        "Jordan Henderson" to "CM",
        "James Milner" to "CM",
        "Jack Wilshere" to "CM",
        "Mateo Kovacic" to "CM",
        "Leandro Paredes" to "CDM",
        "Rodrigo De Paul" to "CM",
        "Lucas Paqueta" to "CAM",
        "Dani Ceballos" to "CM",
        "Saul Niguez" to "CM",
        "Koke" to "CM",
        "Thomas Partey" to "CDM",
        "Jarrod Bowen" to "RW",
        "Ismaila Sarr" to "RW",
        "Allan Saint-Maximin" to "LW",
        "Nicolas Pepe" to "RW",
        "Said Benrahma" to "LW",
        "Yannick Carrasco" to "LW",
        "Ivan Perisic" to "LW",
        "Lucas Moura" to "RW",
        "Mostafa Mohamed" to "ST",
        "Islam Slimani" to "ST",
        "Wissam Ben Yedder" to "ST",
        "Andre-Pierre Gignac" to "ST",
        "Danny Welbeck" to "ST",
        "Divock Origi" to "ST",
        "Michy Batshuayi" to "ST",
        "Javier Hernandez" to "ST",
        "Dominic Calvert-Lewin" to "ST",
        "Callum Wilson" to "ST",
        "Ivan Toney" to "ST",
        "Richarlison" to "ST",
        "Wout Weghorst" to "ST",
        "Memphis Depay" to "ST"
    )

    fun of(player: PlayerCard): String? = natural[player.nameEn]

    /** 0 = exactly his position, 1 = a close sibling position, 2 = same role family only. */
    fun fitRank(player: PlayerCard, slot: String): Int {
        val own = natural[player.nameEn] ?: return 2
        if (own == slot) return 0
        val siblings = mapOf(
            "RB" to setOf("LB", "CB"), "LB" to setOf("RB", "CB"), "CB" to setOf("RB", "LB"),
            "CDM" to setOf("CM"), "CM" to setOf("CDM", "CAM"), "CAM" to setOf("CM"),
            "RW" to setOf("LW"), "LW" to setOf("RW")
        )
        return if (siblings[slot]?.contains(own) == true) 1 else 2
    }

    /** A random candidate among those who fit [slot] best (exact position first). */
    fun randomBest(players: List<PlayerCard>, slot: String): PlayerCard? {
        val best = players.minOfOrNull { fitRank(it, slot) } ?: return null
        return players.filter { fitRank(it, slot) == best }.randomOrNull()
    }

    /** Best-fitting candidates first (ties keep their incoming order). */
    fun bestFirst(players: List<PlayerCard>, slot: String): List<PlayerCard> =
        players.sortedBy { fitRank(it, slot) }
}
