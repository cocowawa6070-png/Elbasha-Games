package com.mostafabek.elbashagames

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            auth = FirebaseAuth.getInstance()
            setContent {
                ElbashaApp(
                    auth = auth,
                    databaseUrl = getString(R.string.firebase_database_url),
                    onGoogleSignIn = { callback -> startGoogleSignIn(callback) }
                )
            }
        } catch (error: Exception) {
            setContent {
                SetupRequiredScreen(
                    message = "إعداد Firebase غير مكتمل. استبدل app/google-services.json بملف مشروعك ثم أعد البناء.\n\n${error.localizedMessage ?: "خطأ في التهيئة"}"
                )
            }
        }
    }

    private fun startGoogleSignIn(onResult: (String?) -> Unit) {
        lifecycleScope.launch {
            try {
                val googleOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(getString(R.string.google_web_client_id))
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleOption)
                    .build()

                val result = CredentialManager.create(this@MainActivity)
                    .getCredential(this@MainActivity, request)

                val credential = result.credential
                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val googleToken = GoogleIdTokenCredential.createFrom(credential.data)
                    val firebaseCredential = GoogleAuthProvider.getCredential(googleToken.idToken, null)
                    auth.signInWithCredential(firebaseCredential)
                        .addOnCompleteListener { task ->
                            onResult(if (task.isSuccessful) null else task.exception?.localizedMessage ?: "فشل تسجيل الدخول بحساب Google")
                        }
                } else {
                    onResult("نوع بيانات تسجيل Google غير متوقع")
                }
            } catch (error: GoogleIdTokenParsingException) {
                onResult("تعذر قراءة حساب Google: ${error.localizedMessage}")
            } catch (error: Exception) {
                onResult(error.localizedMessage ?: "تم إلغاء تسجيل الدخول أو تعذر إكماله")
            }
        }
    }
}
