package com.mostafabek.elbashagames

import kotlin.random.Random

/**
 * Pure rules for same-device Build a Team (2-4 humans on one phone). Kept free of Compose
 * so they can be unit tested. Position labels come from [BuildTeamRules].
 */
object PassAndPlayRules {
    const val MIN_PLAYERS = 2
    const val MAX_PLAYERS = 4

    /**
     * Who picks first rotates every position, so nobody always gets the first choice
     * (later pickers cannot take a player an earlier picker already took).
     */
    fun pickingOrder(playerCount: Int, slotIndex: Int): List<Int> =
        List(playerCount) { (slotIndex + it) % playerCount }

    /** In friend-pick mode, each turn drafts for the next seat; otherwise for the active seat. */
    fun recipientIndex(currentPlayerIndex: Int, playerCount: Int, friendPicksMode: Boolean): Int {
        require(playerCount in MIN_PLAYERS..MAX_PLAYERS)
        val current = currentPlayerIndex.mod(playerCount)
        return if (friendPicksMode) (current + 1) % playerCount else current
    }

    /** Trims names, fills blanks with a default and makes duplicates unique (case-insensitive). */
    fun normalizeNames(raw: List<String>, count: Int, defaultName: (Int) -> String): List<String> {
        val result = mutableListOf<String>()
        for (i in 0 until count) {
            val base = raw.getOrNull(i)?.trim().orEmpty().ifBlank { defaultName(i + 1) }
            var candidate = base
            var suffix = 2
            while (result.any { it.equals(candidate, ignoreCase = true) }) {
                candidate = "$base $suffix"
                suffix++
            }
            result.add(candidate)
        }
        return result
    }

    /**
     * Challenge for one position. Prefers a nationality that still has at least [playerCount]
     * available players so everyone can pick a different one. If no nationality is large enough
     * the challenge accepts any nationality for that position. Returns null only when the
     * position pool itself cannot give every player a different footballer.
     */
    fun createChallenge(
        players: List<PlayerCard>,
        positionCode: String,
        excludedNames: Set<String>,
        playerCount: Int,
        random: Random = Random.Default
    ): NationalityChallenge? {
        val labels = BuildTeamRules.positionLabels[positionCode] ?: return null
        val pool = players.filter { ElbashaPositions.supports(it, positionCode) && it.nameEn !in excludedNames }
        if (pool.size < playerCount) return null
        val groups = pool
            .filter { it.nationalityEn.isNotBlank() && it.nationalityAr.isNotBlank() }
            .groupBy { it.nationalityEn }
            .filterValues { it.size >= playerCount }
        val chosen = groups.entries.randomOrNull(random)
        return if (chosen != null) {
            NationalityChallenge(chosen.value.first().nationalityAr, chosen.key, positionCode, labels.first, labels.second)
        } else {
            NationalityChallenge("", "", positionCode, labels.first, labels.second)
        }
    }

    /** A blank nationality in the challenge means any nationality is allowed. */
    fun eligiblePlayers(
        players: List<PlayerCard>,
        challenge: NationalityChallenge,
        excludedNames: Set<String>
    ): List<PlayerCard> = players.filter {
        ElbashaPositions.supports(it, challenge.positionCode) &&
            it.nameEn !in excludedNames &&
            (challenge.nationalityEn.isBlank() || it.nationalityEn == challenge.nationalityEn)
    }

    /** Index of the single highest rating at this position, or null on a tie / no picks. */
    fun slotWinner(ratings: List<Int>): Int? {
        val best = ratings.maxOrNull() ?: return null
        if (best <= 0) return null
        return ratings.indices.filter { ratings[it] == best }.singleOrNull()
    }

    /** One point per position to the player whose pick has the strictly highest rating. */
    fun tally(teams: List<List<PlayerCard>>, slotCount: Int): List<Int> {
        val points = MutableList(teams.size) { 0 }
        for (slot in 0 until slotCount) {
            val winner = slotWinner(teams.map { it.getOrNull(slot)?.rating ?: 0 })
            if (winner != null) points[winner] = points[winner] + 1
        }
        return points
    }

    /** Players ordered by points, then by total squad rating, then by seat order. */
    fun ranking(points: List<Int>, totals: List<Int>): List<Int> =
        points.indices.sortedWith(
            compareByDescending<Int> { points[it] }.thenByDescending { totals[it] }.thenBy { it }
        )

    /** Everyone level with the leader on both points and total rating (a real draw). */
    fun winners(points: List<Int>, totals: List<Int>): List<Int> {
        val order = ranking(points, totals)
        val top = order.firstOrNull() ?: return emptyList()
        return order.filter { points[it] == points[top] && totals[it] == totals[top] }
    }
}
