package com.mostafabek.elbashagames

import kotlin.random.Random

data class CoachCard(
    val nameAr: String,
    val nameEn: String,
    val rating: Int,
    val styleAr: String,
    val styleEn: String
) {
    /** MatchEngine's coach bonus is capped at eight strength points. */
    val matchBonus: Double get() = ((rating - 70).coerceAtLeast(0) / 3.0).coerceIn(0.0, 8.0)
}

object CoachDatabase {
    val all: List<CoachCard> = listOf(
        CoachCard("بيب جوارديولا", "Pep Guardiola", 96, "استحواذ وبناء لعب", "Possession and build-up"),
        CoachCard("كارلو أنشيلوتي", "Carlo Ancelotti", 94, "مرونة وإدارة مباريات", "Adaptability and game management"),
        CoachCard("جوزيه مورينيو", "Jose Mourinho", 93, "تنظيم دفاعي وتحولات", "Defensive shape and transitions"),
        CoachCard("يورجن كلوب", "Jurgen Klopp", 92, "ضغط عالٍ وسرعة", "High press and pace"),
        CoachCard("زين الدين زيدان", "Zinedine Zidane", 91, "توازن وهدوء", "Balance and composure"),
        CoachCard("أليكس فيرجسون", "Alex Ferguson", 95, "شخصية وعودة في النتيجة", "Leadership and comebacks"),
        CoachCard("دييجو سيميوني", "Diego Simeone", 91, "صلابة دفاعية", "Defensive resilience"),
        CoachCard("أرسين فينجر", "Arsene Wenger", 90, "تطوير ومهارة", "Development and technique"),
        CoachCard("هانسي فليك", "Hansi Flick", 90, "ضغط وسرعة انتقال", "Pressing and fast transitions"),
        CoachCard("أوتو ريهاجل", "Otto Rehhagel", 86, "انضباط تكتيكي", "Tactical discipline")
    )

    fun randomCoach(excludedNames: Set<String> = emptySet(), random: Random = Random.Default): CoachCard? =
        all.filterNot { it.nameEn in excludedNames }.randomOrNull(random)
}

object CoachAuctionRules {
    fun openingPrice(coach: CoachCard): Int = (coach.rating / 12).coerceAtLeast(5)

    fun aiCeiling(coach: CoachCard, opening: Int, budget: Int, difficulty: Int, random: Random = Random.Default): Int {
        if (budget < opening) return 0
        val level = difficulty.coerceIn(0, 3)
        val multiplier = when (level) { 0 -> 1; 1 -> 2; 2 -> 3; else -> 4 }
        val ceiling = opening + (coach.rating - 70).coerceAtLeast(0) / (10 - level * 2) + random.nextInt(0, multiplier + 1)
        return minOf(budget, ceiling)
    }

    fun nextAiBid(currentBid: Int, ceiling: Int, budget: Int, random: Random = Random.Default): Int? =
        listOf(1, 5, 10).filter { currentBid + it <= ceiling && currentBid + it <= budget }
            .randomOrNull(random)?.let { currentBid + it }

    fun canPay(amount: Int, budget: Int): Boolean = amount > 0 && amount <= budget
}
