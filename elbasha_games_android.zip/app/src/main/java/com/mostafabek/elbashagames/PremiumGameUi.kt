package com.mostafabek.elbashagames
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HowToPlayCard(
    title: String,
    steps: List<String>,
    note: String? = null
) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize().border(1.dp, palette.gold.copy(alpha = 0.38f), RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📜", fontSize = 20.sp)
                Text(title, color = palette.gold, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 8.dp))
            }
            steps.forEachIndexed { index, step ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier.size(25.dp).clip(RoundedCornerShape(9.dp))
                            .background(palette.gold.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${index + 1}", color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                    Text(step, color = palette.cream, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
                }
            }
            if (!note.isNullOrBlank()) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(palette.panelAlt).padding(11.dp)) {
                    Text(note, color = palette.muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
fun PremiumPlayerCard(
    player: PlayerCard,
    detail: String,
    eyebrow: String = "ELBASHA PLAYER"
) {
    val palette = LocalElbashaPalette.current
    val english = LocalAppUiSettings.current.english
    AnimatedVisibility(
        visible = true,
        enter = fadeIn(tween(320)) + slideInVertically(initialOffsetY = { it / 10 }, animationSpec = tween(320))
    ) {
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize().border(1.dp, palette.gold.copy(alpha = 0.58f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(palette.panelAlt, palette.panel, palette.deepWine))
            ).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PlayerPortrait(player = player, modifier = Modifier.size(width = 74.dp, height = 88.dp), cornerRadius = 15)
            Column(
                Modifier.size(width = 58.dp, height = 66.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.verticalGradient(listOf(palette.gold, Color(0xFF9C6421))))
                    .padding(5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("${player.rating}", color = palette.deepWine, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = palette.deepWine, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(eyebrow, color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text(
                    if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr),
                    color = palette.cream, fontSize = 17.sp, fontWeight = FontWeight.Black
                )
                Text(
                    "${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.position}",
                    color = palette.muted, fontSize = 11.sp
                )
                Text(detail, color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text("♛", color = palette.gold, fontSize = 19.sp)
        }
    }
    }
}

@Composable
fun PremiumAbilityCard(
    symbol: String,
    title: String,
    description: String,
    status: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().animateContentSize().border(
            1.dp,
            if (enabled) palette.gold.copy(alpha = 0.65f) else palette.muted.copy(alpha = 0.25f),
            RoundedCornerShape(17.dp)
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) palette.panelAlt else palette.surface,
            disabledContainerColor = palette.surface
        ),
        shape = RoundedCornerShape(17.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp))
                    .background(if (enabled) palette.gold.copy(alpha = 0.19f) else palette.muted.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) { Text(symbol, fontSize = 23.sp) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = if (enabled) palette.cream else palette.muted, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Text(description, color = palette.muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text(status, color = if (enabled) palette.gold else palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
        }
    }
}

@Composable
fun MysteryBoxCard(
    index: Int,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().border(1.5.dp, palette.gold.copy(alpha = 0.72f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF25324D), palette.panel, palette.deepWine))).padding(vertical = 18.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Box(
                Modifier.size(width = 78.dp, height = 66.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFFFFE7A1), palette.gold, Color(0xFF8C571A))))
                    .border(2.dp, palette.cream.copy(alpha = 0.8f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(0.dp)) {
                    Box(Modifier.size(width = 27.dp, height = 10.dp).border(2.dp, palette.deepWine, RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)))
                    Text("▣", color = palette.deepWine, fontSize = 34.sp, fontWeight = FontWeight.Black)
                }
            }
            Text("${label.uppercase()}  $index", color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
            Text("✦  ?  ✦", color = palette.cream, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(if (LocalAppUiSettings.current.english) "TAP TO OPEN" else "اضغط لفتح الصندوق", color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PremiumPlayerChoiceCard(
    player: PlayerCard,
    english: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.35f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            PlayerPortrait(player = player, modifier = Modifier.size(width = 54.dp, height = 62.dp), cornerRadius = 12)
            Column(
                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(palette.gold.copy(alpha = 0.16f)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("${player.rating}", color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = palette.muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.position}", color = palette.muted, fontSize = 10.sp)
            }
            Text(if (english) "PICK  ›" else "اختار  ›", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 10.sp)
        }
    }
}


/** Visual squad board shared by Auction, Deal or No Deal, and Build Team. */
@Composable
fun SquadFormationPitch(
    title: String,
    players: List<PlayerCard>,
    slotCount: Int,
    detailFor: (PlayerCard) -> String = { "${it.rating} OVR" }
) {
    val palette = LocalElbashaPalette.current
    val english = LocalAppUiSettings.current.english
    val slots = ElbashaPositions.formationSlots(slotCount.coerceIn(4, 11))
    val playersByRole = players.groupBy { ElbashaPositions.poolRole(it.position) }
    // The reference pitch uses four balanced lines: attackers (wingers + striker),
    // midfield, defence, then goalkeeper. Keep the GK portrait the same size as every card.
    val frontOrder = mapOf("LW" to 0, "ST" to 1, "RW" to 2)
    val midfieldOrder = mapOf("CDM" to 0, "CM" to 1, "CAM" to 2)
    val defenceOrder = mapOf("LB" to 0, "CB" to 1, "RB" to 2)
    val rowRoles = listOf(setOf("ST", "WG"), setOf("MF"), setOf("DF"), setOf("GK"))
    val rows = rowRoles.mapNotNull { roles ->
        val indexedSlots = slots.withIndex()
            .filter { ElbashaPositions.poolRole(it.value) in roles }
            .sortedBy { (_, slot) ->
                when (ElbashaPositions.poolRole(slot)) {
                    "WG", "ST" -> frontOrder[slot] ?: 9
                    "MF" -> midfieldOrder[slot] ?: 9
                    "DF" -> defenceOrder[slot] ?: 9
                    else -> 0
                }
            }
        if (indexedSlots.isEmpty()) null else indexedSlots.map { (slotIndex, slot) ->
            val role = ElbashaPositions.poolRole(slot)
            val roleIndex = slots.take(slotIndex).count { ElbashaPositions.poolRole(it) == role }
            slot to playersByRole[role]?.getOrNull(roleIndex)
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.48f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("${players.size}/${slotCount.coerceIn(4, 11)}", color = palette.cream, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier.fillMaxWidth().height((rows.size * 78 + 20).dp).clip(RoundedCornerShape(17.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF075437), Color(0xFF063B2D), Color(0xFF075437))))
                    .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(17.dp))
            ) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.22f)).align(Alignment.Center))
                Box(Modifier.size(68.dp).border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape).align(Alignment.Center))
                Box(Modifier.fillMaxWidth(0.42f).height(24.dp).border(1.dp, Color.White.copy(alpha = 0.20f)).align(Alignment.TopCenter))
                Box(Modifier.fillMaxWidth(0.42f).height(24.dp).border(1.dp, Color.White.copy(alpha = 0.20f)).align(Alignment.BottomCenter))
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    rows.forEach { line ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            line.forEach { (slot, player) ->
                                Column(Modifier.width(76.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    if (player != null) {
                                        AnimatedVisibility(
                                            visible = true,
                                            enter = fadeIn(tween(300)) + scaleIn(initialScale = 0.78f, animationSpec = tween(300))
                                        ) {
                                            PlayerPortrait(player, Modifier.width(48.dp).height(56.dp), cornerRadius = 8)
                                        }
                                        Text(
                                            if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr),
                                            color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                                        )
                                        Text(detailFor(player), color = palette.gold, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                                    } else {
                                        Box(
                                            Modifier.size(46.dp).border(1.dp, Color.White.copy(alpha = 0.48f), CircleShape)
                                                .background(Color.Black.copy(alpha = 0.12f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(slot, color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp, fontWeight = FontWeight.Black)
                                        }
                                        Text(if (english) "Open slot" else "مركز فارغ", color = Color.White.copy(alpha = 0.65f), fontSize = 8.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


/** Compact position chips matching the bottom slot tracker in the supplied Build Team video. */
@Composable
fun PositionStepStrip(slots: List<String>, activeIndex: Int) {
    val palette = LocalElbashaPalette.current
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        slots.forEachIndexed { index, slot ->
            val complete = index < activeIndex
            val active = index == activeIndex
            Box(
                Modifier.size(width = 37.dp, height = 32.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(when { active -> palette.gold; complete -> palette.good.copy(alpha = 0.28f); else -> palette.panelAlt })
                    .border(1.dp, if (active) palette.gold else palette.muted.copy(alpha = 0.25f), RoundedCornerShape(9.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(slot, color = if (active) palette.deepWine else palette.cream, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

/** Compact bottom roster used by the Deal game, matching the reference's position strip. */
@Composable
fun SquadProgressStrip(
    title: String,
    players: List<PlayerCard>,
    slotCount: Int,
    detailFor: (PlayerCard) -> String = { "${it.rating}" }
) {
    val palette = LocalElbashaPalette.current
    val english = LocalAppUiSettings.current.english
    val slots = ElbashaPositions.formationSlots(slotCount.coerceIn(4, 11))
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.36f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("${players.size}/${slots.size}", color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                slots.forEachIndexed { index, slot ->
                    val player = players.getOrNull(index)
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (player == null) palette.panelAlt else palette.deepWine)
                            .padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        if (player != null) {
                            PlayerPortrait(player, Modifier.size(width = 30.dp, height = 35.dp), cornerRadius = 6)
                            Text(detailFor(player), color = palette.gold, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                        } else {
                            Box(Modifier.size(35.dp).border(1.dp, palette.gold.copy(alpha = 0.35f), CircleShape), contentAlignment = Alignment.Center) {
                                Text(slot, color = palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            }
                            Text(if (english) "OPEN" else "فارغ", color = palette.muted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HiddenCoachAuctionCard(english: Boolean, openingPrice: Int) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().border(1.5.dp, palette.gold.copy(alpha = 0.82f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(palette.panelAlt, palette.deepWine))).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("♛", color = palette.gold, fontSize = 54.sp, fontWeight = FontWeight.Black)
            Text(if (english) "MYSTERY COACH" else "المدرب الخفي", color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
            Text("? ? ?", color = palette.cream, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(if (english) "Identity and rating are hidden until the auction ends." else "اسم المدرب وتقييمه هيتكشفوا بعد انتهاء المزايدة.", color = palette.muted, fontSize = 11.sp, textAlign = TextAlign.Center)
            Text(if (english) "Opening bid: $openingPrice M" else "سعر البداية: $openingPrice مليون", color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun CoachAuctionCard(coach: CoachCard, english: Boolean, openingPrice: Int) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().border(1.5.dp, palette.gold.copy(alpha = 0.7f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("♛", color = palette.gold, fontSize = 48.sp)
            Text(if (english) "COACH ON THE BLOCK" else "المدرب المعروض للمزايدة", color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text(if (english) coach.nameEn else coach.nameAr, color = palette.cream, fontSize = 24.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text("${coach.rating} OVR", color = palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(if (english) coach.styleEn else coach.styleAr, color = palette.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            Text(
                if (english) "Opening bid: $openingPrice M" else "سعر البداية: $openingPrice مليون",
                color = palette.cream, fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}


/** Four-player pick grid from the supplied Deal gameplay reference. Inactive cards dim out. */
@Composable
fun DealPlayerPickCard(
    index: Int,
    player: PlayerCard,
    label: String,
    english: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .border(
                if (enabled) 2.dp else 1.dp,
                if (enabled) palette.gold else palette.muted.copy(alpha = 0.22f),
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) palette.panelAlt else palette.surface,
            disabledContainerColor = palette.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            PlayerPortrait(player, Modifier.fillMaxWidth().height(96.dp), cornerRadius = 11)
            Text(
                if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr),
                color = if (enabled) palette.cream else palette.muted,
                fontSize = 10.sp, fontWeight = FontWeight.Black,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            Text("${player.rating} OVR", color = if (enabled) palette.gold else palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Black)
            if (label.isNotBlank()) {
                Text(label, color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            } else {
                Text(if (english) "BOX $index" else "الصندوق $index", color = palette.muted, fontSize = 9.sp)
            }
        }
    }
}
