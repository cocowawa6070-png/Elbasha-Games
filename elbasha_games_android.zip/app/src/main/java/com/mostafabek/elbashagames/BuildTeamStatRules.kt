package com.mostafabek.elbashagames

import kotlin.random.Random

enum class BuildTeamPositionFilter(val labelAr: String, val labelEn: String) {
    ANY("كل المراكز", "Any position"),
    GK("حراس مرمى", "Goalkeepers"),
    DF("مدافعون", "Defenders"),
    MF("لاعبو وسط", "Midfielders"),
    WG("أجنحة", "Wingers"),
    ST("مهاجمون", "Strikers")
}

enum class BuildTeamLeagueFilter(val labelAr: String, val labelEn: String, val leagueCode: String?) {
    ANY("كل الدوريات المتاحة", "Any available league", null),
    LALIGA("الدوري الإسباني الحالي", "Current LaLiga", "LaLiga")
}

enum class BuildTeamMetric(
    val labelAr: String,
    val labelEn: String,
    val unitAr: String,
    val unitEn: String
) {
    HEIGHT("الطول", "Height", "سم", "cm"),
    WEIGHT("الوزن", "Weight", "كجم", "kg"),
    GOALS("الأهداف", "Goals", "هدف", "goals"),
    YELLOW_CARDS("الكروت الصفراء", "Yellow cards", "كارت", "cards"),
    PACE("السرعة - تقييم ELBASHA", "Pace - ELBASHA rating", "/100", "/100"),
    PLAYER_RATING("تقييم اللاعب", "Player rating", "/100", "/100"),
    AUCTION_PRICE("سعر اللاعب في المزاد", "Auction price", "مليون", "M")
}

enum class BuildTeamDirection(val labelAr: String, val labelEn: String) {
    HIGH("الأعلى يكسب", "Highest wins"),
    LOW("الأقل يكسب", "Lowest wins")
}

data class BuildTeamFilter(
    val position: BuildTeamPositionFilter = BuildTeamPositionFilter.ANY,
    val league: BuildTeamLeagueFilter = BuildTeamLeagueFilter.ANY
)

data class BuildTeamPick(val player: PlayerCard, val value: Int)

enum class BuildTeamRosterFilter(val labelAr: String, val labelEn: String) {
    ALL("كل اللاعبين", "All players"),
    CURRENT("لاعبون حاليون", "Current players"),
    RETIRED("لاعبون معتزلون", "Retired players"),
    RANDOM("عشوائي، والـAI يغيّر الفلتر كل جولة", "Random, AI changes the filter every round")
}

data class BuildTeamRoundChallenge(
    val slot: String,
    val rosterFilter: BuildTeamRosterFilter,
    val filterKey: String,
    val filterLabelAr: String,
    val filterLabelEn: String,
    val metric: BuildTeamMetric,
    val direction: BuildTeamDirection
)

data class BuildTeamRoundPick(
    val player: PlayerCard,
    val value: Int,
    val slot: String,
    val metric: BuildTeamMetric,
    val direction: BuildTeamDirection,
    val filterLabelAr: String,
    val filterLabelEn: String
)

object BuildTeamStatRules {
    private data class DynamicPlayerFilter(
        val key: String,
        val labelAr: String,
        val labelEn: String,
        val matches: (PlayerCard) -> Boolean
    )

    // These are intentionally curated player-name sets, not guesses based on nationality.
    // Unlisted players remain available in the unrestricted pool but are not labelled CURRENT/RETIRED.
    private val currentNames = setOf(
        "Thibaut Courtois", "Alisson Becker", "Ederson", "Jan Oblak", "Marc-Andre ter Stegen",
        "Emiliano Martinez", "David de Gea", "Yassine Bounou", "Mike Maignan", "Gianluigi Donnarumma",
        "Unai Simon", "Jordan Pickford", "Andre Onana", "David Raya", "Wojciech Szczesny", "Andrii Lunin",
        "Ruben Dias", "Virgil van Dijk", "Antonio Rudiger", "Achraf Hakimi", "Trent Alexander-Arnold",
        "William Saliba", "Alessandro Bastoni", "Kim Min-jae", "Ronald Araujo",
        "John Stones", "Kyle Walker", "Kieran Trippier", "Dani Carvajal", "Theo Hernandez", "Andrew Robertson", "Nuno Mendes",
        "Gabriel Magalhaes", "Willian Pacho", "Lamine Yamal", "Kylian Mbappe", "Vinicius Junior",
        "Jude Bellingham", "Fermin Lopez", "Julian Alvarez", "Raphinha", "Isco", "Pablo Barrios",
        "Ante Budimir", "Sergio Camello", "Giuliano Simeone", "Lucas Boye", "Isaac Romero",
        "Sergio Carreira", "Adria Pedrosa", "Jose Gaya", "Javi Rodriguez", "Alex Calatrava",
        "Rodri", "Kevin De Bruyne", "Pedri", "Jamal Musiala", "Federico Valverde", "Declan Rice",
        "Bruno Fernandes", "Vitinha", "Joao Neves", "Joshua Kimmich", "Florian Wirtz", "Martin Odegaard",
        "Enzo Fernandez", "N'Golo Kante", "Lionel Messi", "Cristiano Ronaldo", "Mohamed Salah", "Neymar Jr",
        "Riyad Mahrez", "Bukayo Saka", "Son Heung-min", "Sadio Mane", "Ousmane Dembele",
        "Khvicha Kvaratskhelia", "Angel Di Maria", "Alexis Sanchez", "Raheem Sterling", "Michael Olise",
        "Luis Diaz", "Rayan Cherki", "Pedro Rodriguez", "Angel Correa", "Antoine Griezmann",
        "Hakim Ziyech", "Willian", "Wilfried Zaha", "Robert Lewandowski", "Karim Benzema",
        "Erling Haaland", "Harry Kane", "Viktor Gyokeres", "Alexander Isak", "Edin Dzeko"
    )
    private val retiredNames = setOf(
        "Iker Casillas", "Gianluigi Buffon", "Petr Cech", "Oliver Kahn", "Peter Schmeichel", "Dida",
        "Jose Luis Chilavert", "Rene Higuita", "Samir Handanovic", "Edwin van der Sar", "Walter Zenga",
        "David Seaman", "Paolo Maldini", "Franco Baresi", "Alessandro Nesta", "Fabio Cannavaro",
        "Carles Puyol", "Rio Ferdinand", "Nemanja Vidic", "John Terry", "Gerard Pique", "Dani Alves",
        "Cafu", "Roberto Carlos", "Marcelo", "Ashley Cole", "Philipp Lahm", "Javier Zanetti",
        "Giorgio Chiellini", "Leonardo Bonucci", "Jaap Stam", "Raphael Varane", "Pepe", "Vincent Kompany",
        "Mats Hummels", "Bixente Lizarazu", "Patrice Evra", "Eric Abidal", "Giuseppe Bergomi", "Frank de Boer",
        "Zinedine Zidane", "Andres Iniesta", "Xavi Hernandez", "Toni Kroos", "Andrea Pirlo", "Steven Gerrard",
        "Frank Lampard", "Paul Scholes", "Patrick Vieira", "Claude Makelele", "Yaya Toure", "Clarence Seedorf",
        "Kaka", "Ronaldinho", "Rivaldo", "Michel Platini", "Lothar Matthaus", "Roy Keane", "Cesc Fabregas",
        "Mesut Ozil", "David Silva", "Bastian Schweinsteiger", "Mohamed Aboutrika", "Xabi Alonso", "Bobby Charlton",
        "Jay-Jay Okocha", "Michael Essien", "Gennaro Gattuso", "Park Ji-sung", "Frank Rijkaard", "Michael Ballack",
        "Juan Roman Riquelme", "Michael Laudrup", "Pavel Nedved", "Gheorghe Hagi", "Juan Sebastian Veron", "Guti", "Deco",
        "Arjen Robben", "Franck Ribery", "Gareth Bale", "Eden Hazard", "Luis Figo", "George Best", "Ryan Giggs",
        "David Beckham", "Stanley Matthews", "Hristo Stoichkov", "Robert Pires", "Nani", "Mohamed Zidan",
        "Jesus Navas", "Ricardo Quaresma", "Dirk Kuyt", "Pele", "Diego Maradona", "Ronaldo Nazario",
        "Thierry Henry", "Didier Drogba", "Samuel Eto'o", "Zlatan Ibrahimovic", "Wayne Rooney", "Ruud van Nistelrooy",
        "Marco van Basten", "Gerd Muller", "Eusebio", "Ferenc Puskas", "Romario", "Gabriel Batistuta",
        "Alan Shearer", "Sergio Aguero", "Hossam Hassan", "Miroslav Klose", "Robin van Persie", "Filippo Inzaghi",
        "Hernan Crespo", "Michael Owen", "David Villa", "George Weah", "Carlos Tevez", "Christian Vieri",
        "Robbie Fowler", "Ian Wright", "Mario Gomez", "Gonzalo Higuain"
    )

    /**
     * The legacy catalog stores broad roles (DF/MF/WG). These curated secondary-position
     * pools restore the exact slot distinction needed by the 11-player formation.
     */
    private val exactSlotNames: Map<String, Set<String>> = mapOf(
        "RB" to setOf(
            "Achraf Hakimi", "Trent Alexander-Arnold", "Dani Alves", "Cafu", "Javier Zanetti",
            "Philipp Lahm", "Kyle Walker", "Kieran Trippier", "Dani Carvajal", "Lilian Thuram",
            "Carlos Alberto", "Giuseppe Bergomi"
        ),
        "CB" to setOf(
            "Paolo Maldini", "Sergio Ramos", "Virgil van Dijk", "Franco Baresi", "Alessandro Nesta",
            "Fabio Cannavaro", "Carles Puyol", "Rio Ferdinand", "Nemanja Vidic", "John Terry",
            "Gerard Pique", "Thiago Silva", "Ruben Dias", "Antonio Rudiger", "William Saliba",
            "Alessandro Bastoni", "Kim Min-jae", "Ronald Araujo", "John Stones", "Gabriel Magalhaes",
            "Willian Pacho", "Giorgio Chiellini", "Leonardo Bonucci", "Jaap Stam", "Marcel Desailly",
            "Sol Campbell", "Lucio", "Pepe", "Vincent Kompany", "Mats Hummels", "Frank de Boer"
        ),
        "LB" to setOf(
            "Roberto Carlos", "Marcelo", "Ashley Cole", "Theo Hernandez",
            "Andrew Robertson", "Nuno Mendes", "Bixente Lizarazu", "Patrice Evra", "Eric Abidal",
            "Alejandro Grimaldo", "Alejandro Balde", "Jose Gaya", "Adria Pedrosa", "Sergio Carreira",
            "Javi Rodriguez"
        ),
        "CDM" to setOf(
            "Rodri", "Declan Rice", "Joshua Kimmich", "N'Golo Kante", "Sergio Busquets", "Patrick Vieira",
            "Claude Makelele", "Yaya Toure", "Roy Keane", "Frank Rijkaard", "Gennaro Gattuso",
            "Michael Essien", "Park Ji-sung", "Lothar Matthaus", "Bastian Schweinsteiger"
        ),
        "CM" to setOf(
            "Jude Bellingham", "Pedri", "Federico Valverde", "Vitinha", "Joao Neves", "Florian Wirtz",
            "Enzo Fernandez",
            "Luka Modric", "Andres Iniesta", "Xavi Hernandez", "Toni Kroos", "Andrea Pirlo",
            "Steven Gerrard", "Frank Lampard", "Paul Scholes", "Clarence Seedorf", "Cesc Fabregas",
            "Michael Ballack", "Xabi Alonso", "Pavel Nedved", "Gheorghe Hagi", "Juan Sebastian Veron",
            "Michael Laudrup"
        ),
        "CAM" to setOf(
            "Kevin De Bruyne", "Bruno Fernandes", "Jamal Musiala", "Martin Odegaard", "Isco",
            "Fermin Lopez", "Zinedine Zidane", "Kaka", "Ronaldinho", "Michel Platini", "Mesut Ozil",
            "David Silva", "Jay-Jay Okocha", "Juan Roman Riquelme", "Guti", "Deco", "Rivaldo"
        ),
        "RW" to setOf(
            "Lionel Messi", "Mohamed Salah", "Bukayo Saka", "Riyad Mahrez", "Ousmane Dembele", "Michael Olise",
            "Lamine Yamal", "Angel Di Maria", "Angel Correa", "Pedro Rodriguez", "David Beckham", "Arjen Robben",
            "Luis Figo", "Stanley Matthews", "Hristo Stoichkov", "Robert Pires",
            "Jesus Navas", "Ricardo Quaresma", "Dirk Kuyt", "Mohamed Zidan"
        ),
        "LW" to setOf(
            "Cristiano Ronaldo", "Neymar Jr", "Kylian Mbappe", "Vinicius Junior", "Son Heung-min", "Sadio Mane",
            "Khvicha Kvaratskhelia", "Raphinha", "Alexis Sanchez", "Raheem Sterling", "Luis Diaz", "Wilfried Zaha",
            "Rayan Cherki", "Franck Ribery", "Gareth Bale", "Eden Hazard", "Ryan Giggs", "Nani", "George Best"
        )
    )

    private fun supportsSlot(player: PlayerCard, slot: String): Boolean = when (slot) {
        "GK", "ST" -> player.position == slot
        else -> player.nameEn in exactSlotNames[slot].orEmpty()
    }

    /** Public read-only check used by regression tests and UI safeguards. */
    fun isEligibleForFormationSlot(player: PlayerCard, slot: String): Boolean = supportsSlot(player, slot)

    private val leaguePlayers: Map<String, Set<String>> = mapOf(
        "Premier League" to setOf(
            "Alisson Becker", "Ederson", "David de Gea", "Jordan Pickford", "Andre Onana", "Petr Cech",
            "Peter Schmeichel", "David Seaman", "Virgil van Dijk", "Rio Ferdinand", "Nemanja Vidic",
            "John Terry", "John Stones", "Kyle Walker", "Trent Alexander-Arnold", "Andrew Robertson",
            "Ashley Cole", "Wayne Rooney", "Steven Gerrard", "Frank Lampard", "Paul Scholes", "David Beckham",
            "Mohamed Salah", "Cristiano Ronaldo", "Thierry Henry", "Didier Drogba", "Sergio Aguero",
            "Erling Haaland", "Harry Kane", "Kevin De Bruyne", "Eden Hazard", "Patrick Vieira", "Roy Keane",
            "Cesc Fabregas", "Xabi Alonso"
        ),
        "Serie A" to setOf(
            "Gianluigi Buffon", "Gianluigi Donnarumma", "Mike Maignan", "Paolo Maldini", "Franco Baresi",
            "Alessandro Nesta", "Fabio Cannavaro", "Cafu", "Javier Zanetti", "Giorgio Chiellini",
            "Leonardo Bonucci", "Andrea Pirlo", "Francesco Totti", "Alessandro Del Piero", "Kaka",
            "Ronaldinho", "Ronaldo Nazario", "Zlatan Ibrahimovic", "Andriy Shevchenko", "Christian Vieri",
            "Luka Modric", "Cristiano Ronaldo", "Zinedine Zidane", "Thiago Silva"
        ),
        "LaLiga" to setOf(
            "Thibaut Courtois", "Jan Oblak", "Marc-Andre ter Stegen", "Unai Simon", "Iker Casillas",
            "David de Gea", "Victor Valdes", "Sergio Ramos", "Carles Puyol", "Gerard Pique", "Dani Alves",
            "Marcelo", "Paolo Maldini", "Xavi", "Andres Iniesta", "Sergio Busquets", "Luka Modric",
            "Toni Kroos", "Jude Bellingham", "Pedri", "Gavi", "Isco", "Lionel Messi", "Cristiano Ronaldo",
            "Luis Suarez", "Karim Benzema", "Neymar", "Kylian Mbappe", "Vinicius Junior", "Raphinha",
            "Fermin Lopez", "Julian Alvarez", "Ante Budimir", "Sergio Camello", "Alejandro Grimaldo",
            "Giuliano Simeone", "Alejandro Balde", "Sergio Gomez", "Pablo Barrios", "Lucas Boye",
            "Isaac Romero", "Sergio Carreira", "Adria Pedrosa", "Jose Gaya", "Javi Rodriguez", "Alex Calatrava"
        ),
        "Saudi Pro League" to setOf(
            "Cristiano Ronaldo", "Karim Benzema", "Neymar", "Sadio Mane", "Riyad Mahrez", "N'Golo Kante",
            "Kalidou Koulibaly", "Fabinho", "Roberto Firmino", "Sergej Milinkovic-Savic", "Aymeric Laporte",
            "Yassine Bounou", "Joao Cancelo", "Marcelo Brozovic", "Otavio"
        ),
        "Bundesliga" to setOf(
            "Manuel Neuer", "Oliver Kahn", "Marc-Andre ter Stegen", "Philipp Lahm", "Mats Hummels",
            "Jerome Boateng", "Robert Lewandowski", "Arjen Robben", "Franck Ribery", "Michael Ballack",
            "Miroslav Klose", "Thomas Muller", "Toni Kroos", "Erling Haaland", "Jadon Sancho"
        ),
        "Ligue 1" to setOf(
            "Gianluigi Donnarumma", "Achraf Hakimi", "Thiago Silva", "Ronaldinho", "Neymar",
            "Kylian Mbappe", "Zlatan Ibrahimovic", "Lionel Messi", "Eden Hazard", "David Beckham"
        )
    )

    private fun isCurrentPlayer(player: PlayerCard): Boolean =
        PlayerFactsDatabase.facts(player)?.isCurrent ?: (player.nameEn in currentNames)

    private fun isRetiredPlayer(player: PlayerCard): Boolean =
        PlayerFactsDatabase.facts(player)?.isCurrent?.not() ?: (player.nameEn in retiredNames)

    private fun rosterScopeMatches(player: PlayerCard, scope: BuildTeamRosterFilter): Boolean = when (scope) {
        BuildTeamRosterFilter.ALL, BuildTeamRosterFilter.RANDOM -> true
        BuildTeamRosterFilter.CURRENT -> isCurrentPlayer(player)
        BuildTeamRosterFilter.RETIRED -> isRetiredPlayer(player)
    }

    @Suppress("UNUSED_PARAMETER")
    private fun dynamicFilters(players: List<PlayerCard>, rolePlayers: List<PlayerCard>): List<DynamicPlayerFilter> {
        val filters = mutableListOf(
            DynamicPlayerFilter("all", "كل اللاعبين المطابقين للمركز", "Any player in this position") { true },
            DynamicPlayerFilter("current", "لاعب حالي", "Current player", ::isCurrentPlayer),
            DynamicPlayerFilter("retired", "لاعب معتزل", "Retired player", ::isRetiredPlayer)
        )
        val countries = rolePlayers.map { it.nationalityEn }.filter { it.isNotBlank() }.distinct()
        countries.forEach { country ->
            val ar = rolePlayers.firstOrNull { it.nationalityEn == country }?.nationalityAr ?: country
            filters += DynamicPlayerFilter("nation:$country", "لاعب ${ar} الجنسية", "$country player") { it.nationalityEn == country }
            filters += DynamicPlayerFilter("nation:$country+current", "لاعب ${ar} حالي", "Current $country player") {
                it.nationalityEn == country && isCurrentPlayer(it)
            }
            filters += DynamicPlayerFilter("nation:$country+retired", "لاعب ${ar} معتزل", "Retired $country player") {
                it.nationalityEn == country && isRetiredPlayer(it)
            }
        }
        leaguePlayers.forEach { (league, names) ->
            filters += DynamicPlayerFilter("league:$league", "لاعب لعب في $league", "Played in $league") { it.nameEn in names || PlayerFactsDatabase.facts(it)?.league == league }
        }
        // A useful mixed filter from the examples: Spanish players who appeared in England.
        filters += DynamicPlayerFilter("nation:Spain+league:Premier League", "لاعب إسباني لعب في الدوري الإنجليزي", "Spanish player who played in the Premier League") {
            it.nationalityEn == "Spain" && it.nameEn in leaguePlayers["Premier League"].orEmpty()
        }
        return filters
    }

    /** Reject a roster scope before play if it cannot supply every slot to every participant. */
    fun canBuildFullRoster(
        players: List<PlayerCard>,
        selectedRosterFilter: BuildTeamRosterFilter,
        participantCount: Int,
        slots: List<String>
    ): Boolean {
        if (participantCount !in 2..4 || slots.isEmpty()) return false
        // Treat each participant/slot as a separate assignment. Bipartite matching prevents
        // a fullback from being double-counted as both RB and LB or one player being reused.
        val requiredSlots = slots.flatMap { slot -> List(participantCount) { slot } }
            .sortedBy { slot -> players.count { supportsSlot(it, slot) && rosterScopeMatches(it, selectedRosterFilter) } }
        val assignments = mutableMapOf<String, Int>()
        fun assign(slotIndex: Int, seenPlayers: MutableSet<String>): Boolean {
            val slot = requiredSlots[slotIndex]
            val candidates = players.filter { supportsSlot(it, slot) && rosterScopeMatches(it, selectedRosterFilter) }
            for (candidate in candidates) {
                if (!seenPlayers.add(candidate.nameEn)) continue
                val previousSlot = assignments[candidate.nameEn]
                if (previousSlot == null || assign(previousSlot, seenPlayers)) {
                    assignments[candidate.nameEn] = slotIndex
                    return true
                }
            }
            return false
        }
        return requiredSlots.indices.all { slotIndex -> assign(slotIndex, mutableSetOf()) }
    }

    fun playersForChallenge(
        players: List<PlayerCard>,
        challenge: BuildTeamRoundChallenge,
        usedNames: Set<String> = emptySet()
    ): List<PlayerCard> {
        val filters = dynamicFilters(players, players.filter { supportsSlot(it, challenge.slot) })
        val predicate = filters.firstOrNull { it.key == challenge.filterKey }?.matches ?: { true }
        return players.filter { player ->
            supportsSlot(player, challenge.slot) &&
                player.nameEn !in usedNames &&
                rosterScopeMatches(player, challenge.rosterFilter) &&
                predicate(player) && value(player, challenge.metric) != null
        }
    }

    fun randomRoundChallenge(
        players: List<PlayerCard>,
        slot: String,
        selectedRosterFilter: BuildTeamRosterFilter,
        usedNames: Set<String>,
        participantCount: Int,
        previousFilterKeys: Set<String> = emptySet(),
        random: Random = Random.Default
    ): BuildTeamRoundChallenge? {
        if (participantCount !in 1..4) return null
        if (ElbashaPositions.poolRole(slot).isBlank()) return null
        val rolePlayers = players.filter { supportsSlot(it, slot) && it.nameEn !in usedNames }
        if (rolePlayers.size < participantCount) return null
        val availableScopes = when (selectedRosterFilter) {
            BuildTeamRosterFilter.RANDOM -> listOf(BuildTeamRosterFilter.ALL, BuildTeamRosterFilter.CURRENT, BuildTeamRosterFilter.RETIRED)
            else -> listOf(selectedRosterFilter)
        }
        val candidates = mutableListOf<BuildTeamRoundChallenge>()
        availableScopes.forEach { scope ->
            val scopePlayers = rolePlayers.filter { rosterScopeMatches(it, scope) }
            val filters = dynamicFilters(players, scopePlayers)
            filters.forEach { filter ->
                val matching = scopePlayers.filter(filter.matches)
                if (matching.size >= participantCount) {
                    BuildTeamMetric.entries.forEach { metric ->
                        val withMetric = matching.filter { value(it, metric) != null }
                        if (withMetric.size >= participantCount) {
                            // Points are the player's real stat value (e.g. 192 cm = 192 points),
                            // so every round uses the higher-value-wins rule to keep the match
                            // leaderboard mathematically consistent with round winners.
                            listOf(BuildTeamDirection.HIGH).forEach { direction ->
                                candidates += BuildTeamRoundChallenge(
                                    slot = slot,
                                    rosterFilter = scope,
                                    filterKey = filter.key,
                                    filterLabelAr = filter.labelAr,
                                    filterLabelEn = filter.labelEn,
                                    metric = metric,
                                    direction = direction
                                )
                            }
                        }
                    }
                }
            }
        }
        if (candidates.isEmpty()) {
            // Fallback still respects an explicitly chosen current/retired roster scope.
            val fallbackScope = when (selectedRosterFilter) {
                BuildTeamRosterFilter.RANDOM -> availableScopes.filter { scope ->
                    rolePlayers.count { rosterScopeMatches(it, scope) } >= participantCount
                }.randomOrNull(random) ?: return null
                else -> selectedRosterFilter
            }
            val fallback = BuildTeamRoundChallenge(
                slot, fallbackScope, "all",
                "كل لاعبي المركز", "Any player in this position",
                BuildTeamMetric.PLAYER_RATING, BuildTeamDirection.HIGH
            )
            return fallback.takeIf { playersForChallenge(players, it, usedNames).size >= participantCount }
        }
        val freshFilters = candidates.filterNot { it.filterKey in previousFilterKeys }
        val pool = freshFilters.ifEmpty { candidates }
        return pool.randomOrNull(random)
    }
    fun eligiblePlayers(
        players: List<PlayerCard>,
        filter: BuildTeamFilter,
        metric: BuildTeamMetric
    ): List<PlayerCard> = players.filter { player ->
        val facts = PlayerFactsDatabase.facts(player)
        val positionMatches = when (filter.position) {
            BuildTeamPositionFilter.ANY -> true
            BuildTeamPositionFilter.GK -> ElbashaPositions.poolRole(player.position) == "GK"
            BuildTeamPositionFilter.DF -> ElbashaPositions.poolRole(player.position) == "DF"
            BuildTeamPositionFilter.MF -> ElbashaPositions.poolRole(player.position) == "MF"
            BuildTeamPositionFilter.WG -> ElbashaPositions.poolRole(player.position) == "WG"
            BuildTeamPositionFilter.ST -> ElbashaPositions.poolRole(player.position) == "ST"
        }
        val leagueMatches = when (filter.league) {
            BuildTeamLeagueFilter.ANY -> true
            else -> facts?.let { it.isCurrent && it.league == filter.league.leagueCode } == true
        }
        val statIsAvailable = when (metric) {
            BuildTeamMetric.PLAYER_RATING, BuildTeamMetric.AUCTION_PRICE -> true
            else -> facts?.isCurrent == true
        }
        positionMatches && leagueMatches && statIsAvailable && value(player, metric) != null
    }

    fun value(player: PlayerCard, metric: BuildTeamMetric): Int? {
        val facts = PlayerFactsDatabase.facts(player)
        return when (metric) {
            BuildTeamMetric.HEIGHT -> facts?.heightCm
            BuildTeamMetric.WEIGHT -> facts?.weightKg
            BuildTeamMetric.GOALS -> facts?.goalsSeason
            BuildTeamMetric.YELLOW_CARDS -> facts?.yellowCardsSeason
            BuildTeamMetric.PACE -> facts?.paceRating
            BuildTeamMetric.PLAYER_RATING -> player.rating
            BuildTeamMetric.AUCTION_PRICE -> player.price
        }
    }

    fun chooseAiPlayer(
        candidates: List<PlayerCard>,
        metric: BuildTeamMetric,
        direction: BuildTeamDirection,
        difficulty: Int,
        random: Random = Random.Default
    ): PlayerCard? {
        if (candidates.isEmpty()) return null
        val ranked = if (direction == BuildTeamDirection.HIGH) {
            candidates.sortedByDescending { value(it, metric) ?: Int.MIN_VALUE }
        } else {
            candidates.sortedBy { value(it, metric) ?: Int.MAX_VALUE }
        }
        val ratio = when (difficulty.coerceIn(0, 3)) {
            0 -> 0.75
            1 -> 0.55
            2 -> 0.32
            else -> 0.15
        }
        val count = (ranked.size * ratio).toInt().coerceAtLeast(1)
        return ranked.take(count).randomOrNull(random)
    }

    fun total(picks: List<BuildTeamPick>): Int = picks.sumOf { it.value }

    /** Higher total wins in HIGH mode; lower total wins in LOW mode. Ties remain ties. */
    fun ranking(totals: List<Int>, direction: BuildTeamDirection): List<Int> =
        if (direction == BuildTeamDirection.HIGH) totals.indices.sortedByDescending { totals[it] }
        else totals.indices.sortedBy { totals[it] }

    fun winners(totals: List<Int>, direction: BuildTeamDirection): List<Int> {
        if (totals.isEmpty()) return emptyList()
        val target = if (direction == BuildTeamDirection.HIGH) totals.maxOrNull() else totals.minOrNull()
        return totals.indices.filter { totals[it] == target }
    }

    fun hasEnoughPlayers(
        players: List<PlayerCard>,
        filter: BuildTeamFilter,
        metric: BuildTeamMetric,
        roundCount: Int,
        participantCount: Int
    ): Boolean {
        if (roundCount < 1 || participantCount < 2) return false
        return eligiblePlayers(players, filter, metric).size >= roundCount * participantCount
    }

    fun randomValidSetup(
        roundCount: Int,
        participantCount: Int = 2,
        random: Random = Random.Default
    ): Triple<BuildTeamFilter, BuildTeamMetric, BuildTeamDirection>? {
        val valid = BuildTeamPositionFilter.entries.flatMap { position ->
            BuildTeamLeagueFilter.entries.map { league -> BuildTeamFilter(position, league) }
        }.flatMap { filter ->
            BuildTeamMetric.entries.mapNotNull { metric ->
                if (hasEnoughPlayers(PlayerFactsDatabase.players, filter, metric, roundCount, participantCount)) {
                    Triple(filter, metric, BuildTeamDirection.entries.random(random))
                } else null
            }
        }
        return valid.randomOrNull(random)
    }
}
