package com.mostafabek.elbashagames

import kotlin.random.Random

enum class BuildTeamPositionFilter(val labelAr: String, val labelEn: String) {
    ANY("كل المراكز", "Any position"),
    GK("حراس مرمى", "Goalkeepers"),
    DF("مدافعون", "Defenders"),
    MF("لاعبو وسط", "Midfielders"),
    WG("أجنحة", "Wingers"),
    ST("مهاجمون", "Strikers")
}

enum class BuildTeamLeagueFilter(val labelAr: String, val labelEn: String, val leagueCode: String?) {
    ANY("كل الدوريات المتاحة", "Any available league", null),
    LALIGA("الدوري الإسباني الحالي", "Current LaLiga", "LaLiga")
}

enum class BuildTeamMetric(
    val labelAr: String,
    val labelEn: String,
    val unitAr: String,
    val unitEn: String
) {
    HEIGHT("الطول", "Height", "سم", "cm"),
    WEIGHT("الوزن", "Weight", "كجم", "kg"),
    GOALS("الأهداف", "Goals", "هدف", "goals"),
    YELLOW_CARDS("الكروت الصفراء", "Yellow cards", "كارت", "cards"),
    PACE("السرعة - تقييم ELBASHA", "Pace - ELBASHA rating", "/100", "/100"),
    PLAYER_RATING("تقييم اللاعب", "Player rating", "/100", "/100"),
    AUCTION_PRICE("سعر اللاعب في المزاد", "Auction price", "مليون", "M")
}

enum class BuildTeamDirection(val labelAr: String, val labelEn: String) {
    HIGH("الأعلى يكسب", "Highest wins"),
    LOW("الأقل يكسب", "Lowest wins")
}

data class BuildTeamFilter(
    val position: BuildTeamPositionFilter = BuildTeamPositionFilter.ANY,
    val league: BuildTeamLeagueFilter = BuildTeamLeagueFilter.ANY
)

data class BuildTeamPick(val player: PlayerCard, val value: Int)

object BuildTeamStatRules {
    fun eligiblePlayers(
        players: List<PlayerCard>,
        filter: BuildTeamFilter,
        metric: BuildTeamMetric
    ): List<PlayerCard> = players.filter { player ->
        val facts = PlayerFactsDatabase.facts(player)
        val positionMatches = when (filter.position) {
            BuildTeamPositionFilter.ANY -> true
            BuildTeamPositionFilter.GK -> ElbashaPositions.poolRole(player.position) == "GK"
            BuildTeamPositionFilter.DF -> ElbashaPositions.poolRole(player.position) == "DF"
            BuildTeamPositionFilter.MF -> ElbashaPositions.poolRole(player.position) == "MF"
            BuildTeamPositionFilter.WG -> ElbashaPositions.poolRole(player.position) == "WG"
            BuildTeamPositionFilter.ST -> ElbashaPositions.poolRole(player.position) == "ST"
        }
        val leagueMatches = when (filter.league) {
            BuildTeamLeagueFilter.ANY -> true
            else -> facts?.let { it.isCurrent && it.league == filter.league.leagueCode } == true
        }
        val statIsAvailable = when (metric) {
            BuildTeamMetric.PLAYER_RATING, BuildTeamMetric.AUCTION_PRICE -> true
            else -> facts?.isCurrent == true
        }
        positionMatches && leagueMatches && statIsAvailable && value(player, metric) != null
    }

    fun value(player: PlayerCard, metric: BuildTeamMetric): Int? {
        val facts = PlayerFactsDatabase.facts(player)
        return when (metric) {
            BuildTeamMetric.HEIGHT -> facts?.heightCm
            BuildTeamMetric.WEIGHT -> facts?.weightKg
            BuildTeamMetric.GOALS -> facts?.goalsSeason
            BuildTeamMetric.YELLOW_CARDS -> facts?.yellowCardsSeason
            BuildTeamMetric.PACE -> facts?.paceRating
            BuildTeamMetric.PLAYER_RATING -> player.rating
            BuildTeamMetric.AUCTION_PRICE -> player.price
        }
    }

    fun chooseAiPlayer(
        candidates: List<PlayerCard>,
        metric: BuildTeamMetric,
        direction: BuildTeamDirection,
        difficulty: Int,
        random: Random = Random.Default
    ): PlayerCard? {
        if (candidates.isEmpty()) return null
        val ranked = if (direction == BuildTeamDirection.HIGH) {
            candidates.sortedByDescending { value(it, metric) ?: Int.MIN_VALUE }
        } else {
            candidates.sortedBy { value(it, metric) ?: Int.MAX_VALUE }
        }
        val ratio = when (difficulty.coerceIn(0, 3)) {
            0 -> 0.75
            1 -> 0.55
            2 -> 0.32
            else -> 0.15
        }
        val count = (ranked.size * ratio).toInt().coerceAtLeast(1)
        return ranked.take(count).randomOrNull(random)
    }

    fun total(picks: List<BuildTeamPick>): Int = picks.sumOf { it.value }

    /** Higher total wins in HIGH mode; lower total wins in LOW mode. Ties remain ties. */
    fun ranking(totals: List<Int>, direction: BuildTeamDirection): List<Int> =
        if (direction == BuildTeamDirection.HIGH) totals.indices.sortedByDescending { totals[it] }
        else totals.indices.sortedBy { totals[it] }

    fun winners(totals: List<Int>, direction: BuildTeamDirection): List<Int> {
        if (totals.isEmpty()) return emptyList()
        val target = if (direction == BuildTeamDirection.HIGH) totals.maxOrNull() else totals.minOrNull()
        return totals.indices.filter { totals[it] == target }
    }

    fun hasEnoughPlayers(
        players: List<PlayerCard>,
        filter: BuildTeamFilter,
        metric: BuildTeamMetric,
        roundCount: Int,
        participantCount: Int
    ): Boolean {
        if (roundCount < 1 || participantCount < 2) return false
        return eligiblePlayers(players, filter, metric).size >= roundCount * participantCount
    }

    fun randomValidSetup(
        roundCount: Int,
        participantCount: Int = 2,
        random: Random = Random.Default
    ): Triple<BuildTeamFilter, BuildTeamMetric, BuildTeamDirection>? {
        val valid = BuildTeamPositionFilter.entries.flatMap { position ->
            BuildTeamLeagueFilter.entries.map { league -> BuildTeamFilter(position, league) }
        }.flatMap { filter ->
            BuildTeamMetric.entries.mapNotNull { metric ->
                if (hasEnoughPlayers(PlayerFactsDatabase.players, filter, metric, roundCount, participantCount)) {
                    Triple(filter, metric, BuildTeamDirection.entries.random(random))
                } else null
            }
        }
        return valid.randomOrNull(random)
    }
}
