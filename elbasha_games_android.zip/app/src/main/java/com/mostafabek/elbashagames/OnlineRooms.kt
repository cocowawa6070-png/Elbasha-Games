package com.mostafabek.elbashagames

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

private const val ROOM_CAPACITY = ELBASHA_ROOM_CAPACITY
private const val ROOM_CHAT_LIMIT = 40
private const val ROOM_CHAT_MAX_LENGTH = 250

private data class RoomChatMessage(
    val id: String,
    val senderUid: String,
    val senderName: String,
    val text: String,
    val sentAt: Long
)

@Composable
fun OnlineRoomsScreen(user: FirebaseUser, database: FirebaseDatabase?, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var codeInput by remember { mutableStateOf("") }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var roomSnapshot by remember { mutableStateOf<Map<String, Any?>?>(null) }
    var messages by remember { mutableStateOf<List<RoomChatMessage>>(emptyList()) }
    var messageInput by remember { mutableStateOf("") }
    var selectedGame by remember { mutableStateOf("auction") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }

    val root = database?.reference?.child("onlineRooms")
    val messageRoot = database?.reference?.child("onlineRoomMessages")
    val displayName = (user.displayName?.takeIf { it.isNotBlank() }
        ?: user.email?.substringBefore("@") ?: "Player").take(40)

    DisposableEffect(roomCode, root, messageRoot, english, user.uid) {
        val code = roomCode
        if (code == null || root == null || messageRoot == null) {
            onDispose { }
        } else {
            val roomRef = root.child(code)
            val roomListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists()) {
                        roomSnapshot = null
                        roomCode = null
                        messages = emptyList()
                        status = if (english) "Room closed or not found." else "الغرفة اتقفلت أو مش موجودة."
                    } else {
                        @Suppress("UNCHECKED_CAST")
                        roomSnapshot = snapshot.value as? Map<String, Any?>
                    }
                }

                override fun onCancelled(error: DatabaseError) { status = error.message }
            }
            val chatRef = messageRoot.child(code).limitToLast(ROOM_CHAT_LIMIT)
            val chatListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    messages = snapshot.children.mapNotNull { child ->
                        val value = child.value as? Map<*, *> ?: return@mapNotNull null
                        RoomChatMessage(
                            id = child.key ?: return@mapNotNull null,
                            senderUid = value["senderUid"]?.toString().orEmpty(),
                            senderName = value["senderName"]?.toString() ?: "Player",
                            text = value["text"]?.toString().orEmpty(),
                            sentAt = (value["sentAt"] as? Number)?.toLong() ?: 0L
                        )
                    }.takeLast(ROOM_CHAT_LIMIT)
                }

                override fun onCancelled(error: DatabaseError) { status = error.message }
            }
            roomRef.addValueEventListener(roomListener)
            chatRef.addValueEventListener(chatListener)
            onDispose {
                roomRef.removeEventListener(roomListener)
                chatRef.removeEventListener(chatListener)
            }
        }
    }

    fun makeRoom() {
        if (root == null) {
            status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."
            return
        }
        busy = true
        status = ""
        val code = ElbashaRoomRules.generateCode()
        val room = root.child(code)
        val payload = mapOf(
            "hostUid" to user.uid,
            "createdAt" to ServerValue.TIMESTAMP,
            "status" to "lobby",
            "gameId" to selectedGame,
            "gameState" to mapOf("phase" to "lobby", "revision" to 0L),
            "members" to mapOf(
                user.uid to mapOf("name" to displayName, "ready" to true, "joinedAt" to ServerValue.TIMESTAMP)
            )
        )
        room.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                if (current.value != null) return Transaction.abort()
                current.value = payload
                return Transaction.success(current)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                if (error != null) status = error.message
                else if (committed) {
                    roomCode = code
                    status = if (english) "Room created. Share this code with your friends." else "الغرفة اتعملت. ابعت الكود لأصحابك."
                } else status = if (english) "Code collision. Try again." else "الكود اتكرر، جرّب تاني."
            }
        })
    }

    fun joinRoom() {
        val code = ElbashaRoomRules.normalizeCode(codeInput)
        if (!ElbashaRoomRules.validCode(code)) {
            status = if (english) "Enter a six-character room code." else "اكتب كود غرفة من 6 حروف/أرقام."
            return
        }
        if (root == null) {
            status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."
            return
        }
        busy = true
        status = ""
        val ref = root.child(code)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                if (current.value == null || current.child("status").value != "lobby") return Transaction.abort()
                val members = current.child("members")
                val alreadyMember = members.child(user.uid).value != null
                if (!ElbashaRoomRules.canJoin(members.childrenCount.toInt(), alreadyMember)) return Transaction.abort()
                members.child(user.uid).value = mapOf("name" to displayName, "ready" to false, "joinedAt" to ServerValue.TIMESTAMP)
                return Transaction.success(current)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                if (error != null) status = error.message
                else if (committed) {
                    roomCode = code
                    status = if (english) "Joined room." else "دخلت الغرفة."
                } else status = if (english) "Room does not exist or is full (10 players max)." else "الغرفة مش موجودة أو وصلت 10 لاعبين."
            }
        })
    }

    fun toggleReady() {
        val code = roomCode ?: return
        root?.child(code)?.child("members")?.child(user.uid)?.child("ready")?.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                current.value = !(current.value as? Boolean ?: false)
                return Transaction.success(current)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) status = error.message
            }
        })
    }

    fun sendMessage() {
        val code = roomCode ?: return
        val text = messageInput.trim().take(ROOM_CHAT_MAX_LENGTH)
        if (text.isBlank() || messageRoot == null) return
        val newMessage = messageRoot.child(code).push()
        val value = mapOf(
            "senderUid" to user.uid,
            "senderName" to displayName,
            "text" to text,
            "sentAt" to ServerValue.TIMESTAMP
        )
        newMessage.setValue(value).addOnSuccessListener { messageInput = "" }
            .addOnFailureListener { error -> status = error.message ?: "Message failed" }
    }

    fun startRoomGame(isHost: Boolean, allReady: Boolean, memberCount: Int) {
        val code = roomCode ?: return
        if (!isHost || !allReady || memberCount < 2 || root == null) return
        busy = true
        val ref = root.child(code)
        val updates = mapOf<String, Any>(
            "status" to "started",
            "gameId" to selectedGame,
            "gameState" to mapOf(
                "phase" to "session_created",
                "revision" to 1L,
                "hostUid" to user.uid,
                "startedAt" to ServerValue.TIMESTAMP
            )
        )
        ref.updateChildren(updates).addOnSuccessListener {
            busy = false
            status = if (english) "Session started. All devices received the start event." else "الجلسة بدأت، وكل الأجهزة استلمت إشارة البداية."
        }.addOnFailureListener { error ->
            busy = false
            status = error.message ?: "Could not start the room."
        }
    }

    fun leaveRoom() {
        val code = roomCode ?: return
        val ref = root?.child(code) ?: return
        busy = true
        ref.child("hostUid").get().addOnSuccessListener { hostSnap ->
            val operation = if (hostSnap.getValue(String::class.java) == user.uid) {
                ref.removeValue()
            } else {
                ref.child("members").child(user.uid).removeValue()
            }
            operation.addOnCompleteListener { task ->
                busy = false
                if (task.isSuccessful) {
                    roomCode = null
                    roomSnapshot = null
                    messages = emptyList()
                    status = if (english) "You left the room." else "خرجت من الغرفة."
                } else status = task.exception?.message ?: "Could not leave the room."
            }
        }.addOnFailureListener { error ->
            busy = false
            status = error.message ?: "Could not leave the room."
        }
    }

    val members = ((roomSnapshot?.get("members") as? Map<*, *>) ?: emptyMap<Any, Any>()).entries.toList()
    val isHost = roomSnapshot?.get("hostUid")?.toString() == user.uid
    val roomStarted = roomSnapshot?.get("status")?.toString() == "started"
    val allReady = members.size >= 2 && members.all { entry ->
        val details = entry.value as? Map<*, *> ?: emptyMap<Any, Any>()
        details["ready"] == true
    }
    val myDetails = (roomSnapshot?.get("members") as? Map<*, *>)?.get(user.uid) as? Map<*, *>
    val myReady = myDetails?.get("ready") == true

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onExit) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(if (english) "ONLINE ROOMS" else "الغرف الأونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(if (english) "Private rooms for up to 10 players." else "غرف خاصة للجروب لحد 10 لاعبين.", color = palette.muted)

        Card(colors = CardDefaults.cardColors(containerColor = palette.panelAlt), shape = RoundedCornerShape(14.dp)) {
            Text(
                if (english) "Live lobby, ready state, start event and room chat are connected. The actions inside each game still need their own turn-by-turn synchronization." else "اللوبي والجاهزية وإشارة البداية والشات اللحظي متوصلين. قرارات وأدوار كل لعبة نفسها لسه محتاجة ربط مزامنة منفصل.",
                color = palette.muted, fontSize = 11.sp, modifier = Modifier.padding(12.dp)
            )
        }

        if (roomCode == null) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (english) "Choose the game" else "اختار اللعبة", color = palette.cream, fontWeight = FontWeight.Bold)
                    GameChoiceRow(selectedGame, english, palette) { selectedGame = it }
                    Button(
                        onClick = { makeRoom() }, enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
                    ) { Text(if (english) "Create room" else "إنشاء غرفة", fontWeight = FontWeight.Bold) }
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) },
                        label = { Text(if (english) "Room code" else "كود الغرفة") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { joinRoom() }, enabled = !busy && codeInput.length == 6,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)
                    ) { Text(if (english) "Join room" else "دخول غرفة") }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (english) "ROOM CODE" else "كود الغرفة", color = palette.muted, fontSize = 11.sp)
                    Text(roomCode!!, color = palette.gold, fontSize = 34.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(if (english) "${members.size}/10 players" else "${members.size}/10 لاعبين", color = palette.cream, fontWeight = FontWeight.Bold)
                    members.forEach { entry ->
                        val details = entry.value as? Map<*, *> ?: emptyMap<Any, Any>()
                        val name = details["name"]?.toString() ?: "Player"
                        val ready = details["ready"] == true
                        Row(
                            Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(12.dp)).padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(name, color = palette.cream, modifier = Modifier.weight(1f))
                            Text(
                                if (ready) (if (english) "READY" else "جاهز") else (if (english) "WAITING" else "منتظر"),
                                color = if (ready) palette.gold else palette.muted,
                                fontWeight = FontWeight.Bold, fontSize = 11.sp
                            )
                        }
                    }

                    if (!roomStarted && isHost) {
                        Text(if (english) "GAME FOR THIS ROOM" else "اللعبة المختارة للغرفة", color = palette.cream, fontWeight = FontWeight.Bold)
                        GameChoiceRow(selectedGame, english, palette) { selectedGame = it }
                    } else {
                        val gameName = when (roomSnapshot?.get("gameId")?.toString()) {
                            "deal" -> if (english) "Deal or No Deal" else "ديل أور نو ديل"
                            "build" -> if (english) "Build a Team" else "كوّن فريق"
                            else -> if (english) "Auction" else "المزاد"
                        }
                        Text(if (english) "Selected game: $gameName" else "اللعبة المختارة: $gameName", color = palette.gold, fontWeight = FontWeight.Bold)
                    }

                    if (!roomStarted) {
                        Button(
                            onClick = { toggleReady() }, enabled = !busy,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)
                        ) { Text(if (myReady) (if (english) "Set me not ready" else "إلغاء الجاهزية") else (if (english) "I'm ready" else "أنا جاهز")) }
                        if (isHost) {
                            Button(
                                onClick = { startRoomGame(isHost, allReady, members.size) },
                                enabled = !busy && allReady,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)
                            ) { Text(if (english) "Start room session" else "ابدأ الجلسة", fontWeight = FontWeight.Black) }
                            if (!allReady) Text(if (english) "Need at least 2 players and everyone ready." else "لازم لاعبين على الأقل وكل الموجودين يكونوا جاهزين.", color = palette.muted, fontSize = 11.sp)
                        }
                    } else {
                        Text(if (english) "Session started on the room. Game actions are not yet synchronized." else "الجلسة اتبدأت في الغرفة. أفعال اللعبة نفسها لسه مش متزامنة.", color = palette.gold, fontWeight = FontWeight.Bold)
                    }

                    Text(if (english) "ROOM CHAT" else "شات الغرفة", color = palette.gold, fontWeight = FontWeight.Black)
                    messages.forEach { message ->
                        Column(
                            Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(10.dp)).padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(if (message.senderUid == user.uid) (if (english) "You" else "أنت") else message.senderName, color = palette.gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(message.text, color = palette.cream, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = messageInput,
                            onValueChange = { messageInput = it.take(ROOM_CHAT_MAX_LENGTH) },
                            modifier = Modifier.weight(1f), singleLine = true,
                            label = { Text(if (english) "Message" else "اكتب رسالة") }
                        )
                        Button(onClick = { sendMessage() }, enabled = messageInput.isNotBlank()) {
                            Text(if (english) "Send" else "إرسال")
                        }
                    }
                    Button(
                        onClick = { leaveRoom() }, enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.bad, contentColor = Color.White)
                    ) { Text(if (english) "Leave room" else "مغادرة الغرفة") }
                }
            }
        }
        if (status.isNotBlank()) Text(status, color = palette.gold, fontSize = 12.sp)
        if (database == null) Text(
            if (english) "Firebase is not available. Online rooms require a live Realtime Database connection." else "الغرف محتاجة اتصال Firebase Realtime Database شغال.",
            color = palette.bad
        )
    }
}

@Composable
private fun GameChoiceRow(selected: String, english: Boolean, palette: ElbashaPalette, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        listOf("auction", "deal", "build").forEach { game ->
            val title = when (game) {
                "auction" -> if (english) "Auction" else "المزاد"
                "deal" -> if (english) "Deal" else "ديل"
                else -> if (english) "Build" else "فريق"
            }
            val active = selected == game
            OutlinedButton(
                onClick = { onSelect(game) },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (active) palette.gold.copy(alpha = 0.16f) else Color.Transparent,
                    contentColor = if (active) palette.gold else palette.cream
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (active) palette.gold else palette.muted.copy(alpha = 0.45f))
            ) { Text(title, fontSize = 11.sp, fontWeight = if (active) FontWeight.Black else FontWeight.Medium) }
        }
    }
}
