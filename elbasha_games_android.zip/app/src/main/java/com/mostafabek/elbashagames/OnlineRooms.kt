package com.mostafabek.elbashagames

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

private const val ROOM_CAPACITY = ELBASHA_ROOM_CAPACITY

@Composable
fun OnlineRoomsScreen(user: FirebaseUser, database: FirebaseDatabase?, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var codeInput by remember { mutableStateOf("") }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var roomSnapshot by remember { mutableStateOf<Map<String, Any?>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var listenerRef by remember { mutableStateOf<DatabaseReference?>(null) }
    var listener by remember { mutableStateOf<ValueEventListener?>(null) }
    var connected by remember { mutableStateOf<Boolean?>(null) }
    val root = database?.reference?.child("onlineRooms")

    DisposableEffect(database) {
        val connectionRef = database?.getReference(".info/connected")
        if (connectionRef == null) {
            connected = false
            onDispose { }
        } else {
            val connectionListener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    connected = snapshot.getValue(Boolean::class.java) == true
                }
                override fun onCancelled(error: DatabaseError) {
                    connected = false
                    status = error.message
                }
            }
            connectionRef.addValueEventListener(connectionListener)
            onDispose { connectionRef.removeEventListener(connectionListener) }
        }
    }

    DisposableEffect(roomCode, root) {
        val code = roomCode
        if (code == null || root == null) {
            onDispose { }
        } else {
            val ref = root.child(code)
            val l = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    roomSnapshot = snapshot.value as? Map<String, Any?>
                    if (!snapshot.exists()) { roomCode = null; status = if (english) "Room closed or not found." else "الغرفة اتقفلت أو مش موجودة." }
                }
                override fun onCancelled(error: DatabaseError) { status = error.message }
            }
            listenerRef = ref; listener = l; ref.addValueEventListener(l)
            onDispose { ref.removeEventListener(l); listenerRef = null; listener = null }
        }
    }

    fun makeRoom() {
        if (root == null) { status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."; return }
        if (connected != true) {
            status = if (english) "Connecting to the room server. Try again when the connection indicator turns green." else "لسه بنتصل بسيرفر الغرف. جرّب تاني لما الاتصال يتأكد."
            return
        }
        busy = true
        status = if (english) "Creating room…" else "جاري إنشاء الغرفة…"
        val code = ElbashaRoomRules.generateCode()
        val room = root.child(code)
        val displayName = user.displayName?.trim()?.takeIf { it.isNotEmpty() }
            ?: user.email?.substringBefore("@")?.takeIf { it.isNotEmpty() }
            ?: "Player"
        val payload = mapOf(
            "hostUid" to user.uid,
            "createdAt" to ServerValue.TIMESTAMP,
            "status" to "lobby",
            "gameType" to "lobby",
            "maxPlayers" to ROOM_CAPACITY,
            "members" to mapOf(user.uid to mapOf(
                "name" to displayName.take(40),
                "ready" to true,
                "joinedAt" to ServerValue.TIMESTAMP,
                "seat" to 0
            ))
        )
        // A fresh random six-character code makes collisions exceptionally unlikely.
        // A normal write is faster than a transaction that first downloads and retries the room.
        room.setValue(payload).addOnCompleteListener { task ->
            busy = false
            if (task.isSuccessful) {
                roomCode = code
                status = if (english) "Room created. Share this code with your friends." else "الغرفة اتعملت. ابعت الكود لأصحابك."
            } else {
                val detail = task.exception?.localizedMessage.orEmpty()
                status = if (detail.contains("permission", ignoreCase = true)) {
                    if (english) "Firebase denied room creation. Publish the latest onlineRooms rules." else "Firebase رفض إنشاء الغرفة. انشر آخر قواعد onlineRooms من ملف المشروع."
                } else detail.ifBlank { if (english) "Room creation failed. Check your connection and try again." else "فشل إنشاء الغرفة. راجع الاتصال وجرب تاني." }
            }
        }
    }


    fun joinRoom() {
        val code = ElbashaRoomRules.normalizeCode(codeInput)
        if (!ElbashaRoomRules.validCode(code)) { status = if (english) "Enter a six-character room code." else "اكتب كود غرفة من 6 حروف/أرقام."; return }
        if (root == null) { status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."; return }
        busy = true
        status = if (english) "Joining room…" else "جاري دخول الغرفة…"
        val ref = root.child(code)

        // Reconnect an existing member without committing a no-op transaction at the room root.
        ref.child("members").child(user.uid).get().addOnCompleteListener memberLookup@{ lookup ->
            if (!lookup.isSuccessful) {
                busy = false
                val detail = lookup.exception?.localizedMessage.orEmpty()
                status = if (detail.contains("permission", ignoreCase = true)) {
                    if (english) "Firebase denied room access. Publish the current firebase/database.rules.json rules to the same Realtime Database used by the app."
                    else "Firebase رفض الوصول للغرفة. انشر قواعد firebase/database.rules.json الحالية على نفس قاعدة البيانات المستخدمة في التطبيق."
                } else detail.ifBlank { if (english) "Could not check room membership." else "تعذر التحقق من عضويتك في الغرفة." }
                return@memberLookup
            }
            if (lookup.result.exists()) {
                busy = false
                roomCode = code
                status = if (english) "Reconnected to room." else "تم استكمال دخولك للغرفة."
                return@memberLookup
            }

            ref.runTransaction(object : Transaction.Handler {
                override fun doTransaction(current: MutableData): Transaction.Result {
                    if (current.value == null || current.child("status").value != "lobby") return Transaction.abort()
                    val members = current.child("members")
                    if (members.child(user.uid).value != null) return Transaction.abort()
                    if (members.childrenCount >= ROOM_CAPACITY) return Transaction.abort()
                    val occupied = members.children.mapNotNull { (it.child("seat").value as? Number)?.toInt() }.toSet()
                    val seat = (0 until ROOM_CAPACITY).firstOrNull { it !in occupied } ?: return Transaction.abort()
                    val displayName = user.displayName?.trim()?.takeIf { it.isNotEmpty() }
                        ?: user.email?.substringBefore("@")?.trim()?.takeIf { it.isNotEmpty() }
                        ?: "Player"
                    members.child(user.uid).value = mapOf(
                        "name" to displayName.take(40),
                        "ready" to false,
                        "joinedAt" to ServerValue.TIMESTAMP,
                        "seat" to seat
                    )
                    return Transaction.success(current)
                }
                override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                    busy = false
                    if (error?.code == DatabaseError.PERMISSION_DENIED) {
                        status = if (english) {
                            "Firebase denied joining this room. Publish the supplied firebase/database.rules.json in Realtime Database > Rules for this project."
                        } else {
                            "Firebase رفض دخول الغرفة. انشر ملف firebase/database.rules.json المرفق في Realtime Database > Rules لنفس المشروع."
                        }
                    } else if (error != null) status = error.message
                    else if (committed) {
                        roomCode = code
                        status = if (english) "Joined room." else "دخلت الغرفة."
                    } else status = if (english) "Room does not exist, is closed, or is full (10 players max)." else "الغرفة مش موجودة أو اتقفلت أو وصلت 10 لاعبين."
                }
            })
        }
    }

    fun toggleReady() {
        val code = roomCode ?: return
        root?.child(code)?.child("members")?.child(user.uid)?.child("ready")?.run {
            get().addOnSuccessListener { snap -> setValue(!(snap.getValue(Boolean::class.java) ?: false)) }
        }
    }

    fun leaveRoom() {
        val code = roomCode ?: return
        val ref = root?.child(code) ?: return
        ref.child("hostUid").get().addOnSuccessListener { hostSnap ->
            if (hostSnap.getValue(String::class.java) == user.uid) ref.removeValue()
            else ref.child("members").child(user.uid).removeValue()
            roomCode = null; roomSnapshot = null; status = if (english) "You left the room." else "خرجت من الغرفة."
        }
    }

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onExit) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(if (english) "ONLINE ROOMS" else "الغرف الأونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(8.dp).background(if (connected == true) Color(0xFF42C982) else Color(0xFFD19A43), RoundedCornerShape(50)))
            Text(when (connected) {
                true -> if (english) "Server connected" else "السيرفر متصل"
                false -> if (english) "Server offline" else "السيرفر غير متصل"
                else -> if (english) "Connecting…" else "جاري الاتصال…"
            }, color = palette.muted, fontSize = 11.sp)
        }
        Text(if (english) "Create a private room for up to 10 players." else "اعمل غرفة خاصة للجروب لحد 10 لاعبين.", color = palette.muted)
        Card(colors = CardDefaults.cardColors(containerColor = palette.panelAlt), shape = RoundedCornerShape(14.dp)) {
            Text(if (english) "This page is a general friends lobby. To start a synchronized match, choose Online from inside Auction, Deal or No Deal, or Build a Team." else "دي غرفة عامة للأصدقاء. لبدء مباراة متزامنة، اختار أونلاين من داخل المزاد أو ديل أور نو ديل أو كوّن فريق.", color = palette.muted, fontSize = 11.sp, modifier = Modifier.padding(12.dp))
        }
        if (roomCode == null) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { makeRoom() }, enabled = !busy && connected == true, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Create room" else "إنشاء غرفة", fontWeight = FontWeight.Bold) }
                    OutlinedTextField(value = codeInput, onValueChange = { codeInput = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, label = { Text(if (english) "Room code" else "كود الغرفة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { joinRoom() }, enabled = !busy && connected == true, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)) { Text(if (english) "Join room" else "دخول غرفة") }
                }
            }
        } else {
            val members = ((roomSnapshot?.get("members") as? Map<*, *>) ?: emptyMap<Any, Any>()).entries
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (english) "ROOM CODE" else "كود الغرفة", color = palette.muted, fontSize = 11.sp)
                    Text(roomCode!!, color = palette.gold, fontSize = 34.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(if (english) "${members.size}/10 players" else "${members.size}/10 لاعبين", color = palette.cream, fontWeight = FontWeight.Bold)
                    members.forEach { entry ->
                        val details = entry.value as? Map<*, *> ?: emptyMap<Any, Any>()
                        val name = details["name"]?.toString() ?: "Player"
                        val ready = details["ready"] == true
                        Row(Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = palette.cream, modifier = Modifier.weight(1f))
                            Text(if (ready) (if (english) "READY" else "جاهز") else (if (english) "WAITING" else "منتظر"), color = if (ready) palette.gold else palette.muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                    Button(onClick = { toggleReady() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Toggle ready" else "تغيير حالة جاهزيتي") }
                    Button(onClick = { leaveRoom() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.bad, contentColor = Color.White)) { Text(if (english) "Leave room" else "مغادرة الغرفة") }
                }
            }
        }
        if (status.isNotBlank()) Text(status, color = palette.gold, fontSize = 12.sp)
        if (database == null) Text(if (english) "Firebase is not available. Online rooms require a live Realtime Database connection." else "الغرف محتاجة اتصال Firebase Realtime Database شغال.", color = palette.bad)
    }
}
