package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase

/**
 * Central online entry: choose a game, choose that game's mode, confirm, then
 * create or join a room from the match lobby.
 */
@Composable
fun OnlineRoomsScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var selectedGame by remember { mutableStateOf<String?>(null) }
    var setupConfirmed by remember { mutableStateOf(false) }
    var auctionPro by remember { mutableStateOf(false) }
    var auctionCards by remember { mutableStateOf(true) }
    var buildRoster by remember { mutableStateOf(BuildTeamRosterFilter.RANDOM) }
        var dealTurnSeconds by remember { mutableIntStateOf(30) }
    var dealCardsPerPlayer by remember { mutableIntStateOf(2) }

    BackHandler {
        when {
            setupConfirmed -> setupConfirmed = false
            selectedGame != null -> selectedGame = null
            else -> onExit()
        }
    }

    if (setupConfirmed) {
        when (selectedGame) {
            "auction" -> {
                OnlineAuctionScreen(
                    user = user,
                    database = database,
                    sound = sound,
                    onExit = { setupConfirmed = false; selectedGame = null },
                    initialPro = auctionPro,
                    initialCardsMode = auctionCards,
                    setupLocked = true
                )
                return
            }
            "build" -> {
                OnlineBuildTeamScreen(
                    user = user,
                    database = database,
                    sound = sound,
                    onExit = { setupConfirmed = false; selectedGame = null },
                    initialRosterFilter = buildRoster,
                    setupLocked = true
                )
                return
            }
            "deal" -> {
                OnlineDealScreen(
                    user = user,
                    database = database,
                    sound = sound,
                    onExit = { setupConfirmed = false; selectedGame = null },
                    targetCount = ONLINE_DEAL_SQUAD_SIZE,
                    turnTimeSeconds = dealTurnSeconds,
                    cardsPerPlayer = dealCardsPerPlayer,
                    setupLocked = true
                )
                return
            }
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = {
            if (selectedGame != null) selectedGame = null else onExit()
        }) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(if (english) "ONLINE MATCH" else "العب أونلاين", color = palette.gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(
            if (selectedGame == null)
                (if (english) "Choose the game you want to play with your friends." else "اختار اللعبة اللي عايز تلعبها مع أصحابك.")
            else
                (if (english) "Choose the mode, then confirm to create a room or join by code." else "اختار المود، وبعد التأكيد هتقدر تنشئ غرفة أو تدخل بكود غرفة.") ,
            color = palette.muted,
            fontSize = 12.sp
        )

        if (selectedGame == null) {
            OnlineGameChoiceCard(
                title = if (english) "Deal or No Deal • ONLINE" else "صندوق الحظ • أونلاين",
                subtitle = if (english) "2–4 players • 11 players + coach • private cases • final cards" else "من 2 لـ4 لاعبين • 11 لاعب + مدرب • صناديق سرية • كروت نهائية",
                selected = false,
                onClick = { selectedGame = "deal" }
            )
            OnlineGameChoiceCard(
                title = if (english) "Football Auction" else "المزاد الكروي",
                subtitle = if (english) "Build your squad by bidding" else "كوّن تشكيلتك بالمزايدة",
                selected = false,
                onClick = { selectedGame = "auction" }
            )
            OnlineGameChoiceCard(
                title = if (english) "Build a Team • ONLINE" else "كوّن فريق • أونلاين",
                subtitle = if (english) "2–4 players • 11 positions • changing challenges and stats" else "من 2 لـ4 لاعبين • 11 مركز • تحديات وإحصائيات متغيرة",
                selected = false,
                onClick = { selectedGame = "build" }
            )
        } else when (selectedGame) {
            "auction" -> {
                Text(if (english) "AUCTION SIZE" else "حجم المزاد", color = palette.cream, fontWeight = FontWeight.Black)
                OnlineGameChoiceCard(
                    title = "CLASSIC",
                    subtitle = if (english) "5 players • 100M budget" else "5 لاعبين • ميزانية 100 مليون",
                    selected = !auctionPro,
                    onClick = { auctionPro = false }
                )
                OnlineGameChoiceCard(
                    title = "PRO MAX",
                    subtitle = if (english) "11 players • 200M budget" else "11 لاعب • ميزانية 200 مليون",
                    selected = auctionPro,
                    onClick = { auctionPro = true }
                )
                Text(if (english) "POST-AUCTION MODE" else "مود ما بعد المزاد", color = palette.cream, fontWeight = FontWeight.Black)
                OnlineGameChoiceCard(
                    title = if (english) "Cards mode" else "مود الكروت",
                    subtitle = if (english) "Protection and steal phase" else "مرحلة الحماية والسرقة",
                    selected = auctionCards,
                    onClick = { auctionCards = true }
                )
                OnlineGameChoiceCard(
                    title = if (english) "Normal mode" else "المود الطبيعي",
                    subtitle = if (english) "No special cards" else "من غير كروت خاصة",
                    selected = !auctionCards,
                    onClick = { auctionCards = false }
                )
                Button(onClick = { setupConfirmed = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(if (english) "Confirm auction mode" else "تأكيد مود المزاد", fontWeight = FontWeight.Black)
                }
            }
            "build" -> {
                Text(if (english) "PLAYER POOL" else "مجموعة اللاعبين", color = palette.cream, fontWeight = FontWeight.Black)
                listOf(
                    BuildTeamRosterFilter.ALL,
                    BuildTeamRosterFilter.CURRENT,
                    BuildTeamRosterFilter.RETIRED,
                    BuildTeamRosterFilter.RANDOM
                ).forEach { option ->
                    OnlineGameChoiceCard(
                        title = if (english) option.labelEn else option.labelAr,
                        subtitle = when (option) {
                            BuildTeamRosterFilter.ALL -> if (english) "All players are eligible" else "كل اللاعبين متاحين"
                            BuildTeamRosterFilter.CURRENT -> if (english) "Current players only" else "اللاعبون الحاليون فقط"
                            BuildTeamRosterFilter.RETIRED -> if (english) "Retired players only" else "اللاعبون المعتزلون فقط"
                            BuildTeamRosterFilter.RANDOM -> if (english) "The game changes the filter each round" else "اللعبة بتغيّر الفلتر في كل جولة"
                        },
                        selected = buildRoster == option,
                        onClick = { buildRoster = option }
                    )
                }
                Text(if (english) "The online match uses the same 11-position format as local play." else "المباراة الأونلاين هتستخدم نفس نظام الـ11 مركز بتاع اللعب المحلي.", color = palette.muted, fontSize = 11.sp)
                Button(onClick = { setupConfirmed = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(if (english) "Confirm game mode" else "تأكيد المود", fontWeight = FontWeight.Black)
                }
            }
            "deal" -> {
                OnlineGameChoiceCard(
                    title = if (english) "11 players + coach" else "11 لاعب + مدرب",
                    subtitle = if (english) "Full squad, one coach per player — same as the local game" else "تشكيلة كاملة ومدرب لكل لاعب — نفس اللعب المحلي",
                    selected = true,
                    onClick = {}
                )
                TurnTimeSelector(selectedSeconds = dealTurnSeconds, onSelect = { dealTurnSeconds = it })
                Text(if (english) "FINAL CARDS PER PLAYER" else "عدد الكروت لكل لاعب", color = palette.cream, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { count ->
                        OnlineDealConfigChoice(count.toString(), dealCardsPerPlayer == count) { dealCardsPerPlayer = count }
                    }
                }
                Text(if (english) "Every turn follows the same Deal / No Deal, forced-risk, case reveal, coach and 60-second card rules as local play." else "نفس نظام Deal / No Deal والمخاطرة الإجبارية وكشف الصناديق والمدربين ومرحلة الكروت 60 ثانية الموجود في اللعب المحلي.", color = palette.muted, fontSize = 11.sp)
                Button(onClick = { setupConfirmed = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) {
                    Text(if (english) "Confirm Deal mode" else "تأكيد إعداد صندوق الحظ", fontWeight = FontWeight.Black)
                }
            }
        }
        if (database == null) {
            Text(if (english) "Firebase is not available. Online matches need a live connection." else "Firebase مش متاح. اللعب أونلاين محتاج اتصال شغال.", color = palette.bad, fontSize = 11.sp)
        }
    }
}


@Composable
private fun androidx.compose.foundation.layout.RowScope.OnlineDealConfigChoice(label: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.weight(1f).height(48.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) palette.gold else palette.panel),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(label, color = if (selected) palette.deepWine else palette.cream, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun OnlineGameChoiceCard(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) palette.gold else palette.panel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = if (selected) palette.deepWine else palette.cream, fontWeight = FontWeight.Black)
                Text(subtitle, color = if (selected) palette.deepWine else palette.muted, fontSize = 10.sp)
            }
            if (selected) Text("✓", color = palette.deepWine, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
    }
}
