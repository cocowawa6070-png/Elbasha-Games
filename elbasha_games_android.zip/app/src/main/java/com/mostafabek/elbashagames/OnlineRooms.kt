package com.mostafabek.elbashagames

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

private const val ROOM_CAPACITY = ELBASHA_ROOM_CAPACITY

@Composable
fun OnlineRoomsScreen(user: FirebaseUser, database: FirebaseDatabase?, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var codeInput by remember { mutableStateOf("") }
    var roomCode by remember { mutableStateOf<String?>(null) }
    var roomSnapshot by remember { mutableStateOf<Map<String, Any?>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var listenerRef by remember { mutableStateOf<DatabaseReference?>(null) }
    var listener by remember { mutableStateOf<ValueEventListener?>(null) }
    val root = database?.reference?.child("onlineRooms")

    DisposableEffect(roomCode, root) {
        val code = roomCode
        if (code == null || root == null) {
            onDispose { }
        } else {
            val ref = root.child(code)
            val l = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    roomSnapshot = snapshot.value as? Map<String, Any?>
                    if (!snapshot.exists()) { roomCode = null; status = if (english) "Room closed or not found." else "الغرفة اتقفلت أو مش موجودة." }
                }
                override fun onCancelled(error: DatabaseError) { status = error.message }
            }
            listenerRef = ref; listener = l; ref.addValueEventListener(l)
            onDispose { ref.removeEventListener(l); listenerRef = null; listener = null }
        }
    }

    fun makeRoom() {
        if (root == null) { status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."; return }
        busy = true; status = ""
        val code = ElbashaRoomRules.generateCode()
        val room = root.child(code)
        val payload = mapOf("hostUid" to user.uid, "createdAt" to ServerValue.TIMESTAMP,
            "status" to "lobby", "members" to mapOf(user.uid to mapOf("name" to (user.displayName ?: user.email?.substringBefore("@") ?: "Player"), "ready" to true, "joinedAt" to ServerValue.TIMESTAMP)))
        room.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                if (current.value != null) return Transaction.abort()
                current.value = payload
                return Transaction.success(current)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                if (error != null) status = error.message
                else if (committed) { roomCode = code; status = if (english) "Room created. Share this code with your friends." else "الغرفة اتعملت. ابعت الكود لأصحابك." }
                else status = if (english) "Code collision. Try again." else "الكود اتكرر، جرّب تاني."
            }
        })
    }


    fun joinRoom() {
        val code = ElbashaRoomRules.normalizeCode(codeInput)
        if (!ElbashaRoomRules.validCode(code)) { status = if (english) "Enter a six-character room code." else "اكتب كود غرفة من 6 حروف/أرقام."; return }
        if (root == null) { status = if (english) "Firebase connection is not configured." else "Firebase مش متوصل."; return }
        busy = true; status = ""
        val ref = root.child(code)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                if (current.value == null || current.child("status").value != "lobby") return Transaction.abort()
                val members = current.child("members")
                val existing = members.child(user.uid).value != null
                if (!existing && members.childrenCount >= ROOM_CAPACITY) return Transaction.abort()
                members.child(user.uid).value = mapOf("name" to (user.displayName ?: user.email?.substringBefore("@") ?: "Player"), "ready" to false, "joinedAt" to ServerValue.TIMESTAMP)
                return Transaction.success(current)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                busy = false
                if (error != null) status = error.message
                else if (committed) { roomCode = code; status = if (english) "Joined room." else "دخلت الغرفة." }
                else status = if (english) "Room does not exist or is full (10 players max)." else "الغرفة مش موجودة أو وصلت 10 لاعبين."
            }
        })
    }


    fun toggleReady() {
        val code = roomCode ?: return
        root?.child(code)?.child("members")?.child(user.uid)?.child("ready")?.run {
            get().addOnSuccessListener { snap -> setValue(!(snap.getValue(Boolean::class.java) ?: false)) }
        }
    }

    fun leaveRoom() {
        val code = roomCode ?: return
        val ref = root?.child(code) ?: return
        ref.child("hostUid").get().addOnSuccessListener { hostSnap ->
            if (hostSnap.getValue(String::class.java) == user.uid) ref.removeValue()
            else ref.child("members").child(user.uid).removeValue()
            roomCode = null; roomSnapshot = null; status = if (english) "You left the room." else "خرجت من الغرفة."
        }
    }

    Column(Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onExit) { Text(if (english) "← Back" else "→ رجوع", color = palette.gold) }
        Text(if (english) "ONLINE ROOMS" else "الغرف الأونلاين", color = palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(if (english) "Create a private room for up to 10 players." else "اعمل غرفة خاصة للجروب لحد 10 لاعبين.", color = palette.muted)
        Card(colors = CardDefaults.cardColors(containerColor = palette.panelAlt), shape = RoundedCornerShape(14.dp)) {
            Text(if (english) "Lobby support is available: room codes, live members, and ready state. Game-session synchronization is not yet wired into these rooms." else "المتاح حاليًا هو اللوبي: كود الغرفة، الأعضاء لحظيًا، وحالة الجاهزية. مزامنة اللعب نفسه بين الأجهزة لم يتم ربطها بعد.", color = palette.muted, fontSize = 11.sp, modifier = Modifier.padding(12.dp))
        }
        if (roomCode == null) {
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { makeRoom() }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Create room" else "إنشاء غرفة", fontWeight = FontWeight.Bold) }
                    OutlinedTextField(value = codeInput, onValueChange = { codeInput = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) }, label = { Text(if (english) "Room code" else "كود الغرفة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { joinRoom() }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.cream)) { Text(if (english) "Join room" else "دخول غرفة") }
                }
            }
        } else {
            val members = ((roomSnapshot?.get("members") as? Map<*, *>) ?: emptyMap<Any, Any>()).entries
            Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (english) "ROOM CODE" else "كود الغرفة", color = palette.muted, fontSize = 11.sp)
                    Text(roomCode!!, color = palette.gold, fontSize = 34.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Text(if (english) "${members.size}/10 players" else "${members.size}/10 لاعبين", color = palette.cream, fontWeight = FontWeight.Bold)
                    members.forEach { entry ->
                        val details = entry.value as? Map<*, *> ?: emptyMap<Any, Any>()
                        val name = details["name"]?.toString() ?: "Player"
                        val ready = details["ready"] == true
                        Row(Modifier.fillMaxWidth().background(palette.panelAlt, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = palette.cream, modifier = Modifier.weight(1f))
                            Text(if (ready) (if (english) "READY" else "جاهز") else (if (english) "WAITING" else "منتظر"), color = if (ready) palette.gold else palette.muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                    Button(onClick = { toggleReady() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.gold, contentColor = palette.deepWine)) { Text(if (english) "Toggle ready" else "تغيير حالة جاهزيتي") }
                    Button(onClick = { leaveRoom() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = palette.bad, contentColor = Color.White)) { Text(if (english) "Leave room" else "مغادرة الغرفة") }
                }
            }
        }
        if (status.isNotBlank()) Text(status, color = palette.gold, fontSize = 12.sp)
        if (database == null) Text(if (english) "Firebase is not available. Online rooms require a live Realtime Database connection." else "الغرف محتاجة اتصال Firebase Realtime Database شغال.", color = palette.bad)
    }
}
