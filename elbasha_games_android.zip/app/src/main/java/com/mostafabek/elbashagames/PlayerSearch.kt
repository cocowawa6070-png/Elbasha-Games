package com.mostafabek.elbashagames

/** Shared player-name search for every game that asks users to enter a footballer's name. */
object PlayerSearch {
    private val arabicNames = mapOf(
        "Manuel Neuer" to "مانويل نوير", "Iker Casillas" to "إيكر كاسياس",
        "Gianluigi Buffon" to "جانلويجي بوفون", "Thibaut Courtois" to "تيبو كورتوا",
        "Alisson Becker" to "أليسون بيكر", "Mohamed El Shenawy" to "محمد الشناوي",
        "Essam El Hadary" to "عصام الحضري", "Paolo Maldini" to "باولو مالديني",
        "Sergio Ramos" to "سيرخيو راموس", "Virgil van Dijk" to "فيرجيل فان دايك",
        "Achraf Hakimi" to "أشرف حكيمي", "Zinedine Zidane" to "زين الدين زيدان",
        "Andres Iniesta" to "أندريس إنييستا", "Xavi Hernandez" to "تشافي هيرنانديز",
        "Luka Modric" to "لوكا مودريتش", "Toni Kroos" to "توني كروس",
        "Kevin De Bruyne" to "كيفن دي بروين", "Jude Bellingham" to "جود بيلينجهام",
        "Mohamed Aboutrika" to "محمد أبو تريكة", "Lionel Messi" to "ليونيل ميسي",
        "Cristiano Ronaldo" to "كريستيانو رونالدو", "Mohamed Salah" to "محمد صلاح",
        "Neymar Jr" to "نيمار", "Riyad Mahrez" to "رياض محرز",
        "Kylian Mbappe" to "كيليان مبابي", "Vinicius Junior" to "فينيسيوس جونيور",
        "Lamine Yamal" to "لامين يامال", "Bukayo Saka" to "بوكايو ساكا",
        "Son Heung-min" to "سون هيونج مين", "Erling Haaland" to "إيرلينج هالاند",
        "Harry Kane" to "هاري كين", "Robert Lewandowski" to "روبرت ليفاندوفسكي",
        "Karim Benzema" to "كريم بنزيما", "Sadio Mane" to "ساديو ماني",
        "Didier Drogba" to "ديدييه دروجبا", "Samuel Eto'o" to "صامويل إيتو",
        "Ronaldinho" to "رونالدينيو", "Kaka" to "كاكا", "Rivaldo" to "ريفالدو",
        "Petr Cech" to "بيتر تشيك", "Ederson" to "إيدرسون", "Jan Oblak" to "يان أوبلاك",
        "Marc-Andre ter Stegen" to "مارك أندريه تير شتيجن", "Emiliano Martinez" to "إيميليانو مارتينيز",
        "David de Gea" to "دافيد دي خيا", "Keylor Navas" to "كيلور نافاس", "Hugo Lloris" to "هوجو لوريس",
        "Oliver Kahn" to "أوليفر كان", "Peter Schmeichel" to "بيتر شمايكل", "Dida" to "ديدا",
        "Jose Luis Chilavert" to "خوسيه لويس تشيلافيرت", "Rene Higuita" to "رينيه هيجيتا",
        "Yassine Bounou" to "ياسين بونو", "Mike Maignan" to "مايك مانيان", "Gianluigi Donnarumma" to "جيانلويجي دوناروما",
        "Unai Simon" to "أوناي سيمون", "Jordan Pickford" to "جوردان بيكفورد", "Andre Onana" to "أندريه أونانا",
        "Samir Handanovic" to "سمير هاندانوفيتش", "Edwin van der Sar" to "إدوين فان دير سار",
        "Claudio Bravo" to "كلاوديو برافو", "Walter Zenga" to "والتر زينجا",
        "Franco Baresi" to "فرانكو باريزي", "Alessandro Nesta" to "أليساندرو نيستا", "Fabio Cannavaro" to "فابيو كانافارو",
        "Carles Puyol" to "كارليس بويول", "Rio Ferdinand" to "ريو فرديناند", "Nemanja Vidic" to "نيمانيا فيديتش",
        "John Terry" to "جون تيري", "Gerard Pique" to "جيرارد بيكيه", "Thiago Silva" to "تياغو سيلفا",
        "Ruben Dias" to "روبن دياز", "Antonio Rudiger" to "أنطونيو روديجر", "Trent Alexander-Arnold" to "ترنت ألكسندر أرنولد",
        "Dani Alves" to "داني ألفيش", "Cafu" to "كافو", "Roberto Carlos" to "روبرتو كارلوس", "Marcelo" to "مارسيلو",
        "Ashley Cole" to "آشلي كول", "Philipp Lahm" to "فيليب لام", "Javier Zanetti" to "خافيير زانيتي",
        "Raphael Varane" to "رافاييل فاران", "William Saliba" to "ويليام ساليبا", "Alessandro Bastoni" to "أليساندرو باستوني",
        "Kim Min-jae" to "كيم مين جاي", "Ronald Araujo" to "رونالد أراوخو", "John Stones" to "جون ستونز",
        "Kyle Walker" to "كايل ووكر", "Theo Hernandez" to "ثيو هيرنانديز", "Andrew Robertson" to "أندرو روبرتسون",
        "Giorgio Chiellini" to "جورجيو كيليني", "Leonardo Bonucci" to "ليوناردو بونوتشي", "Jaap Stam" to "ياب ستام",
        "Andrea Pirlo" to "أندريا بيرلو", "Steven Gerrard" to "ستيفن جيرارد", "Frank Lampard" to "فرانك لامبارد",
        "Paul Scholes" to "بول سكولز", "Patrick Vieira" to "باتريك فييرا", "Claude Makelele" to "كلود ماكيليلي",
        "Sergio Busquets" to "سيرجيو بوسكيتس", "Rodri" to "رودري", "Pedri" to "بيدري", "Jamal Musiala" to "جمال موسيالا",
        "Federico Valverde" to "فيديريكو فالفيردي", "Declan Rice" to "ديكلان رايس", "Bruno Fernandes" to "برونو فيرنانديز",
        "Yaya Toure" to "يايا توريه", "Clarence Seedorf" to "كلارنس سيدورف", "Michel Platini" to "ميشيل بلاتيني",
        "Lothar Matthaus" to "لوثار ماتيوس", "Roy Keane" to "روي كين", "Cesc Fabregas" to "سيسك فابريجاس",
        "Mesut Ozil" to "مسعود أوزيل", "David Silva" to "دافيد سيلفا", "Bastian Schweinsteiger" to "باستيان شفاينشتايجر",
        "Hossam Ghaly" to "حسام غالي", "Mohamed Elneny" to "محمد النني",
        "Michael Olise" to "مايكل أوليسيه", "Vitinha" to "فيتينيا", "Nuno Mendes" to "نونو مينديز",
        "Gabriel Magalhaes" to "جابرييل ماجالهايس", "Willian Pacho" to "ويليان باتشو", "Joao Neves" to "جواو نيفيز",
        "Joshua Kimmich" to "جوشوا كيميش", "Luis Diaz" to "لويس دياز", "Florian Wirtz" to "فلوريان فيرتز",
        "Martin Odegaard" to "مارتن أوديجارد", "Enzo Fernandez" to "إنزو فيرنانديز", "Rayan Cherki" to "ريان شرقي",
        "Viktor Gyokeres" to "فيكتور جيوكيريس", "Alexander Isak" to "ألكسندر إيزاك",
        "Arjen Robben" to "أريين روبن", "Franck Ribery" to "فرانك ريبيري", "Gareth Bale" to "جاريث بيل",
        "Eden Hazard" to "إيدين هازارد", "Luis Figo" to "لويس فيجو", "George Best" to "جورج بست",
        "Ryan Giggs" to "ريان جيجز", "Luis Suarez" to "لويس سواريز", "Raphinha" to "رافينيا",
        "Ousmane Dembele" to "عثمان ديمبيلي", "Khvicha Kvaratskhelia" to "خفيتشا كفاراتسخيليا",
        "Angel Di Maria" to "أنخيل دي ماريا", "Alexis Sanchez" to "أليكسيس سانشيز", "David Beckham" to "ديفيد بيكهام",
        "Stanley Matthews" to "ستانلي ماثيوز", "Hristo Stoichkov" to "خريستو ستويتشكوف", "Robert Pires" to "روبير بيريس",
        "Pierre-Emerick Aubameyang" to "بيير إيمريك أوباميانج", "Raheem Sterling" to "رحيم سترلينج",
        "Pele" to "بيليه", "Diego Maradona" to "دييجو مارادونا", "Ronaldo Nazario" to "رونالدو نازاريو",
        "Thierry Henry" to "تييري هنري", "Zlatan Ibrahimovic" to "زلاتان إبراهيموفيتش", "Wayne Rooney" to "واين روني",
        "Ruud van Nistelrooy" to "رود فان نيستلروي", "Marco van Basten" to "ماركو فان باستن", "Gerd Muller" to "جيرد مولر",
        "Eusebio" to "يوزيبيو", "Ferenc Puskas" to "فيرينتس بوشكاش", "Romario" to "روماريو",
        "Gabriel Batistuta" to "جابرييل باتيستوتا", "Alan Shearer" to "آلان شيرر", "Sergio Aguero" to "سيرخيو أجويرو",
        "Jorge Campos" to "خورخي كامبوس", "David Seaman" to "ديفيد سيمان", "Victor Valdes" to "فيكتور فالديس", "Shaka Hislop" to "شاكا هيسلوب",
        "Lilian Thuram" to "ليليان تورام", "Marcel Desailly" to "مارسيل ديسايي", "Sol Campbell" to "سول كامبل", "Wael Gomaa" to "وائل جمعة",
        "Ahmed Hegazi" to "أحمد حجازي", "Mohamed Hany" to "محمد هاني", "Jay-Jay Okocha" to "جاي جاي أوكوشا", "Michael Essien" to "مايكل إيسيان",
        "N'Golo Kante" to "نجولو كانتي", "Gennaro Gattuso" to "جينارو جاتوزو", "Park Ji-sung" to "بارك جي سونغ", "Shinji Kagawa" to "شينجي كاغاوا",
        "Ahmed Hassan" to "أحمد حسن", "Nani" to "ناني", "Pedro Rodriguez" to "بيدرو رودريغيز", "Mohamed Zidan" to "محمد زيدان",
        "Angel Correa" to "أنخيل كوريا", "Hossam Hassan" to "حسام حسن", "Miroslav Klose" to "ميروسلاف كلوزه", "Robin van Persie" to "روبن فان بيرسي",
        "Filippo Inzaghi" to "فيليبو إنزاغي", "Edinson Cavani" to "إدينسون كافاني", "Hernan Crespo" to "هرنان كريسبو",
        "David Raya" to "دافيد رايا", "Lucio" to "لوسيو", "Carlos Alberto" to "كارلوس ألبرتو",
        "Xabi Alonso" to "تشابي ألونسو", "Bobby Charlton" to "بوبي تشارلتون", "Frank Rijkaard" to "فرانك ريكارد",
        "Jens Lehmann" to "ينس ليمان",
        "Fabien Barthez" to "فابيان بارتيز",
        "Tim Howard" to "تيم هاورد",
        "Brad Friedel" to "براد فريدل",
        "Claudio Taffarel" to "كلاوديو تافاريل",
        "Mark Schwarzer" to "مارك شوارزر",
        "Pepe" to "بيبي",
        "Vincent Kompany" to "فنسنت كومباني",
        "Mats Hummels" to "ماتس هوملز",
        "Bixente Lizarazu" to "بيكسنت ليزارازو",
        "Patrice Evra" to "باتريس إيفرا",
        "Eric Abidal" to "إيريك أبيدال",
        "Dani Carvajal" to "داني كارفاخال",
        "Kieran Trippier" to "كيران تريبيير",
        "Giuseppe Bergomi" to "جوزيبي بيرغومي",
        "Frank de Boer" to "فرانك دي بور",
        "Michael Ballack" to "مايكل بالاك",
        "Juan Roman Riquelme" to "خوان رومان ريكيلمي",
        "Michael Laudrup" to "مايكل لاودروب",
        "Pavel Nedved" to "بافيل نيدفيد",
        "Gheorghe Hagi" to "جورجي حاجي",
        "Juan Sebastian Veron" to "خوان سيباستيان فيرون",
        "Thomas Muller" to "توماس مولر",
        "Guti" to "جوتي",
        "Arturo Vidal" to "أرتورو فيدال",
        "Deco" to "ديكو",
        "Antoine Griezmann" to "أنطوان جريزمان",
        "Juan Mata" to "خوان ماتا",
        "Hakim Ziyech" to "حكيم زياش",
        "Willian" to "ويليان",
        "Jesus Navas" to "خيسوس نافاس",
        "Ricardo Quaresma" to "ريكاردو كواريزما",
        "Dirk Kuyt" to "ديرك كاوت",
        "Wilfried Zaha" to "ويلفريد زاها",
        "Michael Owen" to "مايكل أوين",
        "David Villa" to "دافيد فيا",
        "George Weah" to "جورج ويا",
        "Carlos Tevez" to "كارلوس تيفيز",
        "Edin Dzeko" to "إدين دجيكو",
        "Christian Vieri" to "كريستيان فييري",
        "Robbie Fowler" to "روبي فاولر",
        "Ian Wright" to "إيان رايت",
        "Mario Gomez" to "ماريو جوميز",
        "Gonzalo Higuain" to "غونزالو هيغواين",
        "Lev Yashin" to "ليف ياشين",
        "Dino Zoff" to "دينو زوف",
        "Gordon Banks" to "جوردون بانكس",
        "Pepe Reina" to "بيبي رينا",
        "Kasper Schmeichel" to "كاسبر شمايكل",
        "Diogo Costa" to "ديوجو كوستا",
        "Sepp Maier" to "زيب ماير",
        "Franz Beckenbauer" to "فرانتس بيكنباور",
        "Bobby Moore" to "بوبي مور",
        "Gaetano Scirea" to "جايتانو شيريا",
        "Fernando Hierro" to "فرناندو هييرو",
        "Laurent Blanc" to "لوران بلان",
        "Ricardo Carvalho" to "ريكاردو كارفاليو",
        "Jerome Boateng" to "جيروم بواتينج",
        "Dayot Upamecano" to "دايوت أوباميكانو",
        "Pau Cubarsi" to "باو كوبارسي",
        "Josko Gvardiol" to "يوشكو جفارديول",
        "Marquinhos" to "ماركينيوس",
        "Milan Skriniar" to "ميلان سكرينيار",
        "Matthijs de Ligt" to "ماتياس دي ليخت",
        "Joao Cancelo" to "جواو كانسيلو",
        "Jordi Alba" to "جوردي ألبا",
        "Alphonso Davies" to "ألفونسو ديفيز",
        "Federico Dimarco" to "فيديريكو ديماركو",
        "Jules Kounde" to "جول كوندي",
        "Reece James" to "ريس جيمس",
        "Gianluca Zambrotta" to "جيانلوكا زامبروتا",
        "Branislav Ivanovic" to "برانيسلاف إيفانوفيتش",
        "Johan Cruyff" to "يوهان كرويف",
        "Zico" to "زيكو",
        "Socrates" to "سقراط",
        "Roberto Baggio" to "روبرتو باجيو",
        "Ruud Gullit" to "رود خوليت",
        "Dennis Bergkamp" to "دينيس بيركامب",
        "Francesco Totti" to "فرانشيسكو توتي",
        "Alessandro Del Piero" to "أليساندرو ديل بييرو",
        "Paul Pogba" to "بول بوجبا",
        "Casemiro" to "كاسيميرو",
        "Ilkay Gundogan" to "إيلكاي جوندوجان",
        "Marco Verratti" to "ماركو فيراتي",
        "Frenkie de Jong" to "فرينكي دي يونج",
        "Gavi" to "جافي",
        "Aurelien Tchouameni" to "أوريلين تشواميني",
        "Eduardo Camavinga" to "إدواردو كامافينجا",
        "Phil Foden" to "فيل فودين",
        "Cole Palmer" to "كول بالمر",
        "Bernardo Silva" to "برناردو سيلفا",
        "James Rodriguez" to "خاميس رودريجيز",
        "Thiago Alcantara" to "تياجو ألكانتارا",
        "Ivan Rakitic" to "إيفان راكيتيتش",
        "Marek Hamsik" to "ماريك همشيك",
        "Sami Khedira" to "سامي خضيرة",
        "Michael Carrick" to "مايكل كاريك",
        "Edgar Davids" to "إدجار دافيدز",
        "Javier Mascherano" to "خافيير ماسكيرانو",
        "Garrincha" to "جارينشا",
        "Jairzinho" to "جايرزينيو",
        "Marc Overmars" to "مارك أوفرمارس",
        "Kingsley Coman" to "كينجسلي كومان",
        "Leroy Sane" to "ليروي ساني",
        "Marcus Rashford" to "ماركوس راشفورد",
        "Rafael Leao" to "رافائيل لياو",
        "Jeremy Doku" to "جيريمي دوكو",
        "Mohammed Kudus" to "محمد قدوس",
        "Gabriel Martinelli" to "جابرييل مارتينيللي",
        "Jack Grealish" to "جاك جريليش",
        "Mahmoud Trezeguet" to "محمود تريزيجيه",
        "Paulo Futre" to "باولو فوتري",
        "Rodrygo" to "رودريجو",
        "Lautaro Martinez" to "لاوتارو مارتينيز",
        "Victor Osimhen" to "فيكتور أوسيمين",
        "Jurgen Klinsmann" to "يورجن كلينسمان",
        "Gary Lineker" to "جاري لينيكر",
        "Rudi Voller" to "رودي فولر",
        "Hugo Sanchez" to "هوجو سانشيز",
        "Davor Suker" to "دافور شوكر",
        "Andriy Shevchenko" to "أندريه شيفتشينكو",
        "Ian Rush" to "إيان راش",
        "Kenny Dalglish" to "كيني دالجليش",
        "Eric Cantona" to "إريك كانتونا",
        "Fernando Torres" to "فيرناندو توريس",
        "Diego Forlan" to "دييجو فورلان",
        "Mido" to "ميدو",
        "Omar Marmoush" to "عمر مرموش",
        "Darwin Nunez" to "داروين نونيز",
        "Gabriel Jesus" to "جابرييل جيسوس",
        "Roberto Firmino" to "روبرتو فيرمينو",
        "Olivier Giroud" to "أوليفييه جيرو",
        "Ciro Immobile" to "تشيرو إيموبيلي",
        "Jamie Vardy" to "جيمي فاردي",
        "Mauro Icardi" to "ماورو إيكاردي",
        "Radamel Falcao" to "راداميل فالكاو",
        "Luca Toni" to "لوكا توني",
        "Kepa Arrizabalaga" to "كيبا أريثابالاجا",
        "Robert Sanchez" to "روبرت سانشيز",
        "Nick Pope" to "نيك بوب",
        "Aaron Ramsdale" to "آرون رامسديل",
        "Bernd Leno" to "بيرند لينو",
        "Alphonse Areola" to "ألفونس أريولا",
        "Mat Ryan" to "مات رايان",
        "Ali Maaloul" to "علي معلول",
        "Chris Smalling" to "كريس سمولينج",
        "Ben Chilwell" to "بن تشيلويل",
        "Lucas Digne" to "لوكاس دين",
        "Jan Vertonghen" to "يان فيرتونين",
        "Toby Alderweireld" to "توبي ألدرفايرلد",
        "Ezri Konsa" to "إيزري كونسا",
        "Joel Matip" to "جويل ماتيب",
        "Nacho Fernandez" to "ناتشو فرنانديز",
        "Diego Godin" to "دييجو جودين",
        "Sead Kolasinac" to "سياد كولاشيناتش",
        "Ruben Neves" to "روبن نيفيز",
        "Wilfred Ndidi" to "ويلفريد نديدي",
        "Jorginho" to "جورجينيو",
        "Idrissa Gueye" to "إدريسا جاي",
        "Mikel Arteta" to "ميكيل أرتيتا",
        "Jordan Henderson" to "جوردان هندرسون",
        "James Milner" to "جيمس ميلنر",
        "Jack Wilshere" to "جاك ويلشير",
        "Mateo Kovacic" to "ماتيو كوفاسيتش",
        "Leandro Paredes" to "لياندرو باريديس",
        "Rodrigo De Paul" to "رودريجو دي باول",
        "Lucas Paqueta" to "لوكاس باكيتا",
        "Dani Ceballos" to "داني ثيبايوس",
        "Saul Niguez" to "ساؤول نيجيز",
        "Koke" to "كوكي",
        "Thomas Partey" to "توماس بارتي",
        "Jarrod Bowen" to "جارود بوين",
        "Ismaila Sarr" to "إسماعيلا سار",
        "Allan Saint-Maximin" to "ألان سان ماكسيمان",
        "Nicolas Pepe" to "نيكولا بيبي",
        "Said Benrahma" to "سعيد بن رحمة",
        "Yannick Carrasco" to "يانيك كاراسكو",
        "Ivan Perisic" to "إيفان بيريشيتش",
        "Lucas Moura" to "لوكاس مورا",
        "Mostafa Mohamed" to "مصطفى محمد",
        "Islam Slimani" to "إسلام سليماني",
        "Wissam Ben Yedder" to "وسام بن يدر",
        "Andre-Pierre Gignac" to "أندريه بيير جينياك",
        "Danny Welbeck" to "داني ويلبيك",
        "Divock Origi" to "ديفوك أوريجي",
        "Michy Batshuayi" to "ميشي باتشواي",
        "Javier Hernandez" to "خافيير هيرنانديز",
        "Dominic Calvert-Lewin" to "دومينيك كالفرت لوين",
        "Callum Wilson" to "كالوم ويلسون",
        "Ivan Toney" to "إيفان توني",
        "Richarlison" to "ريتشارليسون",
        "Wout Weghorst" to "فوت فيجهورست",
        "Memphis Depay" to "ممفيس ديباي"
    )

    fun arabicName(nameEn: String, fallback: String): String = arabicNames[nameEn] ?: fallback

    /**
     * Forgiving player search.
     *
     * Works on name *tokens*, so the user can type the first name, the last name, both in any
     * order, or a name with a missing/extra space ("debruyne"). On top of exact/prefix/contains
     * matching it tolerates typos (swapped letters, one wrong/missing letter) and common
     * spelling variants (c/k, ph/f, o/u, ق/ك, غ/ج, ة/ه, ص/س ...), in Arabic and English.
     */
    fun matches(nameAr: String, nameEn: String, query: String): Boolean {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.length < 3) return false
        return score(nameAr, nameEn, normalizedQuery, fuzzyMinLength = 4) > 0
    }

    fun suggestions(players: List<PlayerCard>, query: String, limit: Int = 8): List<PlayerCard> =
        suggestionsBy(players, query, limit, { it.nameEn }, { it.nameAr }, { it.rating })

    fun <T> suggestionsBy(
        players: List<T>, query: String, limit: Int = 8,
        nameEn: (T) -> String, nameAr: (T) -> String, rating: (T) -> Int
    ): List<T> {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.length < 3 || limit <= 0) return emptyList()

        fun search(fuzzyMinLength: Int): List<T> = players
            .map { player -> player to score(nameAr(player), nameEn(player), normalizedQuery, fuzzyMinLength) }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<T, Int>> { it.second }.thenByDescending { rating(it.first) })
            .take(limit)
            .map { it.first }

        // First pass: exact / prefix / spelling-variant matches plus light typo tolerance on
        // longer words. If that finds nothing, retry allowing a typo in 4-letter words too.
        val strict = search(fuzzyMinLength = 5)
        if (strict.isNotEmpty()) return strict
        val loose = search(fuzzyMinLength = 4)
        return if (loose.isNotEmpty()) loose else search(fuzzyMinLength = 3)
    }

    // ---------------------------------------------------------------------------------------
    // Scoring
    // ---------------------------------------------------------------------------------------

    private class NameVariant(val tokens: List<String>, val folded: List<String>, val loose: List<String>, val condensed: String)

    private val variantCache = java.util.concurrent.ConcurrentHashMap<String, List<NameVariant>>()

    private fun variantsFor(nameAr: String, nameEn: String): List<NameVariant> =
        variantCache.getOrPut("$nameEn|$nameAr") {
            listOf(nameEn, nameAr, arabicNames[nameEn].orEmpty())
                .filter { it.isNotBlank() }
                .map { raw ->
                    val tokens = tokens(normalize(raw))
                    NameVariant(tokens, tokens.map { fold(it) }, tokens.map { foldLoose(it) }, fold(tokens.joinToString("")))
                }
                .filter { it.tokens.isNotEmpty() }
        }

    private fun score(nameAr: String, nameEn: String, normalizedQuery: String, fuzzyMinLength: Int): Int {
        val queryTokens = tokens(normalizedQuery)
        if (queryTokens.isEmpty()) return 0
        val queryFolded = queryTokens.map { fold(it) }
        val queryLoose = queryTokens.map { foldLoose(it) }
        val queryCondensed = fold(queryTokens.joinToString(""))
        var best = 0
        for (variant in variantsFor(nameAr, nameEn)) {
            // 1) Token by token: every typed word must match some word of the name.
            var total = 0
            var allMatched = true
            for (i in queryTokens.indices) {
                var tokenBest = 0
                for (j in variant.tokens.indices) {
                    val s = tokenScore(queryTokens[i], queryFolded[i], queryLoose[i], variant.tokens[j], variant.folded[j], variant.loose[j], fuzzyMinLength)
                    if (s > tokenBest) tokenBest = s
                }
                if (tokenBest == 0) { allMatched = false; break }
                total += tokenBest
            }
            if (allMatched) best = maxOf(best, total / queryTokens.size)

            // 2) Whole-name comparison with spaces removed ("debruyne" -> "De Bruyne").
            if (queryTokens.size > 1 || variant.tokens.size > 1) {
                if (variant.condensed.startsWith(queryCondensed)) best = maxOf(best, 78)
                else if (queryCondensed.length >= 6 && variant.condensed.contains(queryCondensed)) best = maxOf(best, 64)
                else if (queryCondensed.length >= maxOf(fuzzyMinLength, 5)) {
                    val allowed = allowedEdits(queryCondensed.length)
                    val prefix = variant.condensed.take(queryCondensed.length)
                    if (editDistance(queryCondensed, prefix, allowed) <= allowed) best = maxOf(best, 45)
                }
            }
        }
        return best
    }

    private fun tokenScore(q: String, qFolded: String, qLoose: String, t: String, tFolded: String, tLoose: String, fuzzyMinLength: Int): Int {
        if (q.length < 3) return if (t.startsWith(q)) 60 else 0
        if (t == q) return 100
        if (t.startsWith(q)) return 92 - minOf(10, t.length - q.length)
        if (tFolded == qFolded) return 88
        if (tFolded.startsWith(qFolded)) return 80
        if (t.contains(q)) return 70
        if (qFolded.length >= 3 && tFolded.contains(qFolded)) return 62
        if (q.length >= fuzzyMinLength) {
            // 3-letter words only tolerate a typo in the last-resort pass (fuzzyMinLength == 3).
            val allowed = allowedEdits(qLoose.length).let { if (it == 0 && qLoose.length == 3 && fuzzyMinLength <= 3) 1 else it }
            if (allowed > 0) {
                val whole = editDistance(qLoose, tLoose, allowed)
                val prefix = editDistance(qLoose, tLoose.take(qLoose.length), allowed)
                val d = minOf(whole, prefix)
                if (d <= allowed) return 55 - d * 8
            }
        }
        return 0
    }

    private fun allowedEdits(length: Int): Int = when {
        length <= 3 -> 0
        length <= 7 -> 1
        else -> 2
    }

    /** Damerau-Levenshtein (adjacent swaps count as one edit) with an early exit on length gap. */
    private fun editDistance(a: String, b: String, limit: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > limit) return limit + 1
        val n = a.length
        val m = b.length
        var prev2 = IntArray(m + 1)
        var prev = IntArray(m + 1) { it }
        var cur = IntArray(m + 1)
        for (i in 1..n) {
            cur[0] = i
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = minOf(v, prev2[j - 2] + 1)
                }
                cur[j] = v
            }
            val recycled = prev2
            prev2 = prev
            prev = cur
            cur = recycled
        }
        return prev[m]
    }

    /** Collapses spelling variants so "Cristiano"/"Kristiano" or "غوارديولا"/"جوارديولا" compare equal. */
    private fun fold(token: String): String {
        val prepared = token.replace("ph", "f").replace("ck", "k")
        val out = StringBuilder(prepared.length)
        for (ch in prepared) {
            val mapped = when (ch) {
                'ص', 'ث' -> 'س'
                'ذ', 'ظ' -> 'ز'
                'ض' -> 'د'
                'ط' -> 'ت'
                'ق' -> 'ك'
                'غ' -> 'ج'
                'ة' -> 'ه'
                'c', 'q' -> 'k'
                'y' -> 'i'
                'w' -> 'v'
                'z' -> 's'
                else -> ch
            }
            if (out.isEmpty() || out[out.length - 1] != mapped) out.append(mapped)
        }
        return out.toString()
    }

    /** Like [fold] but also merges o/u and e/i, used only for typo-tolerant comparison. */
    private fun foldLoose(token: String): String {
        val out = StringBuilder(token.length)
        for (ch in fold(token)) {
            val mapped = when (ch) { 'o' -> 'u'; 'e' -> 'i'; else -> ch }
            if (out.isEmpty() || out[out.length - 1] != mapped) out.append(mapped)
        }
        return out.toString()
    }

    private fun tokens(normalized: String): List<String> = normalized
        .split(' ')
        .filter { it.isNotEmpty() }
        .map { token ->
            // "الشناوي" and "شناوي" should be the same word.
            if (token.length > 4 && token.startsWith("ال")) token.substring(2) else token
        }

    fun normalize(value: String): String = java.text.Normalizer
        .normalize(value.trim().lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}"), "")
        .replace("ـ", "")
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace('أ', 'ا')
        .replace('إ', 'ا')
        .replace('آ', 'ا')
        .replace('ؤ', 'و')
        .replace('ئ', 'ي')
        .replace('ى', 'ي')
        .replace('ة', 'ه')
        .replace("ء", "")
        .replace('ø', 'o')
        .replace('ł', 'l')
        .replace('đ', 'd')
        .replace("ß", "ss")
        .replace("'", "")
        .replace("’", "")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
}
