package com.mostafabek.elbashagames

/** Shared player-name search for every game that asks users to enter a footballer's name. */
object PlayerSearch {
    private val arabicNames = mapOf(
        "Manuel Neuer" to "مانويل نوير", "Iker Casillas" to "إيكر كاسياس",
        "Gianluigi Buffon" to "جانلويجي بوفون", "Thibaut Courtois" to "تيبو كورتوا",
        "Alisson Becker" to "أليسون بيكر", "Mohamed El Shenawy" to "محمد الشناوي",
        "Essam El Hadary" to "عصام الحضري", "Paolo Maldini" to "باولو مالديني",
        "Sergio Ramos" to "سيرخيو راموس", "Virgil van Dijk" to "فيرجيل فان دايك",
        "Achraf Hakimi" to "أشرف حكيمي", "Zinedine Zidane" to "زين الدين زيدان",
        "Andres Iniesta" to "أندريس إنييستا", "Xavi Hernandez" to "تشافي هيرنانديز",
        "Luka Modric" to "لوكا مودريتش", "Toni Kroos" to "توني كروس",
        "Kevin De Bruyne" to "كيفن دي بروين", "Jude Bellingham" to "جود بيلينجهام",
        "Mohamed Aboutrika" to "محمد أبو تريكة", "Lionel Messi" to "ليونيل ميسي",
        "Cristiano Ronaldo" to "كريستيانو رونالدو", "Mohamed Salah" to "محمد صلاح",
        "Neymar Jr" to "نيمار", "Riyad Mahrez" to "رياض محرز",
        "Kylian Mbappe" to "كيليان مبابي", "Vinicius Junior" to "فينيسيوس جونيور",
        "Lamine Yamal" to "لامين يامال", "Bukayo Saka" to "بوكايو ساكا",
        "Son Heung-min" to "سون هيونج مين", "Erling Haaland" to "إيرلينج هالاند",
        "Harry Kane" to "هاري كين", "Robert Lewandowski" to "روبرت ليفاندوفسكي",
        "Karim Benzema" to "كريم بنزيما", "Sadio Mane" to "ساديو ماني",
        "Didier Drogba" to "ديدييه دروجبا", "Samuel Eto'o" to "صامويل إيتو",
        "Ronaldinho" to "رونالدينيو", "Kaka" to "كاكا", "Rivaldo" to "ريفالدو",
        "Petr Cech" to "بيتر تشيك", "Ederson" to "إيدرسون", "Jan Oblak" to "يان أوبلاك",
        "Marc-Andre ter Stegen" to "مارك أندريه تير شتيجن", "Emiliano Martinez" to "إيميليانو مارتينيز",
        "David de Gea" to "دافيد دي خيا", "Keylor Navas" to "كيلور نافاس", "Hugo Lloris" to "هوجو لوريس",
        "Oliver Kahn" to "أوليفر كان", "Peter Schmeichel" to "بيتر شمايكل", "Dida" to "ديدا",
        "Jose Luis Chilavert" to "خوسيه لويس تشيلافيرت", "Rene Higuita" to "رينيه هيجيتا",
        "Yassine Bounou" to "ياسين بونو", "Mike Maignan" to "مايك مانيان", "Gianluigi Donnarumma" to "جيانلويجي دوناروما",
        "Unai Simon" to "أوناي سيمون", "Jordan Pickford" to "جوردان بيكفورد", "Andre Onana" to "أندريه أونانا",
        "Samir Handanovic" to "سمير هاندانوفيتش", "Edwin van der Sar" to "إدوين فان دير سار",
        "Claudio Bravo" to "كلاوديو برافو", "Walter Zenga" to "والتر زينجا",
        "Franco Baresi" to "فرانكو باريزي", "Alessandro Nesta" to "أليساندرو نيستا", "Fabio Cannavaro" to "فابيو كانافارو",
        "Carles Puyol" to "كارليس بويول", "Rio Ferdinand" to "ريو فرديناند", "Nemanja Vidic" to "نيمانيا فيديتش",
        "John Terry" to "جون تيري", "Gerard Pique" to "جيرارد بيكيه", "Thiago Silva" to "تياغو سيلفا",
        "Ruben Dias" to "روبن دياز", "Antonio Rudiger" to "أنطونيو روديجر", "Trent Alexander-Arnold" to "ترنت ألكسندر أرنولد",
        "Dani Alves" to "داني ألفيش", "Cafu" to "كافو", "Roberto Carlos" to "روبرتو كارلوس", "Marcelo" to "مارسيلو",
        "Ashley Cole" to "آشلي كول", "Philipp Lahm" to "فيليب لام", "Javier Zanetti" to "خافيير زانيتي",
        "Raphael Varane" to "رافاييل فاران", "William Saliba" to "ويليام ساليبا", "Alessandro Bastoni" to "أليساندرو باستوني",
        "Kim Min-jae" to "كيم مين جاي", "Ronald Araujo" to "رونالد أراوخو", "John Stones" to "جون ستونز",
        "Kyle Walker" to "كايل ووكر", "Theo Hernandez" to "ثيو هيرنانديز", "Andrew Robertson" to "أندرو روبرتسون",
        "Giorgio Chiellini" to "جورجيو كيليني", "Leonardo Bonucci" to "ليوناردو بونوتشي", "Jaap Stam" to "ياب ستام",
        "Andrea Pirlo" to "أندريا بيرلو", "Steven Gerrard" to "ستيفن جيرارد", "Frank Lampard" to "فرانك لامبارد",
        "Paul Scholes" to "بول سكولز", "Patrick Vieira" to "باتريك فييرا", "Claude Makelele" to "كلود ماكيليلي",
        "Sergio Busquets" to "سيرجيو بوسكيتس", "Rodri" to "رودري", "Pedri" to "بيدري", "Jamal Musiala" to "جمال موسيالا",
        "Federico Valverde" to "فيديريكو فالفيردي", "Declan Rice" to "ديكلان رايس", "Bruno Fernandes" to "برونو فيرنانديز",
        "Yaya Toure" to "يايا توريه", "Clarence Seedorf" to "كلارنس سيدورف", "Michel Platini" to "ميشيل بلاتيني",
        "Lothar Matthaus" to "لوثار ماتيوس", "Roy Keane" to "روي كين", "Cesc Fabregas" to "سيسك فابريجاس",
        "Mesut Ozil" to "مسعود أوزيل", "David Silva" to "دافيد سيلفا", "Bastian Schweinsteiger" to "باستيان شفاينشتايجر",
        "Hossam Ghaly" to "حسام غالي", "Mohamed Elneny" to "محمد النني",
        "Michael Olise" to "مايكل أوليسيه", "Vitinha" to "فيتينيا", "Nuno Mendes" to "نونو مينديز",
        "Gabriel Magalhaes" to "جابرييل ماجالهايس", "Willian Pacho" to "ويليان باتشو", "Joao Neves" to "جواو نيفيز",
        "Joshua Kimmich" to "جوشوا كيميش", "Luis Diaz" to "لويس دياز", "Florian Wirtz" to "فلوريان فيرتز",
        "Martin Odegaard" to "مارتن أوديجارد", "Enzo Fernandez" to "إنزو فيرنانديز", "Rayan Cherki" to "ريان شرقي",
        "Viktor Gyokeres" to "فيكتور جيوكيريس", "Alexander Isak" to "ألكسندر إيزاك",
        "Arjen Robben" to "أريين روبن", "Franck Ribery" to "فرانك ريبيري", "Gareth Bale" to "جاريث بيل",
        "Eden Hazard" to "إيدين هازارد", "Luis Figo" to "لويس فيجو", "George Best" to "جورج بست",
        "Ryan Giggs" to "ريان جيجز", "Luis Suarez" to "لويس سواريز", "Raphinha" to "رافينيا",
        "Ousmane Dembele" to "عثمان ديمبيلي", "Khvicha Kvaratskhelia" to "خفيتشا كفاراتسخيليا",
        "Angel Di Maria" to "أنخيل دي ماريا", "Alexis Sanchez" to "أليكسيس سانشيز", "David Beckham" to "ديفيد بيكهام",
        "Stanley Matthews" to "ستانلي ماثيوز", "Hristo Stoichkov" to "خريستو ستويتشكوف", "Robert Pires" to "روبير بيريس",
        "Pierre-Emerick Aubameyang" to "بيير إيمريك أوباميانج", "Raheem Sterling" to "رحيم سترلينج",
        "Pele" to "بيليه", "Diego Maradona" to "دييجو مارادونا", "Ronaldo Nazario" to "رونالدو نازاريو",
        "Thierry Henry" to "تييري هنري", "Zlatan Ibrahimovic" to "زلاتان إبراهيموفيتش", "Wayne Rooney" to "واين روني",
        "Ruud van Nistelrooy" to "رود فان نيستلروي", "Marco van Basten" to "ماركو فان باستن", "Gerd Muller" to "جيرد مولر",
        "Eusebio" to "يوزيبيو", "Ferenc Puskas" to "فيرينتس بوشكاش", "Romario" to "روماريو",
        "Gabriel Batistuta" to "جابرييل باتيستوتا", "Alan Shearer" to "آلان شيرر", "Sergio Aguero" to "سيرخيو أجويرو",
        "Jorge Campos" to "خورخي كامبوس", "David Seaman" to "ديفيد سيمان", "Victor Valdes" to "فيكتور فالديس", "Shaka Hislop" to "شاكا هيسلوب",
        "Lilian Thuram" to "ليليان تورام", "Marcel Desailly" to "مارسيل ديسايي", "Sol Campbell" to "سول كامبل", "Wael Gomaa" to "وائل جمعة",
        "Ahmed Hegazi" to "أحمد حجازي", "Mohamed Hany" to "محمد هاني", "Jay-Jay Okocha" to "جاي جاي أوكوشا", "Michael Essien" to "مايكل إيسيان",
        "N'Golo Kante" to "نجولو كانتي", "Gennaro Gattuso" to "جينارو جاتوزو", "Park Ji-sung" to "بارك جي سونغ", "Shinji Kagawa" to "شينجي كاغاوا",
        "Ahmed Hassan" to "أحمد حسن", "Nani" to "ناني", "Pedro Rodriguez" to "بيدرو رودريغيز", "Mohamed Zidan" to "محمد زيدان",
        "Angel Correa" to "أنخيل كوريا", "Hossam Hassan" to "حسام حسن", "Miroslav Klose" to "ميروسلاف كلوزه", "Robin van Persie" to "روبن فان بيرسي",
        "Filippo Inzaghi" to "فيليبو إنزاغي", "Edinson Cavani" to "إدينسون كافاني", "Hernan Crespo" to "هرنان كريسبو"
    )

    fun arabicName(nameEn: String, fallback: String): String = arabicNames[nameEn] ?: fallback

    /** Returns true only after at least three normalized characters have been entered. */
    fun matches(nameAr: String, nameEn: String, query: String): Boolean {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.length < 3) return false
        return normalize(nameAr).contains(normalizedQuery) ||
            normalize(nameEn).contains(normalizedQuery) ||
            normalize(arabicNames[nameEn].orEmpty()).contains(normalizedQuery)
    }

    fun suggestions(players: List<PlayerCard>, query: String, limit: Int = 8): List<PlayerCard> =
        suggestionsBy(players, query, limit, { it.nameEn }, { it.nameAr }, { it.rating })

    fun <T> suggestionsBy(
        players: List<T>, query: String, limit: Int = 8,
        nameEn: (T) -> String, nameAr: (T) -> String, rating: (T) -> Int
    ): List<T> {
        if (normalize(query).length < 3 || limit <= 0) return emptyList()
        val normalizedQuery = normalize(query)
        return players.asSequence()
            .filter { matches(nameAr(it), nameEn(it), query) }
            .sortedWith(compareBy<T> {
                if (normalize(nameEn(it)).startsWith(normalizedQuery) || normalize(nameAr(it)).startsWith(normalizedQuery)) 0 else 1
            }.thenByDescending { rating(it) })
            .take(limit)
            .toList()
    }

    fun normalize(value: String): String = value
        .trim()
        .lowercase()
        .replace("ـ", "")
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace('أ', 'ا')
        .replace('إ', 'ا')
        .replace('آ', 'ا')
        .replace('ؤ', 'و')
        .replace('ئ', 'ي')
        .replace('ى', 'ي')
        .replace('ة', 'ه')
        .replace(Regex("\\s+"), " ")
}
