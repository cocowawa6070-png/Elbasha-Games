package com.mostafabek.elbashagames

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Sfx {
    Correct, Wrong, Win, Loss, Tick, Click, HiddenReveal,
    // Added in the audio pass: match, auction, deal and UI effects.
    Whistle, Goal, GoalAgainst, Card, Save, Post, Kick, Cheer,
    Coin, Gavel, Whoosh, Pop, Beep, Go, Deal, NoDeal, CaseOpen, Unlock
}

/** Shared game effects plus developer-managed group music. */
class SoundManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("elbasha_audio", Context.MODE_PRIVATE)

    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set

    var musicOn by mutableStateOf(prefs.getBoolean("music", true))
        private set

    /** Menu music album: built-in songs (assets/music) plus songs the player added on this device. */
    val album = MusicAlbum(app)

    /** UI-visible state: no_track, preparing, playing, paused, muted, in_game, ended or error:<reason>. */
    var musicPlaybackStatus by mutableStateOf("no_track")
        private set
    var currentTrackId by mutableStateOf<String?>(prefs.getString("album_current", null))
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var shuffleOn by mutableStateOf(prefs.getBoolean("album_shuffle", false))
        private set
    /** 0 = off, 1 = repeat album, 2 = repeat one song. */
    var repeatMode by mutableIntStateOf(prefs.getInt("album_repeat", 1))
        private set
    var positionMs by mutableIntStateOf(0)
        private set
    var durationMs by mutableIntStateOf(0)
        private set

    private var musicPlayer: MediaPlayer? = null
    private var musicPrepared = false
    private var userPaused = false
    private var appInForeground = true
    private var consecutiveErrors = 0
    private val playHistory = ArrayDeque<String>()
    private val ticker = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val player = musicPlayer
            if (player != null && musicPrepared) {
                runCatching { if (player.isPlaying) positionMs = player.currentPosition }
            }
            if (isPlaying) ticker.postDelayed(this, 500L)
        }
    }

    /** True while a game screen is open: only sound effects play, never the album. */
    private var inGame = false
    val isGameActive: Boolean get() = inGame

    // Group-wide music is controlled by the developer through Realtime Database.
    // Every device downloads the selected audio once, then follows the shared time anchor.
    private var globalMusicTrackMode = false
    private var globalPlaybackRequested = false
    private var globalBasePositionMs = 0L
    private var globalStartedAtMs = 0L
    var globalTrackId by mutableStateOf<String?>(null)
        private set

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(8)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val loadedSounds = mutableSetOf<Int>()
    private val pendingSounds = mutableSetOf<Int>()
    private val effectIds: Map<Sfx, Int>

    init {
        // One-time migration: music was forcibly disabled in earlier builds. Re-enable it once
        // for existing installs, then respect the user's saved toggle from this release onward.
        if (!prefs.getBoolean("music_enabled_migration_v1", false)) {
            musicOn = true
            prefs.edit().putBoolean("music", true).putBoolean("music_enabled_migration_v1", true).apply()
        }
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
                if (pendingSounds.remove(sampleId) && soundOn) pool.play(sampleId, 1f, 1f, 1, 0, 1f)
            }
        }
        effectIds = mapOf(
            Sfx.Correct to pool.load(app, R.raw.sfx_correct, 1),
            Sfx.Wrong to pool.load(app, R.raw.sfx_wrong, 1),
            Sfx.Win to pool.load(app, R.raw.sfx_win, 1),
            Sfx.Loss to pool.load(app, R.raw.sfx_loss, 1),
            Sfx.Tick to pool.load(app, R.raw.sfx_tick, 1),
            Sfx.Click to pool.load(app, R.raw.sfx_click, 1),
            Sfx.HiddenReveal to pool.load(app, R.raw.sfx_hidden_reveal, 1),
            Sfx.Whistle to pool.load(app, R.raw.sfx_whistle, 1),
            Sfx.Goal to pool.load(app, R.raw.sfx_goal, 1),
            Sfx.GoalAgainst to pool.load(app, R.raw.sfx_goal_against, 1),
            Sfx.Card to pool.load(app, R.raw.sfx_card, 1),
            Sfx.Save to pool.load(app, R.raw.sfx_save, 1),
            Sfx.Post to pool.load(app, R.raw.sfx_post, 1),
            Sfx.Kick to pool.load(app, R.raw.sfx_kick, 1),
            Sfx.Cheer to pool.load(app, R.raw.sfx_cheer, 1),
            Sfx.Coin to pool.load(app, R.raw.sfx_coin, 1),
            Sfx.Gavel to pool.load(app, R.raw.sfx_gavel, 1),
            Sfx.Whoosh to pool.load(app, R.raw.sfx_whoosh, 1),
            Sfx.Pop to pool.load(app, R.raw.sfx_pop, 1),
            Sfx.Beep to pool.load(app, R.raw.sfx_beep, 1),
            Sfx.Go to pool.load(app, R.raw.sfx_go, 1),
            Sfx.Deal to pool.load(app, R.raw.sfx_deal, 1),
            Sfx.NoDeal to pool.load(app, R.raw.sfx_no_deal, 1),
            Sfx.CaseOpen to pool.load(app, R.raw.sfx_case_open, 1),
            Sfx.Unlock to pool.load(app, R.raw.sfx_unlock, 1)
        )
    }

    fun play(effect: Sfx) {
        if (!soundOn) return
        effectIds[effect]?.let { id ->
            if (id in loadedSounds) pool.play(id, 1f, 1f, 1, 0, 1f) else pendingSounds.add(id)
        }
    }

    @Suppress("DEPRECATION")
    fun vibrate(milliseconds: Long = 30L) {
        if (!soundOn) return
        val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else vibrator.vibrate(milliseconds)
    }

    fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound", soundOn).apply()
    }

    fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        applyMusicState()
    }

    /** Music is allowed only on menu screens: on, in the foreground, and not inside a game. */
    private fun musicAllowed() = musicOn && appInForeground && !inGame

    /** Starts or pauses the album so it always matches [musicAllowed] and the user's own pause. */
    private fun applyMusicState() {
        // Never fall back to a per-device playlist. Music is accepted only from the
        // developer-controlled global playback command; musicOn remains a local mute.
        if (!globalMusicTrackMode) {
            pausePlayer()
            musicPlaybackStatus = if (musicOn) "no_track" else "muted"
            return
        }
        applyGlobalMusicState()
    }

    private fun pausePlayer() {
        val player = musicPlayer
        if (player != null && musicPrepared) runCatching { if (player.isPlaying) player.pause() }
        isPlaying = false
        ticker.removeCallbacks(tick)
    }

    private fun startAlbumIfNeeded() {
        val tracks = album.tracks
        if (tracks.isEmpty()) {
            releasePlayer()
            musicPlaybackStatus = "no_track"
            return
        }
        val track = tracks.firstOrNull { it.id == currentTrackId } ?: tracks.first()
        prepareTrack(track)
    }

    private fun prepareTrack(track: AlbumTrack) {
        globalMusicTrackMode = false
        globalPlaybackRequested = false
        globalTrackId = null
        releasePlayer()
        currentTrackId = track.id
        prefs.edit().putString("album_current", track.id).apply()
        positionMs = 0
        durationMs = track.durationMs.toInt()
        musicPlaybackStatus = "preparing"
        val player = MediaPlayer()
        musicPlayer = player
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setVolume(1f, 1f)
            album.attach(player, track)
            player.isLooping = repeatMode == 2
            player.setOnPreparedListener { ready ->
                if (musicPlayer === ready) {
                    musicPrepared = true
                    durationMs = runCatching { ready.duration }.getOrDefault(durationMs)
                    consecutiveErrors = 0
                    applyMusicState()
                }
            }
            player.setOnCompletionListener { done -> if (musicPlayer === done) onTrackCompleted() }
            player.setOnErrorListener { failed, what, extra ->
                if (musicPlayer === failed) handleTrackError("decoder_error_${what}_$extra")
                true
            }
            player.prepareAsync()
        } catch (error: Exception) {
            if (musicPlayer === player) handleTrackError(error.localizedMessage ?: error.javaClass.simpleName)
        }
    }

    private fun releasePlayer() {
        ticker.removeCallbacks(tick)
        val player = musicPlayer
        musicPlayer = null
        musicPrepared = false
        isPlaying = false
        if (player != null) runCatching { player.release() }
    }

    /** A broken file never stops the album: skip it, unless every song fails in a row. */
    private fun handleTrackError(reason: String) {
        releasePlayer()
        consecutiveErrors++
        musicPlaybackStatus = "error: $reason"
        val count = album.tracks.size
        if (count > 1 && consecutiveErrors < count) next(autoAdvance = true)
    }

    private fun onTrackCompleted() {
        if (globalMusicTrackMode) {
            globalPlaybackRequested = false
            isPlaying = false
            positionMs = durationMs
            ticker.removeCallbacks(tick)
            musicPlaybackStatus = "ended"
            return
        }
        when {
            repeatMode == 2 -> Unit // MediaPlayer loops by itself
            repeatMode == 0 && !shuffleOn && album.tracks.lastOrNull()?.id == currentTrackId -> {
                isPlaying = false
                positionMs = 0
                ticker.removeCallbacks(tick)
                musicPlaybackStatus = "ended"
            }
            else -> next(autoAdvance = true)
        }
    }

    private fun pickNextId(forward: Boolean): String? {
        val ids = album.tracks.map { it.id }
        if (ids.isEmpty()) return null
        if (ids.size == 1) return ids.first()
        if (shuffleOn) {
            if (!forward) {
                if (playHistory.isNotEmpty()) return playHistory.removeLast()
            }
            return ids.filter { it != currentTrackId }.random()
        }
        val index = ids.indexOf(currentTrackId).takeIf { it >= 0 } ?: 0
        return ids[(index + if (forward) 1 else ids.size - 1) % ids.size]
    }

    // ---- Public album controls (used by MusicAlbumPanel) ----

    fun playTrack(id: String) {
        val track = album.tracks.firstOrNull { it.id == id } ?: return
        if (!musicOn) { musicOn = true; prefs.edit().putBoolean("music", true).apply() }
        userPaused = false
        currentTrackId?.takeIf { it != id }?.let { playHistory.addLast(it); if (playHistory.size > 30) playHistory.removeFirst() }
        consecutiveErrors = 0
        prepareTrack(track)
    }

    fun togglePlayPause() {
        if (!musicOn) { musicOn = true; prefs.edit().putBoolean("music", true).apply() }
        if (isPlaying) {
            userPaused = true
            applyMusicState()
        } else {
            userPaused = false
            if (musicPlayer == null) startAlbumIfNeeded() else applyMusicState()
        }
    }

    fun next(autoAdvance: Boolean = false) {
        val id = pickNextId(forward = true) ?: return
        val track = album.tracks.firstOrNull { it.id == id } ?: return
        if (!autoAdvance) userPaused = false
        currentTrackId?.let { playHistory.addLast(it); if (playHistory.size > 30) playHistory.removeFirst() }
        prepareTrack(track)
    }

    fun previous() {
        // Like most players: a second press within the first seconds goes to the previous song.
        if (positionMs > 3_000 && musicPlayer != null && musicPrepared) { seekTo(0); return }
        val id = pickNextId(forward = false) ?: return
        val track = album.tracks.firstOrNull { it.id == id } ?: return
        userPaused = false
        prepareTrack(track)
    }

    fun seekTo(ms: Int) {
        val player = musicPlayer ?: return
        if (!musicPrepared) return
        runCatching { player.seekTo(ms.coerceIn(0, durationMs.coerceAtLeast(1))) }
        positionMs = ms
    }

    fun toggleShuffle() {
        shuffleOn = !shuffleOn
        prefs.edit().putBoolean("album_shuffle", shuffleOn).apply()
    }

    fun cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        prefs.edit().putInt("album_repeat", repeatMode).apply()
        runCatching { musicPlayer?.isLooping = repeatMode == 2 }
    }

    /** Call after songs were added/removed so playback follows the new album. */
    fun onAlbumChanged() {
        val tracks = album.tracks
        if (tracks.isEmpty()) {
            releasePlayer(); currentTrackId = null; musicPlaybackStatus = "no_track"; return
        }
        if (tracks.none { it.id == currentTrackId }) {
            // The playing song was removed: move on to the first remaining one.
            currentTrackId = tracks.first().id
            if (musicPlayer != null) prepareTrack(tracks.first())
        }
        if (musicPlayer == null) applyMusicState()
    }


    /** Starts a shared track from its app-private cached file at the group playback position. */
    fun playGlobalTrack(
        trackId: String,
        title: String,
        artist: String,
        file: File,
        expectedPositionMs: Long,
        startedAtMs: Long
    ) {
        globalMusicTrackMode = true
        globalTrackId = trackId
        currentTrackId = trackId
        globalPlaybackRequested = true
        globalBasePositionMs = expectedPositionMs.coerceAtLeast(0L)
        globalStartedAtMs = startedAtMs.coerceAtLeast(0L)
        userPaused = false
        releasePlayer()
        positionMs = globalBasePositionMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        durationMs = 0
        musicPlaybackStatus = "preparing"
        val player = MediaPlayer()
        musicPlayer = player
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setVolume(1f, 1f)
            player.setDataSource(file.absolutePath)
            // Keep the developer-selected group track looping until the developer changes it.
            player.isLooping = true
            player.setOnPreparedListener { ready ->
                if (musicPlayer === ready && globalMusicTrackMode && globalTrackId == trackId) {
                    musicPrepared = true
                    durationMs = runCatching { ready.duration }.getOrDefault(0)
                    applyMusicState()
                }
            }
            player.setOnCompletionListener { done -> if (musicPlayer === done) onTrackCompleted() }
            player.setOnErrorListener { failed, what, extra ->
                if (musicPlayer === failed) handleTrackError("shared_audio_error_${what}_$extra")
                true
            }
            player.prepareAsync()
        } catch (error: Exception) {
            if (musicPlayer === player) handleTrackError(error.localizedMessage ?: error.javaClass.simpleName)
        }
    }

    /** Applies a play/pause command and its shared time anchor without downloading the song again. */
    fun updateGlobalPlayback(playing: Boolean, position: Long, startedAt: Long) {
        if (!globalMusicTrackMode) return
        globalPlaybackRequested = playing
        globalBasePositionMs = position.coerceAtLeast(0L)
        globalStartedAtMs = startedAt.coerceAtLeast(0L)
        userPaused = false
        applyMusicState()
    }

    /** True only when this exact shared song is already loaded on this device. */
    fun isGlobalTrackLoaded(trackId: String): Boolean =
        globalMusicTrackMode && globalTrackId == trackId && musicPlayer != null

    /** Current group-synchronized position, including elapsed time since the last play command. */
    fun globalPositionNow(): Long {
        val elapsed = if (globalPlaybackRequested && globalStartedAtMs > 0L) {
            (System.currentTimeMillis() - globalStartedAtMs).coerceAtLeast(0L)
        } else 0L
        val expected = globalBasePositionMs + elapsed
        return if (durationMs > 0) expected % durationMs.toLong() else expected
    }

    /** Stops only this device's shared player; it does not send a stop command to other users. */
    fun clearGlobalTrack() {
        globalMusicTrackMode = false
        globalPlaybackRequested = false
        globalTrackId = null
        globalBasePositionMs = 0L
        globalStartedAtMs = 0L
        releasePlayer()
        currentTrackId = null
        positionMs = 0
        durationMs = 0
        musicPlaybackStatus = "no_track"
    }

    private fun applyGlobalMusicState() {
        val player = musicPlayer
        if (!musicAllowed() || !globalPlaybackRequested) {
            pausePlayer()
            musicPlaybackStatus = when {
                !musicOn -> "muted"
                inGame -> "in_game"
                !globalPlaybackRequested -> "paused"
                else -> "paused"
            }
            return
        }
        if (player == null || !musicPrepared) return
        try {
            val target = globalPositionNow().coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            val current = runCatching { player.currentPosition }.getOrDefault(0)
            if (kotlin.math.abs(current - target) > 900) player.seekTo(target)
            if (!player.isPlaying) player.start()
            isPlaying = true
            positionMs = target
            musicPlaybackStatus = "playing"
            ticker.removeCallbacks(tick)
            ticker.post(tick)
        } catch (error: IllegalStateException) {
            handleTrackError(error.localizedMessage ?: "invalid shared player state")
        }
    }

    /** Called when a game screen opens/closes. Inside a game only sound effects are heard. */
    fun setInGame(active: Boolean) {
        if (inGame == active) return
        inGame = active
        applyMusicState()
    }

    /** Starts the album once the menus are showing (safe to call repeatedly). */
    fun startMusicIfAllowed() = applyMusicState()

    @Suppress("DEPRECATION")
    fun onPause() {
        appInForeground = false
        pool.autoPause()
        pendingSounds.clear()
        pausePlayer()
    }

    @Suppress("DEPRECATION")
    fun onResume() {
        appInForeground = true
        pool.autoResume()
        applyMusicState()
    }

    fun release() {
        releasePlayer()
        ticker.removeCallbacksAndMessages(null)
        pool.release()
    }
}

@Composable
fun SoundToggles(sound: SoundManager) {
    Row {
        ToggleChip(if (sound.soundOn) "🔊" else "🔕") { sound.toggleSound() }
    }
}

@Composable
private fun ToggleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(PanelColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(label, fontSize = 16.sp) }
}
