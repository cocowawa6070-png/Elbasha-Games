package com.mostafabek.elbashagames

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Sfx { Correct, Wrong, Win, Loss, Tick, Click }

/** Session 7 audio policy: only match/game win and loss effects are audible. */
class SoundManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("elbasha_audio", Context.MODE_PRIVATE)

    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(2)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val loadedSounds = mutableSetOf<Int>()
    private val pendingSounds = mutableSetOf<Int>()
    private val effectIds: Map<Sfx, Int>

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
                if (pendingSounds.remove(sampleId) && soundOn) pool.play(sampleId, 1f, 1f, 1, 0, 1f)
            }
        }
        effectIds = mapOf(
            Sfx.Win to pool.load(app, R.raw.sfx_win, 1),
            Sfx.Loss to pool.load(app, R.raw.sfx_loss, 1)
        )
    }

    fun play(effect: Sfx) {
        if (!soundOn || effect !in setOf(Sfx.Win, Sfx.Loss)) return
        effectIds[effect]?.let { id ->
            if (id in loadedSounds) pool.play(id, 1f, 1f, 1, 0, 1f) else pendingSounds.add(id)
        }
    }

    @Suppress("DEPRECATION")
    fun vibrate(milliseconds: Long = 30L) {
        if (!soundOn) return
        val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else vibrator.vibrate(milliseconds)
    }

    fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound", soundOn).apply()
    }

    fun release() { pool.release() }
}

@Composable
fun SoundToggles(sound: SoundManager) {
    Row {
        ToggleChip(if (sound.soundOn) "🔊" else "🔇") { sound.toggleSound() }
    }
}

@Composable
private fun ToggleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(PanelColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(label, fontSize = 16.sp) }
}
