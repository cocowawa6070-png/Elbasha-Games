package com.mostafabek.elbashagames

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Sfx {
    Correct, Wrong, Win, Loss, Tick, Click, HiddenReveal,
    // Added in the audio pass: match, auction, deal and UI effects.
    Whistle, Goal, GoalAgainst, Card, Save, Post, Kick, Cheer,
    Coin, Gavel, Whoosh, Pop, Beep, Go, Deal, NoDeal, CaseOpen, Unlock
}

/** Shared game effects plus developer-managed group music. */
class SoundManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("elbasha_audio", Context.MODE_PRIVATE)

    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set

    var musicOn by mutableStateOf(prefs.getBoolean("music", true))
        private set

    /** UI-visible state so every install can distinguish a missing track from decoder failure. */
    var musicPlaybackStatus by mutableStateOf("no_track")
        private set

    private var musicPlayer: MediaPlayer? = null
    private var musicPrepared = false
    private var musicPath: String? = null
    // Retain the last successfully downloaded file so an explicit Play tap can retry
    // after a transient MediaPlayer/decoder failure without downloading it again.
    private var lastMusicFile: File? = null
    private var appInForeground = true

    /** True while a game screen is open: only sound effects play, never the shared music. */
    private var inGame = false

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(8)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val loadedSounds = mutableSetOf<Int>()
    private val pendingSounds = mutableSetOf<Int>()
    private val effectIds: Map<Sfx, Int>

    init {
        // One-time migration: music was forcibly disabled in earlier builds. Re-enable it once
        // for existing installs, then respect the user's saved toggle from this release onward.
        if (!prefs.getBoolean("music_enabled_migration_v1", false)) {
            musicOn = true
            prefs.edit().putBoolean("music", true).putBoolean("music_enabled_migration_v1", true).apply()
        }
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
                if (pendingSounds.remove(sampleId) && soundOn) pool.play(sampleId, 1f, 1f, 1, 0, 1f)
            }
        }
        effectIds = mapOf(
            Sfx.Correct to pool.load(app, R.raw.sfx_correct, 1),
            Sfx.Wrong to pool.load(app, R.raw.sfx_wrong, 1),
            Sfx.Win to pool.load(app, R.raw.sfx_win, 1),
            Sfx.Loss to pool.load(app, R.raw.sfx_loss, 1),
            Sfx.Tick to pool.load(app, R.raw.sfx_tick, 1),
            Sfx.Click to pool.load(app, R.raw.sfx_click, 1),
            Sfx.HiddenReveal to pool.load(app, R.raw.sfx_hidden_reveal, 1),
            Sfx.Whistle to pool.load(app, R.raw.sfx_whistle, 1),
            Sfx.Goal to pool.load(app, R.raw.sfx_goal, 1),
            Sfx.GoalAgainst to pool.load(app, R.raw.sfx_goal_against, 1),
            Sfx.Card to pool.load(app, R.raw.sfx_card, 1),
            Sfx.Save to pool.load(app, R.raw.sfx_save, 1),
            Sfx.Post to pool.load(app, R.raw.sfx_post, 1),
            Sfx.Kick to pool.load(app, R.raw.sfx_kick, 1),
            Sfx.Cheer to pool.load(app, R.raw.sfx_cheer, 1),
            Sfx.Coin to pool.load(app, R.raw.sfx_coin, 1),
            Sfx.Gavel to pool.load(app, R.raw.sfx_gavel, 1),
            Sfx.Whoosh to pool.load(app, R.raw.sfx_whoosh, 1),
            Sfx.Pop to pool.load(app, R.raw.sfx_pop, 1),
            Sfx.Beep to pool.load(app, R.raw.sfx_beep, 1),
            Sfx.Go to pool.load(app, R.raw.sfx_go, 1),
            Sfx.Deal to pool.load(app, R.raw.sfx_deal, 1),
            Sfx.NoDeal to pool.load(app, R.raw.sfx_no_deal, 1),
            Sfx.CaseOpen to pool.load(app, R.raw.sfx_case_open, 1),
            Sfx.Unlock to pool.load(app, R.raw.sfx_unlock, 1)
        )
    }

    fun play(effect: Sfx) {
        if (!soundOn) return
        effectIds[effect]?.let { id ->
            if (id in loadedSounds) pool.play(id, 1f, 1f, 1, 0, 1f) else pendingSounds.add(id)
        }
    }

    @Suppress("DEPRECATION")
    fun vibrate(milliseconds: Long = 30L) {
        if (!soundOn) return
        val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else vibrator.vibrate(milliseconds)
    }

    fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound", soundOn).apply()
    }

    fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        if (musicPlayer == null) {
            musicPlaybackStatus = if (musicOn) "waiting_for_track" else "muted"
            return
        }
        applyMusicState()
    }

    /** Explicit Play action: unmute this device and resume or retry its current track. */
    fun enableMusicPlayback() {
        if (!musicOn) {
            musicOn = true
            prefs.edit().putBoolean("music", true).apply()
        }
        val player = musicPlayer
        if (player == null) {
            val retryFile = lastMusicFile
            if (retryFile != null && retryFile.isFile && retryFile.length() > 0L) {
                setSharedMusic(retryFile, forceReload = true)
            } else {
                musicPlaybackStatus = "waiting_for_track"
            }
        } else {
            applyMusicState()
        }
    }

    /** Music is allowed only on menu screens: on, in the foreground, and not inside a game. */
    private fun musicAllowed() = musicOn && appInForeground && !inGame

    /** Starts or pauses the shared track so it always matches [musicAllowed]. */
    private fun applyMusicState() {
        val player = musicPlayer ?: return
        if (!musicPrepared) return
        if (musicAllowed()) {
            try {
                if (!player.isPlaying) player.start()
                musicPlaybackStatus = "playing"
            } catch (_: IllegalStateException) {
                musicPlaybackStatus = "start_error"
            }
        } else {
            runCatching { if (player.isPlaying) player.pause() }
            musicPlaybackStatus = when {
                inGame -> "in_game"
                !musicOn -> "muted"
                else -> "paused"
            }
        }
    }

    /** Called when a game screen opens/closes. Inside a game only sound effects are heard. */
    fun setInGame(active: Boolean) {
        if (inGame == active) return
        inGame = active
        applyMusicState()
    }

    /** Plays the latest music file distributed through the shared Realtime Database node. */
    fun setSharedMusic(file: File) = setSharedMusic(file, forceReload = false)

    private fun setSharedMusic(file: File, forceReload: Boolean) {
        if (!file.isFile || file.length() == 0L) {
            musicPlaybackStatus = "invalid_file"
            return
        }
        lastMusicFile = file
        if (!forceReload && musicPath == file.absolutePath && musicPlayer != null) return
        runCatching { musicPlayer?.release() }
        musicPlayer = null
        musicPrepared = false
        musicPath = file.absolutePath
        musicPlaybackStatus = "preparing"
        val player = MediaPlayer()
        musicPlayer = player
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setVolume(1f, 1f)
            player.setDataSource(file.absolutePath)
            player.isLooping = true
            player.setOnPreparedListener { ready ->
                if (musicPlayer === ready) {
                    musicPrepared = true
                    applyMusicState()
                }
            }
            player.setOnErrorListener { failed, what, extra ->
                if (musicPlayer === failed) {
                    musicPrepared = false
                    musicPlayer = null
                    musicPath = null
                    musicPlaybackStatus = "decoder_error_${what}_$extra"
                    runCatching { failed.release() }
                }
                true
            }
            player.prepareAsync()
        } catch (error: Exception) {
            runCatching { player.release() }
            if (musicPlayer === player) musicPlayer = null
            musicPrepared = false
            musicPath = null
            musicPlaybackStatus = "prepare_error: ${error.localizedMessage ?: error.javaClass.simpleName}"
        }
    }

    fun clearSharedMusic() {
        runCatching { musicPlayer?.release() }
        musicPlayer = null
        musicPrepared = false
        musicPath = null
        lastMusicFile = null
        musicPlaybackStatus = "no_track"
    }

    @Suppress("DEPRECATION")
    fun onPause() {
        appInForeground = false
        pool.autoPause()
        pendingSounds.clear()
        val player = musicPlayer
        if (player != null) runCatching {
            if (player.isPlaying) player.pause()
            if (musicPrepared) musicPlaybackStatus = "paused"
        }
    }

    @Suppress("DEPRECATION")
    fun onResume() {
        appInForeground = true
        pool.autoResume()
        applyMusicState()
    }

    fun release() {
        clearSharedMusic()
        pool.release()
    }
}

@Composable
fun SoundToggles(sound: SoundManager) {
    Row {
        ToggleChip(if (sound.soundOn) "🔊" else "🔕") { sound.toggleSound() }
    }
}

@Composable
private fun ToggleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(PanelColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(label, fontSize = 16.sp) }
}
