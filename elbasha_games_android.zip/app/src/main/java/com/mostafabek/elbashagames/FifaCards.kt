package com.mostafabek.elbashagames

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

/** Card sizes. Aspect ratio is always roughly 0.71 (width / height) like a real FUT card. */
enum class FifaCardSize(val widthDp: Int, val heightDp: Int) {
    Tiny(68, 96),
    Small(84, 118),
    Medium(122, 172),
    Large(196, 276)
}

/** FIFA-ultimate-team-like silhouette: peaked top, straight sides, pointed rounded bottom. */
object FifaCardShape : Shape {
    override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(0f, h * 0.085f)
            // Soft shoulder up to the top-centre peak.
            quadraticBezierTo(w * 0.24f, h * 0.075f, w * 0.50f, 0f)
            quadraticBezierTo(w * 0.76f, h * 0.075f, w, h * 0.085f)
            lineTo(w, h * 0.84f)
            // Curved taper to the bottom point.
            quadraticBezierTo(w, h * 0.93f, w * 0.50f, h)
            quadraticBezierTo(0f, h * 0.93f, 0f, h * 0.84f)
            close()
        }
        return Outline.Generic(path)
    }
}

private data class FifaTier(
    val brush: Brush,
    val text: Color,
    val accent: Color,
    val stripe: Color,
    val label: String
)

private fun tierFor(rating: Int): FifaTier = when {
    rating >= 94 -> FifaTier(
        Brush.linearGradient(listOf(Color(0xFF1B2A5C), Color(0xFF3A2C7A), Color(0xFFB9892C))),
        Color(0xFFFFE9A8), Color(0xFFFFD45E), Color(0x33FFFFFF), "ICON"
    )
    rating >= 88 -> FifaTier(
        Brush.linearGradient(listOf(Color(0xFFFFE79A), Color(0xFFE8B64E), Color(0xFF9C6421))),
        Color(0xFF2A1503), Color(0xFF5A2E06), Color(0x33FFFFFF), "GOLD"
    )
    rating >= 80 -> FifaTier(
        Brush.linearGradient(listOf(Color(0xFFF4D98B), Color(0xFFD9A73C), Color(0xFF8C5A1B))),
        Color(0xFF2A1503), Color(0xFF5A2E06), Color(0x26FFFFFF), "GOLD"
    )
    else -> FifaTier(
        Brush.linearGradient(listOf(Color(0xFFE6E8EC), Color(0xFFADB3BD), Color(0xFF6C7380))),
        Color(0xFF1A1D22), Color(0xFF3A3F48), Color(0x33FFFFFF), "SILVER"
    )
}

/**
 * Player card styled like an EA FC card: big rating + position + flag on the left, portrait in
 * the middle, name plate at the bottom. [detail] is an optional small line under the name
 * (price, "MISSED", etc.).
 */
@Composable
fun FifaPlayerCard(
    player: PlayerCard,
    english: Boolean,
    modifier: Modifier = Modifier,
    size: FifaCardSize = FifaCardSize.Medium,
    detail: String? = null
) {
    val tier = tierFor(player.rating)
    val scale = size.widthDp / 196f
    val name = if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr)
    val shortName = if (english) player.nameEn.split(" ").lastOrNull().orEmpty().ifBlank { player.nameEn } else name.split(" ").lastOrNull().orEmpty().ifBlank { name }
    val displayName = if (size == FifaCardSize.Small || size == FifaCardSize.Tiny) shortName else name

    Box(
        modifier = modifier
            .size(width = size.widthDp.dp, height = size.heightDp.dp)
            .clip(FifaCardShape)
            .background(tier.brush)
            .drawBehind {
                // Diagonal sheen lines, like the foil pattern on a real card.
                val step = this.size.width / 3.2f
                for (i in -2..6) {
                    val x = i * step
                    drawLine(
                        color = tier.stripe,
                        start = Offset(x, 0f),
                        end = Offset(x + this.size.width * 0.9f, this.size.height),
                        strokeWidth = this.size.width * 0.10f
                    )
                }
            }
    ) {
        // Inner border following the silhouette (inset by drawing a thin stroked outline).
        Canvas(Modifier.fillMaxSize()) {
            val outline = FifaCardShape.createOutline(this.size, LayoutDirection.Ltr, this)
            if (outline is Outline.Generic) {
                drawPath(outline.path, color = tier.accent.copy(alpha = 0.55f), style = Stroke(width = 2.2f * scale * density))
            }
        }

        // Portrait (right/centre).
        Box(
            Modifier.align(Alignment.TopEnd)
                .padding(top = (30 * scale).dp, end = (12 * scale).dp)
                .size(width = (110 * scale).dp, height = (122 * scale).dp)
        ) {
            PlayerPortrait(player, Modifier.fillMaxSize(), cornerRadius = (16 * scale).toInt().coerceAtLeast(5))
        }

        // Left column: rating, position, flag.
        Column(
            Modifier.align(Alignment.TopStart).padding(start = (14 * scale).dp, top = (28 * scale).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy((1 * scale).dp)
        ) {
            Text("${player.rating}", color = tier.text, fontSize = (38 * scale).sp, fontWeight = FontWeight.Black, lineHeight = (38 * scale).sp)
            Text(player.position, color = tier.text, fontSize = (14 * scale).sp, fontWeight = FontWeight.Black, lineHeight = (14 * scale).sp)
            Box(Modifier.padding(vertical = (3 * scale).dp).size(width = (24 * scale).dp, height = (1.5f * scale).dp).background(tier.accent.copy(alpha = 0.7f)))
            Text(player.flag, fontSize = (18 * scale).sp, lineHeight = (18 * scale).sp)
        }

        // Name plate.
        Column(
            Modifier.align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = (30 * scale).dp, start = (10 * scale).dp, end = (10 * scale).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy((1 * scale).dp)
        ) {
            Box(Modifier.fillMaxWidth(0.82f).height((1.5f * scale).dp).background(tier.accent.copy(alpha = 0.6f)))
            Text(
                if (english) displayName.uppercase() else displayName,
                color = tier.text,
                fontSize = (if (size == FifaCardSize.Large) 17 else 15).times(scale.coerceAtLeast(0.55f)).sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            if (!detail.isNullOrBlank()) {
                Text(
                    detail,
                    color = tier.accent,
                    fontSize = (11 * scale.coerceAtLeast(0.7f)).sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** Card back used before a hidden card is flipped. */
@Composable
fun FifaCardBack(modifier: Modifier = Modifier, size: FifaCardSize = FifaCardSize.Large, label: String = "?") {
    val palette = LocalElbashaPalette.current
    val scale = size.widthDp / 196f
    Box(
        modifier = modifier
            .size(width = size.widthDp.dp, height = size.heightDp.dp)
            .clip(FifaCardShape)
            .background(Brush.linearGradient(listOf(Color(0xFF6A0A24), palette.deepWine, Color(0xFF3A0013))))
            .drawBehind {
                val step = this.size.width / 5f
                for (i in -3..9) {
                    val x = i * step
                    drawLine(Color(0x22E8B64E), Offset(x, 0f), Offset(x + this.size.width, this.size.height), strokeWidth = 2f)
                    drawLine(Color(0x22E8B64E), Offset(x + this.size.width, 0f), Offset(x, this.size.height), strokeWidth = 2f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val outline = FifaCardShape.createOutline(this.size, LayoutDirection.Ltr, this)
            if (outline is Outline.Generic) {
                drawPath(outline.path, color = palette.gold.copy(alpha = 0.85f), style = Stroke(width = 3f * scale * density))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy((6 * scale).dp)) {
            Text("♛", color = palette.gold, fontSize = (60 * scale).sp, fontWeight = FontWeight.Black)
            Text(label, color = palette.cream, fontSize = (34 * scale).sp, fontWeight = FontWeight.Black)
        }
    }
}

private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
    val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/**
 * Hidden-player reveal: the card starts face-down, is lifted, and is turned over as if someone
 * were gripping it by the back, then settles on the table face-up. No hand is drawn.
 *
 * Use `key(player.nameEn) { FlipRevealCard(...) }` so each new reveal replays the animation.
 */
@Composable
fun FlipRevealCard(
    player: PlayerCard,
    english: Boolean,
    modifier: Modifier = Modifier,
    size: FifaCardSize = FifaCardSize.Large,
    startDelayMillis: Int = 350,
    flipMillis: Int = 1700,
    detail: String? = null,
    backLabel: String = "?"
) {
    val progress = remember(player.nameEn) { Animatable(0f) }
    LaunchedEffect(player.nameEn) {
        progress.snapTo(0f)
        kotlinx.coroutines.delay(startDelayMillis.toLong())
        progress.animateTo(1f, tween(flipMillis))
    }
    val density = LocalDensity.current
    val liftPx = with(density) { 26.dp.toPx() }
    val t = progress.value
    val lift = smoothstep(0.00f, 0.28f, t) - smoothstep(0.74f, 1.00f, t)   // 0 -> 1 -> 0
    val flip = smoothstep(0.22f, 0.80f, t)                                  // 0 -> 1
    val angle = 180f * flip
    val showFront = angle > 90f

    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .graphicsLayer {
                    cameraDistance = 16f * density.density
                    rotationY = angle
                    // Tilt toward the viewer mid-turn, like a card pinched by one edge.
                    rotationX = -16f * sin(PI.toFloat() * flip)
                    rotationZ = -5f * lift + 3f * sin(2f * PI.toFloat() * flip)
                    translationY = -liftPx * lift
                    val s = 1f + 0.12f * lift
                    scaleX = s
                    scaleY = s
                }
        ) {
            if (showFront) {
                // The front face is drawn mirrored by the 180deg rotation; flip it back.
                Box(Modifier.graphicsLayer { rotationY = 180f }) {
                    FifaPlayerCard(player, english, size = size, detail = detail)
                }
            } else {
                FifaCardBack(size = size, label = backLabel)
            }
        }
    }
}
