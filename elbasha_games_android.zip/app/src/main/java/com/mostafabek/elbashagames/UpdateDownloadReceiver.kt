package com.mostafabek.elbashagames

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class UpdateDownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (!isUpdateDownloadSuccessful(context, id)) return
        val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
        if (prefs.getLong("download_id", -1L) != id) return

        // Never start an Activity from this background receiver. A visible MainActivity
        // receives this package-scoped signal; otherwise it retries from onResume().
        context.sendBroadcast(Intent(ACTION_UPDATE_READY).setPackage(context.packageName))
    }

    companion object {
        const val ACTION_UPDATE_READY = "com.mostafabek.elbashagames.UPDATE_READY"
    }
}
