package com.mostafabek.elbashagames

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Player headshots are resolved from Wikipedia's free page-image metadata, then cached locally.
 * We deliberately show a neutral fallback when no suitable footballer image is returned.
 */
object PlayerImageRepository {
    private const val TAG = "PlayerImageRepository"
    private const val API = "https://en.wikipedia.org/w/api.php"
    private const val USER_AGENT = "ELBASHA-GAMES/0.3 (Android; player portrait lookup)"
    private const val URL_CACHE_MS = 30L * 24L * 60L * 60L * 1000L
    private const val NEGATIVE_CACHE_MS = 6L * 60L * 60L * 1000L
    // Bump this whenever matching rules change; old incorrect portraits must never survive.
    private const val IMAGE_MATCH_VERSION = "strict-v3-football-description"
    private val memory = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount.coerceAtLeast(1)
    }
    private val aliases = mapOf(
        "Neymar Jr" to "Neymar",
        "Pele" to "Pelé",
        "Eusebio" to "Eusébio",
        "Ronaldo Nazario" to "Ronaldo (Brazilian footballer)",
        "Marc-Andre ter Stegen" to "Marc-André ter Stegen",
        "Jose Luis Chilavert" to "José Luis Chilavert",
        "Rene Higuita" to "René Higuita",
        "Gerd Muller" to "Gerd Müller",
        "Ferenc Puskas" to "Ferenc Puskás",
        "Kaka" to "Kaká",
        "Victor Valdes" to "Víctor Valdés",
        "N'Golo Kante" to "N'Golo Kanté",
        "Pedro Rodriguez" to "Pedro (footballer, born 1987)",
        "Hernan Crespo" to "Hernán Crespo",
        "David Raya" to "David Raya",
        "Lucio" to "Lúcio",
        "Carlos Alberto" to "Carlos Alberto Torres",
        "Xabi Alonso" to "Xabi Alonso",
        "Bobby Charlton" to "Bobby Charlton",
        "Frank Rijkaard" to "Frank Rijkaard",
        "Iker Casillas" to "Iker Casillas",
        "Gianluigi Buffon" to "Gianluigi Buffon",
        "Paolo Maldini" to "Paolo Maldini",
        "Franco Baresi" to "Franco Baresi",
        "Fabio Cannavaro" to "Fabio Cannavaro",
        "Lothar Matthaus" to "Lothar Matthäus",
        "Zinedine Zidane" to "Zinedine Zidane",
        "Andres Iniesta" to "Andrés Iniesta",
        "Xavi Hernandez" to "Xavi",
        "Diego Maradona" to "Diego Maradona",
        "Hristo Stoichkov" to "Hristo Stoichkov",
        "Jay-Jay Okocha" to "Jay-Jay Okocha",
        // Expanded catalog: only names whose Wikipedia title differs (or is ambiguous) need an alias.
        // Accents are ignored by the title matcher, so "Joško Gvardiol" == "Josko Gvardiol".
        "Socrates" to "Sócrates",
        "Gavi" to "Gavi (footballer)",
        "Mido" to "Mido (footballer)",
        "Marquinhos" to "Marquinhos (footballer, born May 1994)",
        "Pau Cubarsi" to "Pau Cubarsí",
        "Hugo Sanchez" to "Hugo Sánchez",
        "Mahmoud Trezeguet" to "Trézéguet (Egyptian footballer)",
        "Zico" to "Zico",
        "Casemiro" to "Casemiro",
        "Rodrygo" to "Rodrygo",
        "Garrincha" to "Garrincha",
        "Pepe Reina" to "Pepe Reina"
    )

    /** Downloaded portraits live in the app's private files dir, so Android never evicts them. */
    private fun portraitDir(context: Context): File =
        File(context.applicationContext.filesDir, "player_portraits").apply { mkdirs() }

    private fun legacyCacheDir(context: Context): File =
        File(context.applicationContext.cacheDir, "player_portraits")

    private fun bundledSlugs(context: Context): Set<String> =
        context.assets.list("player_portraits").orEmpty().map { it.substringBeforeLast('.') }.toSet()

    /**
     * Downloads every missing portrait once (in the background) so cards never wait on the network
     * again. Stops early when the device is offline and retries at most twice a day.
     */
    suspend fun prefetchAll(context: Context, playerNames: List<String>) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences("player_image_cache", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("prefetch_started_at", 0L) < 12L * 60L * 60L * 1000L) return@withContext
        prefs.edit().putLong("prefetch_started_at", now).apply()
        val bundled = bundledSlugs(appContext)
        val folder = portraitDir(appContext)
        var consecutiveFailures = 0
        for (name in playerNames) {
            if (portraitSlug(name) in bundled) continue
            val key = digest("$IMAGE_MATCH_VERSION:$name")
            if (File(folder, "$key.jpg").let { it.isFile && it.length() > 2_000 }) continue
            val bitmap = load(appContext, name)
            if (bitmap == null) consecutiveFailures++ else consecutiveFailures = 0
            // Several misses in a row almost always means "no internet": try again later.
            if (consecutiveFailures >= 8) break
            delay(150)
        }
    }

    suspend fun load(context: Context, playerName: String): Bitmap? = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val key = digest("$IMAGE_MATCH_VERSION:$playerName")
        memory.get(key)?.let { return@withContext it }
        // Bundled artwork always wins: cards can render fully offline when the portrait pack is present.
        loadBundledPortrait(appContext, playerName)?.let { bundled ->
            memory.put(key, bundled)
            return@withContext bundled
        }
        val folder = portraitDir(appContext)
        val imageFile = File(folder, "$key.jpg")
        // One-time migration of portraits cached by older builds.
        if (!imageFile.isFile) {
            val legacy = File(legacyCacheDir(appContext), "$key.jpg")
            if (legacy.isFile && legacy.length() > 2_000) runCatching { legacy.copyTo(imageFile, overwrite = true) }
        }
        if (imageFile.isFile && imageFile.length() > 2_000) {
            BitmapFactory.decodeFile(imageFile.absolutePath)?.let {
                memory.put(key, it)
                return@withContext it
            }
        }

        val prefs = appContext.getSharedPreferences("player_image_cache", Context.MODE_PRIVATE)
        val cacheKey = "image:$key"
        val cached = prefs.getString(cacheKey, null)
        val now = System.currentTimeMillis()
        val imageUrl = when {
            cached == null -> resolveImageUrl(playerName)
            cached.startsWith("none:") -> {
                val timestamp = cached.substringAfter(':').toLongOrNull() ?: 0L
                if (now - timestamp < NEGATIVE_CACHE_MS) return@withContext null
                resolveImageUrl(playerName)
            }
            cached.startsWith("url:") -> {
                val parts = cached.split(':', limit = 3)
                val timestamp = parts.getOrNull(1)?.toLongOrNull() ?: 0L
                if (now - timestamp < URL_CACHE_MS) parts.getOrNull(2) else resolveImageUrl(playerName)
            }
            else -> resolveImageUrl(playerName)
        }
        if (imageUrl.isNullOrBlank()) {
            prefs.edit().putString(cacheKey, "none:$now").apply()
            return@withContext null
        }
        prefs.edit().putString(cacheKey, "url:$now:$imageUrl").apply()
        val bytes = download(imageUrl)
        if (bytes == null) {
            prefs.edit().putString(cacheKey, "none:$now").apply()
            return@withContext null
        }
        runCatching { imageFile.writeBytes(bytes) }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bitmap != null) memory.put(key, bitmap) else imageFile.delete()
        bitmap
    }

    private fun resolveImageUrl(playerName: String): String? {
        // Never use a broad search fallback: it can silently return a different footballer
        // with a similar name. A missing portrait is safer than a confidently wrong one.
        val requestedTitle = aliases[playerName] ?: playerName
        val exactUrl = buildString {
            append(API)
            append("?action=query&format=json&formatversion=2&redirects=1")
            append("&prop=pageimages%7Cpageterms&piprop=thumbnail&pithumbsize=512&pilicense=free")
            append("&wbptterms=description&titles=")
            append(URLEncoder.encode(requestedTitle, "UTF-8"))
        }
        return requestPageImage(exactUrl, playerName, requestedTitle)
    }

    private fun requestPageImage(endpoint: String, playerName: String, requestedTitle: String): String? {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7_000
            readTimeout = 7_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (connection.responseCode !in 200..299) return null
            val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val pages = JSONObject(json).optJSONObject("query")?.optJSONArray("pages") ?: return null
            val acceptedTitles = setOf(playerName, requestedTitle)
            for (index in 0 until pages.length()) {
                val page = pages.optJSONObject(index) ?: continue
                if (page.has("missing")) continue
                if (!PlayerImageMatchRules.isExactPlayerTitle(page.optString("title"), acceptedTitles)) continue
                val description = page.optJSONObject("terms")
                    ?.optJSONArray("description")?.optString(0)
                if (!PlayerImageMatchRules.isFootballerDescription(description)) continue
                val source = page.optJSONObject("thumbnail")?.optString("source")
                    ?.takeIf { it.startsWith("https://upload.wikimedia.org/") }
                if (source != null) return source
            }
            null
        } catch (error: Exception) {
            Log.w(TAG, "Could not resolve exact portrait for $playerName", error)
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun download(imageUrl: String): ByteArray? {
        val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "image/*")
        }
        return try {
            if (connection.responseCode !in 200..299) return null
            val type = connection.contentType.orEmpty()
            if (!type.startsWith("image/")) return null
            connection.inputStream.use { input ->
                val bytes = input.readBytes()
                if (bytes.size !in 2_000..4_000_000) null else bytes
            }
        } catch (error: Exception) {
            Log.w(TAG, "Could not download player portrait", error)
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun portraitSlug(playerName: String): String = playerName.lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')

    private fun loadBundledPortrait(context: Context, playerName: String): Bitmap? {
        val slug = portraitSlug(playerName)
        val extensions = listOf("webp", "jpg", "png")
        for (extension in extensions) {
            val path = "player_portraits/$slug.$extension"
            val bitmap = runCatching {
                context.assets.open(path).use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (bitmap != null) return bitmap
        }
        return null
    }

    fun bundledCount(context: Context): Int = context.assets.list("player_portraits")
        ?.count { file -> listOf(".webp", ".jpg", ".png").any(file::endsWith) } ?: 0

    fun cachedCount(context: Context): Int = portraitDir(context)
        .listFiles()?.count { it.isFile && it.extension.equals("jpg", ignoreCase = true) } ?: 0

    fun cachedBytes(context: Context): Long = portraitDir(context)
        .listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L

    fun clearCache(context: Context) {
        portraitDir(context).deleteRecursively()
        legacyCacheDir(context).deleteRecursively()
        context.applicationContext.getSharedPreferences("player_image_cache", Context.MODE_PRIVATE)
            .edit().clear().apply()
        memory.evictAll()
    }

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .take(12)
        .joinToString("") { "%02x".format(it) }
}

@Composable
fun PlayerPortrait(
    player: PlayerCard,
    modifier: Modifier = Modifier,
    cornerRadius: Int = 14
) {
    val context = LocalContext.current
    val palette = LocalElbashaPalette.current
    val bitmapState = produceState<Bitmap?>(initialValue = null, player.nameEn) {
        value = PlayerImageRepository.load(context, player.nameEn)
    }
    Box(
        modifier = modifier.clip(RoundedCornerShape(cornerRadius.dp))
            .background(Brush.verticalGradient(listOf(palette.gold.copy(alpha = 0.30f), palette.deepWine, palette.panelAlt))),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = bitmapState.value
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "${player.nameEn} portrait",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            val initials = player.nameEn.split(" ").filter { it.isNotBlank() }.take(2).mapNotNull { it.firstOrNull()?.toString() }.joinToString("").uppercase()
            Text(initials.ifBlank { "⚽" }, color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
        }
    }
}
