package com.mostafabek.elbashagames

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase

data class Question(
    val id: String,
    val text: String,
    val options: List<String>,
    val answer: String,
    val difficulty: String, // easy | medium | hard
    val category: String = "",
    val explanation: String = "",
    val textEn: String = text,
    val optionsEn: List<String> = options,
    val answerEn: String = answer,
    val explanationEn: String = explanation
) {
    fun prompt(english: Boolean) = if (english) textEn else text
    fun choices(english: Boolean) = if (english && optionsEn.size == options.size) optionsEn else options
    fun correctAnswer(english: Boolean) = if (english) answerEn else answer
    fun explanationText(english: Boolean) = if (english) explanationEn else explanation
}

object QuestionRepository {
    /** Loads every question under /questionBank/{category}/{questionId}. */
    fun load(database: FirebaseDatabase?, onDone: (List<Question>) -> Unit) {
        if (database == null) {
            onDone(emptyList())
            return
        }
        database.reference.child("questionBank").get()
            .addOnSuccessListener { snapshot ->
                val questions = snapshot.children.flatMap { category ->
                    category.children.mapNotNull { parse(category.key.orEmpty(), it) }
                }
                onDone(questions)
            }
            .addOnFailureListener { onDone(emptyList()) }
    }

    private fun parse(category: String, snapshot: DataSnapshot): Question? {
        val text = snapshot.child("question").getValue(String::class.java)?.trim().orEmpty()
        val answer = snapshot.child("answer").getValue(String::class.java)?.trim().orEmpty()
        if (text.isBlank() || answer.isBlank()) return null
        val difficulty = snapshot.child("difficulty").getValue(String::class.java)
            ?.lowercase()?.takeIf { it in setOf("easy", "medium", "hard") } ?: "medium"
        val explanation = snapshot.child("explanation").getValue(String::class.java).orEmpty()
        val raw = snapshot.child("options").children.mapNotNull { it.getValue(String::class.java)?.trim() }
            .filter { it.isNotBlank() }
        if (raw.size < 2) return null
        val wrong = raw.filter { it != answer }.distinct().shuffled().take(3)
        val options = (wrong + answer).distinct()
        if (options.size < 2) return null

        val answerEn = snapshot.child("answerEn").getValue(String::class.java)?.trim().orEmpty().ifBlank { answer }
        val rawEn = snapshot.child("optionsEn").children.mapNotNull { it.getValue(String::class.java)?.trim() }
            .filter { it.isNotBlank() }
        val wrongEn = rawEn.filter { it != answerEn }.distinct().shuffled().take(3)
        val optionsEn = if (rawEn.size >= 2 && answerEn !in rawEn) wrongEn + answerEn
            else if (rawEn.size >= 2) (wrongEn + answerEn).distinct() else options

        return Question(
            id = snapshot.key ?: text,
            text = text,
            options = options,
            answer = answer,
            difficulty = difficulty,
            category = category,
            explanation = explanation,
            textEn = snapshot.child("questionEn").getValue(String::class.java)?.ifBlank { text } ?: text,
            optionsEn = optionsEn,
            answerEn = answerEn,
            explanationEn = snapshot.child("explanationEn").getValue(String::class.java)?.ifBlank { explanation } ?: explanation
        )
    }

    /** A sizeable built-in bank keeps the game playable before Firebase is configured. */
    val sample: List<Question> = listOf(
        q("s01", "مين فاز بكأس العالم 2022؟", "الأرجنتين", listOf("فرنسا", "البرازيل", "كرواتيا"), "easy", "كأس العالم", "Who won the 2022 FIFA World Cup?", "Argentina", listOf("France", "Brazil", "Croatia")),
        q("s02", "كام لاعب من كل فريق بيبدأوا المباراة داخل الملعب؟", "11", listOf("9", "10", "12"), "easy", "قوانين", "How many players from each team start a match on the pitch?", "11", listOf("9", "10", "12")),
        q("s03", "محمد صلاح انضم إلى ليفربول في سنة كام؟", "2017", listOf("2015", "2016", "2018"), "easy", "لاعبون", "In which year did Mohamed Salah join Liverpool?", "2017", listOf("2015", "2016", "2018")),
        q("s04", "أي دولة استضافت كأس العالم 2018؟", "روسيا", listOf("قطر", "البرازيل", "ألمانيا"), "easy", "كأس العالم", "Which country hosted the 2018 World Cup?", "Russia", listOf("Qatar", "Brazil", "Germany")),
        q("s05", "أي منتخب فاز بأول نسخة من كأس العالم سنة 1930؟", "أوروغواي", listOf("الأرجنتين", "البرازيل", "إيطاليا"), "easy", "كأس العالم", "Which nation won the first World Cup in 1930?", "Uruguay", listOf("Argentina", "Brazil", "Italy")),
        q("s06", "أي منتخب فاز بكأس العالم 2010؟", "إسبانيا", listOf("هولندا", "ألمانيا", "الأوروغواي"), "easy", "كأس العالم", "Which country won the 2010 World Cup?", "Spain", listOf("Netherlands", "Germany", "Uruguay")),
        q("s07", "مين سجّل هدف «يد الله» الشهير في مونديال 1986؟", "دييجو مارادونا", listOf("بيليه", "زيدان", "يوهان كرويف"), "medium", "لاعبون", "Who scored the famous 'Hand of God' goal at the 1986 World Cup?", "Diego Maradona", listOf("Pelé", "Zinedine Zidane", "Johan Cruyff")),
        q("s08", "أي منتخب فاز بأمم أفريقيا 2019؟", "الجزائر", listOf("السنغال", "نيجيريا", "المغرب"), "medium", "أفريقيا", "Which nation won the 2019 Africa Cup of Nations?", "Algeria", listOf("Senegal", "Nigeria", "Morocco")),
        q("s09", "أي منتخب فاز بيورو 2004 في واحدة من أكبر المفاجآت؟", "اليونان", listOf("البرتغال", "التشيك", "هولندا"), "medium", "أوروبا", "Which team stunned Europe by winning Euro 2004?", "Greece", listOf("Portugal", "Czech Republic", "Netherlands")),
        q("s10", "مين المدرب اللي قاد اليونان للفوز بيورو 2004؟", "أوتو ريهاجل", listOf("لويس فيليبي سكولاري", "فابيو كابيلو", "جوزيه مورينيو"), "hard", "مدربون", "Who coached Greece to the Euro 2004 title?", "Otto Rehhagel", listOf("Luiz Felipe Scolari", "Fabio Capello", "José Mourinho")),
        q("s11", "كام هدف سجّل ليونيل ميسي في السنة الميلادية 2012؟", "91", listOf("79", "85", "100"), "hard", "لاعبون", "How many goals did Lionel Messi score in the calendar year 2012?", "91", listOf("79", "85", "100")),
        q("s12", "مين اللاعب اللي سجّل 13 هدفًا في كأس العالم 1958؟", "جوست فونتين", listOf("جيرد مولر", "بيليه", "ساندور كوتشيس"), "hard", "كأس العالم", "Who scored 13 goals at the 1958 World Cup?", "Just Fontaine", listOf("Gerd Müller", "Pelé", "Sándor Kocsis")),
        q("s13", "مين هداف كأس العالم 2014؟", "جيمس رودريجيز", listOf("توماس مولر", "ليونيل ميسي", "نيمار"), "medium", "كأس العالم", "Who won the Golden Boot at the 2014 World Cup?", "James Rodríguez", listOf("Thomas Müller", "Lionel Messi", "Neymar")),
        q("s14", "مين هداف كأس العالم 2018؟", "هاري كين", listOf("كيليان مبابي", "أنطوان جريزمان", "روميلو لوكاكو"), "medium", "كأس العالم", "Who was the top scorer at the 2018 World Cup?", "Harry Kane", listOf("Kylian Mbappé", "Antoine Griezmann", "Romelu Lukaku")),
        q("s15", "مين هداف كأس العالم 2022؟", "كيليان مبابي", listOf("ليونيل ميسي", "أوليفييه جيرو", "جوليان ألفاريز"), "medium", "كأس العالم", "Who won the Golden Boot at the 2022 World Cup?", "Kylian Mbappé", listOf("Lionel Messi", "Olivier Giroud", "Julián Álvarez")),
        q("s16", "مين فاز بركلات الترجيح في نهائي كأس العالم 2022؟", "الأرجنتين", listOf("فرنسا", "الاتنين اتقاسموا الكأس", "لم تُلعب ركلات ترجيح"), "easy", "كأس العالم", "Who won the penalty shoot-out in the 2022 World Cup final?", "Argentina", listOf("France", "The trophy was shared", "There was no shoot-out")),
        q("s17", "مين سجّل ثلاثية فرنسا في نهائي كأس العالم 2022؟", "كيليان مبابي", listOf("كريم بنزيما", "أنطوان جريزمان", "أوليفييه جيرو"), "medium", "كأس العالم", "Who scored France's hat-trick in the 2022 World Cup final?", "Kylian Mbappé", listOf("Karim Benzema", "Antoine Griezmann", "Olivier Giroud")),
        q("s18", "أي منتخب فاز بكأس العالم 2002؟", "البرازيل", listOf("ألمانيا", "تركيا", "إيطاليا"), "easy", "كأس العالم", "Which nation won the 2002 World Cup?", "Brazil", listOf("Germany", "Turkey", "Italy")),
        q("s19", "مين فاز بكأس العالم 2006؟", "إيطاليا", listOf("فرنسا", "ألمانيا", "البرتغال"), "easy", "كأس العالم", "Who won the 2006 World Cup?", "Italy", listOf("France", "Germany", "Portugal")),
        q("s20", "أي منتخب فاز بنهائي كأس العالم 1998؟", "فرنسا", listOf("البرازيل", "كرواتيا", "هولندا"), "easy", "كأس العالم", "Which team won the 1998 World Cup final?", "France", listOf("Brazil", "Croatia", "Netherlands")),
        q("s21", "أي منتخب فاز بكأس العالم 2014؟", "ألمانيا", listOf("الأرجنتين", "هولندا", "البرازيل"), "easy", "كأس العالم", "Which nation won the 2014 World Cup?", "Germany", listOf("Argentina", "Netherlands", "Brazil")),
        q("s22", "أي منتخب فاز بكأس العالم 2018؟", "فرنسا", listOf("كرواتيا", "بلجيكا", "إنجلترا"), "easy", "كأس العالم", "Which nation won the 2018 World Cup?", "France", listOf("Croatia", "Belgium", "England")),
        q("s23", "مين فاز بنهائي كأس العالم 1986؟", "الأرجنتين", listOf("ألمانيا الغربية", "فرنسا", "البرازيل"), "medium", "كأس العالم", "Who won the 1986 World Cup final?", "Argentina", listOf("West Germany", "France", "Brazil")),
        q("s24", "مين فاز بكأس العالم 1970؟", "البرازيل", listOf("إيطاليا", "ألمانيا الغربية", "أوروغواي"), "medium", "كأس العالم", "Who won the 1970 World Cup?", "Brazil", listOf("Italy", "West Germany", "Uruguay")),
        q("s25", "أي منتخب خسر نهائي كأس العالم 2014 أمام ألمانيا؟", "الأرجنتين", listOf("البرازيل", "هولندا", "فرنسا"), "easy", "كأس العالم", "Which team lost the 2014 World Cup final to Germany?", "Argentina", listOf("Brazil", "Netherlands", "France")),
        q("s26", "ما نتيجة ألمانيا والبرازيل في نصف نهائي مونديال 2014؟", "7-1 لألمانيا", listOf("3-0 للبرازيل", "2-1 لألمانيا", "4-2 للبرازيل"), "medium", "كأس العالم", "What was the score in the Germany v Brazil 2014 semi-final?", "Germany won 7-1", listOf("Brazil won 3-0", "Germany won 2-1", "Brazil won 4-2")),
        q("s27", "أي منتخب أفريقي وصل إلى نصف نهائي كأس العالم 2022؟", "المغرب", listOf("مصر", "السنغال", "الكاميرون"), "easy", "أفريقيا", "Which African nation reached the 2022 World Cup semi-finals?", "Morocco", listOf("Egypt", "Senegal", "Cameroon")),
        q("s28", "أي منتخب أفريقي كان أول منتخب يصل إلى ربع نهائي كأس العالم؟", "الكاميرون", listOf("نيجيريا", "المغرب", "السنغال"), "hard", "أفريقيا", "Which African team was first to reach a World Cup quarter-final?", "Cameroon", listOf("Nigeria", "Morocco", "Senegal")),
        q("s29", "أي منتخب يُلقب بـ«السامبا»؟", "البرازيل", listOf("الأرجنتين", "كولومبيا", "البرتغال"), "easy", "منتخبات", "Which national team is nicknamed the Seleção / Samba team?", "Brazil", listOf("Argentina", "Colombia", "Portugal")),
        q("s30", "أي منتخب فاز بأمم أفريقيا 2021 التي أُقيمت في 2022؟", "السنغال", listOf("مصر", "الكاميرون", "المغرب"), "medium", "أفريقيا", "Who won AFCON 2021, played in 2022?", "Senegal", listOf("Egypt", "Cameroon", "Morocco")),
        q("s31", "كم مرة فازت مصر بكأس أمم أفريقيا حتى نسخة 2010؟", "7 مرات", listOf("5 مرات", "6 مرات", "8 مرات"), "medium", "أفريقيا", "How many AFCON titles had Egypt won by the 2010 edition?", "7", listOf("5", "6", "8")),
        q("s32", "أي منتخب فاز بأمم أفريقيا 2006 على أرض مصر؟", "مصر", listOf("كوت ديفوار", "الكاميرون", "نيجيريا"), "easy", "أفريقيا", "Which team won AFCON 2006 hosted by Egypt?", "Egypt", listOf("Ivory Coast", "Cameroon", "Nigeria")),
        q("s33", "مين سجّل هدف فوز مصر على غانا في نهائي أمم أفريقيا 2010؟", "محمد ناجي جدو", listOf("محمد زيدان", "حسني عبد ربه", "عماد متعب"), "hard", "أفريقيا", "Who scored Egypt's winning goal against Ghana in the 2010 AFCON final?", "Mohamed Nagy Gedo", listOf("Mohamed Zidan", "Hossam Abdel Rabou", "Emad Moteab")),
        q("s34", "أي منتخب فاز بأمم أفريقيا 1996؟", "جنوب أفريقيا", listOf("تونس", "نيجيريا", "غانا"), "hard", "أفريقيا", "Which nation won the 1996 Africa Cup of Nations?", "South Africa", listOf("Tunisia", "Nigeria", "Ghana")),
        q("s35", "أي منتخب فاز بأول نسخة من أمم أفريقيا عام 1957؟", "مصر", listOf("السودان", "إثيوبيا", "غانا"), "hard", "أفريقيا", "Who won the first Africa Cup of Nations in 1957?", "Egypt", listOf("Sudan", "Ethiopia", "Ghana")),
        q("s36", "مين فاز بأول نسخة من كأس أوروبا للأندية البطلة سنة 1956؟", "ريال مدريد", listOf("ميلان", "بنفيكا", "برشلونة"), "medium", "أوروبا", "Who won the first European Cup in 1956?", "Real Madrid", listOf("AC Milan", "Benfica", "Barcelona")),
        q("s37", "أي فريق حقق ريمونتادا إسطنبول الشهيرة في نهائي 2005؟", "ليفربول", listOf("ميلان", "مانشستر يونايتد", "تشيلسي"), "easy", "أوروبا", "Which team made the famous Istanbul comeback in the 2005 final?", "Liverpool", listOf("AC Milan", "Manchester United", "Chelsea")),
        q("s38", "مين كان خصم ليفربول في نهائي دوري أبطال أوروبا 2005؟", "ميلان", listOf("يوفنتوس", "ريال مدريد", "بايرن ميونخ"), "medium", "أوروبا", "Who faced Liverpool in the 2005 Champions League final?", "AC Milan", listOf("Juventus", "Real Madrid", "Bayern Munich")),
        q("s39", "أي فريق حقق الثلاثية الإنجليزية التاريخية سنة 1999؟", "مانشستر يونايتد", listOf("أرسنال", "ليفربول", "تشيلسي"), "medium", "أوروبا", "Which club won the historic treble in 1999?", "Manchester United", listOf("Arsenal", "Liverpool", "Chelsea")),
        q("s40", "أي فريق فاز بدوري أبطال أوروبا لأول مرة سنة 2012؟", "تشيلسي", listOf("مانشستر سيتي", "باريس سان جيرمان", "أرسنال"), "easy", "أوروبا", "Which club won its first Champions League title in 2012?", "Chelsea", listOf("Manchester City", "Paris Saint-Germain", "Arsenal")),
        q("s41", "أي فريق فاز بالدوري الإنجليزي موسم 2015-2016 في مفاجأة تاريخية؟", "ليستر سيتي", listOf("توتنهام", "أرسنال", "ليفربول"), "easy", "أوروبا", "Which club won the 2015-16 Premier League in a historic surprise?", "Leicester City", listOf("Tottenham", "Arsenal", "Liverpool")),
        q("s42", "أي فريق أنهى الدوري الإنجليزي 2003-2004 دون هزيمة؟", "أرسنال", listOf("مانشستر يونايتد", "تشيلسي", "ليفربول"), "medium", "أوروبا", "Which club went unbeaten in the 2003-04 Premier League season?", "Arsenal", listOf("Manchester United", "Chelsea", "Liverpool")),
        q("s43", "مين سجّل هدف الفوز لبايرن ميونخ في نهائي دوري الأبطال 2020؟", "كينغسلي كومان", listOf("روبرت ليفاندوفسكي", "توماس مولر", "سيرج غنابري"), "hard", "أوروبا", "Who scored the winner for Bayern in the 2020 Champions League final?", "Kingsley Coman", listOf("Robert Lewandowski", "Thomas Müller", "Serge Gnabry")),
        q("s44", "مين أول لاعب أفريقي فاز بالكرة الذهبية سنة 1995؟", "جورج ويا", listOf("ديدييه دروجبا", "صامويل إيتو", "يايا توريه"), "medium", "لاعبون", "Who became the first African Ballon d'Or winner in 1995?", "George Weah", listOf("Didier Drogba", "Samuel Eto'o", "Yaya Touré")),
        q("s45", "مين اللاعب الملقب بـ«الظاهرة»؟", "رونالدو نازاريو", listOf("كريستيانو رونالدو", "رونالدينيو", "كاكا"), "easy", "لاعبون", "Which player was nicknamed 'O Fenômeno' / 'The Phenomenon'?", "Ronaldo Nazário", listOf("Cristiano Ronaldo", "Ronaldinho", "Kaká")),
        q("s46", "مين اللاعب اللي نطّح ماركو ماتيراتزي في نهائي كأس العالم 2006؟", "زين الدين زيدان", listOf("تييري هنري", "فرانشيسكو توتي", "فابيو كانافارو"), "medium", "لاعبون", "Who headbutted Marco Materazzi in the 2006 World Cup final?", "Zinedine Zidane", listOf("Thierry Henry", "Francesco Totti", "Fabio Cannavaro")),
        q("s47", "أي لاعب برازيلي فاز بكأس العالم 3 مرات كلاعب؟", "بيليه", listOf("رونالدو", "رونالدينيو", "ريفالدو"), "hard", "لاعبون", "Which Brazilian player won three World Cups as a player?", "Pelé", listOf("Ronaldo", "Ronaldinho", "Rivaldo")),
        q("s48", "مين صاحب الرقم القياسي لأهداف نسخة واحدة من كأس العالم بـ13 هدفًا؟", "جوست فونتين", listOf("جيرد مولر", "رونالدو", "كيليان مبابي"), "hard", "لاعبون", "Who holds the record for most goals in one World Cup edition with 13?", "Just Fontaine", listOf("Gerd Müller", "Ronaldo", "Kylian Mbappé")),
        q("s49", "ما لقب الحارس المصري عصام الحضري الشهير؟", "السد العالي", listOf("الأخطبوط", "المايسترو", "المدفعجي"), "easy", "مصر", "What is Egyptian goalkeeper Essam El-Hadary's famous nickname?", "The High Dam", listOf("The Octopus", "The Maestro", "The Cannon")),
        q("s50", "مين نجم الأهلي المصري الملقب بـ«الماجيكو»؟", "محمد أبو تريكة", listOf("محمد بركات", "عماد متعب", "حسام غالي"), "easy", "مصر", "Which Al Ahly legend was nicknamed 'El Magico'?", "Mohamed Aboutrika", listOf("Mohamed Barakat", "Emad Moteab", "Hossam Ghaly")),
        q("s51", "كام دقيقة مدة المباراة الأصلية في كرة القدم بدون وقت بدل ضائع؟", "90 دقيقة", listOf("80 دقيقة", "100 دقيقة", "120 دقيقة"), "easy", "قوانين", "How long is normal playing time in football, excluding added time?", "90 minutes", listOf("80 minutes", "100 minutes", "120 minutes")),
        q("s52", "علامة الجزاء تبعد كام متر عن خط المرمى؟", "11 مترًا", listOf("9 أمتار", "10 أمتار", "12 مترًا"), "medium", "قوانين", "How far is the penalty mark from the goal line?", "11 metres", listOf("9 metres", "10 metres", "12 metres")),
        q("s53", "كام لاعب لازم يفضلوا على الأقل في الفريق عشان المباراة تستمر؟", "7 لاعبين", listOf("5 لاعبين", "6 لاعبين", "8 لاعبين"), "hard", "قوانين", "What is the minimum number of players a team must have for a match to continue?", "7 players", listOf("5 players", "6 players", "8 players")),
        q("s54", "هل ممكن تسجيل هدف مباشرة من رمية التماس؟", "لا", listOf("نعم، في أي مرمى", "نعم، في مرمى الخصم فقط", "فقط في الوقت الإضافي"), "hard", "قوانين", "Can a goal be scored directly from a throw-in?", "No", listOf("Yes, into either goal", "Yes, only into the opponents' goal", "Only in extra time")),
        q("s55", "هل يوجد تسلل مباشرة من ركلة مرمى؟", "لا", listOf("نعم دائمًا", "نعم لو المهاجم داخل المنطقة", "حسب حكم الراية"), "hard", "قوانين", "Can a player be offside directly from a goal kick?", "No", listOf("Yes, always", "Yes, if inside the box", "It depends on the assistant referee")),
        q("s56", "ما لون البطاقة التي تعني الطرد؟", "الحمراء", listOf("الصفراء", "الزرقاء", "الخضراء"), "easy", "قوانين", "Which card means a player is sent off?", "Red", listOf("Yellow", "Blue", "Green")),
        q("s57", "أي جزء من جسم اللاعب لا يُحتسب به تسلل؟", "اليد والذراع", listOf("الرأس", "القدم", "الكتف"), "hard", "قوانين", "Which body parts are not considered when judging offside?", "Hands and arms", listOf("Head", "Feet", "Shoulder")),
        q("s58", "مين فاز ببطولة يورو 2016؟", "البرتغال", listOf("فرنسا", "ألمانيا", "إيطاليا"), "easy", "أوروبا", "Who won UEFA Euro 2016?", "Portugal", listOf("France", "Germany", "Italy")),
        q("s59", "أي منتخب فاز بيورو 2020 التي أُقيمت مبارياتها النهائية في 2021؟", "إيطاليا", listOf("إنجلترا", "إسبانيا", "الدنمارك"), "medium", "أوروبا", "Who won Euro 2020, played its final in 2021?", "Italy", listOf("England", "Spain", "Denmark")),
        q("s60", "مين سجّل هدف البرتغال في نهائي يورو 2016؟", "إيدير", listOf("كريستيانو رونالدو", "ناني", "ريكاردو كواريزما"), "hard", "أوروبا", "Who scored Portugal's winning goal in the Euro 2016 final?", "Éder", listOf("Cristiano Ronaldo", "Nani", "Ricardo Quaresma")),
        q("s61", "مين فاز بكأس أمم أفريقيا 2023؟", "كوت ديفوار", listOf("نيجيريا", "السنغال", "جنوب أفريقيا"), "easy", "أفريقيا", "Who won the 2023 Africa Cup of Nations?", "Côte d’Ivoire", listOf("Nigeria", "Senegal", "South Africa")),
        q("s62", "مين فاز بأمم أفريقيا 2021 اللي اتلعبت في 2022؟", "السنغال", listOf("مصر", "الكاميرون", "المغرب"), "easy", "أفريقيا", "Who won AFCON 2021, played in 2022?", "Senegal", listOf("Egypt", "Cameroon", "Morocco")),
        q("s63", "أي منتخب هو الوحيد اللي فاز بأمم أفريقيا 3 مرات متتالية؟", "مصر", listOf("الكاميرون", "غانا", "نيجيريا"), "hard", "أفريقيا", "Which country is the only team to win three consecutive AFCON titles?", "Egypt", listOf("Cameroon", "Ghana", "Nigeria")),
        q("s64", "مين الهداف التاريخي لكأس أمم أفريقيا برصيد 18 هدفًا؟", "صامويل إيتو", listOf("ديدييه دروجبا", "حسام حسن", "ساديو ماني"), "hard", "أفريقيا", "Who is AFCON's all-time top scorer with 18 goals?", "Samuel Eto’o", listOf("Didier Drogba", "Hossam Hassan", "Sadio Mané")),
        q("s65", "مين أول منتخب أفريقي وعربي شارك في كأس العالم؟", "مصر", listOf("المغرب", "تونس", "الجزائر"), "medium", "مصر", "Which was the first African and Arab team to play at a World Cup?", "Egypt", listOf("Morocco", "Tunisia", "Algeria")),
        q("s66", "مين المنتخب اللي فاز على مصر 4-2 في كأس العالم 1934؟", "المجر", listOf("إيطاليا", "النمسا", "ألمانيا"), "hard", "مصر", "Which team beat Egypt 4-2 at the 1934 World Cup?", "Hungary", listOf("Italy", "Austria", "Germany")),
        q("s67", "مين سجّل هدفي مصر في ظهورها الأول بكأس العالم سنة 1934؟", "عبد الرحمن فوزي", listOf("مختار التتش", "حسين حجازي", "محمد لطيف"), "hard", "مصر", "Who scored Egypt's two goals in its 1934 World Cup debut?", "Abdelrahman Fawzi", listOf("Mokhtar El-Tetsh", "Hussein Hegazi", "Mohamed Latif")),
        q("s68", "مين فاز ببطولة يورو 2024؟", "إسبانيا", listOf("إنجلترا", "فرنسا", "ألمانيا"), "easy", "أوروبا", "Who won UEFA Euro 2024?", "Spain", listOf("England", "France", "Germany")),
        q("s69", "مين خسر نهائي يورو 2000 قدام فرنسا؟", "إيطاليا", listOf("البرتغال", "هولندا", "ألمانيا"), "medium", "أوروبا", "Which team lost the Euro 2000 final to France?", "Italy", listOf("Portugal", "Netherlands", "Germany")),
        q("s70", "مين سجّل الهدف الذهبي لفرنسا في نهائي يورو 2000؟", "دافيد تريزيجيه", listOf("زين الدين زيدان", "تييري هنري", "سيلفان ويلتورد"), "hard", "أوروبا", "Who scored France's golden goal in the Euro 2000 final?", "David Trezeguet", listOf("Zinedine Zidane", "Thierry Henry", "Sylvain Wiltord")),
        q("s71", "أي منتخب فاز بيورو 1992 في مفاجأة كبيرة؟", "الدنمارك", listOf("ألمانيا", "هولندا", "السويد"), "medium", "أوروبا", "Which team won Euro 1992 in a famous surprise?", "Denmark", listOf("Germany", "Netherlands", "Sweden")),
        q("s72", "مين فاز بكأس العالم 1994؟", "البرازيل", listOf("إيطاليا", "السويد", "بلغاريا"), "easy", "كأس العالم", "Who won the 1994 FIFA World Cup?", "Brazil", listOf("Italy", "Sweden", "Bulgaria")),
        q("s73", "إيه نتيجة نهائي كأس العالم 1994 بعد الوقت الإضافي وقبل ركلات الترجيح؟", "0-0", listOf("1-0 للبرازيل", "1-0 لإيطاليا", "2-2"), "hard", "كأس العالم", "What was the score after extra time in the 1994 World Cup final, before penalties?", "0-0", listOf("Brazil led 1-0", "Italy led 1-0", "2-2")),
        q("s74", "مين فاز بدوري أبطال أوروبا 2025؟", "باريس سان جيرمان", listOf("إنتر ميلان", "ريال مدريد", "أرسنال"), "easy", "أوروبا", "Who won the 2025 UEFA Champions League?", "Paris Saint-Germain", listOf("Inter", "Real Madrid", "Arsenal")),
        q("s75", "كام هدف سجّل باريس سان جيرمان في نهائي دوري الأبطال 2025؟", "5", listOf("2", "3", "4"), "medium", "أوروبا", "How many goals did Paris Saint-Germain score in the 2025 Champions League final?", "5", listOf("2", "3", "4")),
        q("s76", "مين فاز بدوري أبطال أوروبا 2023؟", "مانشستر سيتي", listOf("إنتر ميلان", "ريال مدريد", "بايرن ميونخ"), "easy", "أوروبا", "Who won the 2023 UEFA Champions League?", "Manchester City", listOf("Inter", "Real Madrid", "Bayern Munich")),
        q("s77", "مين سجّل هدف مانشستر سيتي في نهائي دوري الأبطال 2023؟", "رودري", listOf("إيرلينج هالاند", "كيفن دي بروين", "فيل فودين"), "hard", "أوروبا", "Who scored Manchester City's goal in the 2023 Champions League final?", "Rodri", listOf("Erling Haaland", "Kevin De Bruyne", "Phil Foden")),
        q("s78", "مين فاز بدوري أبطال أوروبا 2024؟", "ريال مدريد", listOf("بوروسيا دورتموند", "بايرن ميونخ", "باريس سان جيرمان"), "easy", "أوروبا", "Who won the 2024 UEFA Champions League?", "Real Madrid", listOf("Borussia Dortmund", "Bayern Munich", "Paris Saint-Germain")),
        q("s79", "مين فاز بنهائي دوري الأبطال 2019 قدام توتنهام؟", "ليفربول", listOf("توتنهام", "مانشستر سيتي", "أياكس"), "easy", "أوروبا", "Who beat Tottenham in the 2019 Champions League final?", "Liverpool", listOf("Tottenham", "Manchester City", "Ajax")),
        q("s80", "مين سجّل هدف بايرن ميونخ الوحيد في نهائي دوري الأبطال 2020؟", "كينغسلي كومان", listOf("روبرت ليفاندوفسكي", "توماس مولر", "سيرج غنابري"), "hard", "أوروبا", "Who scored Bayern Munich's only goal in the 2020 Champions League final?", "Kingsley Coman", listOf("Robert Lewandowski", "Thomas Müller", "Serge Gnabry")),
        q("s81", "مين فاز بدوري أبطال أوروبا 2004 بقيادة جوزيه مورينيو؟", "بورتو", listOf("موناكو", "ميلان", "تشيلسي"), "medium", "أوروبا", "Which team won the 2004 Champions League under José Mourinho?", "Porto", listOf("Monaco", "AC Milan", "Chelsea")),
        q("s82", "مين فاز بنهائي دوري الأبطال 2021؟", "تشيلسي", listOf("مانشستر سيتي", "ريال مدريد", "باريس سان جيرمان"), "medium", "أوروبا", "Who won the 2021 Champions League final?", "Chelsea", listOf("Manchester City", "Real Madrid", "Paris Saint-Germain")),
        q("s83", "مين سجّل هدفين برشلونة في نهائي دوري الأبطال 2009 ضد مانشستر يونايتد؟", "صامويل إيتو وميسي", listOf("تشافي وإنييستا", "هنري وميسي", "بويول وإيتو"), "hard", "أوروبا", "Who scored Barcelona's two goals in the 2009 Champions League final against Manchester United?", "Samuel Eto’o and Messi", listOf("Xavi and Iniesta", "Henry and Messi", "Puyol and Eto’o")),
        q("s84", "مين فاز بنهائي دوري الأبطال 2012 بعد ركلات الترجيح؟", "تشيلسي", listOf("بايرن ميونخ", "ريال مدريد", "برشلونة"), "medium", "أوروبا", "Who won the 2012 Champions League final on penalties?", "Chelsea", listOf("Bayern Munich", "Real Madrid", "Barcelona")),
        q("s85", "مين فاز بكأس أمم أفريقيا 2017؟", "الكاميرون", listOf("مصر", "غانا", "بوركينا فاسو"), "medium", "أفريقيا", "Who won the 2017 Africa Cup of Nations?", "Cameroon", listOf("Egypt", "Ghana", "Burkina Faso"))
    )

    private fun q(
        id: String,
        text: String,
        answer: String,
        wrong: List<String>,
        difficulty: String,
        category: String,
        textEn: String,
        answerEn: String,
        wrongEn: List<String>,
        explanation: String = "",
        explanationEn: String = ""
    ) = Question(
        id = id,
        text = text,
        options = listOf(answer) + wrong,
        answer = answer,
        difficulty = difficulty,
        category = category,
        explanation = explanation,
        textEn = textEn,
        optionsEn = listOf(answerEn) + wrongEn,
        answerEn = answerEn,
        explanationEn = explanationEn
    )
}
