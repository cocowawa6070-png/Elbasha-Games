package com.mostafabek.elbashagames

import kotlin.random.Random

data class MatchScore(val userGoals: Int, val opponentGoals: Int) {
    val userWon: Boolean get() = userGoals > opponentGoals
    val opponentWon: Boolean get() = userGoals < opponentGoals
    val isDraw: Boolean get() = userGoals == opponentGoals
}

/** Lightweight local match simulation: squad quality influences chances, but never guarantees a win. */
object MatchEngine {
    fun simulate(
        userTeam: List<PlayerCard>,
        opponentTeam: List<PlayerCard>,
        userCoachBonus: Double = 0.0,
        opponentCoachBonus: Double = 0.0,
        random: Random = Random.Default
    ): MatchScore {
        val userStrength = strength(userTeam, userCoachBonus)
        val opponentStrength = strength(opponentTeam, opponentCoachBonus)
        val difference = ((userStrength - opponentStrength) / 28.0).coerceIn(-0.8, 0.8)
        val userExpectedGoals = (1.25 + difference * 0.85).coerceIn(0.20, 2.50)
        val opponentExpectedGoals = (1.25 - difference * 0.85).coerceIn(0.20, 2.50)
        return MatchScore(
            userGoals = poisson(userExpectedGoals, random),
            opponentGoals = poisson(opponentExpectedGoals, random)
        )
    }

    private fun strength(team: List<PlayerCard>, coachBonus: Double): Double {
        if (team.isEmpty()) return 60.0 + coachBonus
        val averageRating = team.sumOf { it.rating }.toDouble() / team.size
        val positionalCoverage = team.map { it.position }.distinct().size * 0.55
        return averageRating + positionalCoverage + coachBonus.coerceIn(0.0, 8.0)
    }

    private fun poisson(lambda: Double, random: Random): Int {
        val threshold = kotlin.math.exp(-lambda)
        var product = 1.0
        var goals = 0
        do {
            goals++
            product *= random.nextDouble()
        } while (product > threshold && goals < 7)
        return (goals - 1).coerceIn(0, 6)
    }
}
