package com.mostafabek.elbashagames

import kotlin.random.Random

data class MatchScore(val userGoals: Int, val opponentGoals: Int) {
    val userWon: Boolean get() = userGoals > opponentGoals
    val opponentWon: Boolean get() = userGoals < opponentGoals
    val isDraw: Boolean get() = userGoals == opponentGoals
}

/** Lightweight local match simulation: squad quality influences chances, but never guarantees a win. */
object MatchEngine {
    fun simulate(
        userTeam: List<PlayerCard>,
        opponentTeam: List<PlayerCard>,
        userCoachBonus: Double = 0.0,
        opponentCoachBonus: Double = 0.0,
        random: Random = Random.Default,
        targetSquadSize: Int? = null
    ): MatchScore {
        val defaultLineupSize = maxOf(userTeam.size, opponentTeam.size).coerceIn(4, 11)
        val lineupSize = (targetSquadSize ?: defaultLineupSize).coerceIn(4, 11)
        val userStrength = strength(userTeam, userCoachBonus, lineupSize)
        val opponentStrength = strength(opponentTeam, opponentCoachBonus, lineupSize)
        val difference = ((userStrength - opponentStrength) / 28.0).coerceIn(-0.8, 0.8)
        val userExpectedGoals = (1.25 + difference * 0.85).coerceIn(0.20, 2.50)
        val opponentExpectedGoals = (1.25 - difference * 0.85).coerceIn(0.20, 2.50)
        return MatchScore(
            userGoals = poisson(userExpectedGoals, random),
            opponentGoals = poisson(opponentExpectedGoals, random)
        )
    }

    private fun strength(team: List<PlayerCard>, coachBonus: Double, lineupSize: Int): Double {
        if (team.isEmpty()) return 60.0 + coachBonus
        val lineup = selectBestLineup(team, lineupSize)
        val averageRating = lineup.sumOf { it.rating }.toDouble() / lineup.size.coerceAtLeast(1)
        val positionalCoverage = positionalFit(lineup, lineupSize) * 6.0
        return averageRating + positionalCoverage + coachBonus.coerceIn(0.0, 8.0)
    }

    /**
     * Picks the strongest legal starting group when a game grants extra players (for example,
     * a bank deal in Deal or No Deal). Positional coverage takes priority over rating, so a
     * bench duplicate never displaces a missing role merely because its OVR is higher.
     */
    internal fun selectBestLineup(team: List<PlayerCard>, targetSize: Int): List<PlayerCard> {
        val requiredSize = targetSize.coerceIn(1, 11)
        if (team.size <= requiredSize) return team

        var best = team.take(requiredSize)
        var bestCoverage = positionalFit(best, requiredSize)
        var bestAverage = best.sumOf { it.rating }.toDouble() / requiredSize
        val selected = ArrayList<PlayerCard>(requiredSize)

        fun search(start: Int) {
            if (selected.size == requiredSize) {
                val coverage = positionalFit(selected, requiredSize)
                val average = selected.sumOf { it.rating }.toDouble() / requiredSize
                if (coverage > bestCoverage || (coverage == bestCoverage && average > bestAverage)) {
                    best = selected.toList()
                    bestCoverage = coverage
                    bestAverage = average
                }
                return
            }
            val stillNeeded = requiredSize - selected.size
            val lastStart = team.size - stillNeeded
            for (index in start..lastStart) {
                selected.add(team[index])
                search(index + 1)
                selected.removeAt(selected.lastIndex)
            }
        }

        search(0)
        return best
    }

    /** Measures coverage by tactical role families, allowing a defender to fill a defender slot. */
    internal fun positionalFit(team: List<PlayerCard>, targetSize: Int = team.size): Double {
        if (team.isEmpty()) return 0.0
        val expected = ElbashaPositions.formationSlots(targetSize.coerceIn(4, 11))
            .groupingBy { ElbashaPositions.poolRole(it) }
            .eachCount()
            .filterKeys { it.isNotBlank() }
        val actual = team.groupingBy { ElbashaPositions.poolRole(it.position) }
            .eachCount()
            .filterKeys { it.isNotBlank() }
        val matchedSlots = expected.entries.sumOf { (role, count) ->
            minOf(count, actual[role] ?: 0)
        }
        return (matchedSlots.toDouble() / expected.values.sum().coerceAtLeast(1)).coerceIn(0.0, 1.0)
    }

    private fun poisson(lambda: Double, random: Random): Int {
        val threshold = kotlin.math.exp(-lambda)
        var product = 1.0
        var goals = 0
        do {
            goals++
            product *= random.nextDouble()
        } while (product > threshold && goals < 7)
        return (goals - 1).coerceIn(0, 6)
    }
}
