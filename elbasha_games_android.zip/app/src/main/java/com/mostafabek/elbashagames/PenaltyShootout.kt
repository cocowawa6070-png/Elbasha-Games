package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random

private enum class PenaltyDirection { Left, Center, Right }

@Composable
fun PenaltyShootoutScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    var defending by remember { mutableStateOf(false) }
    var attempt by remember { mutableIntStateOf(0) }
    var playerGoals by remember { mutableIntStateOf(0) }
    var keeperSaves by remember { mutableIntStateOf(0) }
    var computerGoals by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf<String?>(null) }
    var finished by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var difficulty by remember { mutableStateOf("Balanced") }
    val playerPattern = remember { mutableListOf<PenaltyDirection>() }

    val won = playerGoals > computerGoals
    val drawn = playerGoals == computerGoals
    val finalScore = playerGoals * 100 + keeperSaves * 75 + when {
        won -> 200
        drawn -> 100
        else -> 0
    }

    BackHandler { onExit() }

    DisposableEffect(Unit) {
        sound.playMusic(Track.Tournament)
        onDispose { sound.playMusic(Track.Menu) }
    }

    LaunchedEffect(finished) {
        if (finished) {
            if (won) sound.play(Sfx.Win)
            ScoreRepository.submit(database, user, finalScore) { saved ->
                saveStatus = if (saved) {
                    if (english) "Penalty challenge score saved ✅" else "اتحفظت نتيجة ضربات الترجيح ✅"
                } else {
                    if (english) "Could not save your score. Check Firebase setup." else "تعذر حفظ النتيجة. راجع إعدادات Firebase."
                }
            }
        }
    }

    fun resetGame() {
        defending = false
        attempt = 0
        playerGoals = 0
        keeperSaves = 0
        computerGoals = 0
        feedback = null
        saveStatus = ""
        playerPattern.clear()
        finished = false
    }

    fun takeAction(direction: PenaltyDirection) {
        if (feedback != null || finished) return
        sound.play(Sfx.Click)
        playerPattern.add(direction)
        val levels = mapOf("Rookie" to 0.10f, "Balanced" to 0.35f, "Pro" to 0.65f, "Legend" to 0.90f)
        val learnChance = levels[difficulty] ?: 0.35f
        val predicted = playerPattern.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        val guessedDirection = if (predicted != null && Random.nextFloat() < learnChance) predicted else PenaltyDirection.values().random()
        val saveChance = when (difficulty) { "Rookie" -> 0.35f; "Pro" -> 0.68f; "Legend" -> 0.82f; else -> 0.52f }
        val wasSaved = direction == guessedDirection && Random.nextFloat() < saveChance
        if (!defending) {
            if (wasSaved) {
                feedback = if (english) "SAVED! The goalkeeper guessed your direction." else "اتصدّت! الحارس قرأ اتجاهك صح."
                sound.play(Sfx.Wrong)
                sound.vibrate(110)
            } else {
                playerGoals++
                feedback = if (english) "GOAL! A clean finish." else "جوووول! تسديدة متقنة."
                sound.play(Sfx.Correct)
                sound.vibrate(30)
            }
        } else {
            if (wasSaved) {
                keeperSaves++
                feedback = if (english) "BIG SAVE! You denied the shot." else "تصدي عالمي! منعت هدف مؤكد."
                sound.play(Sfx.Win)
                sound.vibrate(30)
            } else {
                computerGoals++
                feedback = if (english) "The CPU scores this one." else "الكمبيوتر سجّل المرة دي."
                sound.play(Sfx.Wrong)
                sound.vibrate(100)
            }
        }
    }

    fun continueMatch() {
        feedback = null
        if (attempt < 4) {
            attempt++
        } else if (!defending) {
            defending = true
            attempt = 0
        } else {
            finished = true
        }
    }

    if (finished) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine)))
                .verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                when {
                    won -> uiText("🏆 فزت بركلات الترجيح!", "🏆 You won the shootout!")
                    drawn -> uiText("🤝 تعادل!", "🤝 It's a draw!")
                    else -> uiText("🥅 الكمبيوتر كسب", "🥅 The CPU won")
                },
                color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(18.dp))
            Text("$playerGoals - $computerGoals", color = Gold, fontSize = 52.sp, fontWeight = FontWeight.Black)
            Text(uiText("أهدافك مقابل أهداف الكمبيوتر", "Your goals vs CPU goals"), color = Muted)
            Spacer(Modifier.height(8.dp))
            Text(uiText("تصدياتك: $keeperSaves", "Your saves: $keeperSaves"), color = Cream, fontWeight = FontWeight.Bold)
            Text("$finalScore ${uiText("نقطة", "points")}", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving your result…") }, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(
                onClick = { resetGame() },
                modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
            ) { Text(uiText("مباراة جديدة", "Play again"), fontWeight = FontWeight.Bold) }
            TextButton(onClick = onExit) { Text(uiText("الرجوع للألعاب", "Back to games"), color = Gold) }
        }
        return
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine)))
            .verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(uiText("🥅 تحدي ضربات الترجيح", "🥅 Penalty Shootout"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text(uiText("مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Rookie", "Balanced", "Pro", "Legend").forEach { level ->
                TextButton(onClick = { if (attempt == 0 && playerGoals == 0 && computerGoals == 0) difficulty = level }) {
                    Text(if (difficulty == level) "★ $level" else level, color = if (difficulty == level) Gold else Muted, fontSize = 11.sp)
                }
            }
        }
        Text(
            if (!defending) uiText("دورك تسدد: اختار مكان التسديدة وحاول تخدع الحارس.", "Your turn to shoot: choose a corner and beat the keeper.")
            else uiText("دورك تحرس: توقّع اتجاه تسديدة الكمبيوتر واختار مكان القفزة.", "Your turn to keep: predict the CPU shot and choose where to dive."),
            color = Muted, fontSize = 13.sp
        )
        Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$playerGoals", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text(uiText("أهدافك", "You"), color = Cream)
                }
                Text(":", color = Muted, fontSize = 28.sp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$computerGoals", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text(uiText("الكمبيوتر", "CPU"), color = Cream)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$keeperSaves", color = LocalElbashaPalette.current.good, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text(uiText("تصدياتك", "Saves"), color = Cream)
                }
            }
        }
        Box(
            Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF236E42), Color(0xFF12452F)))),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🥅", fontSize = 58.sp)
                AnimatedContent(
                    targetState = feedback,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "penalty-feedback"
                ) { result ->
                    Text(
                        result ?: if (!defending) uiText("اختار مكان التسديدة", "Choose your shot") else uiText("اختار اتجاه القفزة", "Choose your dive"),
                        color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (!defending) uiText("التسديدة ${attempt + 1} من 5", "Shot ${attempt + 1} of 5") else uiText("التصدي ${attempt + 1} من 5", "Save ${attempt + 1} of 5"), color = Cream, fontWeight = FontWeight.Bold)
            Text(if (!defending) uiText("مرحلة التسديد", "Shooting phase") else uiText("مرحلة الحراسة", "Goalkeeping phase"), color = Gold, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                PenaltyDirection.Left to uiText("شمال", "Left"),
                PenaltyDirection.Center to uiText("في النص", "Center"),
                PenaltyDirection.Right to uiText("يمين", "Right")
            ).forEach { (direction, label) ->
                Button(
                    onClick = { takeAction(direction) },
                    enabled = feedback == null,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine, disabledContainerColor = PanelColor, disabledContentColor = Muted)
                ) { Text(label, fontWeight = FontWeight.Bold) }
            }
        }
        if (feedback != null) {
            Button(
                onClick = { continueMatch() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = PanelAltColor, contentColor = Cream)
            ) {
                Text(
                    if (!defending && attempt == 4) uiText("انتقل للحراسة 🧤", "Switch to goalkeeping 🧤")
                    else if (defending && attempt == 4) uiText("اعرض النتيجة 🏆", "Show final result 🏆")
                    else uiText("التالي ←", "Next →")
                )
            }
        }
        Text(
            uiText("الكمبيوتر بيتعلم من تكرار اتجاهاتك. مستوى الصعوبة بيحدد قوة قراءة النمط ودقة التصدي.", "The CPU adapts to repeated directions. Difficulty changes how well it reads patterns and its save accuracy."),
            color = Muted, fontSize = 11.sp
        )
    }
}

