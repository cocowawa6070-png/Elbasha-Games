package com.mostafabek.elbashagames

import kotlin.random.Random

/** Rules for Deal or No Deal. Every participant owns a private set of four cases. */
object DealRules {
    const val FINAL_CARD_WINDOW_SECONDS = 60
    const val MIN_TEAM_SIZE = 6
    const val MAX_TEAM_SIZE = 11
    const val MIN_CARDS_PER_PLAYER = 1
    const val MAX_CARDS_PER_PLAYER = 5
    const val MIN_PARTICIPANTS = 2
    const val MAX_PARTICIPANTS = 4

    /**
     * Minimum size of a filtered player pool for this slot. Each earlier slot in the same
     * broad role may consume up to two players per participant (one rejected, one accepted);
     * the current slot still needs four fresh cases per participant.
     */
    fun minimumCandidatesRequired(slots: List<String>, slotIndex: Int, participantCount: Int): Int? {
        if (participantCount !in MIN_PARTICIPANTS..MAX_PARTICIPANTS || slotIndex !in slots.indices) return null
        val role = ElbashaPositions.poolRole(slots[slotIndex])
        if (role.isEmpty()) return null
        val priorSameRoleSlots = slots.take(slotIndex).count { ElbashaPositions.poolRole(it) == role }
        return participantCount * (4 + 2 * priorSameRoleSlots)
    }

    /**
     * Build a separate four-case hand (1 strong, 2 medium, 1 weak) for each participant. Case contents are disjoint for
     * this position, and no participant gets a player already drafted or rejected by anyone.
     * Unopened cases are not exposed to other participants and are discarded after the turn.
     */
    fun createPrivateCaseSets(
        players: List<PlayerCard>,
        slot: String,
        participantSeenNames: List<Set<String>>,
        draftedNames: Set<String>,
        random: Random = Random.Default
    ): List<List<PlayerCard>> {
        require(participantSeenNames.size in MIN_PARTICIPANTS..MAX_PARTICIPANTS)
        val globallyBlocked = draftedNames + participantSeenNames.flatten().toSet()
        val reservedForThisRound = mutableSetOf<String>()
        return participantSeenNames.map {
            val pool = players.filter { player ->
                ElbashaPositions.supports(player, slot) &&
                    player.nameEn !in globallyBlocked && player.nameEn !in reservedForThisRound
            }
            // Every hand holds 1 strong + 2 medium + 1 weak player. Inside a tier the players who
            // really play this slot come first; a missing tier is topped up from the other tiers.
            fun pick(tier: PlayerTier, count: Int, taken: Set<String>) = pool
                .filter { it.tier == tier && it.nameEn !in taken }
                .shuffled(random)
                .sortedBy { PlayerNaturalPositions.fitRank(it, slot) }
                .take(count)
            val chosen = mutableListOf<PlayerCard>()
            chosen += pick(PlayerTier.STRONG, 1, emptySet())
            chosen += pick(PlayerTier.MEDIUM, 2, chosen.map { it.nameEn }.toSet())
            chosen += pick(PlayerTier.WEAK, 1, chosen.map { it.nameEn }.toSet())
            if (chosen.size < 4) {
                chosen += pool.filter { candidate -> chosen.none { it.nameEn == candidate.nameEn } }
                    .shuffled(random)
                    .sortedBy { PlayerNaturalPositions.fitRank(it, slot) }
                    .take(4 - chosen.size)
            }
            require(chosen.size == 4) {
                "Not enough unique ${ElbashaPositions.poolRole(slot)} players for private cases at $slot"
            }
            reservedForThisRound += chosen.map { it.nameEn }
            chosen.shuffled(random).map { it.copy(position = slot) }
        }
    }

    /** Return every case left unopened after the decision, preserving its visible case number. */
    fun unopenedCasesAfterDecision(
        cases: List<PlayerCard>,
        acceptedIndex: Int,
        rejectedIndex: Int = -1
    ): List<Pair<Int, PlayerCard>> {
        if (cases.size != 4 || acceptedIndex !in cases.indices || rejectedIndex !in -1..3 || rejectedIndex == acceptedIndex) {
            return emptyList()
        }
        return cases.mapIndexedNotNull { index, player ->
            if (index == acceptedIndex || index == rejectedIndex) null else index to player
        }
    }

    /** Deal accepts the first opened case. No rejected player is transferred to another team. */
    fun acceptDeal(cases: List<PlayerCard>, firstIndex: Int): DealDraftResult? {
        if (cases.size != 4 || firstIndex !in cases.indices) return null
        return DealDraftResult(accepted = cases[firstIndex], rejected = null, openedIndex = firstIndex)
    }

    /** No Deal locks the first case and forces acceptance of exactly one of the other three. */
    fun acceptRisk(cases: List<PlayerCard>, firstIndex: Int, secondIndex: Int): DealDraftResult? {
        if (cases.size != 4 || firstIndex !in cases.indices || secondIndex !in cases.indices || secondIndex == firstIndex) return null
        return DealDraftResult(
            accepted = cases[secondIndex],
            rejected = cases[firstIndex],
            openedIndex = secondIndex
        )
    }

    /** AI chooses from its own private hand only; it never uses or sees the human's cases. */
    fun chooseAiOpeningIndex(cases: List<PlayerCard>, difficulty: Int, random: Random = Random.Default): Int? {
        if (cases.size != 4) return null
        val level = difficulty.coerceIn(0, 3)
        // Easy samples from the whole hand; Expert narrows to the strongest available case.
        val focus = when (level) {
            0 -> 1.0
            1 -> 0.75
            2 -> 0.50
            else -> 0.25
        }
        val shortlist = cases.sortedByDescending { it.rating }.take((cases.size * focus).toInt().coerceAtLeast(1))
        val chosen = shortlist.randomOrNull(random) ?: return null
        return cases.indexOf(chosen)
    }

    /** On harder settings the AI is more likely to risk a low first reveal for a better one. */
    fun aiShouldRisk(first: PlayerCard, cases: List<PlayerCard>, difficulty: Int): Boolean {
        if (cases.size != 4) return false
        val bestAlternative = cases.filterNot { it.nameEn == first.nameEn }.maxOfOrNull { it.rating } ?: return false
        val requiredGap = when (difficulty.coerceIn(0, 3)) {
            0 -> 12
            1 -> 8
            2 -> 5
            else -> 2
        }
        return bestAlternative - first.rating >= requiredGap
    }

    fun chooseAiRiskIndex(cases: List<PlayerCard>, firstIndex: Int, difficulty: Int, random: Random = Random.Default): Int? {
        if (cases.size != 4 || firstIndex !in cases.indices) return null
        val alternatives = cases.indices.filter { it != firstIndex }
        val level = difficulty.coerceIn(0, 3)
        val focus = when (level) { 0 -> 1.0; 1 -> 0.75; 2 -> 0.50; else -> 0.25 }
        val count = (alternatives.size * focus).toInt().coerceAtLeast(1)
        val preferred = alternatives.sortedByDescending { cases[it].rating }.take(count)
        return preferred.randomOrNull(random)
    }

    fun createFinalCardHand(count: Int, random: Random = Random.Default): List<DealFinalCard> {
        require(count in MIN_CARDS_PER_PLAYER..MAX_CARDS_PER_PLAYER)
        if (count == 1) return listOf(DealFinalCard(if (random.nextBoolean()) DealFinalCardType.STEAL else DealFinalCardType.SHIELD))
        return List(count) { index ->
            DealFinalCard(if (index % 2 == 0) DealFinalCardType.STEAL else DealFinalCardType.SHIELD)
        }.shuffled(random)
    }

    /** The card phase allows stealing only an unprotected player from another team. */
    fun canSteal(target: PlayerCard, protectedNames: Set<String>): Boolean = target.nameEn !in protectedNames

    /** A steal moves one player; it never duplicates the player across two squads. */
    fun stealPlayer(
        teams: List<List<PlayerCard>>,
        stealingTeam: Int,
        targetTeam: Int,
        targetName: String,
        protectedNames: Set<String>
    ): List<List<PlayerCard>>? {
        if (stealingTeam !in teams.indices || targetTeam !in teams.indices || stealingTeam == targetTeam) return null
        val target = teams[targetTeam].firstOrNull { it.nameEn == targetName } ?: return null
        if (!canSteal(target, protectedNames)) return null
        return teams.mapIndexed { index, team ->
            when (index) {
                stealingTeam -> team + target
                targetTeam -> team.filterNot { it.nameEn == targetName }
                else -> team
            }
        }
    }

    fun protectPlayer(
        team: List<PlayerCard>,
        currentProtected: Set<String>,
        playerName: String
    ): Set<String>? {
        if (team.none { it.nameEn == playerName }) return null
        return currentProtected + playerName
    }
}

data class DealDraftResult(
    val accepted: PlayerCard,
    val rejected: PlayerCard?,
    val openedIndex: Int
)

enum class DealFinalCardType { STEAL, SHIELD }

data class DealFinalCard(val type: DealFinalCardType)
