package com.mostafabek.elbashagames

import kotlin.random.Random

/** Pure draft rules for Deal or No Deal. */

data class DealStealResolution(
    val userTeam: List<PlayerCard>,
    val aiTeam: List<PlayerCard>,
    val userStole: PlayerCard?,
    val aiStole: PlayerCard?,
    val sameTargetCanceled: Boolean
)

object DealRules {
    /** Build four unique boxes for a round from the required role, excluding both teams. */
    fun createRoundBoxes(
        players: List<PlayerCard>,
        slot: String,
        excludedNames: Set<String>,
        random: Random = Random.Default
    ): List<PlayerCard> = players
        .filter { ElbashaPositions.supports(it, slot) && it.nameEn !in excludedNames }
        .shuffled(random)
        .take(4)
        .map { it.copy(position = slot) }

    /** AI may not draft a player already owned OR shown in any of the current round's boxes. */
    fun eligibleAiPlayers(
        players: List<PlayerCard>,
        slot: String,
        userTeam: List<PlayerCard>,
        aiTeam: List<PlayerCard>,
        visibleBoxes: List<PlayerCard>
    ): List<PlayerCard> {
        val blocked = (userTeam + aiTeam + visibleBoxes).map { it.nameEn }.toSet()
        return players.filter { ElbashaPositions.supports(it, slot) && it.nameEn !in blocked }
    }

    /** Higher difficulty focuses its random choice on stronger eligible players. */
    fun chooseAiPlayer(
        players: List<PlayerCard>,
        slot: String,
        userTeam: List<PlayerCard>,
        aiTeam: List<PlayerCard>,
        visibleBoxes: List<PlayerCard>,
        difficulty: Int,
        random: Random = Random.Default
    ): PlayerCard? {
        val candidates = eligibleAiPlayers(players, slot, userTeam, aiTeam, visibleBoxes)
        if (candidates.isEmpty()) return null
        val aiIsBehind = aiTeam.sumOf { it.rating } < userTeam.sumOf { it.rating }
        val baseFocus = when (difficulty.coerceIn(0, 3)) {
            0 -> 0.78
            1 -> 0.60
            2 -> 0.40
            else -> 0.24
        }
        val focusRatio = (baseFocus + if (aiIsBehind) -0.10 else 0.08).coerceIn(0.15, 0.90)
        val focusSize = (candidates.size * focusRatio).toInt().coerceAtLeast(1)
        return candidates.sortedByDescending { it.rating }.take(focusSize).randomOrNull(random)
            ?.copy(position = slot)
    }

    /** Return the weakest unopened player other than excluded box indices for Sabotage. */
    fun weakestUnopenedBoxIndex(boxes: List<PlayerCard>, excludedIndices: Set<Int>): Int? =
        boxes.indices.filter { it !in excludedIndices }
            .minWithOrNull(compareBy<Int> { boxes[it].rating }.thenBy { it })

    /**
     * Resolve both steal cards atomically. The user's target must belong to the AI squad,
     * and the AI's target must belong to the user's squad. If both point at the same
     * footballer (possible with stale/duplicated team state), both steals are canceled.
     * A shield blocks the steal against its protected player.
     */
    fun resolveSimultaneousSteals(
        userTargetName: String,
        aiTargetName: String?,
        userTeam: List<PlayerCard>,
        aiTeam: List<PlayerCard>,
        userShieldedName: String?,
        aiShieldedName: String?
    ): DealStealResolution {
        if (aiTargetName != null && userTargetName == aiTargetName) {
            return DealStealResolution(userTeam, aiTeam, null, null, true)
        }
        val userTarget = aiTeam.firstOrNull { it.nameEn == userTargetName }
            ?.takeUnless { it.nameEn == aiShieldedName }
        val aiTarget = aiTargetName?.let { name -> userTeam.firstOrNull { it.nameEn == name } }
            ?.takeUnless { it.nameEn == userShieldedName }

        val nextUser = buildList {
            addAll(userTeam.filterNot { it.nameEn == aiTarget?.nameEn })
            userTarget?.let { add(it) }
        }
        val nextAi = buildList {
            addAll(aiTeam.filterNot { it.nameEn == userTarget?.nameEn })
            aiTarget?.let { add(it) }
        }
        return DealStealResolution(nextUser, nextAi, userTarget, aiTarget, false)
    }

    /** The bank can only select an unopened box, never the first revealed box. */
    fun randomUnopenedBoxIndex(boxCount: Int, openedIndex: Int, random: Random = Random.Default): Int? {
        if (boxCount <= 1 || openedIndex !in 0 until boxCount) return null
        return (0 until boxCount).filter { it != openedIndex }.randomOrNull(random)
    }
}
