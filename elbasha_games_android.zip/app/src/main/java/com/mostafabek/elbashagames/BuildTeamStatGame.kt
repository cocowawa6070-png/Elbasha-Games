package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class BuildTeamPlayMode { PASS_AND_PLAY, AI }
private enum class BuildTeamStatPhase { SETUP, COUNTDOWN, HANDOVER, PICKING, AI_THINKING, ROUND_REVEAL, RESULT }

/**
 * Build a Team follows the 11 real formation slots from goalkeeper to striker.
 * The AI generates a fresh player filter and metric for every slot; higher values score more.
 */
@Composable
fun BuildTeamStatScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val palette = LocalElbashaPalette.current
    var onlineMode by remember { mutableStateOf(false) }
    if (onlineMode) {
        OnlineBuildTeamScreen(user, database, sound) { onlineMode = false }
        return
    }

    val squadSize = 11
    val slots = remember { ElbashaPositions.formationSlots(squadSize) }
    var mode by remember { mutableStateOf(BuildTeamPlayMode.PASS_AND_PLAY) }
    var phase by remember { mutableStateOf(BuildTeamStatPhase.SETUP) }
    var playerCount by remember { mutableIntStateOf(2) }
    var turnTimeSeconds by remember { mutableIntStateOf(30) }
    var turnSecondsLeft by remember { mutableIntStateOf(30) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var rosterFilter by remember { mutableStateOf(BuildTeamRosterFilter.RANDOM) }
    var countdown by remember { mutableIntStateOf(3) }
    var roundRevealReady by remember { mutableStateOf(false) }
    var roundRevealCount by remember { mutableIntStateOf(0) }
    var roundIndex by remember { mutableIntStateOf(0) }
    var turnIndex by remember { mutableIntStateOf(0) }
    var searchText by remember { mutableStateOf("") }
    var pendingPlayer by remember { mutableStateOf<PlayerCard?>(null) }
    var status by remember { mutableStateOf("") }
    var pickLocked by remember { mutableStateOf(false) }
    var scoreSaved by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var showLeaderboard by remember { mutableStateOf(false) }
    val nameInputs = remember { mutableStateListOf("", "", "", "") }
    val teamPicks = remember { List(PassAndPlayRules.MAX_PLAYERS) { mutableStateListOf<BuildTeamRoundPick>() } }
    var activeChallenge by remember { mutableStateOf<BuildTeamRoundChallenge?>(null) }
    var challengeHistory by remember { mutableStateOf(emptyList<BuildTeamRoundChallenge>()) }

    val activePlayerTotal = if (mode == BuildTeamPlayMode.AI) 2 else playerCount
    val normalizedNames = if (mode == BuildTeamPlayMode.AI) {
        listOf(user.displayName?.trim().takeUnless { it.isNullOrBlank() } ?: user.email?.substringBefore("@") ?: "مصطفى", "ELBASHA AI")
    } else {
        PassAndPlayRules.normalizeNames(nameInputs.toList(), playerCount) { if (english) "Player $it" else "لاعب $it" }
    }
    val order = if (mode == BuildTeamPlayMode.AI) listOf(0, 1) else PassAndPlayRules.pickingOrder(playerCount, roundIndex)
    val currentPlayerIndex = order.getOrNull(turnIndex) ?: 0
    val currentPlayerName = normalizedNames.getOrNull(currentPlayerIndex).orEmpty()
    val usedNames = teamPicks.take(activePlayerTotal).flatMap { list -> list.map { it.player.nameEn } }.toSet()
    val challenge = activeChallenge
    val challengeCandidates = challenge?.let {
        BuildTeamStatRules.playersForChallenge(PlayerFactsDatabase.players, it, usedNames)
    }.orEmpty()
    val suggestions = if (PlayerSearch.normalize(searchText).length >= 3) {
        PlayerSearch.suggestions(challengeCandidates, searchText, limit = 12)
    } else emptyList()
    val totals = (0 until activePlayerTotal).map { index -> teamPicks[index].sumOf { it.value } }
    val ranking = totals.indices.sortedByDescending { totals[it] }
    val progress = ((roundIndex * activePlayerTotal + turnIndex).toFloat() / (squadSize * activePlayerTotal)).coerceIn(0f, 1f)
    val currentRoundPicks = (0 until activePlayerTotal).mapNotNull { index -> teamPicks[index].getOrNull(roundIndex)?.let { index to it } }
    val roundWinners = if (currentRoundPicks.isEmpty() || challenge == null) emptySet() else {
        val target = if (challenge.direction == BuildTeamDirection.HIGH) currentRoundPicks.maxOf { it.second.value }
        else currentRoundPicks.minOf { it.second.value }
        currentRoundPicks.filter { it.second.value == target }.map { it.first }.toSet()
    }

    fun makeChallenge(slotIndex: Int): BuildTeamRoundChallenge? {
        val slot = slots.getOrNull(slotIndex) ?: return null
        val alreadyUsed = teamPicks.take(activePlayerTotal).flatMap { list -> list.map { it.player.nameEn } }.toSet()
        return BuildTeamStatRules.randomRoundChallenge(
            players = PlayerFactsDatabase.players,
            slot = slot,
            selectedRosterFilter = rosterFilter,
            usedNames = alreadyUsed,
            participantCount = activePlayerTotal,
            previousFilterKeys = challengeHistory.map { it.filterKey }.toSet(),
            random = Random.Default
        )
    }

    fun resetMatch() {
        teamPicks.forEach { it.clear() }
        roundIndex = 0
        turnIndex = 0
        turnSecondsLeft = turnTimeSeconds
        searchText = ""
        pendingPlayer = null
        status = ""
        saveStatus = ""
        scoreSaved = false
        pickLocked = false
        countdown = 3
        roundRevealReady = false
        roundRevealCount = 0
        activeChallenge = null
        challengeHistory = emptyList()
        showLeaderboard = false
    }

    fun startGame() {
        if (!BuildTeamStatRules.canBuildFullRoster(PlayerFactsDatabase.players, rosterFilter, activePlayerTotal, slots)) {
            status = if (english) "This player-pool filter cannot fill all 11 positions for every participant. Choose All or Random." else "فلتر نطاق اللاعبين ده مش فيه عدد كفاية لملء الـ11 مركز لكل المشاركين. اختار كل اللاعبين أو عشوائي."
            return
        }
        resetMatch()
        val first = makeChallenge(0)
        if (first == null) {
            status = if (english) "Not enough eligible players for an 11-player formation with this roster filter." else "عدد اللاعبين المتاحين مش كفاية لتكوين 11 لاعبًا بالفلتر ده. اختار كل اللاعبين أو عشوائي."
            return
        }
        activeChallenge = first
        challengeHistory = listOf(first)
        phase = BuildTeamStatPhase.COUNTDOWN
        sound.play(Sfx.Click)
    }

    fun advanceToNextRound() {
        if (roundIndex >= squadSize - 1) {
            phase = BuildTeamStatPhase.RESULT
            return
        }
        val nextIndex = roundIndex + 1
        val nextChallenge = makeChallenge(nextIndex)
        if (nextChallenge == null) {
            status = if (english) "The player pool ran out for ${slots[nextIndex]}. The match ends with the completed rounds." else "اللاعبين المطابقين خلصوا في مركز ${slots[nextIndex]}، هنحسب النتيجة بالجولات المكتملة."
            phase = BuildTeamStatPhase.RESULT
            return
        }
        roundIndex = nextIndex
        activeChallenge = nextChallenge
        challengeHistory = challengeHistory + nextChallenge
        turnIndex = 0
        roundRevealReady = false
        roundRevealCount = 0
        pendingPlayer = null
        pickLocked = false
        searchText = ""
        phase = if (mode == BuildTeamPlayMode.PASS_AND_PLAY) BuildTeamStatPhase.HANDOVER else BuildTeamStatPhase.PICKING
    }

    fun advanceAfterPick() {
        searchText = ""
        pendingPlayer = null
        pickLocked = false
        if (mode == BuildTeamPlayMode.AI) {
            if (turnIndex == 0) {
                turnIndex = 1
                phase = BuildTeamStatPhase.AI_THINKING
            } else {
                roundRevealReady = false
                roundRevealCount = 0
                countdown = 3
                phase = BuildTeamStatPhase.ROUND_REVEAL
            }
        } else if (turnIndex < playerCount - 1) {
            turnIndex++
            phase = BuildTeamStatPhase.HANDOVER
        } else {
            roundRevealReady = false
            roundRevealCount = 0
            countdown = 3
            phase = BuildTeamStatPhase.ROUND_REVEAL
        }
        sound.play(Sfx.Correct)
    }

    fun choosePlayer(player: PlayerCard) {
        val active = activeChallenge ?: return
        if (phase != BuildTeamStatPhase.PICKING || pickLocked) return
        if (challengeCandidates.none { it.nameEn == player.nameEn }) return
        val value = BuildTeamStatRules.value(player, active.metric) ?: return
        pickLocked = true
        val slotPlayer = player.copy(position = active.slot)
        teamPicks[currentPlayerIndex].add(
            BuildTeamRoundPick(
                player = slotPlayer,
                value = value,
                slot = active.slot,
                metric = active.metric,
                direction = active.direction,
                filterLabelAr = active.filterLabelAr,
                filterLabelEn = active.filterLabelEn
            )
        )
        sound.play(Sfx.Correct)
        sound.vibrate(22)
        advanceAfterPick()
    }

    BackHandler { onExit() }

    LaunchedEffect(phase) {
        if (phase == BuildTeamStatPhase.COUNTDOWN) {
            for (number in 3 downTo 1) {
                countdown = number
                delay(850)
                if (phase != BuildTeamStatPhase.COUNTDOWN) return@LaunchedEffect
            }
            phase = if (mode == BuildTeamPlayMode.PASS_AND_PLAY) BuildTeamStatPhase.HANDOVER else BuildTeamStatPhase.PICKING
        } else if (phase == BuildTeamStatPhase.ROUND_REVEAL) {
            roundRevealReady = false
            roundRevealCount = 0
            for (number in 3 downTo 1) {
                countdown = number
                delay(850)
                if (phase != BuildTeamStatPhase.ROUND_REVEAL) return@LaunchedEffect
            }
            if (phase == BuildTeamStatPhase.ROUND_REVEAL) {
                roundRevealReady = true
                for (count in 1..activePlayerTotal) {
                    delay(750)
                    if (phase != BuildTeamStatPhase.ROUND_REVEAL) return@LaunchedEffect
                    roundRevealCount = count.coerceAtMost(currentRoundPicks.size)
                    sound.play(Sfx.HiddenReveal)
                }
            }
        }
    }

    LaunchedEffect(phase, roundIndex, turnIndex, activeChallenge) {
        if (phase == BuildTeamStatPhase.PICKING) pickLocked = false
        if (phase == BuildTeamStatPhase.AI_THINKING) {
            delay(950)
            if (phase != BuildTeamStatPhase.AI_THINKING) return@LaunchedEffect
            val active = activeChallenge ?: return@LaunchedEffect
            val candidates = BuildTeamStatRules.playersForChallenge(PlayerFactsDatabase.players, active, usedNames)
            val choice = BuildTeamStatRules.chooseAiPlayer(candidates, active.metric, active.direction, aiDifficulty)
            if (choice != null) {
                val value = BuildTeamStatRules.value(choice, active.metric) ?: 0
                teamPicks[1].add(
                    BuildTeamRoundPick(
                        player = choice.copy(position = active.slot),
                        value = value,
                        slot = active.slot,
                        metric = active.metric,
                        direction = active.direction,
                        filterLabelAr = active.filterLabelAr,
                        filterLabelEn = active.filterLabelEn
                    )
                )
                sound.play(Sfx.Tick)
                roundRevealReady = false
                roundRevealCount = 0
                countdown = 3
                phase = BuildTeamStatPhase.ROUND_REVEAL
            } else {
                status = if (english) "AI has no unused player for this position and filter." else "الـAI معندوش لاعب متاح للمركز والفلتر ده."
                phase = BuildTeamStatPhase.RESULT
            }
        }
    }

    LaunchedEffect(phase, roundIndex, turnIndex, turnTimeSeconds, activeChallenge) {
        if (phase == BuildTeamStatPhase.PICKING) {
            val timedRound = roundIndex
            val timedTurn = turnIndex
            for (seconds in turnTimeSeconds downTo 1) {
                turnSecondsLeft = seconds
                delay(1_000)
                if (phase != BuildTeamStatPhase.PICKING || roundIndex != timedRound || turnIndex != timedTurn) return@LaunchedEffect
            }
            if (phase == BuildTeamStatPhase.PICKING && roundIndex == timedRound && turnIndex == timedTurn) {
                val active = activeChallenge ?: return@LaunchedEffect
                val automaticPick = pendingPlayer?.takeIf { candidate -> challengeCandidates.any { it.nameEn == candidate.nameEn } }
                    ?: if (active.direction == BuildTeamDirection.HIGH) {
                        challengeCandidates.maxByOrNull { BuildTeamStatRules.value(it, active.metric) ?: Int.MIN_VALUE }
                    } else {
                        challengeCandidates.minByOrNull { BuildTeamStatRules.value(it, active.metric) ?: Int.MAX_VALUE }
                    }
                if (automaticPick != null) {
                    status = if (english) "Time expired: the strongest eligible answer for this round was selected." else "الوقت خلص، اتختار أفضل لاعب متاح حسب تحدي الجولة."
                    choosePlayer(automaticPick)
                } else {
                    status = if (english) "No unused players remain for this position." else "مفيش لاعبين متاحين للمركز ده."
                    phase = BuildTeamStatPhase.RESULT
                }
            }
        }
    }

    LaunchedEffect(phase, totals, ranking) {
        if (phase == BuildTeamStatPhase.RESULT && mode == BuildTeamPlayMode.AI && !scoreSaved) {
            scoreSaved = true
            val userWon = totals.getOrNull(0)?.let { userTotal ->
                userTotal > (totals.getOrNull(1) ?: Int.MIN_VALUE)
            } ?: false
            val score = if (userWon) 1_000 + totals[0].coerceAtLeast(0) else 0
            if (ElbashaAccess.isDeveloper(user.uid)) {
                saveStatus = if (english) "Developer account is excluded from competitive rankings." else "حساب المطور مستبعد من الترتيب التنافسي."
            } else {
                ScoreRepository.submit(database, user, score) { saved ->
                    saveStatus = if (saved) {
                        if (english) "Result saved to the leaderboard." else "تم حفظ النتيجة في الترتيب."
                    } else {
                        if (english) "Could not save the result. Check Firebase." else "تعذر حفظ النتيجة. راجع Firebase."
                    }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = palette.panelAlt),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(localizedText(english, "كوّن فريق", "BUILD A TEAM"), color = palette.gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text(
                    localizedText(english, "11 جولة من الحارس للمهاجم. كل مركز له فلتر وإحصائية جديدة يختارهم الـAI؛ تختار لاعبًا مطابقًا، وقيمة الإحصائية نفسها تتحول لنقاط، والأعلى يكسب.", "Eleven rounds from goalkeeper to striker. The AI creates a new filter and stat for each position; the chosen player's actual value becomes points, and higher values win."),
                    color = palette.cream, fontSize = 12.sp, lineHeight = 18.sp
                )
            }
        }

        if (phase !in setOf(BuildTeamStatPhase.SETUP, BuildTeamStatPhase.COUNTDOWN)) {
            val active = challenge
            if (active != null) {
                val posLabel = BuildTeamRules.positionLabels[active.slot]?.let { if (english) it.second else it.first } ?: active.slot
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.2.dp, palette.gold.copy(alpha = 0.65f), RoundedCornerShape(18.dp)),
                    colors = CardDefaults.cardColors(containerColor = palette.panel),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(localizedText(english, "الجولة ${roundIndex + 1} من 11 • ${active.slot}", "ROUND ${roundIndex + 1} / 11 • ${active.slot}"), color = palette.gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text(posLabel, color = palette.cream, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Text("${active.rosterFilter.labelAr} • ${if (english) active.filterLabelEn else active.filterLabelAr}", color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${if (english) active.metric.labelEn else active.metric.labelAr} (${if (english) active.metric.unitEn else active.metric.unitAr})", color = palette.gold, fontWeight = FontWeight.Bold)
                            Text(if (english) active.direction.labelEn else active.direction.labelAr, color = palette.cream, fontWeight = FontWeight.Black)
                        }
                        Text(localizedText(english, "المركز ده لازم يطلع من نفس الفلتر. ممنوع اختيار حارس بدل مهاجم أو العكس.", "The selected player must match this position. A goalkeeper can never fill a striker slot."), color = palette.muted, fontSize = 10.sp)
                    }
                }
            }
            Button(
                onClick = { showLeaderboard = !showLeaderboard },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.panelAlt, contentColor = palette.gold)
            ) { Text(if (showLeaderboard) localizedText(english, "إخفاء ترتيب الجيم", "HIDE GAME LEADERBOARD") else localizedText(english, "ترتيب الجيم أثناء اللعب", "VIEW GAME LEADERBOARD"), fontWeight = FontWeight.Black) }
            if (showLeaderboard) {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(localizedText(english, "ترتيب المباراة الحالية", "CURRENT MATCH LEADERBOARD"), color = palette.gold, fontWeight = FontWeight.Black)
                        ranking.forEachIndexed { place, index ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("${place + 1}. ${normalizedNames[index]}", color = palette.cream, fontWeight = FontWeight.Bold)
                                Text("${totals[index]} ${localizedText(english, "نقطة", "pts")}", color = palette.gold, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }

        when (phase) {
            BuildTeamStatPhase.SETUP -> {
                Text(localizedText(english, "طريقة اللعب", "PLAY MODE"), color = Cream, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ModeChoiceCard(
                        modifier = Modifier.weight(1f),
                        title = localizedText(english, "جهاز واحد", "ONE DEVICE"),
                        subtitle = localizedText(english, "2 إلى 4 لاعبين", "2 to 4 players"),
                        selected = mode == BuildTeamPlayMode.PASS_AND_PLAY
                    ) { mode = BuildTeamPlayMode.PASS_AND_PLAY }
                    ModeChoiceCard(
                        modifier = Modifier.weight(1f),
                        title = localizedText(english, "ضد AI", "VS AI"),
                        subtitle = localizedText(english, "لاعب واحد", "Single player"),
                        selected = mode == BuildTeamPlayMode.AI
                    ) { mode = BuildTeamPlayMode.AI }
                    ModeChoiceCard(
                        modifier = Modifier.weight(1f),
                        title = localizedText(english, "أونلاين", "ONLINE"),
                        subtitle = localizedText(english, "غرف اللعب", "Game rooms"),
                        selected = false
                    ) { onlineMode = true }
                }

                if (mode == BuildTeamPlayMode.PASS_AND_PLAY) {
                    Text(localizedText(english, "عدد اللاعبين", "PLAYERS"), color = Cream, fontWeight = FontWeight.Bold)
                    ChoiceRow((PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS).map { it.toString() }, playerCount.toString()) {
                        playerCount = it.toInt()
                    }
                    repeat(playerCount) { index ->
                        OutlinedTextField(
                            value = nameInputs[index], onValueChange = { nameInputs[index] = it.take(20) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text(localizedText(english, "اسم اللاعب ${index + 1}", "Player ${index + 1} name")) },
                            colors = outlinedColors()
                        )
                    }
                } else {
                    Text(localizedText(english, "هتلعب ضد ELBASHA AI، والـAI هيختار لاعبًا في نفس المركز وبنفس فلتر الجولة.", "You play ELBASHA AI. It must choose a player in the same position under the same round filter."), color = palette.muted, fontSize = 12.sp)
                    Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI DIFFICULTY"), color = Cream, fontWeight = FontWeight.Bold)
                    ChoiceRow(listOf("سهل", "متوازن", "صعب", "صعب جدًا"), listOf("سهل", "متوازن", "صعب", "صعب جدًا")[aiDifficulty]) {
                        aiDifficulty = listOf("سهل", "متوازن", "صعب", "صعب جدًا").indexOf(it).coerceAtLeast(0)
                    }
                }

                Text(localizedText(english, "فلتر نطاق اللاعبين", "PLAYER POOL FILTER"), color = Cream, fontWeight = FontWeight.Bold)
                ChoiceRow(
                    BuildTeamRosterFilter.entries.map { if (english) it.labelEn else it.labelAr },
                    if (english) rosterFilter.labelEn else rosterFilter.labelAr
                ) { selected ->
                    rosterFilter = BuildTeamRosterFilter.entries.first { (if (english) it.labelEn else it.labelAr) == selected }
                }
                Text(
                    localizedText(english, "الاختيار ده بيحدد نطاق اللاعبين فقط. الفلتر الدقيق والإحصائية بيتغيروا تلقائيًا كل جولة، والقيمة الأعلى هي اللي تكسب وتتحسب كنقاط.", "This only sets the player pool. The exact filter and stat change every round; higher values win and count directly as points."),
                    color = palette.muted, fontSize = 11.sp, lineHeight = 16.sp
                )

                Text(localizedText(english, "ترتيب المراكز الثابت", "FIXED POSITION ORDER"), color = Cream, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(15.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        slots.forEachIndexed { index, slot ->
                            val label = BuildTeamRules.positionLabels[slot]?.let { if (english) it.second else it.first } ?: slot
                            Text("${index + 1}. $label", color = if (index == 0 || index == 10) palette.gold else palette.cream, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(localizedText(english, "وقت الاختيار", "PICK TIMER"), color = Cream, fontWeight = FontWeight.Bold)
                ChoiceRow(listOf("15", "30", "60", "90"), turnTimeSeconds.toString()) { turnTimeSeconds = it.toInt() }
                Text(localizedText(english, "كل مباراة فيها 11 لاعبًا بالترتيب المحدد. مفيش اختيار مركز أو إحصائية ثابتة من الإعداد.", "Every match contains 11 players in the fixed order. Position or scoring stat cannot be locked at setup."), color = palette.muted, fontSize = 11.sp)
                if (status.isNotBlank()) Text(status, color = palette.bad, fontSize = 12.sp)
                Button(
                    onClick = { startGame() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "ابدأ تكوين الفريق", "START BUILDING THE TEAM"), fontWeight = FontWeight.Black) }
            }

            BuildTeamStatPhase.COUNTDOWN -> CountdownStage(countdown, localizedText(english, "التحدي هيبدأ", "The challenge starts"))

            BuildTeamStatPhase.HANDOVER -> {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(localizedText(english, "سلّم الموبايل", "PASS THE PHONE"), color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        Text(currentPlayerName, color = Cream, fontWeight = FontWeight.Black, fontSize = 26.sp)
                        Text(localizedText(english, "الجولة ${roundIndex + 1} من 11. باقي اللاعبين يبعدوا عينهم عن الشاشة.", "Round ${roundIndex + 1} of 11. Everyone else, look away."), color = palette.muted, textAlign = TextAlign.Center)
                        Button(
                            onClick = { searchText = ""; pendingPlayer = null; pickLocked = false; phase = BuildTeamStatPhase.PICKING; sound.play(Sfx.Click) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                        ) { Text(localizedText(english, "أنا $currentPlayerName — جاهز", "I'm $currentPlayerName — ready"), fontWeight = FontWeight.Bold) }
                    }
                }
            }

            BuildTeamStatPhase.AI_THINKING -> {
                Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(localizedText(english, "ELBASHA AI بيختار", "ELBASHA AI IS CHOOSING"), color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = palette.surface)
                        Text(localizedText(english, "بيفاضل بين اللاعبين المطابقين للتحدي الحالي.", "It is comparing players who match the current challenge."), color = palette.muted, textAlign = TextAlign.Center)
                    }
                }
            }

            BuildTeamStatPhase.PICKING -> {
                BuildTeamStatDraftBoard(
                    title = localizedText(english, "ملعب $currentPlayerName", "$currentPlayerName's pitch"),
                    picks = teamPicks[currentPlayerIndex].map { BuildTeamPick(it.player, it.value) },
                    slotCount = squadSize,
                    metric = challenge?.metric ?: BuildTeamMetric.PLAYER_RATING,
                    english = english
                )
                Text(localizedText(english, "دور ${currentPlayerName}", "${currentPlayerName}'s turn"), color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(localizedText(english, "المركز ${roundIndex + 1} من 11", "POSITION ${roundIndex + 1} OF 11"), color = palette.cream, fontWeight = FontWeight.Bold)
                    TurnTimerPill(turnSecondsLeft, turnTimeSeconds)
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = palette.panel)
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it; pendingPlayer = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(localizedText(english, "اكتب أول 3 أحرف من اسم اللاعب", "Type at least 3 letters of the player name")) },
                    colors = outlinedColors()
                )
                if (PlayerSearch.normalize(searchText).length < 3) {
                    Text(localizedText(english, "الاقتراحات هتظهر بعد أول 3 أحرف، وكل الأسماء لازم تطابق فلتر الجولة والمركز.", "Suggestions appear after 3 letters. Every result must match this round's filter and position."), color = palette.muted, fontSize = 11.sp)
                } else if (suggestions.isEmpty()) {
                    Text(localizedText(english, "مفيش لاعب متاح مطابق للتحدي ده.", "No unused player matches this challenge."), color = palette.bad, fontSize = 12.sp)
                }
                suggestions.forEach { player ->
                    val value = BuildTeamStatRules.value(player, challenge?.metric ?: BuildTeamMetric.PLAYER_RATING) ?: return@forEach
                    val selected = pendingPlayer?.nameEn == player.nameEn
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = !pickLocked) { pendingPlayer = player }
                            .border(if (selected) 2.dp else 1.dp, if (selected) palette.gold else palette.muted.copy(alpha = 0.2f), RoundedCornerShape(15.dp)),
                        colors = CardDefaults.cardColors(containerColor = if (selected) palette.panelAlt else palette.panel),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PlayerPortrait(player, Modifier.size(width = 65.dp, height = 76.dp), cornerRadius = 10)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = palette.cream, fontWeight = FontWeight.Black)
                                val facts = PlayerFactsDatabase.facts(player)
                                Text(facts?.let { "${it.club} • ${it.league}" } ?: "${player.nationalityAr} • ${player.position}", color = palette.muted, fontSize = 10.sp)
                                Text("$value ${if (english) challenge?.metric?.unitEn else challenge?.metric?.unitAr} = $value ${localizedText(english, "نقطة", "points")}", color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            }
                            if (selected) Text("✓", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                pendingPlayer?.let { selected ->
                    val selectedValue = BuildTeamStatRules.value(selected, challenge?.metric ?: BuildTeamMetric.PLAYER_RATING) ?: 0
                    Button(
                        onClick = { choosePlayer(selected) },
                        enabled = !pickLocked && phase == BuildTeamStatPhase.PICKING,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        Text(localizedText(english, "أكد ${selected.nameAr} • +$selectedValue نقطة", "CONFIRM ${selected.nameEn} • +$selectedValue POINTS"), fontWeight = FontWeight.Black)
                    }
                }
                if (status.isNotBlank()) Text(status, color = palette.bad, fontSize = 11.sp)
            }

            BuildTeamStatPhase.ROUND_REVEAL -> {
                if (!roundRevealReady) {
                    CountdownStage(countdown, localizedText(english, "كشف اختيارات الجولة", "Revealing this round's picks"))
                } else {
                    Text(localizedText(english, "كشف الجولة ${roundIndex + 1}", "ROUND ${roundIndex + 1} REVEAL"), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    currentRoundPicks.take(roundRevealCount).forEach { (playerIndex, pick) ->
                        androidx.compose.animation.AnimatedVisibility(
                            visible = true,
                            enter = androidx.compose.animation.fadeIn(tween(280)) + androidx.compose.animation.scaleIn(tween(320), initialScale = 0.9f)
                        ) {
                            BuildTeamRoundPickCard(normalizedNames[playerIndex], pick, playerIndex in roundWinners, english)
                        }
                    }
                    if (roundRevealCount < currentRoundPicks.size) {
                        Text(localizedText(english, "جاري كشف اختيارات اللاعبين...", "Revealing players one by one..."), color = palette.muted, fontSize = 11.sp)
                    }
                    Text(
                        if (roundWinners.size == 1) localizedText(english, "نقطة الجولة: ${normalizedNames[roundWinners.first()]}", "Round winner: ${normalizedNames[roundWinners.first()]}")
                        else localizedText(english, "تعادل في الجولة", "Round tied"),
                        color = Gold, fontWeight = FontWeight.Black
                    )
                    ranking.forEachIndexed { place, index ->
                        Text("${place + 1}. ${normalizedNames[index]} • ${totals[index]} ${localizedText(english, "نقطة", "points")}", color = Cream, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Button(
                        onClick = { advanceToNextRound() },
                        enabled = roundRevealCount >= currentRoundPicks.size,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                    ) {
                        Text(if (roundIndex == squadSize - 1) localizedText(english, "اعرض النتيجة النهائية", "SHOW FINAL RESULTS") else localizedText(english, "الجولة التالية", "NEXT ROUND"), fontWeight = FontWeight.Black)
                    }
                }
            }

            BuildTeamStatPhase.RESULT -> {
                Text(localizedText(english, "النتيجة النهائية", "FINAL RESULT"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                val winnerIndex = totals.indices.maxByOrNull { totals[it] } ?: 0
                val tied = totals.count { it == totals.getOrElse(winnerIndex) { 0 } } > 1
                Text(
                    if (tied) localizedText(english, "تعادل في مجموع النقاط", "Draw on total points")
                    else localizedText(english, "الفائز: ${normalizedNames[winnerIndex]}", "Winner: ${normalizedNames[winnerIndex]}"),
                    color = Gold, fontWeight = FontWeight.Black, fontSize = 19.sp
                )
                ranking.forEachIndexed { place, playerIndex ->
                    Card(colors = CardDefaults.cardColors(containerColor = palette.panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${place + 1}.", color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                                Text(normalizedNames[playerIndex], color = Cream, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                Text("${totals[playerIndex]} ${localizedText(english, "نقطة", "points")}", color = Gold, fontWeight = FontWeight.Black)
                            }
                            teamPicks[playerIndex].forEachIndexed { pickIndex, pick ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${pickIndex + 1}. ${pick.slot}", color = palette.muted, fontSize = 10.sp, modifier = Modifier.padding(end = 6.dp))
                                    PlayerPortrait(pick.player, Modifier.size(width = 38.dp, height = 44.dp), cornerRadius = 6)
                                    Column(Modifier.weight(1f).padding(start = 7.dp)) {
                                        Text(if (english) pick.player.nameEn else pick.player.nameAr, color = Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("${pick.filterLabelAr} • ${pick.metric.labelAr}", color = palette.muted, fontSize = 9.sp)
                                    }
                                    Text("${pick.value}", color = Gold, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
                if (saveStatus.isNotBlank()) Text(saveStatus, color = palette.muted, fontSize = 11.sp)
                Button(
                    onClick = { resetMatch(); phase = BuildTeamStatPhase.SETUP },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "تحدي جديد", "NEW CHALLENGE"), fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
private fun BuildTeamRoundPickCard(playerName: String, pick: BuildTeamRoundPick, isRoundWinner: Boolean, english: Boolean) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().border(if (isRoundWinner) 2.dp else 1.dp, if (isRoundWinner) palette.gold else palette.muted.copy(alpha = 0.25f), RoundedCornerShape(17.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(17.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PlayerPortrait(pick.player, Modifier.size(width = 72.dp, height = 84.dp), cornerRadius = 11)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(playerName, color = if (isRoundWinner) palette.gold else palette.cream, fontWeight = FontWeight.Black)
                Text(if (english) pick.player.nameEn else pick.player.nameAr, color = palette.cream, fontWeight = FontWeight.Bold)
                Text("${pick.value} ${if (english) pick.metric.unitEn else pick.metric.unitAr} = ${pick.value} ${if (english) "points" else "نقطة"}", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
            if (isRoundWinner) Text("WIN", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 11.sp)
        }
    }
}

@Composable
private fun BuildTeamStatDraftBoard(
    title: String,
    picks: List<BuildTeamPick>,
    slotCount: Int,
    metric: BuildTeamMetric,
    english: Boolean
) {
    val palette = LocalElbashaPalette.current
    val visibleSlots = slotCount.coerceAtLeast(4)
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = palette.gold, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text("${picks.size}/$slotCount", color = palette.cream, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF075437), Color(0xFF063B2D), Color(0xFF075437))))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp)).padding(9.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    (0 until visibleSlots).toList().chunked(3).forEach { rowIndexes ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            rowIndexes.forEach { index ->
                                val pick = picks.getOrNull(index)
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                        .background(if (pick == null) Color.Black.copy(alpha = 0.12f) else palette.deepWine)
                                        .border(1.dp, if (pick == null) Color.White.copy(alpha = 0.25f) else palette.gold.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                                        .padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    if (pick != null) {
                                        PlayerPortrait(pick.player, Modifier.height(55.dp).fillMaxWidth(), cornerRadius = 7)
                                        Text(if (english) pick.player.nameEn else pick.player.nameAr, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text("+${pick.value} ${if (english) "pts" else "نقطة"}", color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                    } else {
                                        Box(Modifier.height(55.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                            Text("${index + 1}", color = Color.White.copy(alpha = 0.85f), fontSize = 22.sp, fontWeight = FontWeight.Black)
                                        }
                                        Text(if (english) "OPEN SLOT" else "مركز فارغ", color = Color.White.copy(alpha = 0.7f), fontSize = 8.sp)
                                    }
                                }
                            }
                            repeat(3 - rowIndexes.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            Text(localizedText(english, "المجموع الحالي: ${BuildTeamStatRules.total(picks)} نقطة • ${metric.labelAr}", "Current total: ${BuildTeamStatRules.total(picks)} points • ${metric.labelEn}"), color = palette.gold, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
    }
}

private fun eligibleMetricCount(filter: BuildTeamFilter, metric: BuildTeamMetric): Int =
    BuildTeamStatRules.eligiblePlayers(PlayerFactsDatabase.players, filter, metric).size

@Composable
private fun ModeChoiceCard(
    modifier: Modifier,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(modifier = modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = if (selected) Gold else palette.panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(subtitle, color = if (selected) DeepWine else palette.muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ChoiceRow(values: List<String>, selected: String, enabled: List<Int>? = null, onSelect: (String) -> Unit) {
    val palette = LocalElbashaPalette.current
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEachIndexed { index, value ->
            val isEnabled = enabled?.getOrNull(index)?.let { it > 0 } ?: true
            Box(
                Modifier.clip(RoundedCornerShape(10.dp))
                    .background(when { !isEnabled -> palette.surface; value == selected -> Gold; else -> palette.panel })
                    .clickable(enabled = isEnabled) { onSelect(value) }
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    value,
                    color = when { !isEnabled -> palette.muted; value == selected -> DeepWine; else -> Cream },
                    fontWeight = if (value == selected) FontWeight.Black else FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Cream,
    unfocusedTextColor = Cream,
    focusedBorderColor = Gold,
    unfocusedBorderColor = LocalElbashaPalette.current.muted,
    focusedLabelColor = Gold,
    unfocusedLabelColor = LocalElbashaPalette.current.muted,
    cursorColor = Gold
)
