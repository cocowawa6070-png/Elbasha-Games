package com.mostafabek.elbashagames

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** User-facing preferences shared by every screen. */
data class AppUiSettings(
    val english: Boolean = false,
    val darkTheme: Boolean = true
)

val LocalAppUiSettings = compositionLocalOf { AppUiSettings() }

/** Central palette so the light/dark switch changes the whole experience, not just Material buttons. */
data class ElbashaPalette(
    val wine: Color,
    val deepWine: Color,
    val gold: Color,
    val cream: Color,
    val muted: Color,
    val panel: Color,
    val panelAlt: Color,
    val surface: Color,
    val good: Color,
    val bad: Color
)

private val DarkPalette = ElbashaPalette(
    wine = Color(0xFF500014),
    deepWine = Color(0xFF210009),
    gold = Color(0xFFE8B64E),
    cream = Color(0xFFFFF0D2),
    muted = Color(0xFFCABBAA),
    panel = Color(0xFF35101B),
    panelAlt = Color(0xFF4A1B28),
    surface = Color(0xFF2B0C15),
    good = Color(0xFF1F6B3A),
    bad = Color(0xFF8B1E2B)
)

private val LightPalette = ElbashaPalette(
    wine = Color(0xFFE8D7C8),
    deepWine = Color(0xFFFFF8F1),
    gold = Color(0xFF9B5C0B),
    cream = Color(0xFF2D1B18),
    muted = Color(0xFF705D54),
    panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFF1E5DA),
    surface = Color(0xFFFFFDFB),
    good = Color(0xFF1F7A46),
    bad = Color(0xFFB32635)
)

val LocalElbashaPalette = compositionLocalOf { DarkPalette }

@Composable
fun uiText(arabic: String, english: String): String =
    if (LocalAppUiSettings.current.english) english else arabic

/**
 * Non-composable localization helper for callbacks, coroutine effects and remember initializers.
 * Those scopes cannot read CompositionLocal values directly.
 */
fun localizedText(isEnglish: Boolean, arabic: String, englishText: String): String =
    if (isEnglish) englishText else arabic

val Wine: Color
    @Composable get() = LocalElbashaPalette.current.wine
val DeepWine: Color
    @Composable get() = LocalElbashaPalette.current.deepWine
val Gold: Color
    @Composable get() = LocalElbashaPalette.current.gold
val Cream: Color
    @Composable get() = LocalElbashaPalette.current.cream
val Muted: Color
    @Composable get() = LocalElbashaPalette.current.muted
val PanelColor: Color
    @Composable get() = LocalElbashaPalette.current.panel
val PanelAltColor: Color
    @Composable get() = LocalElbashaPalette.current.panelAlt

fun paletteFor(darkTheme: Boolean): ElbashaPalette = if (darkTheme) DarkPalette else LightPalette


/** Rich stadium-inspired background used behind the main app screens. */
@Composable
fun Modifier.elbashaAtmosphere(): Modifier {
    val palette = LocalElbashaPalette.current
    val ambience = rememberInfiniteTransition(label = "elbasha-ambient-background")
    val drift by ambience.animateFloat(
        initialValue = -0.045f, targetValue = 0.045f,
        animationSpec = infiniteRepeatable(tween(8200, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "ambient-drift"
    )
    val glow by ambience.animateFloat(
        initialValue = 0.035f, targetValue = 0.085f,
        animationSpec = infiniteRepeatable(tween(5100, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "ambient-glow"
    )
    return drawBehind {
        drawRect(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(palette.wine, palette.deepWine, palette.surface)
            )
        )
        val w = size.width
        val h = size.height
        drawCircle(
            color = palette.gold.copy(alpha = glow),
            radius = size.minDimension * 0.48f,
            center = Offset(w * (0.91f + drift), h * (0.12f + drift))
        )
        drawCircle(
            color = palette.gold.copy(alpha = 0.035f),
            radius = size.minDimension * 0.30f,
            center = Offset(w * (0.04f - drift), h * (0.76f - drift))
        )
        drawArc(
            color = palette.gold.copy(alpha = 0.10f),
            startAngle = 190f,
            sweepAngle = 160f,
            useCenter = false,
            topLeft = Offset(-w * 0.22f, h * 0.58f),
            size = Size(w * 1.44f, h * 0.72f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        drawLine(
            color = palette.gold.copy(alpha = 0.055f),
            start = Offset(w * 0.06f, h * 0.18f),
            end = Offset(w * 0.94f, h * 0.18f),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = palette.gold.copy(alpha = 0.04f),
            start = Offset(w * 0.12f, h * 0.86f),
            end = Offset(w * 0.88f, h * 0.86f),
            strokeWidth = 1.dp.toPx()
        )
    }
}
