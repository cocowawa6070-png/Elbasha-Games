package com.mostafabek.elbashagames

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** User-facing preferences shared by every screen. */
data class AppUiSettings(
    val english: Boolean = false,
    val darkTheme: Boolean = true
)

val LocalAppUiSettings = compositionLocalOf { AppUiSettings() }

/** Central palette so the light/dark switch changes the whole experience, not just Material buttons. */
data class ElbashaPalette(
    val wine: Color,
    val deepWine: Color,
    val gold: Color,
    val cream: Color,
    val muted: Color,
    val panel: Color,
    val panelAlt: Color,
    val surface: Color,
    val good: Color,
    val bad: Color
)

private val DarkPalette = ElbashaPalette(
    wine = Color(0xFF500014),
    deepWine = Color(0xFF210009),
    gold = Color(0xFFE8B64E),
    cream = Color(0xFFFFF0D2),
    muted = Color(0xFFCABBAA),
    panel = Color(0xFF35101B),
    panelAlt = Color(0xFF4A1B28),
    surface = Color(0xFF2B0C15),
    good = Color(0xFF1F6B3A),
    bad = Color(0xFF8B1E2B)
)

private val LightPalette = ElbashaPalette(
    wine = Color(0xFFE8D7C8),
    deepWine = Color(0xFFFFF8F1),
    gold = Color(0xFF9B5C0B),
    cream = Color(0xFF2D1B18),
    muted = Color(0xFF705D54),
    panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFF1E5DA),
    surface = Color(0xFFFFFDFB),
    good = Color(0xFF1F7A46),
    bad = Color(0xFFB32635)
)

val LocalElbashaPalette = compositionLocalOf { DarkPalette }

@Composable
fun uiText(arabic: String, english: String): String =
    if (LocalAppUiSettings.current.english) english else arabic

/**
 * Non-composable localization helper for callbacks, coroutine effects and remember initializers.
 * Those scopes cannot read CompositionLocal values directly.
 */
fun localizedText(isEnglish: Boolean, arabic: String, englishText: String): String =
    if (isEnglish) englishText else arabic

val Wine: Color
    @Composable get() = LocalElbashaPalette.current.wine
val DeepWine: Color
    @Composable get() = LocalElbashaPalette.current.deepWine
val Gold: Color
    @Composable get() = LocalElbashaPalette.current.gold
val Cream: Color
    @Composable get() = LocalElbashaPalette.current.cream
val Muted: Color
    @Composable get() = LocalElbashaPalette.current.muted
val PanelColor: Color
    @Composable get() = LocalElbashaPalette.current.panel
val PanelAltColor: Color
    @Composable get() = LocalElbashaPalette.current.panelAlt

fun paletteFor(darkTheme: Boolean): ElbashaPalette = if (darkTheme) DarkPalette else LightPalette


/** Rich stadium-inspired background used behind the main app screens. */
@Composable
fun Modifier.elbashaAtmosphere(): Modifier {
    val palette = LocalElbashaPalette.current
    // One slow loop (28 s) drives drifting stadium spotlights and rising golden embers.
    val transition = rememberInfiniteTransition(label = "atmosphere")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(28_000, easing = LinearEasing), RepeatMode.Restart),
        label = "atmosphere-phase"
    )
    return drawBehind {
        drawRect(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(palette.wine, palette.deepWine, palette.surface)
            )
        )
        val w = size.width
        val h = size.height
        drawCircle(
            color = palette.gold.copy(alpha = 0.075f),
            radius = size.minDimension * 0.48f,
            center = Offset(w * 0.96f, h * 0.12f)
        )
        drawCircle(
            color = palette.gold.copy(alpha = 0.035f),
            radius = size.minDimension * 0.30f,
            center = Offset(w * 0.04f, h * 0.76f)
        )
        drawArc(
            color = palette.gold.copy(alpha = 0.10f),
            startAngle = 190f,
            sweepAngle = 160f,
            useCenter = false,
            topLeft = Offset(-w * 0.22f, h * 0.58f),
            size = Size(w * 1.44f, h * 0.72f),
            style = Stroke(width = 1.4.dp.toPx())
        )
        drawLine(
            color = palette.gold.copy(alpha = 0.055f),
            start = Offset(w * 0.06f, h * 0.18f),
            end = Offset(w * 0.94f, h * 0.18f),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = palette.gold.copy(alpha = 0.04f),
            start = Offset(w * 0.12f, h * 0.86f),
            end = Offset(w * 0.88f, h * 0.86f),
            strokeWidth = 1.dp.toPx()
        )

        // ---- Life: moving spotlights ----
        val twoPi = (2.0 * Math.PI).toFloat()
        val spotRadius = size.minDimension * 0.70f
        val spotA = Offset(w * (0.5f + 0.42f * sin(phase * twoPi)), h * (0.28f + 0.14f * cos(phase * twoPi * 2f)))
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                colors = listOf(palette.gold.copy(alpha = 0.12f), Color.Transparent),
                center = spotA, radius = spotRadius
            ),
            radius = spotRadius, center = spotA
        )
        val spotB = Offset(w * (0.5f - 0.38f * sin(phase * twoPi + 1.7f)), h * (0.74f + 0.10f * sin(phase * twoPi * 3f)))
        drawCircle(
            brush = androidx.compose.ui.graphics.Brush.radialGradient(
                colors = listOf(palette.cream.copy(alpha = 0.05f), Color.Transparent),
                center = spotB, radius = spotRadius * 0.8f
            ),
            radius = spotRadius * 0.8f, center = spotB
        )

        // ---- Life: rising golden embers that fade in and out ----
        for (i in 0 until 18) {
            val speed = 1 + i % 3
            val progress = (phase * speed + (i * 0.618f) % 1f) % 1f
            val x = w * (((i * 0.137f) + 0.05f + 0.025f * sin(progress * twoPi + i)) % 1f)
            val y = h * (1f - progress)
            val fade = abs(sin(progress * Math.PI.toFloat()))
            drawCircle(
                color = (if (i % 4 == 0) palette.cream else palette.gold).copy(alpha = 0.30f * fade),
                radius = (1.1f + (i % 3) * 0.8f).dp.toPx(),
                center = Offset(x, y)
            )
        }
    }
}
