package com.mostafabek.elbashagames

/** Rules for the optional 20-second protection/steal phase after the football auction. */
object PostAuctionCardRules {
    const val WINDOW_SECONDS = 20

    fun canProtect(cardUsed: Boolean, squadSize: Int): Boolean = !cardUsed && squadSize > 0

    fun eligibleStealTargets(players: List<PlayerCard>, protectedName: String?): List<PlayerCard> =
        players.filterNot { it.nameEn == protectedName }

    fun canSteal(cardUsed: Boolean, players: List<PlayerCard>, protectedName: String?): Boolean =
        !cardUsed && eligibleStealTargets(players, protectedName).isNotEmpty()
}
