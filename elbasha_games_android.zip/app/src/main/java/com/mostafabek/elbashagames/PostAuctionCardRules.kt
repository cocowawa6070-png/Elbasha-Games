package com.mostafabek.elbashagames

/** Rules for the optional 20-second protection/steal phase after the football auction. */
object PostAuctionCardRules {
    const val WINDOW_SECONDS = 20

    fun canProtect(cardUsed: Boolean, squadSize: Int): Boolean = !cardUsed && squadSize > 0

    /** Protected players stay selectable: trying to steal one is a deliberate, wasted attempt. */
    @Suppress("UNUSED_PARAMETER")
    fun eligibleStealTargets(players: List<PlayerCard>, protectedName: String?): List<PlayerCard> = players

    fun isProtectedTarget(target: PlayerCard, protectedName: String?): Boolean =
        target.nameEn == protectedName

    fun canExchange(target: PlayerCard, replacement: PlayerCard): Boolean =
        target.nameEn != replacement.nameEn && target.position == replacement.position

    fun eligibleReplacements(players: List<PlayerCard>, target: PlayerCard): List<PlayerCard> =
        players.filter { canExchange(target, it) }

    @Suppress("UNUSED_PARAMETER")
    fun canSteal(cardUsed: Boolean, players: List<PlayerCard>, protectedName: String?): Boolean =
        !cardUsed && players.isNotEmpty()
}
