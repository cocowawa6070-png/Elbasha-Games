package com.mostafabek.elbashagames

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private data class ReleaseInfo(val versionCode: Int, val versionName: String, val apkUrl: String)

private data class DownloadSnapshot(
    val status: Int,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val reason: Int
)

@Composable
fun AppUpdaterCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val english = LocalAppUiSettings.current.english
    val preferences = remember(context) {
        context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    }

    var status by remember(english) {
        mutableStateOf(
            localizedText(
                english,
                "تحقق من وجود تحديثات جديدة على GitHub.",
                "Check GitHub for new updates."
            )
        )
    }
    var busy by remember { mutableStateOf(false) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    var activeDownloadId by remember {
        mutableStateOf(preferences.getLong("download_id", -1L).takeIf { it > 0L })
    }
    var downloadSnapshot by remember { mutableStateOf<DownloadSnapshot?>(null) }

    // Poll DownloadManager while a download is active so progress is visible in-app,
    // including after the user leaves and reopens this screen.
    LaunchedEffect(activeDownloadId) {
        val downloadId = activeDownloadId ?: return@LaunchedEffect
        while (true) {
            val snapshot = withContext(Dispatchers.IO) {
                queryUpdateDownload(context, downloadId)
            }

            if (snapshot == null) {
                status = localizedText(
                    english,
                    "تعذر العثور على مهمة التنزيل. جرّب تنزيل التحديث مرة أخرى.",
                    "The download task could not be found. Please try downloading again."
                )
                activeDownloadId = null
                break
            }

            downloadSnapshot = snapshot
            when (snapshot.status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    status = localizedText(
                        english,
                        "اكتمل تنزيل التحديث. جاري فتح خطوة التثبيت...",
                        "Update downloaded. Opening the installation step..."
                    )
                    val installerOpened = installDownloadedUpdateIfReady(context)
                    status = when {
                        installerOpened -> localizedText(
                            english,
                            "اكتمل التنزيل. اتبع نافذة أندرويد لإكمال التثبيت.",
                            "Download complete. Follow the Android prompt to finish installation."
                        )
                        android.os.Build.VERSION.SDK_INT >= 26 &&
                            !context.packageManager.canRequestPackageInstalls() -> localizedText(
                            english,
                            "اكتمل التنزيل. اسمح للتطبيق بتثبيت التطبيقات من هذا المصدر، ثم ارجع للتطبيق.",
                            "Download complete. Allow installs from this source, then return to the app."
                        )
                        else -> localizedText(
                            english,
                            "اكتمل التنزيل، لكن لم أتمكن من فتح نافذة التثبيت. اضغط تنزيل وتثبيت مرة أخرى أو أعد فتح التطبيق.",
                            "Download complete, but the installer could not be opened. Tap Download and Install again or reopen the app."
                        )
                    }
                    activeDownloadId = null
                    break
                }

                DownloadManager.STATUS_FAILED -> {
                    status = localizedText(
                        english,
                        "فشل تنزيل التحديث: ${downloadFailureMessage(snapshot.reason)}. تحقق من الإنترنت والمساحة المتاحة ثم حاول مرة أخرى.",
                        "Update download failed: ${downloadFailureMessage(snapshot.reason)}. Check your connection and free storage, then try again."
                    )
                    activeDownloadId = null
                    break
                }

                else -> {
                    status = when (snapshot.status) {
                        DownloadManager.STATUS_PAUSED -> localizedText(
                            english,
                            "التنزيل متوقف مؤقتًا: ${downloadPauseMessage(snapshot.reason)}",
                            "Download paused: ${downloadPauseMessage(snapshot.reason)}"
                        )
                        else -> localizedText(
                            english,
                            "جاري تنزيل التحديث...",
                            "Downloading update..."
                        )
                    }
                }
            }
            delay(500)
        }
    }

    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(status, modifier = Modifier.padding(bottom = 8.dp))

        Button(
            enabled = !busy && activeDownloadId == null,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    busy = true
                    release = null
                    status = localizedText(
                        english,
                        "جاري البحث عن آخر إصدار...",
                        "Checking for the latest release..."
                    )
                    try {
                        val latest = withContext(Dispatchers.IO) { fetchLatestRelease() }
                        release = latest
                        status = when {
                            latest == null -> localizedText(
                                english,
                                "مفيش إصدار منشور على GitHub لحد دلوقتي. أول ما ننشر APK في قسم Releases، التحقق من التحديثات هيشتغل من هنا.",
                                "No GitHub release has been published yet. Once an APK is published under Releases, this button will check it here."
                            )
                            latest.versionCode > BuildConfig.VERSION_CODE -> localizedText(
                                english,
                                "يتوفر إصدار ${latest.versionName}. اضغط تنزيل وتثبيت.",
                                "Version ${latest.versionName} is available. Tap Download and Install."
                            )
                            latest.versionCode == BuildConfig.VERSION_CODE -> localizedText(
                                english,
                                "أنت تستخدم أحدث إصدار (${BuildConfig.VERSION_NAME}).",
                                "You are using the latest version (${BuildConfig.VERSION_NAME})."
                            )
                            else -> localizedText(
                                english,
                                "الإصدار المثبت (${BuildConfig.VERSION_NAME}) أحدث من آخر إصدار منشور على GitHub (${latest.versionName}).",
                                "The installed version (${BuildConfig.VERSION_NAME}) is newer than the latest GitHub release (${latest.versionName})."
                            )
                        }
                    } catch (e: Exception) {
                        release = null
                        status = localizedText(
                            english,
                            "تعذر التحقق من التحديثات: ${e.localizedMessage ?: "خطأ اتصال"}",
                            "Could not check for updates: ${e.localizedMessage ?: "connection error"}"
                        )
                    } finally {
                        busy = false
                    }
                }
            }
        ) {
            Text(
                if (busy) localizedText(english, "جاري التحقق...", "Checking...")
                else localizedText(english, "التحقق من التحديثات", "Check for updates")
            )
        }

        val available = release
        if (available != null && available.versionCode > BuildConfig.VERSION_CODE) {
            Button(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                enabled = !busy && activeDownloadId == null,
                onClick = {
                    scope.launch {
                        busy = true
                        downloadSnapshot = null
                        status = localizedText(
                            english,
                            "جاري تجهيز تنزيل التحديث...",
                            "Preparing update download..."
                        )
                        try {
                            val downloadId = withContext(Dispatchers.IO) {
                                enqueueUpdateDownload(context, available.apkUrl)
                            }
                            activeDownloadId = downloadId
                            status = localizedText(
                                english,
                                "بدأ التنزيل. تابع النسبة والحجم بالأسفل.",
                                "Download started. Track its progress and size below."
                            )
                        } catch (e: Exception) {
                            status = localizedText(
                                english,
                                "فشل بدء التنزيل: ${e.localizedMessage ?: "خطأ غير معروف"}",
                                "Could not start download: ${e.localizedMessage ?: "unknown error"}"
                            )
                        } finally {
                            busy = false
                        }
                    }
                }
            ) {
                Text(
                    localizedText(
                        english,
                        "تنزيل وتثبيت ${available.versionName}",
                        "Download and install ${available.versionName}"
                    )
                )
            }
        }

        val progress = downloadSnapshot
        if (progress != null && progress.status != DownloadManager.STATUS_FAILED) {
            val hasKnownSize = progress.totalBytes > 0L
            val fraction = if (hasKnownSize) {
                (progress.downloadedBytes.toDouble() / progress.totalBytes.toDouble())
                    .toFloat().coerceIn(0f, 1f)
            } else {
                0f
            }
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
            val sizeText = if (hasKnownSize) {
                val percent = (fraction * 100f).toInt()
                "${formatBytes(progress.downloadedBytes)} / ${formatBytes(progress.totalBytes)} ($percent%)"
            } else {
                "${formatBytes(progress.downloadedBytes)} / ${localizedText(english, "حجم غير معروف", "size unknown")}"
            }
            Text(sizeText, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

private fun queryUpdateDownload(context: Context, downloadId: Long): DownloadSnapshot? {
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return null
    return cursor.use {
        if (!it.moveToFirst()) return null
        DownloadSnapshot(
            status = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
            downloadedBytes = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
            totalBytes = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
            reason = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
        )
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 0L) return "—"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1.0) String.format(Locale.US, "%.1f MB", mb)
    else String.format(Locale.US, "%.0f KB", bytes / 1024.0)
}

private fun downloadFailureMessage(reason: Int): String = when (reason) {
    DownloadManager.ERROR_INSUFFICIENT_SPACE -> "مساحة التخزين غير كافية"
    DownloadManager.ERROR_DEVICE_NOT_FOUND -> "مكان حفظ الملف غير متاح"
    DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "رابط التنزيل أعاد تحويلات كثيرة"
    DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "خادم GitHub رفض طلب التنزيل"
    DownloadManager.ERROR_HTTP_DATA_ERROR -> "حدث خطأ أثناء نقل البيانات"
    DownloadManager.ERROR_CANNOT_RESUME -> "تعذر استكمال التنزيل"
    DownloadManager.ERROR_FILE_ERROR -> "تعذر حفظ الملف"
    else -> "رمز الخطأ $reason"
}

private fun downloadPauseMessage(reason: Int): String = when (reason) {
    DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "في انتظار اتصال بالإنترنت"
    DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "في انتظار اتصال Wi-Fi"
    DownloadManager.PAUSED_WAITING_TO_RETRY -> "سيحاول التنزيل مرة أخرى"
    else -> "رمز الحالة $reason"
}

/**
 * Returns null only when the repository has no published GitHub Releases yet.
 * GitHub's /releases/latest endpoint returns HTTP 404 in that normal state.
 */
private fun fetchLatestRelease(): ReleaseInfo? {
    val connection = URL(
        "https://api.github.com/repos/cocowawa6070-png/Elbasha-Games/releases/latest"
    ).openConnection() as HttpURLConnection

    connection.connectTimeout = 15_000
    connection.readTimeout = 15_000
    connection.requestMethod = "GET"
    connection.instanceFollowRedirects = true
    connection.setRequestProperty("Accept", "application/vnd.github+json")
    connection.setRequestProperty("User-Agent", "ELBASHA-GAMES-Android")
    connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")

    try {
        val responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) return null
        if (responseCode !in 200..299) {
            val errorBody = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val apiMessage = runCatching {
                JSONObject(errorBody).optString("message").takeIf { it.isNotBlank() }
            }.getOrNull()
            error("GitHub HTTP $responseCode${apiMessage?.let { ": $it" }.orEmpty()}")
        }

        val responseText = connection.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(responseText)
        val tagName = json.optString("tag_name").trim()
        val releaseBody = json.optString("body", "")
        val versionCode = Regex("(?im)^\\s*versionCode\\s*[:=]\\s*(\\d+)\\s*$")
            .find(releaseBody)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: error("إصدار GitHub لا يحتوي على versionCode صالح")

        val assets = json.optJSONArray("assets")
            ?: error("إصدار GitHub لا يحتوي على قائمة ملفات APK")
        val apkAsset = (0 until assets.length())
            .asSequence()
            .map { assets.optJSONObject(it) }
            .filterNotNull()
            .firstOrNull { it.optString("name").endsWith(".apk", ignoreCase = true) }
            ?: error("تم العثور على إصدار GitHub لكن ملف APK غير مرفق به")

        val apkUrl = apkAsset.optString("browser_download_url").trim()
            .takeIf { it.startsWith("https://", ignoreCase = true) }
            ?: error("رابط تنزيل APK في GitHub غير صالح")
        val versionName = tagName.ifBlank { "v$versionCode" }
        return ReleaseInfo(versionCode, versionName, apkUrl)
    } finally {
        connection.disconnect()
    }
}

private fun enqueueUpdateDownload(context: Context, apkUrl: String): Long {
    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        ?: error("External downloads directory is unavailable")
    val destination = File(downloadDirectory, "elbasha-update.apk")
    if (destination.exists() && !destination.delete()) {
        error("Could not replace the previous update file")
    }

    val request = DownloadManager.Request(Uri.parse(apkUrl))
        .setTitle("ELBASHA GAMES Update")
        .setDescription("Downloading the latest version")
        .setMimeType("application/vnd.android.package-archive")
        // VISIBILITY_VISIBLE shows the ongoing download notification, not only completion.
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
        .setDestinationInExternalFilesDir(
            context,
            Environment.DIRECTORY_DOWNLOADS,
            "elbasha-update.apk"
        )

    val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val downloadId = downloadManager.enqueue(request)
    context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
        .edit()
        .putLong("download_id", downloadId)
        .apply()
    return downloadId
}

fun handleUpdateDownloadCompleted(context: Context, downloadId: Long) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    if (prefs.getLong("download_id", -1L) != downloadId) return
    installDownloadedUpdateIfReady(context)
}

fun isUpdateDownloadSuccessful(context: Context, downloadId: Long): Boolean {
    if (downloadId < 0L) return false
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return false
    return cursor.use {
        it.moveToFirst() &&
            it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) ==
            DownloadManager.STATUS_SUCCESSFUL
    }
}

/** Returns true when Android's installer or its per-app permission screen was opened. */
fun installDownloadedUpdateIfReady(context: Context): Boolean {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    val downloadId = prefs.getLong("download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, -1L)) return false
    if (!isUpdateDownloadSuccessful(context, downloadId)) return false

    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return false
    val file = File(downloadDirectory, "elbasha-update.apk")
    if (!file.isFile || file.length() == 0L) return false

    if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
        val permissionPromptedId = prefs.getLong("install_permission_prompted_download_id", -1L)
        if (UpdatePromptRules.shouldPrompt(downloadId, permissionPromptedId)) {
            val settingsIntent = Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return runCatching {
                context.startActivity(settingsIntent)
                prefs.edit().putLong("install_permission_prompted_download_id", downloadId).apply()
                true
            }.getOrDefault(false)
        }
        return false
    }

    val promptedId = prefs.getLong("install_prompted_download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, promptedId)) return false
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    return runCatching {
        context.startActivity(intent)
        // Persist only after Android accepted the request, so a failed launch can be retried.
        prefs.edit().putLong("install_prompted_download_id", downloadId).apply()
        true
    }.getOrDefault(false)
}
