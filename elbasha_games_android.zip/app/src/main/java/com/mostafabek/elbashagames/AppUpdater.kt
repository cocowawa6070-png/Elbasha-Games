package com.mostafabek.elbashagames

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private data class ReleaseInfo(val versionCode: Int, val versionName: String, val apkUrl: String)

@Composable
fun AppUpdaterCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val english = LocalAppUiSettings.current.english
    var status by remember(english) {
        mutableStateOf(
            localizedText(
                english,
                "تحقق من وجود تحديثات جديدة على GitHub.",
                "Check GitHub for new updates."
            )
        )
    }
    var busy by remember { mutableStateOf(false) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }

    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(status, modifier = Modifier.padding(bottom = 8.dp))

        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    busy = true
                    release = null // Never leave a stale download button after a failed/new check.
                    status = localizedText(
                        english,
                        "جاري البحث عن آخر إصدار...",
                        "Checking for the latest release..."
                    )
                    try {
                        val latest = withContext(Dispatchers.IO) { fetchLatestRelease() }
                        release = latest
                        status = when {
                            latest == null -> localizedText(
                                english,
                                "مفيش إصدار منشور على GitHub لحد دلوقتي. أول ما ننشر APK في قسم Releases، التحقق من التحديثات هيشتغل من هنا.",
                                "No GitHub release has been published yet. Once an APK is published under Releases, this button will check it here."
                            )

                            latest.versionCode > BuildConfig.VERSION_CODE -> localizedText(
                                english,
                                "يتوفر إصدار ${latest.versionName}. اضغط تنزيل وتثبيت.",
                                "Version ${latest.versionName} is available. Tap Download and Install."
                            )

                            latest.versionCode == BuildConfig.VERSION_CODE -> localizedText(
                                english,
                                "أنت تستخدم أحدث إصدار (${BuildConfig.VERSION_NAME}).",
                                "You are using the latest version (${BuildConfig.VERSION_NAME})."
                            )

                            else -> localizedText(
                                english,
                                "الإصدار المثبت (${BuildConfig.VERSION_NAME}) أحدث من آخر إصدار منشور على GitHub (${latest.versionName}).",
                                "The installed version (${BuildConfig.VERSION_NAME}) is newer than the latest GitHub release (${latest.versionName})."
                            )
                        }
                    } catch (e: Exception) {
                        release = null
                        status = localizedText(
                            english,
                            "تعذر التحقق من التحديثات: ${e.localizedMessage ?: "خطأ اتصال"}",
                            "Could not check for updates: ${e.localizedMessage ?: "connection error"}"
                        )
                    } finally {
                        busy = false
                    }
                }
            }
        ) {
            Text(
                if (busy) localizedText(english, "جاري التحقق...", "Checking...")
                else localizedText(english, "التحقق من التحديثات", "Check for updates")
            )
        }

        val available = release
        if (available != null && available.versionCode > BuildConfig.VERSION_CODE) {
            Button(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                enabled = !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        status = localizedText(
                            english,
                            "جاري تجهيز تنزيل التحديث...",
                            "Preparing update download..."
                        )
                        try {
                            withContext(Dispatchers.IO) {
                                enqueueUpdateDownload(context, available.apkUrl)
                            }
                            status = localizedText(
                                english,
                                "بدأ التنزيل. ستظهر نافذة التثبيت بعد اكتماله.",
                                "Download started. The installer will appear when it finishes."
                            )
                        } catch (e: Exception) {
                            status = localizedText(
                                english,
                                "فشل تنزيل التحديث: ${e.localizedMessage ?: "خطأ"}",
                                "Update download failed: ${e.localizedMessage ?: "error"}"
                            )
                        } finally {
                            busy = false
                        }
                    }
                }
            ) {
                Text(
                    localizedText(
                        english,
                        "تنزيل وتثبيت ${available.versionName}",
                        "Download and install ${available.versionName}"
                    )
                )
            }
        }
    }
}

/**
 * Returns null only when the repository has no published GitHub Releases yet.
 * GitHub's /releases/latest endpoint returns HTTP 404 in that normal state.
 */
private fun fetchLatestRelease(): ReleaseInfo? {
    val connection = URL(
        "https://api.github.com/repos/cocowawa6070-png/Elbasha-Games/releases/latest"
    ).openConnection() as HttpURLConnection

    connection.connectTimeout = 15_000
    connection.readTimeout = 15_000
    connection.requestMethod = "GET"
    connection.instanceFollowRedirects = true
    connection.setRequestProperty("Accept", "application/vnd.github+json")
    connection.setRequestProperty("User-Agent", "ELBASHA-GAMES-Android")
    connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")

    try {
        val responseCode = connection.responseCode
        if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
            // This repository currently has no Releases. It is not a connection failure.
            return null
        }

        if (responseCode !in 200..299) {
            val errorBody = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val apiMessage = runCatching {
                JSONObject(errorBody).optString("message").takeIf { it.isNotBlank() }
            }.getOrNull()
            error("GitHub HTTP $responseCode${apiMessage?.let { ": $it" }.orEmpty()}")
        }

        val responseText = connection.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(responseText)
        val tagName = json.optString("tag_name").trim()
        val releaseBody = json.optString("body", "")
        val versionCode = Regex("(?im)^\\s*versionCode\\s*[:=]\\s*(\\d+)\\s*$")
            .find(releaseBody)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: error("إصدار GitHub لا يحتوي على versionCode صالح")

        val assets = json.optJSONArray("assets")
            ?: error("إصدار GitHub لا يحتوي على قائمة ملفات APK")
        val apkAsset = (0 until assets.length())
            .asSequence()
            .map { assets.optJSONObject(it) }
            .filterNotNull()
            .firstOrNull { it.optString("name").endsWith(".apk", ignoreCase = true) }
            ?: error("تم العثور على إصدار GitHub لكن ملف APK غير مرفق به")

        val apkUrl = apkAsset.optString("browser_download_url").trim()
            .takeIf { it.startsWith("https://", ignoreCase = true) }
            ?: error("رابط تنزيل APK في GitHub غير صالح")
        val versionName = tagName.ifBlank { "v$versionCode" }

        return ReleaseInfo(versionCode, versionName, apkUrl)
    } finally {
        connection.disconnect()
    }
}

private fun enqueueUpdateDownload(context: Context, apkUrl: String) {
    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        ?: error("External downloads directory is unavailable")
    val destination = File(downloadDirectory, "elbasha-update.apk")
    destination.delete()

    val request = DownloadManager.Request(Uri.parse(apkUrl))
        .setTitle("ELBASHA GAMES Update")
        .setDescription("Downloading the latest version")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
        .setDestinationInExternalFilesDir(
            context,
            Environment.DIRECTORY_DOWNLOADS,
            "elbasha-update.apk"
        )

    val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val downloadId = downloadManager.enqueue(request)
    context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
        .edit()
        .putLong("download_id", downloadId)
        .apply()
}

fun handleUpdateDownloadCompleted(context: Context, downloadId: Long) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    if (prefs.getLong("download_id", -1L) != downloadId) return
    installDownloadedUpdateIfReady(context)
}

fun isUpdateDownloadSuccessful(context: Context, downloadId: Long): Boolean {
    if (downloadId < 0L) return false
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return false
    return cursor.use {
        it.moveToFirst() &&
            it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) ==
            DownloadManager.STATUS_SUCCESSFUL
    }
}

fun installDownloadedUpdateIfReady(context: Context) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    val downloadId = prefs.getLong("download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, -1L)) return
    if (!isUpdateDownloadSuccessful(context, downloadId)) return

    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return
    val file = File(downloadDirectory, "elbasha-update.apk")
    if (!file.isFile || file.length() == 0L) return

    // Request the per-app install permission once for this download. When the user
    // returns from Settings, MainActivity.onResume() retries and opens the installer.
    if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
        val permissionPromptedId = prefs.getLong("install_permission_prompted_download_id", -1L)
        if (UpdatePromptRules.shouldPrompt(downloadId, permissionPromptedId)) {
            prefs.edit().putLong("install_permission_prompted_download_id", downloadId).apply()
            val settingsIntent = Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settingsIntent)
        }
        return
    }

    val promptedId = prefs.getLong("install_prompted_download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, promptedId)) return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    // Track the actual download ID rather than a global Boolean. The latter would
    // permanently suppress installer prompts for every future release.
    prefs.edit().putLong("install_prompted_download_id", downloadId).apply()
    context.startActivity(intent)
}
