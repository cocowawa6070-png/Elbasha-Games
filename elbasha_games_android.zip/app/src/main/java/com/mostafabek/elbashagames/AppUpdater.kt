package com.mostafabek.elbashagames

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private data class ReleaseInfo(val versionCode: Int, val versionName: String, val apkUrl: String)

@Composable
fun AppUpdaterCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val english = LocalAppUiSettings.current.english
    var status by remember(english) { mutableStateOf(localizedText(english, "تحقق من وجود تحديثات جديدة على GitHub.", "Check GitHub for new updates.")) }
    var busy by remember { mutableStateOf(false) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(status, modifier = Modifier.padding(bottom = 8.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                busy = true; status = localizedText(english, "جاري البحث عن آخر إصدار...", "Checking for the latest release...")
                try {
                    val latest = withContext(Dispatchers.IO) { fetchLatestRelease() }
                    release = latest
                    status = if (latest.versionCode <= BuildConfig.VERSION_CODE) localizedText(english, "أنت تستخدم أحدث إصدار (${BuildConfig.VERSION_NAME}).", "You are using the latest version (${BuildConfig.VERSION_NAME}).") else localizedText(english, "يتوفر إصدار ${latest.versionName}. اضغط تنزيل وتثبيت.", "Version ${latest.versionName} is available. Tap Download and Install.")
                } catch (e: Exception) { status = localizedText(english, "تعذر التحقق من التحديث: ${e.localizedMessage ?: "خطأ اتصال"}", "Could not check for updates: ${e.localizedMessage ?: "connection error"}") }
                finally { busy = false }
            }
        }) { Text(if (busy) localizedText(english, "جاري التحقق...", "Checking...") else localizedText(english, "التحقق من التحديثات", "Check for updates")) }
        val available = release
        if (available != null && available.versionCode > BuildConfig.VERSION_CODE) {
            Button(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !busy, onClick = {
                scope.launch {
                    busy = true; status = localizedText(english, "جاري تجهيز تنزيل التحديث...", "Preparing update download...")
                    try {
                        withContext(Dispatchers.IO) { enqueueUpdateDownload(context, available.apkUrl) }
                        status = localizedText(english, "بدأ التنزيل. ستظهر نافذة التثبيت بعد اكتماله.", "Download started. The installer will appear when it finishes.")
                    } catch (e: Exception) { status = localizedText(english, "فشل تنزيل التحديث: ${e.localizedMessage ?: "خطأ"}", "Update download failed: ${e.localizedMessage ?: "error"}") }
                    finally { busy = false }
                }
            }) { Text(localizedText(english, "تنزيل وتثبيت ${available.versionName}", "Download and install ${available.versionName}")) }
        }
    }
}

private fun fetchLatestRelease(): ReleaseInfo {
    val c = URL("https://api.github.com/repos/cocowawa6070-png/Elbasha-Games/releases/latest").openConnection() as HttpURLConnection
    c.connectTimeout = 12000; c.readTimeout = 12000
    c.setRequestProperty("Accept", "application/vnd.github+json")
    try {
        if (c.responseCode !in 200..299) error("GitHub HTTP ${c.responseCode}")
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = j.optString("tag_name", "").removePrefix("v")
        val body = j.optString("body", "")
        val code = Regex("(?im)^versionCode\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull()
            ?: tag.split('.').lastOrNull()?.toIntOrNull() ?: error("بيانات versionCode غير موجودة")
        val assets = j.getJSONArray("assets")
        val apk = (0 until assets.length()).map { assets.getJSONObject(it) }.firstOrNull { it.optString("name").endsWith(".apk", true) }?.optString("browser_download_url")
            ?.takeIf { it.startsWith("https://") } ?: error("ملف APK غير موجود في GitHub Release")
        return ReleaseInfo(code, j.optString("tag_name", "v$code"), apk)
    } finally { c.disconnect() }
}

private fun enqueueUpdateDownload(context: Context, apkUrl: String) {
    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
        ?: error("External downloads directory is unavailable")
    val destination = File(downloadDirectory, "elbasha-update.apk")
    destination.delete()
    val request = DownloadManager.Request(Uri.parse(apkUrl))
        .setTitle("ELBASHA GAMES Update")
        .setDescription("Downloading the latest version")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedOverMetered(true).setAllowedOverRoaming(false)
        .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "elbasha-update.apk")
    val id = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE).edit()
        .putLong("download_id", id).apply()
}

fun handleUpdateDownloadCompleted(context: Context, downloadId: Long) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    if (prefs.getLong("download_id", -1L) != downloadId) return
    installDownloadedUpdateIfReady(context)
}

fun isUpdateDownloadSuccessful(context: Context, downloadId: Long): Boolean {
    if (downloadId < 0L) return false
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val cursor = manager.query(DownloadManager.Query().setFilterById(downloadId)) ?: return false
    return cursor.use {
        it.moveToFirst() && it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
    }
}

fun installDownloadedUpdateIfReady(context: Context) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    val downloadId = prefs.getLong("download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, -1L)) return
    if (!isUpdateDownloadSuccessful(context, downloadId)) return
    val downloadDirectory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return
    val file = File(downloadDirectory, "elbasha-update.apk")
    if (!file.isFile || file.length() == 0L) return

    // Request the per-app install permission once for this download. When the user
    // returns from Settings, MainActivity.onResume() retries and opens the installer.
    if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
        val permissionPromptedId = prefs.getLong("install_permission_prompted_download_id", -1L)
        if (UpdatePromptRules.shouldPrompt(downloadId, permissionPromptedId)) {
            prefs.edit().putLong("install_permission_prompted_download_id", downloadId).apply()
            val settingsIntent = Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settingsIntent)
        }
        return
    }

    val promptedId = prefs.getLong("install_prompted_download_id", -1L)
    if (!UpdatePromptRules.shouldPrompt(downloadId, promptedId)) return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    // Track the actual download ID rather than a global Boolean. The latter would
    // permanently suppress installer prompts for every future release.
    prefs.edit().putLong("install_prompted_download_id", downloadId).apply()
    context.startActivity(intent)
}
