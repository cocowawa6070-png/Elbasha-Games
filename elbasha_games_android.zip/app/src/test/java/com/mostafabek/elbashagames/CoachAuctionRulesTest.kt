package com.mostafabek.elbashagames

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class CoachAuctionRulesTest {
    @Test
    fun everyCoachHasAValidOpeningPrice() {
        CoachDatabase.all.forEach { coach ->
            assertTrue(CoachAuctionRules.openingPrice(coach) > 0)
            assertTrue(CoachAuctionRules.openingPrice(coach) <= 100)
        }
    }

    @Test
    fun aiCoachBidsStayWithinCeilingAndBudget() {
        CoachDatabase.all.forEach { coach ->
            val opening = CoachAuctionRules.openingPrice(coach)
            val budget = opening + 40
            val ceiling = CoachAuctionRules.aiCeiling(coach, opening, budget, 3, Random(7))
            assertTrue(ceiling in opening..budget)
            val next = CoachAuctionRules.nextAiBid(opening - 1, ceiling, budget, Random(11))
            if (next != null) {
                assertTrue(next >= opening)
                assertTrue(next <= ceiling)
                assertTrue(next <= budget)
            }
        }
    }

    @Test
    fun noCoachIsPickedWhenNobodyCanAffordTheOpeningPrice() {
        val coach = CoachDatabase.all.first()
        val opening = CoachAuctionRules.openingPrice(coach)
        assertTrue(!CoachAuctionRules.canPay(opening, opening - 1))
        assertTrue(CoachAuctionRules.canPay(opening, opening))
    }

    @Test
    fun coachCatalogIsNonEmptyAndNamesAreUnique() {
        assertNotNull(CoachDatabase.all.firstOrNull())
        assertEquals(CoachDatabase.all.size, CoachDatabase.all.map { it.nameEn }.toSet().size)
    }
}
