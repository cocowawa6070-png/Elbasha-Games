package com.mostafabek.elbashagames

import com.mostafabek.elbashagames.AuctionRules
import com.mostafabek.elbashagames.AuctionWinner
import com.mostafabek.elbashagames.DealRules
import com.mostafabek.elbashagames.BuildTeamRules
import com.mostafabek.elbashagames.PlayerDatabase
import com.mostafabek.elbashagames.PlayerTier
import com.mostafabek.elbashagames.tier
import com.mostafabek.elbashagames.PlayerCard
import com.mostafabek.elbashagames.ElbashaPositions
import com.mostafabek.elbashagames.MatchEngine
import com.mostafabek.elbashagames.PlayerImageMatchRules
import kotlin.random.Random

/** Pure Kotlin regression suite: executed by CoreRulesRegressionTest and locally via kotlinc. */
fun runCoreRulesSmokeTest() {
    // Pass-and-play friend-pick mode routes each active seat to the next seat, cyclically.
    for (count in PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS) {
        for (current in 0 until count) {
            check(PassAndPlayRules.recipientIndex(current, count, false) == current)
            check(PassAndPlayRules.recipientIndex(current, count, true) == (current + 1) % count)
        }
    }
    check(PassAndPlayRules.recipientIndex(-1, 2, false) == 1)

    // Online turns reject stale revisions, finished sessions and actions from the wrong player.
    check(OnlineMatchRules.canCommit(4L, 4L, "uid-a", "uid-a", "playing"))
    check(!OnlineMatchRules.canCommit(3L, 4L, "uid-a", "uid-a", "playing"))
    check(!OnlineMatchRules.canCommit(4L, 4L, "uid-b", "uid-a", "playing"))
    check(!OnlineMatchRules.canCommit(4L, 4L, "uid-a", "uid-a", "finished"))
    check(OnlineMatchRules.nextTurn(listOf("a", "b", "c"), 1) == "c")
    check(OnlineMatchRules.nextTurn(listOf("a", "b"), 1) == "a")
    check(OnlineMatchRules.validBid(8, 7, 5, 10))
    check(!OnlineMatchRules.validBid(7, 7, 5, 10))
    check(!OnlineMatchRules.validBid(11, 7, 5, 10))
    check(OnlineMatchRules.shouldFinish(5, 5))
    check(!OnlineMatchRules.shouldFinish(4, 5))

    // Build a Team uses the selected player stat as points, not the player's OVR.
    val spanishCurrentGoalkeepers = BuildTeamStatRules.eligiblePlayers(
        PlayerFactsDatabase.players,
        BuildTeamFilter(BuildTeamPositionFilter.GK, BuildTeamLeagueFilter.LALIGA),
        BuildTeamMetric.HEIGHT
    )
    val joanGarcia = spanishCurrentGoalkeepers.single { it.nameEn == "Joan Garcia" }
    val courtois = spanishCurrentGoalkeepers.single { it.nameEn == "Thibaut Courtois" }
    check(BuildTeamStatRules.value(joanGarcia, BuildTeamMetric.HEIGHT) == 193)
    check(BuildTeamStatRules.value(courtois, BuildTeamMetric.HEIGHT) == 200)
    check(BuildTeamStatRules.value(joanGarcia, BuildTeamMetric.WEIGHT) == 85)
    check(BuildTeamStatRules.value(courtois, BuildTeamMetric.WEIGHT) == 96)
    check(BuildTeamStatRules.winners(listOf(96, 85), BuildTeamDirection.LOW) == listOf(1))
    check(BuildTeamStatRules.total(listOf(
        BuildTeamPick(joanGarcia, 193), BuildTeamPick(courtois, 200)
    )) == 393)
    check(BuildTeamStatRules.winners(listOf(200, 193), BuildTeamDirection.HIGH) == listOf(0))
    check(BuildTeamStatRules.winners(listOf(200, 193), BuildTeamDirection.LOW) == listOf(1))
    check(BuildTeamStatRules.hasEnoughPlayers(
        PlayerFactsDatabase.players,
        BuildTeamFilter(BuildTeamPositionFilter.GK, BuildTeamLeagueFilter.LALIGA),
        BuildTeamMetric.HEIGHT, roundCount = 5, participantCount = 2
    ))
    check(!BuildTeamStatRules.hasEnoughPlayers(
        PlayerFactsDatabase.players,
        BuildTeamFilter(BuildTeamPositionFilter.GK, BuildTeamLeagueFilter.LALIGA),
        BuildTeamMetric.HEIGHT, roundCount = 3, participantCount = 4
    ))
    val allPlayersByRating = BuildTeamStatRules.eligiblePlayers(
        PlayerFactsDatabase.players, BuildTeamFilter(), BuildTeamMetric.PLAYER_RATING
    )
    check(allPlayersByRating.size == PlayerFactsDatabase.players.size)
    check(BuildTeamStatRules.eligiblePlayers(
        PlayerFactsDatabase.players, BuildTeamFilter(), BuildTeamMetric.AUCTION_PRICE
    ).size == PlayerFactsDatabase.players.size)
    check(PlayerSearch.suggestions(spanishCurrentGoalkeepers, "Joan").single().nameEn == "Joan Garcia")
    val minimumRolePools = mapOf(
        BuildTeamPositionFilter.GK to 10,
        BuildTeamPositionFilter.DF to 7,
        BuildTeamPositionFilter.MF to 4,
        BuildTeamPositionFilter.WG to 5,
        BuildTeamPositionFilter.ST to 5
    )
    minimumRolePools.forEach { (position, minimum) ->
        val rolePool = BuildTeamStatRules.eligiblePlayers(
            PlayerFactsDatabase.players,
            BuildTeamFilter(position, BuildTeamLeagueFilter.LALIGA),
            BuildTeamMetric.HEIGHT
        )
        check(rolePool.size >= minimum) { "LaLiga $position filter has only ${rolePool.size} usable players" }
        check(rolePool.all { PlayerFactsDatabase.facts(it)?.isCurrent == true })
    }
    check(BuildTeamStatRules.eligiblePlayers(
        PlayerFactsDatabase.players,
        BuildTeamFilter(BuildTeamPositionFilter.ST, BuildTeamLeagueFilter.LALIGA),
        BuildTeamMetric.GOALS
    ).any { it.nameEn == "Ante Budimir" })
    check(BuildTeamStatRules.value(
        PlayerFactsDatabase.players.single { it.nameEn == "Fermin Lopez" }, BuildTeamMetric.GOALS
    ) == 7)
    val caseSamples = PlayerDatabase.players.take(4)
    check(DealRules.unopenedCasesAfterDecision(caseSamples, acceptedIndex = 0).map { it.first } == listOf(1, 2, 3))
    check(DealRules.unopenedCasesAfterDecision(caseSamples, acceptedIndex = 2, rejectedIndex = 0).map { it.first } == listOf(1, 3))
    check(DealRules.unopenedCasesAfterDecision(caseSamples, acceptedIndex = 0, rejectedIndex = 0).isEmpty())
    check(BuildTeamStatRules.chooseAiPlayer(
        listOf(joanGarcia, courtois), BuildTeamMetric.HEIGHT, BuildTeamDirection.HIGH, 3, Random(7)
    )?.nameEn == "Thibaut Courtois")
    check(BuildTeamStatRules.chooseAiPlayer(
        listOf(joanGarcia, courtois), BuildTeamMetric.HEIGHT, BuildTeamDirection.LOW, 3, Random(7)
    )?.nameEn == "Joan Garcia")
    check(BuildTeamStatRules.randomValidSetup(5, 2, Random(7)) != null)
    val formationSlots = ElbashaPositions.formationSlots(11)
    check(formationSlots.size == 11)
    check(formationSlots.first() == "GK" && formationSlots.last() == "ST")
    for (scope in BuildTeamRosterFilter.entries) {
        for (participants in 2..4) {
            check(BuildTeamStatRules.canBuildFullRoster(PlayerFactsDatabase.players, scope, participants, formationSlots)) {
                "Cannot build an exact 11-slot roster for $scope with $participants participants"
            }
        }
        // Simulate complete four-player matches: no player may be reused or drain a later position.
        var usedFormationNames = emptySet<String>()
        var priorRoundFilters = emptySet<String>()
        formationSlots.forEachIndexed { index, slot ->
            val generated = BuildTeamStatRules.randomRoundChallenge(
                PlayerFactsDatabase.players, slot, scope,
                usedFormationNames, participantCount = 4, previousFilterKeys = priorRoundFilters, random = Random(700 + index + scope.ordinal * 10_000)
            ) ?: error("No valid challenge generated for $scope at slot $slot")
            val candidates = BuildTeamStatRules.playersForChallenge(PlayerFactsDatabase.players, generated, usedFormationNames)
            check(candidates.size >= 4) { "Not enough candidates for $scope at $slot: ${candidates.size}" }
            check(candidates.all { BuildTeamStatRules.isEligibleForFormationSlot(it, slot) })
            check(candidates.none { it.nameEn in usedFormationNames })
            check(generated.direction == BuildTeamDirection.HIGH) { "Raw stat values must always add points consistently" }
            val selected = candidates.shuffled(Random(1_000 + index)).take(4)
            usedFormationNames = usedFormationNames + selected.map { it.nameEn }
            priorRoundFilters = priorRoundFilters + generated.filterKey
        }
        check(usedFormationNames.size == 44) { "Four participants must complete 11 unique positions for $scope" }
        for (slot in listOf("GK", "CB", "CM", "RW", "ST")) {
            val statusChallenge = BuildTeamRoundChallenge(
                slot, scope, "${if (scope == BuildTeamRosterFilter.CURRENT) "current" else "retired"}",
                scope.labelAr, scope.labelEn, BuildTeamMetric.PLAYER_RATING, BuildTeamDirection.HIGH
            )
            if (scope != BuildTeamRosterFilter.ALL && scope != BuildTeamRosterFilter.RANDOM) {
                check(BuildTeamStatRules.playersForChallenge(PlayerFactsDatabase.players, statusChallenge).size >= 2)
            }
        }
    }
    // An update installer prompt is scoped to one download ID, not the app lifetime.
    check(UpdatePromptRules.shouldPrompt(42L, -1L))
    check(!UpdatePromptRules.shouldPrompt(42L, 42L))
    check(UpdatePromptRules.shouldPrompt(43L, 42L))
    check(!UpdatePromptRules.shouldPrompt(-1L, 42L))
    check(!UpdatePromptRules.shouldPrompt(0L, -1L))
    // Portrait metadata must match the exact requested player and positively identify
    // a footballer; ambiguous people must fall back instead of showing a wrong image.
    check(PlayerImageMatchRules.isExactPlayerTitle("Ronaldo (Brazilian footballer)", setOf("Ronaldo Nazario", "Ronaldo (Brazilian footballer)")))
    check(!PlayerImageMatchRules.isExactPlayerTitle("Ronaldo", setOf("Ronaldo Nazario", "Ronaldo (Brazilian footballer)")))
    check(PlayerImageMatchRules.isFootballerDescription("Brazilian former professional footballer"))
    check(PlayerImageMatchRules.isFootballerDescription("Argentine soccer player"))
    check(!PlayerImageMatchRules.isFootballerDescription("Brazilian actor and television personality"))
    check(!PlayerImageMatchRules.isFootballerDescription(null))
    repeat(1_000) { seed ->
        val actual = if (seed % 2 == 0) "Manuel Neuer" else "Manuel Neuer (businessman)"
        val accepted = PlayerImageMatchRules.isExactPlayerTitle(actual, setOf("Manuel Neuer"))
        check(accepted == (seed % 2 == 0))
    }

    check(PostAuctionCardRules.WINDOW_SECONDS == 20)
    val postCardSample = PlayerDatabase.players.take(3)
    check(PostAuctionCardRules.canProtect(false, postCardSample.size))
    check(!PostAuctionCardRules.canProtect(true, postCardSample.size))
    check(PostAuctionCardRules.eligibleStealTargets(postCardSample, postCardSample.first().nameEn) == postCardSample)
    check(PostAuctionCardRules.isProtectedTarget(postCardSample.first(), postCardSample.first().nameEn))
    check(!PostAuctionCardRules.isProtectedTarget(postCardSample.last(), postCardSample.first().nameEn))
    check(PostAuctionCardRules.canExchange(
        PlayerCard("Weak CM", "وسط ضعيف", "CM", 75, 5, ""),
        PlayerCard("Strong CM", "وسط قوي", "CM", 91, 8, "")
    ))
    check(!PostAuctionCardRules.canExchange(
        PlayerCard("Weak CM", "وسط ضعيف", "CM", 75, 5, ""),
        PlayerCard("Strong ST", "مهاجم", "ST", 91, 8, "")
    ))
    check(PostAuctionCardRules.eligibleReplacements(
        listOf(PlayerCard("Weak CM", "وسط ضعيف", "CM", 75, 5, ""), PlayerCard("GK", "حارس", "GK", 90, 6, "")),
        PlayerCard("Strong CM", "وسط قوي", "CM", 91, 8, "")
    ).single().nameEn == "Weak CM")
    check(PostAuctionCardRules.canSteal(false, postCardSample, postCardSample.first().nameEn))
    check(!PostAuctionCardRules.canSteal(true, postCardSample, null))
    // A one-player squad is still a valid steal target; same-position exchange is validated separately.
    check(PostAuctionCardRules.canSteal(false, postCardSample.take(1), postCardSample.first().nameEn))

    check(AuctionRules.openingPrice(94) == 6)
    check(AuctionRules.openingPrice(70) == 5)
    check(AuctionRules.spendLimit(100, 4) == 80)
    check(AuctionRules.spendLimit(15, 3) == 0)
    check(AuctionRules.spendLimit(100, -2) == 100)
    check(AuctionRules.spendLimitForLots(100, listOf(
        PlayerCard("A", "أ", "ST", 92, 6, ""),
        PlayerCard("B", "ب", "GK", 84, 6, "")
    )) == 88)
    check(AuctionRules.spendLimitForLots(10, listOf(
        PlayerCard("A", "أ", "ST", 92, 6, ""),
        PlayerCard("B", "ب", "GK", 84, 6, "")
    )) == 0)
    val futureReserveLots = listOf(
        PlayerCard("Future A", "أ", "ST", 92, 6, ""),
        PlayerCard("Future B", "ب", "GK", 84, 6, "")
    )
    check(AuctionRules.availableBudgetForCurrentLot(30, 6, futureReserveLots) == 18)
    check(AuctionRules.availableBudgetForCurrentLot(17, 6, futureReserveLots) == 0)
    check(AuctionRules.availableBudgetForCurrentLot(5, 6, emptyList()) == 0)
    check(AuctionRules.availableBudgetForCurrentLot(6, 6, emptyList()) == 6)
    check(AuctionRules.isValidUserBid(11, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(10, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(21, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(4, 0, 5, 20))
    check(AuctionRules.minimumNextUserBid(4, 5) == 5)
    check(AuctionRules.minimumNextUserBid(10, 5) == 11)
    check(AuctionRules.adjustUserBidDraft(15, -1, 11, 20) == 14)
    check(AuctionRules.adjustUserBidDraft(11, -1, 11, 20) == 11)
    check(AuctionRules.adjustUserBidDraft(14, 5, 11, 20) == 19)
    check(AuctionRules.adjustUserBidDraft(14, 10, 11, 18) == null)
    repeat(10_000) { seed ->
        val opening = 5 + seed % 9
        val current = opening - 1 + seed % 35
        val minimum = AuctionRules.minimumNextUserBid(current, opening)
        val budget = minimum + seed % 35
        val draft = minimum + (seed % (budget - minimum + 1))
        val decremented = AuctionRules.adjustUserBidDraft(draft, -1, minimum, budget)
        check(decremented != null && decremented in minimum..draft)
        val increment = listOf(1, 5, 10)[seed % 3]
        val raised = AuctionRules.adjustUserBidDraft(draft, increment, minimum, budget)
        if (draft + increment <= budget) check(raised == draft + increment) else check(raised == null)
        check(AuctionRules.isValidUserBid(minimum, current, opening, budget))
    }
    check(AuctionRules.payablePrice(10, 6, true) == 8)
    check(AuctionRules.payablePrice(7, 6, true) == 6)
    check(AuctionRules.payablePrice(10, 6, false) == 10)
    check(AuctionRules.canBuyOpening(6, 8, 6))
    check(!AuctionRules.canBuyOpening(6, 8, 5))
    check(!AuctionRules.canBuyOpening(6, 5, 10))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 8, 20) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 6))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 6, 15) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 6))
    check(AuctionRules.settleWhenUserPasses(17, 6, true, 20, 20) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 17))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 5, 20).winner == AuctionWinner.Unsold)
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 20, 5).winner == AuctionWinner.Unsold)
    check(AuctionRules.settleWhenAiPasses(7, 6, true) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.User, 6))
    check(AuctionRules.settleWhenAiPasses(10, 6, false) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.User, 10))
    check(AuctionRules.calculateAiBidCeiling(92, 6, 4, 3, 1, Random(1)) == 0)
    check(AuctionRules.calculateAiBidCeiling(92, 6, 200, 3, 0, Random(1)) == 0)

    // The auction queue must contain 24 Classic / 42 Pro Max distinct lots, in formation order.
    for ((size, total) in listOf(5 to 24, 11 to 42)) {
        val lots = ElbashaPositions.auctionPool(size, total)
        check(lots.size == total)
        check(lots.map { it.nameEn }.distinct().size == lots.size)
        check(lots.take(size).map { it.position } == ElbashaPositions.formationSlots(size))
        check(lots.all { ElbashaPositions.supports(it, it.position) })
    }
    // Auction appearance mix: 50% medium, 30% weak, 20% strong.
    for ((size, total) in listOf(5 to 24, 11 to 42)) {
        repeat(50) {
            val lots = ElbashaPositions.auctionPool(size, total)
            check(lots.count { it.tier == PlayerTier.STRONG } == Math.round(total * 0.20).toInt())
            check(lots.count { it.tier == PlayerTier.WEAK } == Math.round(total * 0.30).toInt())
            check(lots.count { it.tier == PlayerTier.MEDIUM } == total - Math.round(total * 0.20).toInt() - Math.round(total * 0.30).toInt())
        }
    }
    // Repeated formation roles reserve different future lots, never the same CB twice.
    val repeatedRoleLots = listOf(
        PlayerCard("CB One", "مدافع 1", "CB", 91, 6, ""),
        PlayerCard("CB Two", "مدافع 2", "CB", 80, 6, ""),
        PlayerCard("GK One", "حارس", "GK", 85, 6, ""),
        PlayerCard("ST One", "مهاجم", "ST", 88, 6, "")
    )
    val repeatedReserves = AuctionRules.reserveLotsForRequiredSlots(listOf("CB", "CB", "GK", "ST"), repeatedRoleLots)
    check(repeatedReserves.size == 4)
    check(repeatedReserves.map { it.nameEn }.distinct().size == 4)
    check(repeatedReserves.groupingBy { it.position }.eachCount() == mapOf("CB" to 2, "GK" to 1, "ST" to 1))
    check(repeatedReserves.first().nameEn == "CB Two")

    repeat(5_000) { seed ->
        val currentOpening = 5 + seed % 9
        val upcoming = ElbashaPositions.auctionPool(5 + seed % 7, seed % 70 + 1).drop(1)
        val reserve = upcoming.sumOf { AuctionRules.openingPrice(it.rating) }
        val wallet = seed % 180
        val available = AuctionRules.availableBudgetForCurrentLot(wallet, currentOpening, upcoming)
        if (available == 0) check(wallet - reserve < currentOpening)
        else check(available == wallet - reserve && available >= currentOpening)
    }

    // Difficulty must raise the AI's average ceiling without allowing it over budget.
    val auctionCeilingAverages = (0..3).map { difficulty ->
        (0 until 2_000).map { seed ->
            AuctionRules.calculateAiBidCeiling(90, 6, 100, difficulty, 1, Random(difficulty * 20_000 + seed))
        }.also { values -> values.forEach { check(it == 0 || it in 6..100) } }.filter { it > 0 }.average()
    }
    check(auctionCeilingAverages.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Auction AI difficulty should raise average bid ceilings: $auctionCeilingAverages"
    }
    repeat(10_000) { seed ->
        val budget = seed % 60
        val opening = 5 + seed % 8
        val ceiling = AuctionRules.calculateAiBidCeiling(70 + seed % 30, opening, budget, seed % 4, seed % 3, Random(seed))
        check(ceiling == 0 || (ceiling >= opening && ceiling <= budget))
    }

    // A hidden player that collides with a queued lot must replace it, not shorten the game.
    repeat(1_000) { seed ->
        val size = if (seed % 2 == 0) 5 else 11
        val lots = ElbashaPositions.auctionPool(size, 42)
        val collision = lots[seed % lots.size]
        val preserved = AuctionRules.preserveQueueAfterHiddenReward(
            remainingLots = lots,
            hiddenPlayer = collision,
            occupiedNames = emptySet(),
            random = Random(seed)
        )
        check(preserved.size == lots.size)
        check(preserved.map { it.nameEn }.distinct().size == preserved.size)
        check(preserved[seed % lots.size].nameEn != collision.nameEn)
        check(ElbashaPositions.poolRole(preserved[seed % lots.size].position) == ElbashaPositions.poolRole(collision.position))
    }
    val noCollisionPool = ElbashaPositions.auctionPool(5, 24)
    val unrelatedHidden = PlayerDatabase.players.first { it.nameEn !in noCollisionPool.map(PlayerCard::nameEn) }
    check(AuctionRules.preserveQueueAfterHiddenReward(noCollisionPool, unrelatedHidden, emptySet()) == noCollisionPool)

    repeat(10_000) { seed ->
        val current = seed % 40
        val ceiling = current + (seed % 12)
        val budget = current + (seed % 14)
        val next = AuctionRules.nextAiBid(current, ceiling, budget, Random(seed))
        if (next != null) {
            check(next > current && next <= ceiling && next <= budget)
            check(next - current in setOf(1, 5, 10))
        } else {
            check(listOf(1, 5, 10).none { current + it <= ceiling && current + it <= budget })
        }
    }

    for (size in 4..11) {
        val slots = ElbashaPositions.formationSlots(size)
        check(slots.size == size && slots.first() == "GK" && slots.last() == "ST")
        check(slots.any { it in setOf("CDM", "CM", "CAM") })
        check(slots.any { it in setOf("RB", "CB", "LB") })
        val pool = ElbashaPositions.auctionPool(size, 42)
        check(pool.size == 42 && pool.map { it.nameEn }.distinct().size == 42)
        check(pool.take(size).zip(slots).all { (player, slot) -> player.position == slot })
        check(pool.all { ElbashaPositions.supports(it, it.position) })
    }

    // Deal or No Deal: every participant receives a private, disjoint four-case hand.
    check(DealRules.FINAL_CARD_WINDOW_SECONDS == 60)
    check(DealRules.MIN_TEAM_SIZE == 6 && DealRules.MAX_TEAM_SIZE == 11)
    val privateSeen = List(4) { emptySet<String>() }
    val privateHands = DealRules.createPrivateCaseSets(
        PlayerDatabase.players, "GK", privateSeen, emptySet(), Random(991)
    )
    check(privateHands.size == 4)
    check(privateHands.all { it.size == 4 && it.map(PlayerCard::nameEn).distinct().size == 4 })
    check(privateHands.flatten().map { it.nameEn }.distinct().size == 16) {
        "Four participants must never share a case/player in the same slot"
    }
    check(privateHands.flatten().all { it.position == "GK" })
    // Every Deal hand is 1 strong (89+), 2 medium (82-88) and 1 weak (<82) player.
    check(privateHands.all { hand ->
        hand.count { it.tier == PlayerTier.STRONG } == 1 &&
            hand.count { it.tier == PlayerTier.MEDIUM } == 2 &&
            hand.count { it.tier == PlayerTier.WEAK } == 1
    })
    for (size in DealRules.MIN_TEAM_SIZE..DealRules.MAX_TEAM_SIZE) {
        val slots = ElbashaPositions.formationSlots(size)
        for (participants in DealRules.MIN_PARTICIPANTS..DealRules.MAX_PARTICIPANTS) {
            slots.forEachIndexed { index, slot ->
                val minimum = DealRules.minimumCandidatesRequired(slots, index, participants)!!
                val available = PlayerDatabase.players.count { ElbashaPositions.supports(it, slot) }
                check(available >= minimum) { "Full player pool does not support $size/$participants at $slot ($available < $minimum)" }
            }
        }
    }

    val sampleCases = privateHands.first()
    val acceptedDeal = DealRules.acceptDeal(sampleCases, 2)!!
    check(acceptedDeal.accepted.nameEn == sampleCases[2].nameEn)
    check(acceptedDeal.rejected == null && acceptedDeal.openedIndex == 2)
    check(DealRules.acceptDeal(sampleCases, -1) == null)
    check(DealRules.acceptDeal(sampleCases.take(3), 0) == null)

    val acceptedRisk = DealRules.acceptRisk(sampleCases, 1, 3)!!
    check(acceptedRisk.accepted.nameEn == sampleCases[3].nameEn)
    check(acceptedRisk.rejected?.nameEn == sampleCases[1].nameEn)
    check(acceptedRisk.openedIndex == 3)
    check(DealRules.acceptRisk(sampleCases, 1, 1) == null) {
        "No Deal must force a different case, never the rejected case"
    }
    check(DealRules.acceptRisk(sampleCases, 1, 4) == null)

    val rejectedName = acceptedRisk.rejected!!.nameEn
    val seenAfterRisk = privateSeen.toMutableList().also { it[0] = it[0] + rejectedName + acceptedRisk.accepted.nameEn }
    val nextPrivateHands = DealRules.createPrivateCaseSets(
        PlayerDatabase.players, "GK", seenAfterRisk, emptySet(), Random(992)
    )
    check(nextPrivateHands.flatten().none { it.nameEn == rejectedName }) {
        "A rejected player must not be offered again to any participant"
    }
    check(nextPrivateHands.flatten().map { it.nameEn }.distinct().size == 16)

    // Private boxes stay independent across every supported formation and each tactical slot.
    for (size in DealRules.MIN_TEAM_SIZE..DealRules.MAX_TEAM_SIZE) {
        val slots = ElbashaPositions.formationSlots(size)
        check(slots.first() == "GK" && slots.last() == "ST")
        for ((round, slot) in slots.withIndex()) {
            val hands = DealRules.createPrivateCaseSets(
                PlayerDatabase.players,
                slot,
                List(4) { emptySet() },
                emptySet(),
                Random(size * 100 + round)
            )
            check(hands.size == 4 && hands.all { it.size == 4 })
            check(hands.flatten().map { it.nameEn }.distinct().size == 16)
            check(hands.flatten().all { ElbashaPositions.supports(it, slot) && it.position == slot })
        }
    }

    repeat(2_000) { seed ->
        val hand = PlayerDatabase.players.filter { ElbashaPositions.supports(it, "ST") }
            .shuffled(Random(seed)).take(4)
        val firstIndex = DealRules.chooseAiOpeningIndex(hand, seed % 4, Random(seed * 17))!!
        check(firstIndex in 0..3)
        val riskIndex = DealRules.chooseAiRiskIndex(hand, firstIndex, seed % 4, Random(seed * 19))!!
        check(riskIndex in 0..3 && riskIndex != firstIndex)
        val result = if (DealRules.aiShouldRisk(hand[firstIndex], hand, seed % 4)) {
            DealRules.acceptRisk(hand, firstIndex, riskIndex)
        } else DealRules.acceptDeal(hand, firstIndex)
        check(result != null)
        check(result.accepted.nameEn != result.rejected?.nameEn)
    }

    repeat(500) { seed ->
        for (cards in DealRules.MIN_CARDS_PER_PLAYER..DealRules.MAX_CARDS_PER_PLAYER) {
            val hand = DealRules.createFinalCardHand(cards, Random(seed * 13 + cards))
            check(hand.size == cards)
            check(hand.all { it.type in setOf(DealFinalCardType.STEAL, DealFinalCardType.SHIELD) })
        }
    }

    val teamA = PlayerDatabase.players.take(3)
    val teamB = PlayerDatabase.players.drop(3).take(3)
    val protected = setOf(teamB[0].nameEn)
    check(!DealRules.canSteal(teamB[0], protected))
    check(DealRules.canSteal(teamB[1], protected))
    check(DealRules.stealPlayer(listOf(teamA, teamB), 0, 1, teamB[0].nameEn, protected) == null)
    val stolenTeams = DealRules.stealPlayer(listOf(teamA, teamB), 0, 1, teamB[1].nameEn, protected)!!
    check(stolenTeams[0].last().nameEn == teamB[1].nameEn)
    check(stolenTeams[1].none { it.nameEn == teamB[1].nameEn })
    check((stolenTeams[0] + stolenTeams[1]).map { it.nameEn }.distinct().size == 6)
    val protectedAfter = DealRules.protectPlayer(teamA, emptySet(), teamA[1].nameEn)!!
    check(teamA[1].nameEn in protectedAfter)
    check(DealRules.protectPlayer(teamA, emptySet(), "not-in-this-squad") == null)

    // Full Build Team drafts: both sides must select distinct players from the exact challenge.
    for (size in 4..11) {
        repeat(100) { seed ->
            val slots = ElbashaPositions.formationSlots(size)
            val userTeam = mutableListOf<PlayerCard>()
            val aiTeam = mutableListOf<PlayerCard>()
            for ((round, slot) in slots.withIndex()) {
                val excluded = (userTeam + aiTeam).map { it.nameEn }.toSet()
                val challenge = BuildTeamRules.createNationalityChallenge(
                    PlayerDatabase.players, slot, excluded, Random(seed * 31 + round)
                ) ?: error("No nationality challenge for size=$size slot=$slot seed=$seed")
                val userCandidates = BuildTeamRules.eligiblePlayers(PlayerDatabase.players, challenge, excluded)
                check(userCandidates.size >= 2)
                val userPick = userCandidates.random(Random(seed * 101 + round))
                val aiCandidates = BuildTeamRules.eligiblePlayers(
                    PlayerDatabase.players, challenge, excluded + userPick.nameEn
                )
                val aiPick = BuildTeamRules.chooseAiPlayer(aiCandidates, seed % 4, Random(seed * 211 + round))
                    ?: error("AI had no legal pick for $challenge")
                check(userPick.nameEn != aiPick.nameEn)
                check(userPick.nationalityEn == challenge.nationalityEn && aiPick.nationalityEn == challenge.nationalityEn)
                check(ElbashaPositions.supports(userPick, slot) && ElbashaPositions.supports(aiPick, slot))
                userTeam += userPick.copy(position = slot)
                aiTeam += aiPick.copy(position = slot)
            }
            check(userTeam.size == size && aiTeam.size == size)
            check((userTeam + aiTeam).map { it.nameEn }.distinct().size == size * 2)
        }
    }
    val buildCandidates = PlayerDatabase.players.filter { ElbashaPositions.supports(it, "DF") }
    val buildDifficultyAverages = (0..3).map { difficulty ->
        (0 until 1_000).map { seed ->
            BuildTeamRules.chooseAiPlayer(buildCandidates, difficulty, Random(difficulty * 10_000 + seed))!!.rating.toDouble()
        }.average()
    }
    check(buildDifficultyAverages.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Build Team AI difficulty should produce stronger average picks: $buildDifficultyAverages"
    }

    val dealDifficultyAverages = (0..3).map { difficulty ->
        (0 until 1_000).map { seed ->
            val hand = PlayerDatabase.players.filter { ElbashaPositions.supports(it, "GK") }
                .shuffled(Random(seed)).take(4)
            hand[DealRules.chooseAiOpeningIndex(hand, difficulty, Random(difficulty * 20_000 + seed))!!].rating.toDouble()
        }.average()
    }
    check(dealDifficultyAverages.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Deal AI opening choices should improve with difficulty: $dealDifficultyAverages"
    }


    // Random Swap must preserve paid price, squad size and the auction queue, while
    // selecting an unused player from the same role and avoiding future lots.
    val swapRoles = listOf("GK", "DF", "MF", "WG", "ST")
    repeat(1_000) { seed ->
        val role = swapRoles[seed % swapRoles.size]
        val rolePlayers = PlayerDatabase.players.filter { ElbashaPositions.supports(it, role) }
        val old = rolePlayers[seed % rolePlayers.size].copy(position = role)
        val current = rolePlayers[(seed + 1) % rolePlayers.size].copy(position = role)
        val queue = rolePlayers.drop(2).take(3).map { it.copy(position = role) }
        val otherOwned = listOfNotNull(
            rolePlayers.getOrNull(4)?.takeIf { it.nameEn !in setOf(old.nameEn, current.nameEn) }?.copy(position = role)
        )
        val bought = listOf(old to (7 + seed % 5))
        val result = AuctionRules.randomSwap(bought, otherOwned, current, queue, Random(seed))
            ?: error("Random Swap failed to find a legal candidate for $role")
        check(result.updatedBought.size == bought.size)
        check(result.oldPlayer.nameEn == old.nameEn)
        check(result.updatedBought.single().second == bought.single().second)
        check(result.newPlayer.nameEn !in (otherOwned + listOf(current) + queue).map { it.nameEn })
        check(result.newPlayer.nameEn != old.nameEn)
        check(ElbashaPositions.supports(result.newPlayer, role))
        check(queue.map { it.nameEn } == rolePlayers.drop(2).take(3).map { it.nameEn })
    }

    val classic = ElbashaPositions.auctionPool(5, 24)
    repeat(100) {
        val result = MatchEngine.simulate(classic, ElbashaPositions.auctionPool(5, 24), targetSquadSize = 5)
        check(result.userGoals in 0..6 && result.opponentGoals in 0..6)
    }
    // A strong duplicate-role substitute must not create an invalid starting lineup.
    val extraGoalkeeper = PlayerDatabase.players.first { it.position == "GK" && it.nameEn !in classic.map { p -> p.nameEn } }
        .copy(position = "GK")
    val bankedSquad = listOf(extraGoalkeeper) + classic
    val bestFive = MatchEngine.selectBestLineup(bankedSquad, 5)
    check(bestFive.size == 5 && MatchEngine.positionalFit(bestFive, 5) == 1.0)
    repeat(100) { seed ->
        val result = MatchEngine.simulate(bankedSquad, classic, random = Random(seed), targetSquadSize = 5)
        check(result.userGoals in 0..6 && result.opponentGoals in 0..6)
    }

    // Statistical sanity: a materially stronger, position-complete squad should win more often.
    val fiveSlots = ElbashaPositions.formationSlots(5)
    val strongSquad = fiveSlots.map { slot ->
        PlayerDatabase.players.filter { ElbashaPositions.supports(it, slot) }
            .maxBy { it.rating }.copy(position = slot)
    }
    val weakSquad = fiveSlots.map { slot ->
        PlayerDatabase.players.filter { ElbashaPositions.supports(it, slot) }
            .minBy { it.rating }.copy(position = slot)
    }
    var strongWins = 0
    var weakWins = 0
    var draws = 0
    repeat(1_000) { seed ->
        val score = MatchEngine.simulate(strongSquad, weakSquad, random = Random(50_000 + seed), targetSquadSize = 5)
        when {
            score.userWon -> strongWins++
            score.opponentWon -> weakWins++
            else -> draws++
        }
    }
    check(strongWins > weakWins && strongWins >= 500) {
        "A stronger lineup should win at least half of the statistical sample: strong=$strongWins weak=$weakWins draws=$draws"
    }

    // Equal squads must not show a large persistent first-side advantage.
    var equalUserWins = 0
    var equalAiWins = 0
    repeat(1_000) { seed ->
        val score = MatchEngine.simulate(strongSquad, strongSquad, random = Random(90_000 + seed), targetSquadSize = 5)
        when {
            score.userWon -> equalUserWins++
            score.opponentWon -> equalAiWins++
        }
    }
    check(kotlin.math.abs(equalUserWins - equalAiWins) <= 100) {
        "Equal teams show unexpected first-side bias: user=$equalUserWins ai=$equalAiWins"
    }
    println("PASS: Auction reserve, bid counter and bidding (10,000+ randomized cases), hidden reward queue stability (1,000 cases), Deal private cases/Deal/Risk/AI/Shield/Steal, strict portrait metadata, invariant-checked Random Swaps, full 4..11-player Build Team drafts (800 games), friend-pick recipient rotation, four-level AI strength ordering, and 2,200 match simulations including balance checks")
}


fun main() = runCoreRulesSmokeTest()
