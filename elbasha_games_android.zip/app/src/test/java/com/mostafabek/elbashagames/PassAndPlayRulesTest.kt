package com.mostafabek.elbashagames

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PassAndPlayRulesTest {
    private fun card(name: String, rating: Int) =
        PlayerCard(name, name, "ST", rating, 5, "", "", "")

    @Test
    fun pickingOrderRotatesEverySlot() {
        assertEquals(listOf(0, 1, 2), PassAndPlayRules.pickingOrder(3, 0))
        assertEquals(listOf(1, 2, 0), PassAndPlayRules.pickingOrder(3, 1))
        assertEquals(listOf(0, 1, 2), PassAndPlayRules.pickingOrder(3, 3))
    }

    @Test
    fun friendPickModeSendsEachTurnToTheNextPlayer() {
        for (count in PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS) {
            for (current in 0 until count) {
                assertEquals(current, PassAndPlayRules.recipientIndex(current, count, false))
                assertEquals((current + 1) % count, PassAndPlayRules.recipientIndex(current, count, true))
            }
        }
    }

    @Test
    fun namesAreFilledAndUnique() {
        val names = PassAndPlayRules.normalizeNames(listOf(" Ali ", "ali", ""), 3) { "P$it" }
        assertEquals(listOf("Ali", "ali 2", "P3"), names)
    }

    @Test
    fun slotWinnerNeedsAUniqueBestRating() {
        assertEquals(1, PassAndPlayRules.slotWinner(listOf(80, 90, 70)))
        assertNull(PassAndPlayRules.slotWinner(listOf(90, 90, 70)))
        assertNull(PassAndPlayRules.slotWinner(listOf(0, 0)))
    }

    @Test
    fun tallyAndWinnersUseTotalRatingAsTieBreak() {
        val a = listOf(card("a1", 90), card("a2", 70))
        val b = listOf(card("b1", 80), card("b2", 75))
        val points = PassAndPlayRules.tally(listOf(a, b), 2)
        assertEquals(listOf(1, 1), points)
        val totals = listOf(160, 155)
        assertEquals(listOf(0), PassAndPlayRules.winners(points, totals))
        assertEquals(listOf(0, 1), PassAndPlayRules.winners(points, listOf(155, 155)))
    }

    @Test
    fun everySquadSizeCanBeDraftedByTwoToFourPlayers() {
        for (playerCount in PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS) {
            for (teamSize in 4..11) {
                val used = mutableSetOf<String>()
                for (slot in ElbashaPositions.formationSlots(teamSize)) {
                    val challenge = PassAndPlayRules.createChallenge(PlayerDatabase.players, slot, used, playerCount)
                    assertNotNull("no challenge for $slot ($playerCount players, size $teamSize)", challenge)
                    val eligible = PassAndPlayRules.eligiblePlayers(PlayerDatabase.players, challenge!!, used)
                    assertTrue("too few eligible players for $slot", eligible.size >= playerCount)
                    used.addAll(eligible.take(playerCount).map { it.nameEn })
                }
            }
        }
    }
}
