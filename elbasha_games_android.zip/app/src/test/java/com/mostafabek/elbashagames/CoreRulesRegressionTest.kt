package com.mostafabek.elbashagames

import org.junit.Test

class CoreRulesRegressionTest {
    @Test
    fun auctionDealBuildTeamImagesAndMatchRulesStayValid() {
        runCoreRulesSmokeTest()
    }
}
