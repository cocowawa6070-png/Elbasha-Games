package com.mostafabek.elbashagames

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class OnlineRoomRulesTest {
    @Test fun generatedCodesAreEightCharactersAndValid() {
        repeat(5000) {
            val code = ElbashaRoomRules.generateCode(Random(it))
            assertEquals(8, code.length)
            assertTrue(ElbashaRoomRules.validCode(code))
            assertFalse(code.any { character -> character in "IO01" })
        }
    }

    @Test fun normalizationAndFourPlayerCapacity() {
        assertEquals("ABCDEF12", ElbashaRoomRules.normalizeCode("ab-cd ef12"))
        assertTrue(ElbashaRoomRules.canJoin(3, alreadyMember = false))
        assertFalse(ElbashaRoomRules.canJoin(4, alreadyMember = false))
        assertTrue(ElbashaRoomRules.canJoin(4, alreadyMember = true))
        assertTrue(ElbashaRoomRules.canJoin(1, alreadyMember = false, capacity = 2))
        assertFalse(ElbashaRoomRules.canJoin(1, alreadyMember = false, capacity = 5))
    }
}
