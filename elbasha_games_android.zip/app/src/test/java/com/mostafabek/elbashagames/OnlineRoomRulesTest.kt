package com.mostafabek.elbashagames


import org.junit.Assert.* 
import org.junit.Test
import kotlin.random.Random

class OnlineRoomRulesTest {
    @Test fun generatedCodesAreSixCharactersAndValid() {
        repeat(5000) {
            val code = ElbashaRoomRules.generateCode(Random(it))
            assertEquals(6, code.length)
            assertTrue(ElbashaRoomRules.validCode(code))
            assertFalse(code.any { it in "IO01" })
        }
    }
    @Test fun normalizationAndCapacity() {
        assertEquals("ABC234", ElbashaRoomRules.normalizeCode("ab-c 234"))
        assertTrue(ElbashaRoomRules.canJoin(9, false))
        assertFalse(ElbashaRoomRules.canJoin(10, false))
        assertTrue(ElbashaRoomRules.canJoin(10, true))
    }
}
