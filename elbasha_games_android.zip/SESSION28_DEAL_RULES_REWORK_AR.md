# ELBASHA GAMES — Session 28: Deal or No Deal rules and rating rework

**Date:** 22 November 2026  
**Source:** `ELBASHA_GAMES_MERGED_BUILD62.zip` (Build62_FIXED as the source of truth) plus the user's Deal gameplay video `Screen_Recording_20261121_224249.mp4` and final written clarification.

## Deal rules now represented in source

- Each participant receives four private and independent hidden cases for every formation slot. The case sets are disjoint within that slot.
- Deal accepts the revealed player. No Deal permanently rejects the revealed player, locks the original case, and forces the participant to choose one of the remaining three cases; the replacement player is accepted automatically.
- The rejected player is excluded from future case generation and is not transferred to an opponent.
- AI chooses only from its own private case set. Same-device mode supports 2–4 participants.
- Each squad is completed first, then a coach is assigned and revealed. Only after all participants have coaches does a single 60-second card phase begin.
- The only Deal cards are Steal and Shield. Steal allows choosing an opponent's team and then an unprotected player; Shield chooses one member of the owner's team. The old bank deck and Sabotage rules are removed.
- The setup screen includes a searchable custom player filter. A capacity check blocks a filtered pool that cannot support the selected formation/participant count. Full squad pitches are shown with each coach before and during the final card phase.
- Deal online remains disabled until hidden case data can be kept private per participant.

## Ratings rebalanced

- 236 players: 58 rated 90+, 162 rated 80–89, 16 rated below 80.
- Lionel Messi and Cristiano Ronaldo are the only 99-rated players.
- Selected inflated Icons/Heroes and current-player ratings were reduced; player prices were recalculated from OVR.
- `RATING_RESEARCH_AR.md` records the comparison sources and limitations. Non-Icon Prime values are not claimed to be exact EA ratings.

## Validation completed

- `python3 tools/validate_catalog.py`: PASS.
- Kotlin/JVM rule runner for `DealRules.kt`: PASS across 6–11-player formations, up to four participants, Deal/Risk, AI, Steal, and Shield. AI pick averages increase with difficulty (sample run: 86.53, 88.43, 89.57, 90.78).
- ZIP/source metadata and Android resources validation is documented separately after packaging.
- A standalone `kotlinc` parse check of the Compose screen found no syntax-shaped diagnostics, but could not resolve AndroidX/Firebase because the Android classpath is unavailable.

## Not verified

- No Gradle/Android SDK build was available; no APK build is claimed.
- Compose runtime, touch flow, animations, and full card phase still require GitHub Actions and an on-device test.
- The spectator/voice-chat switches shown in the video are not active. Deal online is intentionally disabled.
