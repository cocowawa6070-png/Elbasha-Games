# ELBASHA GAMES

**Developer:** Mostafa Bek  
**Package:** `com.mostafabek.elbashagames`  
**Stack:** Kotlin, Jetpack Compose, Firebase Authentication and Realtime Database.

## Changes in this source package

- Football question bank expanded from 85 to **105 bilingual questions**. Difficulty labels are retained in the question model.
- Added `PlayerDatabase.kt`, a shared catalog of **151 players** across GK, DF, MF, WG and ST positions.
- Player ratings are ELBASHA game ratings: Messi and Cristiano Ronaldo are the only 99-rated players; all other entries are between 75 and 98. These are not official EA FC ratings.
- The playable 5-a-side draft now draws from the shared player catalog instead of a tiny hard-coded list. Player choices show name, position context, overall rating and draft cost; no attribute bars or PlayStyles are included.
- Penalty Shootout now offers Rookie, Balanced, Pro and Legend CPU difficulty. Higher levels have stronger pattern-reading and save accuracy.

## Important scope notes

This package does **not** yet implement the full Auction, Billion Auction, Deal or No Deal, secret-criteria Build a Team, Market Master, The Filter or Number Challenge game engines. Their rules are documented in `GAME_RULES_AR.md`; do not treat those modes as playable yet. The 151-player catalog is currently connected to the 5-a-side draft and is ready to be reused when those modes are implemented.

Online rooms, live multiplayer synchronization and voice chat are also not implemented. The Firebase rules provide groundwork only.

## Firebase setup

1. Confirm Firebase Authentication Email/Password and Google providers are configured.
2. Set `firebase_database_url` in `app/src/main/res/values/strings.xml` to the exact Realtime Database URL from Firebase Console.
3. Review and publish `firebase/database.rules.json` in Realtime Database Rules.
4. Build using the repository's GitHub Actions workflow.

## In-app updates

- The Settings screen includes a GitHub Releases update checker.
- It reads the latest public release, downloads its APK with Android Download Manager, and opens the Android package installer when the download completes.
- Android still requires the user to allow installs from this app and confirm the installation; silent installation is not supported for an ordinary app.
- Publishing an update: push a tag such as `v0.2.1`. The `Publish ELBASHA GAMES Update` workflow builds a release-signed APK and attaches it to a GitHub Release. The same signing key must be kept permanently.
- The updater expects a release body line `versionCode: N` and an APK asset.

## Build status

The source package was edited and packaged, but this environment does not have Android SDK/Gradle available. Therefore no APK build or device test is claimed. Run GitHub Actions and inspect the build result before installing.
