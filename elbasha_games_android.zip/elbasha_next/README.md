# ELBASHA GAMES

**Developer:** Mostafa Bek  
**Package:** `com.mostafabek.elbashagames`  
**Stack:** Kotlin, Jetpack Compose, Firebase Authentication and Realtime Database.

## Current first-release scope

The first release is intentionally limited to three game entries:

1. **Football Auction** - Classic (5 players / 100M) and Pro Max (11 players / 200M), with a local AI rival, separate budgets, squad-rating comparison, and a same-position hidden-player reward for the losing side. Hidden bonus players are removed from future lots to prevent duplicates. Last Bid and Wild Card are currently simple one-use prototype effects; the remaining special-card rules still need to be completed against the agreed game rules.
2. **Deal or No Deal** - four-box rounds, accept/risk decision, mandatory second-box choice, occasional bank offer and a local AI rival that biases its picks toward stronger available players when behind. Multiplayer stealing/protection card interactions are not implemented yet.
3. **Build Your Team** - choose a squad size from 4 to 11, select players by position, use a size-scaled budget and save a score. This is currently a solo draft; secret answers, custom criteria judging and multiplayer team comparison remain follow-up work.

The other game screens remain in source but are hidden from the first-release game catalog so they can be added gradually.

## Player catalog and search

- Shared catalog contains **165 players** across GK, DF, MF, WG and ST.
- All 165 entries have Arabic search/display aliases in `PlayerSearch.kt`; English search remains supported.
- Suggestions are hidden until at least **3 characters** are entered, then show up to 8 matches, prioritizing names that start with the query.
- Arabic normalization removes diacritics/tatweel and standardizes common alef/hamza/taa-marbuta variants.
- Ratings and player prices are curated in-app relative values; prices now scale consistently with the rating. Current-player tiers use FC 27 ranking as a reference and are rescaled to ELBASHA values, while legends are judged by peak legacy. Messi and Cristiano Ronaldo are the only 99-rated players; all other players are 75-98.
- Country flags and Arabic/English nationality labels are mapped for all 165 players. Player portraits and club names are still incomplete and should be verified before a public release.

## Questions and AI

- The bilingual football question bank currently contains **120 questions**: 36 easy, 41 medium and 43 hard.
- Penalty Shootout has Rookie, Balanced, Pro and Legend CPU difficulty.
- The new Auction and Deal screens have basic local AI opponents. They are not online multiplayer opponents and do not yet implement every special-card rule.

## Not yet implemented

- Full multiplayer rooms, live synchronization, voice chat and reconnect handling.
- Full secret-criteria Build Your Team multiplayer rules.
- The remaining Auction special-card rules, including the hidden-player half-price card, No Risk No Fun and player-swap effects.
- Full Deal or No Deal protection/steal/sabotage card interactions.
- Billion Auction, Market Master, The Filter and Number Challenge.
- Developer music management backed by Supabase.
- Complete player portraits, club/nationality metadata and verified flag assets.

The detailed agreed rules are documented in `GAME_RULES_AR.md`. A visible game button must not be interpreted as proof that every online or card-based rule is complete.

## Developer account and leaderboard

- The configured developer Firebase UID is granted developer access directly.
- The developer account is excluded from competitive score submissions and leaderboard display. Auction and Deal or No Deal now submit completed-game scores through `ScoreRepository`.
- Additional admin UIDs can still be granted through the Firebase `admins` path.

## Firebase setup

1. Confirm Firebase Authentication Email/Password and Google providers are configured.
2. Verify `firebase_database_url` in `app/src/main/res/values/strings.xml`; it is prefilled from `google-services.json` as `https://elbasha-games-default-rtdb.firebaseio.com`. Confirm it matches the Realtime Database URL shown in Firebase Console.
3. Review and publish `firebase/database.rules.json` in Realtime Database Rules.
4. Build using the repository's GitHub Actions workflow.

## In-app updates

- The Settings screen includes a GitHub Releases update checker.
- It reads the latest public release, downloads its APK with Android Download Manager, and opens the Android package installer when the download completes.
- Android still requires the user to allow installs from this app and confirm the installation; silent installation is not supported for an ordinary app.
- Publishing an update: push a tag such as `v0.2.1`. The `Publish ELBASHA GAMES Update` workflow builds a release-signed APK and attaches it to a GitHub Release. The same signing key must be kept permanently.
- The updater expects a release body line `versionCode: N` and an APK asset.

## Validation and build status

- Run `python3 tools/validate_catalog.py` for fast source-level checks of player count, unique names, Arabic aliases, rating constraints and the three-game first-release scope.
- Player-search smoke tests were run independently for English, Arabic, the 3-character threshold and diacritic normalization.
- Android Gradle build and device testing have **not** been completed in this environment because Android SDK/Gradle are unavailable here. Run GitHub Actions and inspect its result before treating an APK as installable.
- The source validator also checks all 120 built-in bilingual questions for unique IDs and prompts, four distinct options, valid difficulty, and answer leakage in either language, confirms the Firebase database URL, checks auction hidden-player safeguards and score wiring, and verifies the release version-code workflow.
