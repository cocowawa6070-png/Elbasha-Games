# ELBASHA GAMES — next setup and verification

1. Extract this ZIP. The Android project is inside `elbasha_next/`; upload the contents of that folder to the root of the existing GitHub repository, preserving `.github/workflows/`.
2. Verify `app/src/main/res/values/strings.xml`: `firebase_database_url` is prefilled as `https://elbasha-games-default-rtdb.firebaseio.com`, copied from `app/google-services.json`. Confirm it matches the URL in Firebase Console.
3. Review and publish `firebase/database.rules.json` in the Firebase Realtime Database Rules tab. The rules file is included but has not been deployed from this environment.
4. Confirm the GitHub repository secrets `ANDROID_DEBUG_KEYSTORE_BASE64` and `ANDROID_DEBUG_KEYSTORE_PASSWORD` are configured. Keep the same signing key for future updates.
5. Run the `Build Elbasha Games APK` GitHub Actions workflow for a debug APK. For a signed GitHub Release, push a version tag such as `v0.3.0`; the release workflow runs only for `v*` tags. If a build fails, inspect the first Gradle error block before changing more source.

## Included in this source update
- 165-player catalog with Arabic/English search aliases and a 3-character suggestion threshold.
- Three first-release game entries: Auction, Deal or No Deal, and Build Your Team.
- Auction has Classic and Pro Max budgets, a local AI rival, same-position hidden-player reward for the losing side, duplicate-lot protection, and a guard against AI purchases below the opening price.
- Auction and Deal or No Deal submit completed-game scores; the developer account remains excluded from the competitive leaderboard.
- Deal or No Deal has four-box rounds, a risk decision, a mandatory second-box choice, and occasional bank offers.
- 120 bilingual football questions with source-level checks for duplicate IDs and answer leakage.
- Release workflow version-code calculation fixed to use Bash arithmetic supported by GitHub Actions.

## Still incomplete
- Full Auction special-card rules (hidden-player half-price card, No Risk No Fun, player swaps and other card effects).
- Deal or No Deal protection/steal/sabotage cards.
- Full secret-criteria Build Your Team multiplayer rules.
- Online rooms, realtime multiplayer, voice chat, and reconnect handling.
- Complete player portraits and verified club names; country flags and Arabic/English nationality labels are now included for the catalog.
- Supabase music management.

No full Android APK build or device test is claimed from this environment. Run GitHub Actions and inspect its result before treating an APK as installable.
