# Stable GitHub Actions signing key for ELBASHA GAMES

The GitHub-hosted runner is temporary. If it uses the automatically generated Android debug key, the APK signing certificate can change between workflow runs. Google/Firebase Android OAuth must recognize the certificate that actually signs the APK.

This project now uses a stable debug keystore supplied through GitHub Actions secrets. The private keystore is intentionally **not** included in this project ZIP or the public repository.

## 1. Add the two GitHub Actions secrets

Open the repository:

`Settings` → `Secrets and variables` → `Actions` → `New repository secret`

Create these two repository secrets:

- `ANDROID_DEBUG_KEYSTORE_BASE64`: the complete one-line contents of the separate file `elbasha-keystore-base64.txt` supplied with this project update.
- `ANDROID_DEBUG_KEYSTORE_PASSWORD`: the password in the separate private file `ELBASHA_SIGNING_PRIVATE_INFO.txt` supplied with this project update.

Do not commit either private file to the repository. Do not paste the values into source code, workflow files, or public issues.

## 2. Register this key in Firebase

In Firebase Console → Project settings → Your apps → Android app `com.mostafabek.elbashagames` → SHA certificate fingerprints, add:

- SHA-1: `2C:4A:D1:40:F9:60:F1:7E:77:E4:64:0F:F4:89:71:9D:A1:D4:6A:0B`
- SHA-256: `F6:E7:D3:B8:F0:49:33:B7:21:EE:AE:3A:89:69:0E:7F:9B:A4:03:1D:F4:18:74:AF:A0:52:27:7D:F2:8D:05:ED`

Keep the old fingerprints for now; just add these two new ones.

## 3. Refresh google-services.json

After saving both fingerprints, download the updated `google-services.json` from the same Android app in Firebase Console. Replace `app/google-services.json` in this project with the newly downloaded file.

The Web OAuth client ID in `app/src/main/res/values/strings.xml` should remain the Web client ID for the `elbasha-games` Firebase project. Do not replace it with the Android OAuth client ID.

## 4. Build and install

Run the GitHub Actions workflow `Build Elbasha Games APK`. It will print the signing certificate fingerprints used by the APK. They should match the two fingerprints above.

Because this is a new signing key, Android will not install this APK as an update over an older APK signed with a different key. Uninstall the old test APK first, then install the new one. Firebase account data is stored remotely; local app preferences may reset.

## Security note

This is a stable **debug/testing** signing key, not a production Play Store release key. Keep the keystore and both GitHub secrets private. Never publish the keystore or its Base64 contents in the public repository.
