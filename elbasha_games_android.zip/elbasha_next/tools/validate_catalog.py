#!/usr/bin/env python3
"""Fast source-level checks for the ELBASHA player catalog and MVP scope."""
from pathlib import Path
import json
import re
import random
import xml.etree.ElementTree as ET
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "app/src/main/java/com/mostafabek/elbashagames"
players_source = (BASE / "PlayerDatabase.kt").read_text(encoding="utf-8")
search_source = (BASE / "PlayerSearch.kt").read_text(encoding="utf-8")
build_source = (BASE / "BuildTeamGame.kt").read_text(encoding="utf-8")
ui_source = (BASE / "ElbashaUi.kt").read_text(encoding="utf-8")
questions_source = (BASE / "Questions.kt").read_text(encoding="utf-8")

players = re.findall(
    r'PlayerCard\("([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([A-Z]+)"\s*,\s*(\d+)\s*,\s*(\d+)\s*,',
    players_source,
)
if len(players) != 165:
    sys.exit(f"FAIL: expected 165 player records, found {len(players)}")

names = [p[0] for p in players]
if "🌍" in players_source:
    sys.exit("FAIL: player nationality flags still contain globe placeholders")
if len(re.findall(r'PlayerCard\("[^"]+"\s*,\s*"[^"]+"\s*,\s*"[A-Z]+"\s*,\s*\d+\s*,\s*\d+\s*,\s*"[^"]+"\s*,\s*"[^"]+"\s*,\s*"[^"]+"\)', players_source)) != 165:
    sys.exit("FAIL: all players must have bilingual nationality labels")
if len(names) != len(set(names)):
    sys.exit("FAIL: duplicate English player names")

arabic_names = [p[1] for p in players]
if len(arabic_names) != len(set(arabic_names)):
    sys.exit("FAIL: duplicate Arabic display names")
if any(not re.search(r"[\u0600-\u06FF]", name) for name in arabic_names):
    bad = [p[0] for p in players if not re.search(r"[\u0600-\u06FF]", p[1])]
    sys.exit(f"FAIL: players missing Arabic display names: {bad}")

positions = {position: sum(1 for p in players if p[2] == position)
             for position in {p[2] for p in players}}
if positions != {"GK": 30, "DF": 38, "MF": 41, "WG": 33, "ST": 23}:
    sys.exit(f"FAIL: unexpected position distribution: {positions}")

ratings = {name: int(rating) for name, _, _, rating, _ in players}
prices = {name: int(price) for name, _, _, _, price in players}
if any(rating < 75 or rating > 99 for rating in ratings.values()):
    sys.exit("FAIL: player rating outside 75..99")
expected_99 = {"Lionel Messi", "Cristiano Ronaldo"}
actual_99 = {name for name, rating in ratings.items() if rating == 99}
if actual_99 != expected_99:
    sys.exit(f"FAIL: 99-rated players mismatch: {sorted(actual_99)}")
expected_prices = {name: 8 + ((rating - 75) * 4 + 12) // 24 for name, rating in ratings.items()}
if prices != expected_prices:
    sys.exit("FAIL: player prices must scale consistently with ELBASHA ratings")
expected_current_tiers = {
    "Kylian Mbappe": 98, "Erling Haaland": 98,
    "Thibaut Courtois": 97, "Rodri": 97, "Ousmane Dembele": 97,
    "Harry Kane": 97, "Jude Bellingham": 97, "Pedri": 97, "Lamine Yamal": 97,
    "Mohamed Salah": 94, "Bukayo Saka": 94,
    "Michael Olise": 97, "Vitinha": 97, "Nuno Mendes": 96,
    "Gabriel Magalhaes": 96, "Willian Pacho": 96, "Joao Neves": 95,
    "Joshua Kimmich": 95, "Luis Diaz": 95, "Florian Wirtz": 93,
    "Martin Odegaard": 93, "Enzo Fernandez": 93, "Rayan Cherki": 93,
    "Viktor Gyokeres": 93, "Alexander Isak": 93,
}
for player_name, expected_rating in expected_current_tiers.items():
    if ratings.get(player_name) != expected_rating:
        sys.exit(f"FAIL: current-player rating tier mismatch for {player_name}: {ratings.get(player_name)}")

alias_pairs = dict(re.findall(r'"([^"]+)"\s+to\s+"([^"]+)"', search_source))
missing_aliases = sorted(set(names) - set(alias_pairs))
if missing_aliases:
    sys.exit(f"FAIL: missing Arabic search aliases: {missing_aliases}")
alias_mismatches = sorted(
    name for name, arabic, _, _, _ in players if alias_pairs.get(name) != arabic
)
if alias_mismatches:
    sys.exit(f"FAIL: Arabic display/search aliases differ: {alias_mismatches}")

if "PlayerSearch.normalize(searchText).length < 3" not in build_source:
    sys.exit("FAIL: Build Team search must enforce the 3-character threshold")
if "fun createNationalityChallenge" not in build_source or "fun chooseAiPlayer" not in build_source:
    sys.exit("FAIL: Build Team must provide nationality-based challenges and an AI draft")
if "صعب جدًا" not in build_source or "0.20" not in build_source:
    sys.exit("FAIL: Build Team must include the Very Hard AI level")
launch_source_for_ai = (BASE / "LaunchGames.kt").read_text(encoding="utf-8")
if "private fun auctionAiBidCeiling" not in launch_source_for_ai or launch_source_for_ai.count("AiDifficultyAr.indices") < 2:
    sys.exit("FAIL: Auction and Deal or No Deal must expose four AI difficulty levels")
if "else -> 2" not in launch_source_for_ai or "else -> 0.24" not in launch_source_for_ai:
    sys.exit("FAIL: Very Hard AI strategy settings are missing")
if "BuildPhase.Result" not in build_source or "ScoreRepository.submit(database, user, score)" not in build_source:
    sys.exit("FAIL: Build Team must finish with a result and submit a score")
match_engine = (BASE / "MatchEngine.kt").read_text(encoding="utf-8")
if "fun simulate(" not in match_engine or "userExpectedGoals" not in match_engine:
    sys.exit("FAIL: first-release games must use the shared probability-based match simulator")
if "fun <T> suggestionsBy" not in search_source:
    sys.exit("FAIL: shared generic player suggestion engine is missing")

# The current Build Team MVP uses real nationality metadata. Verify that its
# 4..11-player formations can generate a two-player matchup for every slot.
player_meta = re.findall(
    r'PlayerCard\("([^"]+)"\s*,\s*"[^"]+"\s*,\s*"([A-Z]+)"\s*,\s*\d+\s*,\s*\d+\s*,\s*"[^"]+"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\)',
    players_source,
)
formations = {
    4: ["GK", "DF", "MF", "ST"],
    5: ["GK", "DF", "MF", "WG", "ST"],
    6: ["GK", "DF", "DF", "MF", "WG", "ST"],
    7: ["GK", "DF", "DF", "MF", "MF", "WG", "ST"],
    8: ["GK", "DF", "DF", "MF", "MF", "WG", "WG", "ST"],
    9: ["GK", "DF", "DF", "DF", "MF", "MF", "WG", "WG", "ST"],
    10: ["GK", "DF", "DF", "DF", "MF", "MF", "MF", "WG", "WG", "ST"],
    11: ["GK", "DF", "DF", "DF", "MF", "MF", "MF", "WG", "WG", "ST", "ST"],
}
if len(player_meta) != 165:
    sys.exit(f"FAIL: expected nationality metadata for 165 players, found {len(player_meta)}")
for size, formation in formations.items():
    for trial in range(300):
        used = set()
        for position in formation:
            groups = {}
            for name, player_position, nationality_ar, nationality_en in player_meta:
                if player_position == position and name not in used and nationality_ar and nationality_en:
                    groups.setdefault(nationality_en, []).append(name)
            eligible_groups = [names_in_group for names_in_group in groups.values() if len(names_in_group) >= 2]
            if not eligible_groups:
                sys.exit(f"FAIL: Build Team cannot form a two-player nationality challenge (size={size}, position={position})")
            chosen_group = random.choice(eligible_groups)
            used.update(random.sample(chosen_group, 2))


catalog = re.findall(r'GameItem\("(auction|deal|build)"', ui_source)
if catalog != ["auction", "deal", "build"]:
    sys.exit(f"FAIL: first-release game catalog is not exactly Auction/Deal/Build Team: {catalog}")




strings_root = ET.parse(ROOT / "app/src/main/res/values/strings.xml").getroot()
string_values = {node.attrib.get("name"): (node.text or "").strip() for node in strings_root.findall("string")}
google_config = json.loads((ROOT / "app/google-services.json").read_text(encoding="utf-8"))
expected_database_url = google_config.get("project_info", {}).get("firebase_url", "").strip()
configured_database_url = string_values.get("firebase_database_url", "")
if not expected_database_url or configured_database_url != expected_database_url:
    sys.exit("FAIL: firebase_database_url must match project_info.firebase_url in google-services.json")
gradle_app_config = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
package_match = re.search(r'applicationId\s*=\s*"([^"]+)"', gradle_app_config)
configured_package = package_match.group(1) if package_match else ""
google_packages = {
    client.get("client_info", {}).get("android_client_info", {}).get("package_name")
    for client in google_config.get("client", [])
}
if not configured_package or configured_package not in google_packages:
    sys.exit("FAIL: Android applicationId must match a package in google-services.json")
web_client_ids = {
    oauth.get("client_id")
    for client in google_config.get("client", [])
    for oauth in client.get("oauth_client", [])
    if oauth.get("client_type") == 3
}
if not string_values.get("google_web_client_id") or string_values["google_web_client_id"] not in web_client_ids:
    sys.exit("FAIL: google_web_client_id must match an OAuth client of type 3 in google-services.json")

release_workflow = (ROOT / ".github/workflows/release.yml").read_text(encoding="utf-8")
if "github.run_number + 2" in release_workflow or "GITHUB_RUN_NUMBER + 2" not in release_workflow:
    sys.exit("FAIL: release workflow version code must be calculated in shell, not GitHub expression arithmetic")
if "python3 tools/validate_catalog.py" not in release_workflow:
    sys.exit("FAIL: release workflow must run source validation before publishing")
if "workflow_dispatch" in release_workflow:
    sys.exit("FAIL: release publishing should only run from version tags, not a branch dispatch")
if "APP_VERSION_CODE" not in release_workflow or "${{ steps.version.outputs.version_code }}" not in release_workflow or "id: version" not in release_workflow:
    sys.exit("FAIL: release workflow must pass the calculated version code to Gradle and release notes")


updater_source = (BASE / "AppUpdater.kt").read_text(encoding="utf-8")
if "isUpdateDownloadSuccessful(context, prefs.getLong(\"download_id\", -1L))" not in updater_source:
    sys.exit("FAIL: updater must verify DownloadManager success before launching the installer")
if "destination.delete()" not in updater_source:
    sys.exit("FAIL: updater must clear an old APK before downloading a replacement")
receiver_source = (BASE / "UpdateDownloadReceiver.kt").read_text(encoding="utf-8")
if "if (!isUpdateDownloadSuccessful(context, id)) return" not in receiver_source:
    sys.exit("FAIL: updater receiver must ignore failed DownloadManager transfers")

launch_source = (BASE / "LaunchGames.kt").read_text(encoding="utf-8")
if "grantHiddenPlayer(lot.position, toUser = true)" not in launch_source or "grantHiddenPlayer(lot.position, toUser = false)" not in launch_source:
    sys.exit("FAIL: auction must grant a same-position hidden bonus player to the losing side")
if "advanceRound(userCount = bought.size + 1)" not in launch_source or "advanceRound(aiCount = aiBought.size + 1)" not in launch_source:
    sys.exit("FAIL: auction must end correctly when either side fills its target squad")
if "val payable = if (wildCardUsed) (bid - 2).coerceAtLeast(opening) else bid" not in launch_source:
    sys.exit("FAIL: Wild Card must reduce the final paid amount without invalidating the opening bid")
if "remainingLots = remainingLots.filterNot { it.nameEn == hidden.nameEn }" not in launch_source:
    sys.exit("FAIL: hidden bonus player must be removed from future auction lots")
if "val lot = remainingLots.firstOrNull()" not in launch_source:
    sys.exit("FAIL: auction must advance through the remaining-lot queue")
if "val aiIsBehind = aiTeam.sumOf { it.rating } < team.sumOf { it.rating }" not in launch_source:
    sys.exit("FAIL: Deal or No Deal AI must adapt its draft choices to the user's current squad rating")
if "aiBudget < opening" not in launch_source:
    sys.exit("FAIL: AI must not buy a player below the opening bid when its budget is insufficient")
if "boxes.indices.filter { it != firstBoxIndex }.randomOrNull()" not in launch_source:
    sys.exit("FAIL: Deal bank offer must select randomly among the three unopened boxes")
if launch_source.count("MatchEngine.simulate(") < 2:
    sys.exit("FAIL: Auction and Deal or No Deal must both simulate a match")
if launch_source.count("ScoreRepository.submit(database, user,") != 2:
    sys.exit("FAIL: Auction and Deal or No Deal must both submit completed-game scores")
if "fun AuctionGameScreen(user: FirebaseUser" not in launch_source or "fun DealOrNoDealScreen(user: FirebaseUser" not in launch_source:
    sys.exit("FAIL: completed games are missing authenticated score context")


question_rows = re.findall(
    r'q\("(s\d+)",\s*"([^"]+)",\s*"([^"]+)",\s*listOf\(([^)]*)\),\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*listOf\(([^)]*)\)',
    questions_source,
)
if len(question_rows) != 120 or len({row[0] for row in question_rows}) != 120:
    sys.exit(f"FAIL: expected 120 unique built-in questions, found {len(question_rows)}")
if len({row[1] for row in question_rows}) != 120 or len({row[6] for row in question_rows}) != 120:
    sys.exit("FAIL: duplicate Arabic or English question prompts detected")
answer_leaks = [row[0] for row in question_rows if row[2].strip() and row[2].strip() in row[1]]
answer_leaks_en = [row[0] for row in question_rows if row[7].strip().casefold() in row[6].casefold()]
if answer_leaks or answer_leaks_en:
    sys.exit(f"FAIL: answers appear in prompt text (AR={answer_leaks}, EN={answer_leaks_en})")
invalid_options = []
for row in question_rows:
    wrong_ar = re.findall(r'"([^"]+)"', row[3])
    wrong_en = re.findall(r'"([^"]+)"', row[8])
    if len(wrong_ar) != 3 or len(set(wrong_ar)) != 3 or len(wrong_en) != 3 or len(set(wrong_en)) != 3 or row[2] in wrong_ar or row[7] in wrong_en:
        invalid_options.append(row[0])
if invalid_options:
    sys.exit(f"FAIL: questions must have three distinct wrong options: {invalid_options}")
invalid_difficulty = [row[0] for row in question_rows if row[4] not in {"easy", "medium", "hard"}]
if invalid_difficulty:
    sys.exit(f"FAIL: invalid question difficulty values: {invalid_difficulty}")
difficulty_counts = {level: sum(1 for row in question_rows if row[4] == level) for level in ("easy", "medium", "hard")}
if difficulty_counts != {"easy": 36, "medium": 41, "hard": 43}:
    sys.exit(f"FAIL: unexpected question difficulty distribution: {difficulty_counts}")

print("PASS: 165 unique players with country flags and bilingual nationality labels")
print("PASS: all players have matching Arabic display names and search aliases")
print("PASS: position distribution is valid (GK 30 / DF 38 / MF 41 / WG 33 / ST 23)")
print("PASS: only Messi and Cristiano are rated 99")
print("PASS: current-player rating tiers are calibrated to relative FC 27 rankings")
print("PASS: player prices scale consistently with in-app ratings")
print("PASS: shared 3-character player suggestions and Build Team AI challenge")
print("PASS: four AI difficulty levels in all three first-release games")
print("PASS: all 4..11-player formations can generate nationality matchups")
print("PASS: shared match engine used by first-release games")
print("PASS: first-release catalog contains the three selected games")
print("PASS: Auction hidden-player reward, correct squad completion, Wild Card discount and AI opening-bid guard")
print("PASS: Deal bank offer picks a random unopened box")
print("PASS: both Auction and Deal or No Deal run a match simulation")
print("PASS: Auction and Deal or No Deal submit completed scores")
print("PASS: Deal or No Deal AI uses an adaptive rating-based draft")
print("PASS: release workflow calculates versionCode with shell arithmetic")
print("PASS: Firebase URL, Google web client ID and Android package match google-services.json")
print("PASS: updater verifies completed downloads and clears stale APKs")
print("PASS: 120 unique questions, 36 easy / 41 medium / 43 hard, four choices each, no answer leakage")
