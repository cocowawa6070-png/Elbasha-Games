package com.mostafabek.elbashagames

/** Account-level access rules for the private ELBASHA GAMES group. */
object ElbashaAccess {
    const val DeveloperUid = "1NZfGRNjIOcpz3SmdBDdg3auJs82"

    fun isDeveloper(uid: String?): Boolean = uid == DeveloperUid
}
