package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random

private data class AuctionLot(val player: PlayerCard, val opening: Int)

private fun auctionAiBidCeiling(rating: Int, opening: Int, budget: Int, difficulty: Int): Int {
    if (budget < opening) return 0
    val passChance = when (difficulty) { 0 -> 24; 1 -> 13; 2 -> 6; else -> 2 }
    if (rating < 93 && Random.nextInt(100) < passChance) return 0
    val divisor = when (difficulty) { 0 -> 18; 1 -> 15; 2 -> 13; else -> 11 }
    val randomRange = when (difficulty) { 0 -> 2; 1 -> 3; 2 -> 4; else -> 5 }
    val strategicCeiling = opening + (rating / divisor) + Random.nextInt(0, randomRange + 1)
    return minOf(budget, strategicCeiling)
}

private val AiDifficultyAr = listOf("سهل", "متوازن", "صعب", "صعب جدًا")
private val AiDifficultyEn = listOf("Easy", "Balanced", "Hard", "Very hard")

@Composable
fun AuctionGameScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var pro by remember { mutableStateOf(false) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var started by remember { mutableStateOf(false) }
    var budget by remember { mutableIntStateOf(100) }
    var aiBudget by remember { mutableIntStateOf(100) }
    var bought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var aiBought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var hiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var aiHiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var remainingLots by remember { mutableStateOf(emptyList<PlayerCard>()) }
    var bid by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var ended by remember { mutableStateOf(false) }
    var lastBidUsed by remember { mutableStateOf(false) }
    var wildCardUsed by remember { mutableStateOf(false) }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var matchResult by remember { mutableStateOf<MatchScore?>(null) }
    val targetCount = if (pro) 11 else 5
    val startBudget = if (pro) 200 else 100
    val pool = remember(pro, started) {
        PlayerDatabase.players.shuffled().take(if (pro) 42 else 24)
    }
    val lot = remainingLots.firstOrNull()
    val userRating = bought.sumOf { it.first.rating } + hiddenPlayers.sumOf { it.rating }
    val aiRating = aiBought.sumOf { it.first.rating } + aiHiddenPlayers.sumOf { it.rating }
    val userSquad = bought.map { it.first } + hiddenPlayers
    val aiSquad = aiBought.map { it.first } + aiHiddenPlayers
    val userCoachBonus = (budget.toDouble() / startBudget * 6.0).coerceIn(0.0, 6.0)
    val aiCoachBonus = (aiBudget.toDouble() / startBudget * 6.0).coerceIn(0.0, 6.0)

    LaunchedEffect(ended) {
        if (ended) {
            val result = matchResult ?: MatchEngine.simulate(userSquad, aiSquad, userCoachBonus, aiCoachBonus).also {
                matchResult = it
            }
            sound.play(if (result.userWon) Sfx.Win else Sfx.Wrong)
            if (!scoreSubmitted) {
                scoreSubmitted = true
                if (ElbashaAccess.isDeveloper(user.uid)) {
                    saveStatus = uiText("حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
                } else {
                    val matchBonus = when {
                        result.userWon -> 1_000
                        result.isDraw -> 500
                        else -> 0
                    }
                    ScoreRepository.submit(database, user, userRating * 10 + matchBonus) { saved ->
                        saveStatus = if (saved) uiText("تم حفظ نقاط المزاد", "Auction score saved")
                        else uiText("تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                    }
                }
            }
        }
    }

    fun grantHiddenPlayer(position: String, toUser: Boolean) {
        val alreadyUsed = (bought.map { it.first } + aiBought.map { it.first } + hiddenPlayers + aiHiddenPlayers)
            .map { it.nameEn }.toSet()
        val hidden = PlayerDatabase.players
            .filter { it.position == position && it.nameEn !in alreadyUsed }
            .randomOrNull() ?: return
        // A bonus player must not appear again as a later auction lot.
        remainingLots = remainingLots.filterNot { it.nameEn == hidden.nameEn }
        if (toUser) hiddenPlayers = hiddenPlayers + hidden else aiHiddenPlayers = aiHiddenPlayers + hidden
    }

    fun advanceRound(userCount: Int = bought.size, aiCount: Int = aiBought.size) {
        remainingLots = remainingLots.drop(1)
        bid = 0
        if (userCount >= targetCount || aiCount >= targetCount || remainingLots.isEmpty()) ended = true
    }

    BackHandler { onExit() }
    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }
    Column(Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f)); SoundToggles(sound)
        }
        Text(uiText("🔨 المزاد الكروي", "🔨 Football Auction"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
        if (!started) {
            Text(uiText("اختار نظام المزاد", "Choose auction mode"), color = Cream, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { mode ->
                    Card(Modifier.weight(1f).clickable { pro = mode }, colors = CardDefaults.cardColors(containerColor = if (pro == mode) Gold else PanelColor)) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (mode) "PRO MAX" else "CLASSIC", color = if (pro == mode) DeepWine else Cream, fontWeight = FontWeight.Black)
                            Text(if (mode) "11 ${uiText("لاعبًا", "players")} • 200M" else "5 ${uiText("لاعبين", "players")} • 100M", color = if (pro == mode) DeepWine else Muted)
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText("منافسة ضد الذكاء الاصطناعي", "Play against AI"), color = Cream, fontWeight = FontWeight.Bold)
                    Text(uiText("كل لاعب يدخل المزاد مرة واحدة. راقب ميزانيتك، والخصم يزايد وفق تقييم اللاعب وميزانيته ومستوى الصعوبة.", "You bid against an AI rival. It considers player rating, remaining budget and difficulty."), color = Muted, fontSize = 12.sp)
                }
            }
            Text(uiText("مستوى AI", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                AiDifficultyAr.indices.forEach { level ->
                    val selected = aiDifficulty == level
                    Card(Modifier.weight(1f).clickable { aiDifficulty = level }, colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor), shape = RoundedCornerShape(10.dp)) {
                        Text(if (english) AiDifficultyEn[level] else AiDifficultyAr[level], color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                    }
                }
            }
            Button(onClick = {
                started = true
                budget = startBudget
                aiBudget = startBudget
                bought = emptyList()
                aiBought = emptyList()
                hiddenPlayers = emptyList()
                aiHiddenPlayers = emptyList()
                remainingLots = pool
                bid = 0
                ended = false
                message = ""
                lastBidUsed = false
                wildCardUsed = false
                scoreSubmitted = false
                saveStatus = ""
                matchResult = null
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine), modifier = Modifier.fillMaxWidth()) {
                Text(uiText("ابدأ المزاد", "Start auction"))
            }
        } else if (ended || bought.size >= targetCount || lot == null) {
            Text(uiText("🏆 انتهى المزاد", "🏆 Auction complete"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(uiText("نتيجة المنافسة", "Match result"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiText("فريقك", "Your team"), color = Cream)
                        Text("$userRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${bought.size}/$targetCount", color = Muted)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiText("الخصم AI", "AI rival"), color = Cream)
                        Text("$aiRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${aiBought.size}/$targetCount", color = Muted)
                    }
                }
            }
            Text(uiText("نتيجة المباراة المحاكاة", "Simulated match result"), color = Cream, fontWeight = FontWeight.Bold)
            Text(
                matchResult?.let { "${it.userGoals}  -  ${it.opponentGoals}" } ?: uiText("جاري محاكاة المباراة…", "Simulating match…"),
                color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Black
            )
            Text(
                when {
                    matchResult == null -> uiText("جاري تجهيز النتيجة", "Preparing result")
                    matchResult!!.userWon -> uiText("👑 كسبت المباراة!", "👑 You won the match!")
                    matchResult!!.opponentWon -> uiText("الخصم كسب المباراة.", "The AI won the match.")
                    else -> uiText("المباراة انتهت بالتعادل.", "The match ended in a draw.")
                }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Text(uiText("قوة الفريق: $userRating مقابل $aiRating • مكافأة المدرب حسب الرصيد المتبقي", "Squad rating: $userRating vs $aiRating • Coach bonus is based on remaining budget"), color = Muted, fontSize = 11.sp)
            Text(uiText("ميزانيتك المتبقية: $budget مليون", "Your remaining budget: $budget M"), color = Cream)
            Text(uiText("ميزانية الخصم المتبقية: $aiBudget مليون", "AI remaining budget: $aiBudget M"), color = Muted)
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp)
            Text(uiText("تشكيلتك", "Your squad"), color = Cream, fontWeight = FontWeight.Bold)
            bought.forEach { (p, price) -> PlayerLine(p, "${p.rating} OVR • $price M") }
            if (hiddenPlayers.isNotEmpty()) {
                Text(uiText("🎁 اللاعبون المخفيون اللي كسبتهم", "🎁 Your hidden bonus players"), color = Gold, fontWeight = FontWeight.Bold)
                hiddenPlayers.forEach { PlayerLine(it, uiText("هدية مجانية", "Free hidden bonus")) }
            }
            if (aiHiddenPlayers.isNotEmpty()) {
                Text(uiText("اللاعبون المخفيون للخصم", "AI hidden bonus players"), color = Muted, fontWeight = FontWeight.Bold)
                aiHiddenPlayers.forEach { PlayerLine(it, uiText("هدية مجانية", "Free hidden bonus")) }
            }
            Button(onClick = { started = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(uiText("العب من جديد", "Play again"))
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${uiText("لاعب", "Player")} ${bought.size + 1}/$targetCount", color = Cream)
                Text("💰 $budget M", color = Gold, fontWeight = FontWeight.Black)
            }
            Text(uiText("الخصم: ${aiBought.size} لاعب • $aiBudget مليون", "AI: ${aiBought.size} players • $aiBudget M"), color = Muted, fontSize = 12.sp)
            LinearProgressIndicator(progress = { bought.size.toFloat() / targetCount }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor)
            Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${lot.position}  •  ${lot.rating} OVR", color = Gold, fontWeight = FontWeight.Black)
                    Text(if (english) lot.nameEn else PlayerSearch.arabicName(lot.nameEn, lot.nameAr), color = Cream, fontSize = 22.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    val opening = (lot.rating / 14).coerceAtLeast(5)
                    Text(uiText("السعر الافتتاحي $opening مليون", "Opening bid $opening million"), color = Muted)
                }
            }
            Text(uiText("مزايدتك الحالية: $bid مليون", "Your current bid: $bid M"), color = Gold, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10).forEach { increment ->
                    OutlinedButton(onClick = {
                        if (bid + increment <= budget) bid += increment
                        else message = uiText("ميزانيتك مش مكفية للمزايدة دي", "Not enough budget for this bid")
                    }, modifier = Modifier.weight(1f)) { Text("+$increment M", color = Cream) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (!lastBidUsed && bid + 3 <= budget) { bid += 3; lastBidUsed = true; message = uiText("كارت Last Bid زوّد مزايدتك 3 مليون", "Last Bid card added 3M") }
                    else message = uiText("كارت Last Bid غير متاح أو الميزانية لا تكفي", "Last Bid is unavailable or budget is too low")
                }, modifier = Modifier.weight(1f), enabled = !lastBidUsed) { Text("⚡ Last Bid", color = Gold) }
                OutlinedButton(onClick = {
                    if (!wildCardUsed) { wildCardUsed = true; message = uiText("Wild Card اتفعل: خصم 2 مليون من السعر النهائي عند الفوز (بحد أدنى سعر الافتتاح).", "Wild Card active: 2M off your final winning price (opening-price floor).") }
                }, modifier = Modifier.weight(1f), enabled = !wildCardUsed) { Text("🃏 Wild Card", color = Gold) }
            }
            Button(onClick = {
                val opening = (lot.rating / 14).coerceAtLeast(5)
                val aiMax = if (aiBought.size >= targetCount) 0 else auctionAiBidCeiling(lot.rating, opening, aiBudget, aiDifficulty)
                val payable = if (wildCardUsed) (bid - 2).coerceAtLeast(opening) else bid
                if (bid < opening) {
                    message = uiText("مزايدتك أقل من السعر الافتتاحي", "Your bid is below the opening price")
                } else if (payable > budget) {
                    message = uiText("ميزانيتك لا تكفي بعد تطبيق الكارت", "Your budget cannot cover the final price")
                } else if (bid >= aiMax || aiBudget < opening) {
                    bought = bought + (lot to payable)
                    budget -= payable
                    grantHiddenPlayer(lot.position, toUser = false)
                    message = uiText("كسبت المزاد! اللاعب بقى معاك مقابل $payable مليون 👑", "You won the auction! Player added for $payable M 👑")
                    sound.play(Sfx.Correct)
                    advanceRound(userCount = bought.size + 1)
                } else {
                    aiBought = aiBought + (lot to aiMax)
                    aiBudget -= aiMax
                    grantHiddenPlayer(lot.position, toUser = true)
                    message = uiText("الخصم زايد عليك وخد اللاعب مقابل $aiMax مليون", "AI outbid you and bought the player for $aiMax M")
                    sound.play(Sfx.Wrong)
                    advanceRound(aiCount = aiBought.size + 1)
                }
                sound.vibrate(20)
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(uiText("ثبّت المزايدة", "Confirm bid"), fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = {
                val opening = (lot.rating / 14).coerceAtLeast(5)
                val aiMax = if (aiBought.size >= targetCount) 0 else auctionAiBidCeiling(lot.rating, opening, aiBudget, aiDifficulty)
                if (aiMax > 0 && aiBought.size < targetCount) {
                    val paid = minOf(aiBudget, aiMax)
                    aiBought = aiBought + (lot to paid)
                    aiBudget -= paid
                    grantHiddenPlayer(lot.position, toUser = true)
                    message = uiText("عدّيت الجولة والخصم أخذ اللاعب", "You passed; AI bought the player")
                    advanceRound(aiCount = aiBought.size + 1)
                } else {
                    message = uiText("اللاعب لم يُشترَ", "Player went unsold")
                    advanceRound()
                }
                sound.play(Sfx.Click)
            }, modifier = Modifier.fillMaxWidth()) { Text(uiText("Pass / تخطي", "Pass"), color = Cream) }
            if (message.isNotBlank()) Text(message, color = Cream, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(uiText("فريقك حتى الآن", "Your squad so far"), color = Cream, fontWeight = FontWeight.Bold)
            bought.forEach { (p, price) -> PlayerLine(p, "${p.rating} OVR • $price M") }
        }
    }
}

@Composable
fun DealOrNoDealScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var round by remember { mutableIntStateOf(1) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var phase by remember { mutableStateOf("choose") }
    var first by remember { mutableStateOf<PlayerCard?>(null) }
    var second by remember { mutableStateOf<PlayerCard?>(null) }
    var firstBoxIndex by remember { mutableIntStateOf(-1) }
    var secondBoxIndex by remember { mutableIntStateOf(-1) }
    var team by remember { mutableStateOf(listOf<PlayerCard>()) }
    var aiTeam by remember { mutableStateOf(listOf<PlayerCard>()) }
    var boxes by remember { mutableStateOf(PlayerDatabase.players.shuffled().take(4)) }
    var status by remember { mutableStateOf("") }
    var bankOffer by remember { mutableStateOf(false) }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var matchResult by remember { mutableStateOf<MatchScore?>(null) }
    val done = round > 5
    fun draftAiPlayer(excluded: List<PlayerCard>) {
        val blocked = (excluded + aiTeam).map { it.nameEn }.toSet()
        val candidates = PlayerDatabase.players.filterNot { it.nameEn in blocked }
        if (candidates.isEmpty()) return
        val aiIsBehind = aiTeam.sumOf { it.rating } < team.sumOf { it.rating }
        val baseFocus = when (aiDifficulty) { 0 -> 0.78; 1 -> 0.60; 2 -> 0.40; else -> 0.24 }
        val focusRatio = (baseFocus + if (aiIsBehind) -0.10 else 0.08).coerceIn(0.15, 0.90)
        val focusSize = (candidates.size * focusRatio).toInt().coerceAtLeast(1)
        val choice = candidates.sortedByDescending { it.rating }.take(focusSize).randomOrNull()
        if (choice != null) aiTeam = aiTeam + choice
    }
    val userRating = team.sumOf { it.rating }
    val aiRating = aiTeam.sumOf { it.rating }
    LaunchedEffect(done) {
        if (done) {
            val result = matchResult ?: MatchEngine.simulate(team, aiTeam).also {
                matchResult = it
            }
            sound.play(if (result.userWon) Sfx.Win else Sfx.Wrong)
            if (!scoreSubmitted) {
                scoreSubmitted = true
                if (ElbashaAccess.isDeveloper(user.uid)) {
                    saveStatus = uiText("حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
                } else {
                    val matchBonus = when {
                        result.userWon -> 1_000
                        result.isDraw -> 500
                        else -> 0
                    }
                    ScoreRepository.submit(database, user, userRating * 10 + matchBonus) { saved ->
                        saveStatus = if (saved) uiText("تم حفظ نقاط اللعبة", "Game score saved")
                        else uiText("تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                    }
                }
            }
        }
    }
    BackHandler { onExit() }
    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }
    Column(Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }; Spacer(Modifier.weight(1f)); SoundToggles(sound) }
        Text(uiText("🎁 Deal or No Deal", "🎁 Deal or No Deal"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        if (round == 1 && phase == "choose" && team.isEmpty() && aiTeam.isEmpty()) {
            Text(uiText("مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                AiDifficultyAr.indices.forEach { level ->
                    val selectedLevel = aiDifficulty == level
                    Card(Modifier.weight(1f).clickable { aiDifficulty = level }, colors = CardDefaults.cardColors(containerColor = if (selectedLevel) Gold else PanelColor), shape = RoundedCornerShape(10.dp)) {
                        Text(if (english) AiDifficultyEn[level] else AiDifficultyAr[level], color = if (selectedLevel) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                    }
                }
            }
        }
        Text(uiText("الجولة $round من 5", "Round $round of 5"), color = Cream)
        if (done) {
            Text(uiText("🏆 نتيجة Deal or No Deal", "🏆 Deal or No Deal result"), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiText("فريقك", "Your team"), color = Cream)
                        Text("$userRating", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiText("فريق AI", "AI team"), color = Cream)
                        Text("$aiRating", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp)
            Text(uiText("نتيجة المباراة المحاكاة", "Simulated match result"), color = Cream, fontWeight = FontWeight.Bold)
            Text(matchResult?.let { "${it.userGoals}  -  ${it.opponentGoals}" } ?: uiText("جاري المحاكاة…", "Simulating…"), color = Gold, fontSize = 35.sp, fontWeight = FontWeight.Black)
            Text(when {
                matchResult == null -> uiText("جاري تجهيز النتيجة", "Preparing result")
                matchResult!!.userWon -> uiText("👑 كسبت المباراة!", "👑 You won the match!")
                matchResult!!.opponentWon -> uiText("الذكاء الاصطناعي كسب المباراة", "The AI won the match")
                else -> uiText("المباراة انتهت بالتعادل", "The match ended in a draw")
            }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(uiText("تشكيلتك", "Your squad"), color = Cream, fontWeight = FontWeight.Bold)
            team.forEach { PlayerLine(it, "${it.rating} OVR") }
            Text(uiText("تشكيلة الخصم", "AI squad"), color = Cream, fontWeight = FontWeight.Bold)
            aiTeam.forEach { PlayerLine(it, "${it.rating} OVR") }
            Button(onClick = { round = 1; phase = "choose"; team = emptyList(); aiTeam = emptyList(); scoreSubmitted = false; saveStatus = ""; matchResult = null; first = null; second = null; firstBoxIndex = -1; secondBoxIndex = -1; boxes = PlayerDatabase.players.shuffled().take(4); status = ""; bankOffer = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(uiText("جولة جديدة", "New game")) }
        } else {
            Text(when (phase) { "choose" -> uiText("اختار صندوقًا من الأربعة", "Choose one of the four boxes"); "decision" -> uiText("تقبل اللاعب ولا تخاطر؟", "Deal or take a risk?"); else -> uiText("الصندوق الثاني إجباري", "The second box is mandatory") }, color = Cream, fontWeight = FontWeight.Bold)
            if (phase == "choose") {
                boxes.forEachIndexed { index, player ->
                    Card(Modifier.fillMaxWidth().clickable { first = player; firstBoxIndex = index; phase = "decision"; status = ""; bankOffer = Random.nextInt(100) < 28 }, colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) { Text("📦  ${uiText("الصندوق", "Box")} ${index + 1}", color = Cream, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("?", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black) }
                    }
                }
            } else if (phase == "decision") {
                first?.let { PlayerReveal(it, english) }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { first?.let { chosen -> team = team + chosen; draftAiPlayer(team) }; round++; phase = "choose"; boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4); first = null; second = null; firstBoxIndex = -1; secondBoxIndex = -1; sound.play(Sfx.Correct) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(uiText("Deal", "Deal")) }
                    OutlinedButton(onClick = { phase = "second" }, modifier = Modifier.weight(1f)) { Text(uiText("No Deal", "No Deal"), color = Cream) }
                }
                if (bankOffer) {
                    Card(colors = CardDefaults.cardColors(containerColor = Gold), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(uiText("🏦 عرض البنك ظهر!", "🏦 The bank has an offer!"), color = DeepWine, fontWeight = FontWeight.Black)
                            Text(uiText("اقبل وخد اللاعب المكشوف ولاعب الصندوق الثاني معًا، من غير ما تعرفه قبل الموافقة.", "Accept both the revealed player and one hidden second-box player."), color = DeepWine, fontSize = 12.sp)
                            Button(onClick = {
                                val hiddenIndex = boxes.indices.filter { it != firstBoxIndex }.randomOrNull()
                                val hidden = hiddenIndex?.let(boxes::getOrNull)
                                team = team + listOfNotNull(first, hidden)
                                draftAiPlayer(team)
                                round++
                                phase = "choose"
                                first = null
                                second = null
                                firstBoxIndex = -1
                                secondBoxIndex = -1
                                bankOffer = false
                                boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4)
                                status = uiText("قبلت عرض البنك وحصلت على لاعبين", "Bank deal accepted: two players added")
                                sound.play(Sfx.Correct)
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = DeepWine, contentColor = Gold)) {
                                Text(uiText("اقبل عرض البنك", "Accept bank deal"))
                            }
                        }
                    }
                } else {
                    Text(uiText("عرض البنك ممكن يظهر في بعض الأدوار", "The bank may make an offer in some rounds"), color = Muted, fontSize = 12.sp)
                }
            } else if (phase == "second") {
                Text(uiText("اختار صندوقًا ثانيًا، ولازم تاخد واحد من اللاعبين", "Choose a second box. You must keep one of the two players."), color = Muted)
                boxes.forEachIndexed { index, player ->
                    if (index != firstBoxIndex) {
                        Card(Modifier.fillMaxWidth().clickable { second = player; secondBoxIndex = index; phase = "select" }, colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                            Text("📦  ${uiText("الصندوق", "Box")} ${index + 1}", color = Cream, modifier = Modifier.padding(16.dp))
                        }
                    }
                }
            }
            if (phase == "select") {
                first?.let { PlayerReveal(it, english) }
                second?.let { PlayerReveal(it, english) }
                Text(uiText("اختار اللاعب اللي هتحتفظ بيه", "Choose the player to keep"), color = Gold, fontWeight = FontWeight.Bold)
                listOfNotNull(first, second).forEach { player ->
                    OutlinedButton(onClick = { team = team + player; draftAiPlayer(team); round++; phase = "choose"; first = null; second = null; firstBoxIndex = -1; secondBoxIndex = -1; boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4); status = uiText("تم ضم اللاعب لفريقك", "Player added to your team") }, modifier = Modifier.fillMaxWidth()) { Text("${if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr)} • ${player.rating}", color = Cream) }
                }
            }
            if (status.isNotBlank()) Text(status, color = Gold)
            Text(uiText("فريقك: ${team.size} لاعب", "Your squad: ${team.size} players"), color = Cream)
            team.forEach { PlayerLine(it, "${it.rating} OVR") }
        }
    }
}

@Composable
private fun PlayerLine(player: PlayerCard, detail: String) {
    val english = LocalAppUiSettings.current.english
    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${player.rating}", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr} • ${player.position}", color = Muted, fontSize = 11.sp)
            }
            Text(detail, color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp, textAlign = TextAlign.End)
        }
    }
}

@Composable
private fun PlayerReveal(player: PlayerCard, english: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("⭐ ${player.rating} OVR", color = Gold, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr} • ${player.position}", color = Muted)
        }
    }
}
