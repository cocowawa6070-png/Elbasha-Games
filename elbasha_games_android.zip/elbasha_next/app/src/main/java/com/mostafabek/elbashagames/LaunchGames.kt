package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import kotlin.random.Random

private data class AuctionLot(val player: PlayerCard, val opening: Int)

private fun auctionAiBidCeiling(rating: Int, opening: Int, budget: Int, difficulty: Int): Int {
    if (budget < opening) return 0
    val passChance = when (difficulty) { 0 -> 24; 1 -> 13; 2 -> 6; else -> 2 }
    if (rating < 93 && Random.nextInt(100) < passChance) return 0
    val divisor = when (difficulty) { 0 -> 18; 1 -> 15; 2 -> 13; else -> 11 }
    val randomRange = when (difficulty) { 0 -> 2; 1 -> 3; 2 -> 4; else -> 5 }
    val strategicCeiling = opening + (rating / divisor) + Random.nextInt(0, randomRange + 1)
    return minOf(budget, strategicCeiling)
}

private val AiDifficultyAr = listOf("سهل", "متوازن", "صعب", "صعب جدًا")
private val AiDifficultyEn = listOf("Easy", "Balanced", "Hard", "Very hard")

@Composable
fun AuctionGameScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var pro by remember { mutableStateOf(false) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var started by remember { mutableStateOf(false) }
    var budget by remember { mutableIntStateOf(100) }
    var aiBudget by remember { mutableIntStateOf(100) }
    var bought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var aiBought by remember { mutableStateOf(listOf<Pair<PlayerCard, Int>>()) }
    var hiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var aiHiddenPlayers by remember { mutableStateOf(listOf<PlayerCard>()) }
    var remainingLots by remember { mutableStateOf(emptyList<PlayerCard>()) }
    var bid by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var ended by remember { mutableStateOf(false) }
    var lastBidUsed by remember { mutableStateOf(false) }
    var wildCardUsed by remember { mutableStateOf(false) }
    var randomSwapUsed by remember { mutableStateOf(false) }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var matchResult by remember { mutableStateOf<MatchScore?>(null) }
    val targetCount = if (pro) 11 else 5
    val startBudget = if (pro) 200 else 100
    val pool = remember(pro, started) {
        PlayerDatabase.players.shuffled().take(if (pro) 42 else 24)
    }
    val lot = remainingLots.firstOrNull()
    val userRating = bought.sumOf { it.first.rating } + hiddenPlayers.sumOf { it.rating }
    val aiRating = aiBought.sumOf { it.first.rating } + aiHiddenPlayers.sumOf { it.rating }
    val userSquad = bought.map { it.first } + hiddenPlayers
    val aiSquad = aiBought.map { it.first } + aiHiddenPlayers
    val userCoachBonus = (budget.toDouble() / startBudget * 6.0).coerceIn(0.0, 6.0)
    val aiCoachBonus = (aiBudget.toDouble() / startBudget * 6.0).coerceIn(0.0, 6.0)

    LaunchedEffect(ended) {
        if (ended) {
            val result = matchResult ?: MatchEngine.simulate(userSquad, aiSquad, userCoachBonus, aiCoachBonus).also {
                matchResult = it
            }
            sound.play(if (result.userWon) Sfx.Win else Sfx.Wrong)
            if (!scoreSubmitted) {
                scoreSubmitted = true
                if (ElbashaAccess.isDeveloper(user.uid)) {
                    saveStatus = localizedText(english, "حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
                } else {
                    val matchBonus = when {
                        result.userWon -> 1_000
                        result.isDraw -> 500
                        else -> 0
                    }
                    ScoreRepository.submit(database, user, userRating * 10 + matchBonus) { saved ->
                        saveStatus = if (saved) localizedText(english, "تم حفظ نقاط المزاد", "Auction score saved")
                        else localizedText(english, "تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                    }
                }
            }
        }
    }

    fun grantHiddenPlayer(position: String, toUser: Boolean) {
        val alreadyUsed = (bought.map { it.first } + aiBought.map { it.first } + hiddenPlayers + aiHiddenPlayers)
            .map { it.nameEn }.toSet()
        val hidden = PlayerDatabase.players
            .filter { it.position == position && it.nameEn !in alreadyUsed }
            .randomOrNull() ?: return
        // A bonus player must not appear again as a later auction lot.
        remainingLots = remainingLots.filterNot { it.nameEn == hidden.nameEn }
        if (toUser) hiddenPlayers = hiddenPlayers + hidden else aiHiddenPlayers = aiHiddenPlayers + hidden
    }

    fun advanceRound(userCount: Int = bought.size, aiCount: Int = aiBought.size) {
        remainingLots = remainingLots.drop(1)
        bid = 0
        if (userCount >= targetCount || aiCount >= targetCount || remainingLots.isEmpty()) ended = true
    }

    BackHandler { onExit() }
    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }
    Column(Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f)); SoundToggles(sound)
        }
        Text(localizedText(english, "🔨 المزاد الكروي", "🔨 Football Auction"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
        if (!started) {
            HowToPlayCard(
                title = localizedText(english, "إزاي تكسب المزاد؟", "How to win the auction"),
                steps = if (english) listOf(
                    "Choose Classic (5 players / 100M) or Pro Max (11 players / 200M).",
                    "A player card appears with a starting price. Raise your bid by 1M, 5M or 10M.",
                    "Use Last Bid to add 3M once, Wild Card for 2M off a winning price, or Random Swap to replace one squad player for free.",
                    "Confirm your bid to face the AI, or Pass and let the round move on.",
                    "The higher bid wins. The losing side gets a hidden free player in the same position.",
                    "When squads are complete, a simulated match decides the winner. Remaining budget adds a coach bonus."
                ) else listOf(
                    "اختار كلاسيك: 5 لاعبين و100 مليون، أو Pro Max: 11 لاعب و200 مليون.",
                    "هتظهر بطاقة لاعب بسعر افتتاحي. زوّد مزايدتك بمليون أو 5 أو 10 مليون.",
                    "Last Bid يزوّد 3 مليون مرة واحدة، وWild Card يخصم 2 مليون لو كسبت، وRandom Swap يبدّل لاعبًا من تشكيلتك مجانًا.",
                    "اضغط تثبيت المزايدة لمواجهة الـAI، أو Pass عشان تعدّي الجولة.",
                    "أعلى مزايدة تكسب اللاعب. الطرف الخاسر ياخد لاعب مخفي مجاني من نفس المركز.",
                    "بعد اكتمال التشكيلتين، مباراة محاكاة تحدد الفائز. الفلوس المتبقية بتدي مكافأة للمدرب."
                ),
                note = localizedText(english, "خلي بالك: ممنوع تتخطى ميزانيتك، واللاعب المخفي مش هيظهر غير في النتيجة.", "Stay within your budget. Hidden bonus players are revealed only in the final results.")
            )
            Text(localizedText(english, "اختار نظام المزاد", "Choose auction mode"), color = Cream, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(false, true).forEach { mode ->
                    Card(Modifier.weight(1f).clickable { pro = mode }, colors = CardDefaults.cardColors(containerColor = if (pro == mode) Gold else PanelColor)) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(if (mode) "PRO MAX" else "CLASSIC", color = if (pro == mode) DeepWine else Cream, fontWeight = FontWeight.Black)
                            Text(if (mode) "11 ${localizedText(english, "لاعبًا", "players")} • 200M" else "5 ${localizedText(english, "لاعبين", "players")} • 100M", color = if (pro == mode) DeepWine else Muted)
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(localizedText(english, "منافسة ضد الذكاء الاصطناعي", "Play against AI"), color = Cream, fontWeight = FontWeight.Bold)
                    Text(localizedText(english, "كل لاعب يدخل المزاد مرة واحدة. راقب ميزانيتك، والخصم يزايد وفق تقييم اللاعب وميزانيته ومستوى الصعوبة.", "You bid against an AI rival. It considers player rating, remaining budget and difficulty."), color = Muted, fontSize = 12.sp)
                }
            }
            Text(localizedText(english, "مستوى AI", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                AiDifficultyAr.indices.forEach { level ->
                    val selected = aiDifficulty == level
                    Card(Modifier.weight(1f).clickable { aiDifficulty = level }, colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor), shape = RoundedCornerShape(10.dp)) {
                        Text(if (english) AiDifficultyEn[level] else AiDifficultyAr[level], color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                    }
                }
            }
            Button(onClick = {
                started = true
                budget = startBudget
                aiBudget = startBudget
                bought = emptyList()
                aiBought = emptyList()
                hiddenPlayers = emptyList()
                aiHiddenPlayers = emptyList()
                remainingLots = pool
                bid = 0
                ended = false
                message = ""
                lastBidUsed = false
                wildCardUsed = false
                randomSwapUsed = false
                scoreSubmitted = false
                saveStatus = ""
                matchResult = null
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine), modifier = Modifier.fillMaxWidth()) {
                Text(localizedText(english, "ابدأ المزاد", "Start auction"))
            }
        } else if (ended || bought.size >= targetCount || lot == null) {
            Text(localizedText(english, "🏆 انتهى المزاد", "🏆 Auction complete"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(localizedText(english, "نتيجة المنافسة", "Match result"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريقك", "Your team"), color = Cream)
                        Text("$userRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${bought.size}/$targetCount", color = Muted)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "الخصم AI", "AI rival"), color = Cream)
                        Text("$aiRating", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("${aiBought.size}/$targetCount", color = Muted)
                    }
                }
            }
            Text(localizedText(english, "نتيجة المباراة المحاكاة", "Simulated match result"), color = Cream, fontWeight = FontWeight.Bold)
            Text(
                matchResult?.let { "${it.userGoals}  -  ${it.opponentGoals}" } ?: localizedText(english, "جاري محاكاة المباراة…", "Simulating match…"),
                color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Black
            )
            Text(
                when {
                    matchResult == null -> localizedText(english, "جاري تجهيز النتيجة", "Preparing result")
                    matchResult!!.userWon -> localizedText(english, "👑 كسبت المباراة!", "👑 You won the match!")
                    matchResult!!.opponentWon -> localizedText(english, "الخصم كسب المباراة.", "The AI won the match.")
                    else -> localizedText(english, "المباراة انتهت بالتعادل.", "The match ended in a draw.")
                }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Text(localizedText(english, "قوة الفريق: $userRating مقابل $aiRating • مكافأة المدرب حسب الرصيد المتبقي", "Squad rating: $userRating vs $aiRating • Coach bonus is based on remaining budget"), color = Muted, fontSize = 11.sp)
            Text(localizedText(english, "ميزانيتك المتبقية: $budget مليون", "Your remaining budget: $budget M"), color = Cream)
            Text(localizedText(english, "ميزانية الخصم المتبقية: $aiBudget مليون", "AI remaining budget: $aiBudget M"), color = Muted)
            Text(saveStatus.ifBlank { localizedText(english, "جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp)
            Text(localizedText(english, "تشكيلتك", "Your squad"), color = Cream, fontWeight = FontWeight.Bold)
            bought.forEach { (p, price) -> PlayerLine(p, "${p.rating} OVR • $price M") }
            if (hiddenPlayers.isNotEmpty()) {
                Text(localizedText(english, "🎁 اللاعبون المخفيون اللي كسبتهم", "🎁 Your hidden bonus players"), color = Gold, fontWeight = FontWeight.Bold)
                hiddenPlayers.forEach { PlayerLine(it, localizedText(english, "هدية مجانية", "Free hidden bonus")) }
            }
            if (aiHiddenPlayers.isNotEmpty()) {
                Text(localizedText(english, "اللاعبون المخفيون للخصم", "AI hidden bonus players"), color = Muted, fontWeight = FontWeight.Bold)
                aiHiddenPlayers.forEach { PlayerLine(it, localizedText(english, "هدية مجانية", "Free hidden bonus")) }
            }
            Button(onClick = { started = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(localizedText(english, "العب من جديد", "Play again"))
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${localizedText(english, "لاعب", "Player")} ${bought.size + 1}/$targetCount", color = Cream)
                Text("💰 $budget M", color = Gold, fontWeight = FontWeight.Black)
            }
            Text(localizedText(english, "الخصم: ${aiBought.size} لاعب • $aiBudget مليون", "AI: ${aiBought.size} players • $aiBudget M"), color = Muted, fontSize = 12.sp)
            LinearProgressIndicator(progress = { bought.size.toFloat() / targetCount }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor)
            val openingPrice = (lot.rating / 14).coerceAtLeast(5)
            PremiumPlayerCard(
                player = lot,
                detail = localizedText(english, "سعر البداية: $openingPrice مليون", "Starting bid: $openingPrice M"),
                eyebrow = localizedText(english, "بطاقة اللاعب المعروض", "PLAYER ON THE BLOCK")
            )
            Text(localizedText(english, "مزايدتك الحالية: $bid مليون", "Your current bid: $bid M"), color = Gold, fontWeight = FontWeight.Bold)
            Text(
                localizedText(english, "زوّد المبلغ من الأزرار، استخدم البطاقة المناسبة لو محتاج، وبعدها ثبّت المزايدة أو اعمل Pass.", "Use the bid buttons, activate a card if needed, then confirm your bid or Pass."),
                color = Muted, fontSize = 11.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 5, 10).forEach { increment ->
                    OutlinedButton(onClick = {
                        if (bid + increment <= budget) bid += increment
                        else message = localizedText(english, "ميزانيتك مش مكفية للمزايدة دي", "Not enough budget for this bid")
                    }, modifier = Modifier.weight(1f)) { Text("+$increment M", color = Cream) }
                }
            }
            Text(localizedText(english, "بطاقاتك الخاصة", "YOUR SPECIAL CARDS"), color = Cream, fontWeight = FontWeight.Black, fontSize = 12.sp)
            PremiumAbilityCard(
                symbol = "⚡",
                title = "Last Bid",
                description = localizedText(english, "زوّد مزايدتك الحالية 3 مليون مرة واحدة.", "Add 3M to your current bid once."),
                status = when {
                    lastBidUsed -> localizedText(english, "مستخدمة", "USED")
                    bid + 3 > budget -> localizedText(english, "الرصيد لا يكفي", "LOW BUDGET")
                    else -> localizedText(english, "متاحة", "READY")
                },
                enabled = !lastBidUsed && bid + 3 <= budget
            ) {
                if (!lastBidUsed && bid + 3 <= budget) {
                    bid += 3
                    lastBidUsed = true
                    message = localizedText(english, "كارت Last Bid زوّد مزايدتك 3 مليون", "Last Bid card added 3M")
                }
            }
            PremiumAbilityCard(
                symbol = "🃏",
                title = "Wild Card",
                description = localizedText(english, "لو كسبت، اخصم 2 مليون من السعر النهائي، من غير النزول عن سعر البداية.", "If you win, take 2M off the final price, never below the opening bid."),
                status = if (wildCardUsed) localizedText(english, "مفعّلة", "ACTIVE") else localizedText(english, "متاحة", "READY"),
                enabled = !wildCardUsed
            ) {
                if (!wildCardUsed) {
                    wildCardUsed = true
                    message = localizedText(english, "Wild Card اتفعل: خصم 2 مليون من السعر النهائي عند الفوز.", "Wild Card active: 2M off your final winning price.")
                }
            }
            PremiumAbilityCard(
                symbol = "🔁",
                title = localizedText(english, "Random Swap", "Random Swap"),
                description = localizedText(english, "بدّل لاعبًا عشوائيًا من تشكيلتك بلاعب آخر من نفس المركز مجانًا، من غير تغيير المبلغ المدفوع.", "Replace one random player in your squad with another from the same position for free. Your paid price stays unchanged."),
                status = when {
                    randomSwapUsed -> localizedText(english, "مستخدمة", "USED")
                    bought.isEmpty() -> localizedText(english, "بعد أول لاعب", "AFTER FIRST PICK")
                    else -> localizedText(english, "متاحة", "READY")
                },
                enabled = !randomSwapUsed && bought.isNotEmpty()
            ) {
                if (!randomSwapUsed && bought.isNotEmpty()) {
                    val swapIndex = bought.indices.randomOrNull()
                    val oldEntry = swapIndex?.let(bought::getOrNull)
                    val ownedNames = (userSquad + aiSquad).map { it.nameEn }.toSet()
                    val replacement = oldEntry?.let { entry ->
                        PlayerDatabase.players.filter { candidate ->
                            candidate.position == entry.first.position &&
                                candidate.nameEn !in ownedNames &&
                                candidate.nameEn != lot.nameEn
                        }.randomOrNull()
                    }
                    if (swapIndex != null && oldEntry != null && replacement != null) {
                        bought = bought.toMutableList().also { it[swapIndex] = replacement to oldEntry.second }
                        remainingLots = remainingLots.filterNot { it.nameEn == replacement.nameEn } + oldEntry.first
                        randomSwapUsed = true
                        message = localizedText(english, "تم التبديل مجانًا: ${oldEntry.first.nameAr} ← ${replacement.nameAr}", "Free swap complete: ${oldEntry.first.nameEn} → ${replacement.nameEn}")
                        sound.play(Sfx.Correct)
                    } else {
                        message = localizedText(english, "مفيش لاعب بديل مناسب حاليًا.", "No eligible replacement is available right now.")
                    }
                }
            }
            Button(onClick = {
                val opening = (lot.rating / 14).coerceAtLeast(5)
                val aiMax = if (aiBought.size >= targetCount) 0 else auctionAiBidCeiling(lot.rating, opening, aiBudget, aiDifficulty)
                val payable = if (wildCardUsed) (bid - 2).coerceAtLeast(opening) else bid
                if (bid < opening) {
                    message = localizedText(english, "مزايدتك أقل من السعر الافتتاحي", "Your bid is below the opening price")
                } else if (payable > budget) {
                    message = localizedText(english, "ميزانيتك لا تكفي بعد تطبيق الكارت", "Your budget cannot cover the final price")
                } else if (bid >= aiMax || aiBudget < opening) {
                    bought = bought + (lot to payable)
                    budget -= payable
                    grantHiddenPlayer(lot.position, toUser = false)
                    message = localizedText(english, "كسبت المزاد! اللاعب بقى معاك مقابل $payable مليون 👑", "You won the auction! Player added for $payable M 👑")
                    sound.play(Sfx.Correct)
                    advanceRound()
                } else {
                    aiBought = aiBought + (lot to aiMax)
                    aiBudget -= aiMax
                    grantHiddenPlayer(lot.position, toUser = true)
                    message = localizedText(english, "الخصم زايد عليك وخد اللاعب مقابل $aiMax مليون", "AI outbid you and bought the player for $aiMax M")
                    sound.play(Sfx.Wrong)
                    advanceRound()
                }
                sound.vibrate(20)
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                Text(localizedText(english, "ثبّت المزايدة", "Confirm bid"), fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = {
                val opening = (lot.rating / 14).coerceAtLeast(5)
                val aiMax = if (aiBought.size >= targetCount) 0 else auctionAiBidCeiling(lot.rating, opening, aiBudget, aiDifficulty)
                if (aiMax > 0 && aiBought.size < targetCount) {
                    val paid = minOf(aiBudget, aiMax)
                    aiBought = aiBought + (lot to paid)
                    aiBudget -= paid
                    grantHiddenPlayer(lot.position, toUser = true)
                    message = localizedText(english, "عدّيت الجولة والخصم أخذ اللاعب", "You passed; AI bought the player")
                    advanceRound()
                } else {
                    message = localizedText(english, "اللاعب لم يُشترَ", "Player went unsold")
                    advanceRound()
                }
                sound.play(Sfx.Click)
            }, modifier = Modifier.fillMaxWidth()) { Text(localizedText(english, "Pass / تخطي", "Pass"), color = Cream) }
            if (message.isNotBlank()) Text(message, color = Cream, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(localizedText(english, "فريقك حتى الآن", "Your squad so far"), color = Cream, fontWeight = FontWeight.Bold)
            bought.forEach { (p, price) -> PlayerLine(p, "${p.rating} OVR • $price M") }
        }
    }
}

@Composable
fun DealOrNoDealScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var round by remember { mutableIntStateOf(1) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var phase by remember { mutableStateOf("choose") }
    var first by remember { mutableStateOf<PlayerCard?>(null) }
    var second by remember { mutableStateOf<PlayerCard?>(null) }
    var firstBoxIndex by remember { mutableIntStateOf(-1) }
    var secondBoxIndex by remember { mutableIntStateOf(-1) }
    var team by remember { mutableStateOf(listOf<PlayerCard>()) }
    var aiTeam by remember { mutableStateOf(listOf<PlayerCard>()) }
    var boxes by remember { mutableStateOf(PlayerDatabase.players.shuffled().take(4)) }
    var status by remember { mutableStateOf("") }
    var bankOffer by remember { mutableStateOf(false) }
    var scoreSubmitted by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var matchResult by remember { mutableStateOf<MatchScore?>(null) }
    val done = round > 5
    fun draftAiPlayer(excluded: List<PlayerCard>) {
        val blocked = (excluded + aiTeam).map { it.nameEn }.toSet()
        val candidates = PlayerDatabase.players.filterNot { it.nameEn in blocked }
        if (candidates.isEmpty()) return
        val aiIsBehind = aiTeam.sumOf { it.rating } < team.sumOf { it.rating }
        val baseFocus = when (aiDifficulty) { 0 -> 0.78; 1 -> 0.60; 2 -> 0.40; else -> 0.24 }
        val focusRatio = (baseFocus + if (aiIsBehind) -0.10 else 0.08).coerceIn(0.15, 0.90)
        val focusSize = (candidates.size * focusRatio).toInt().coerceAtLeast(1)
        val choice = candidates.sortedByDescending { it.rating }.take(focusSize).randomOrNull()
        if (choice != null) aiTeam = aiTeam + choice
    }
    val userRating = team.sumOf { it.rating }
    val aiRating = aiTeam.sumOf { it.rating }
    LaunchedEffect(done) {
        if (done) {
            val result = matchResult ?: MatchEngine.simulate(team, aiTeam).also {
                matchResult = it
            }
            sound.play(if (result.userWon) Sfx.Win else Sfx.Wrong)
            if (!scoreSubmitted) {
                scoreSubmitted = true
                if (ElbashaAccess.isDeveloper(user.uid)) {
                    saveStatus = localizedText(english, "حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
                } else {
                    val matchBonus = when {
                        result.userWon -> 1_000
                        result.isDraw -> 500
                        else -> 0
                    }
                    ScoreRepository.submit(database, user, userRating * 10 + matchBonus) { saved ->
                        saveStatus = if (saved) localizedText(english, "تم حفظ نقاط اللعبة", "Game score saved")
                        else localizedText(english, "تعذر حفظ النقاط. راجع اتصال Firebase.", "Could not save score. Check Firebase.")
                    }
                }
            }
        }
    }
    BackHandler { onExit() }
    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }
    Column(Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }; Spacer(Modifier.weight(1f)); SoundToggles(sound) }
        Text(localizedText(english, "🎁 Deal or No Deal", "🎁 Deal or No Deal"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        if (round == 1 && phase == "choose" && team.isEmpty() && aiTeam.isEmpty()) {
            HowToPlayCard(
                title = localizedText(english, "قواعد الصناديق ببساطة", "How the box game works"),
                steps = if (english) listOf(
                    "Choose one of four sealed boxes. Its player is revealed.",
                    "Deal: keep the revealed player and move to the next round.",
                    "No Deal: open a second box, then you must keep exactly one of the two revealed players.",
                    "Sometimes the Bank offers both the revealed player and a random unopened box. Accepting takes both.",
                    "After five rounds, your squad faces the AI in a simulated match."
                ) else listOf(
                    "اختار صندوق واحد من أربعة، وبعدها اللاعب اللي جواه هيظهر.",
                    "Deal: توافق وتضم اللاعب المكشوف لفريقك وتنتقل للجولة اللي بعدها.",
                    "No Deal: تفتح صندوق تاني، وبعدها لازم تختار لاعب واحد من الاتنين تحتفظ بيه.",
                    "أحيانًا البنك يعرض عليك اللاعب المكشوف ومعاه لاعب صندوق تاني عشوائي. قبول العرض يديك الاتنين.",
                    "بعد 5 جولات، فريقك يواجه فريق الـAI في مباراة محاكاة."
                ),
                note = localizedText(english, "الصناديق بتحتوي على لاعبين من قاعدة اللعبة. اختيارك بيحدد فريقك، مش مجرد نقاط حظ.", "Boxes contain players from the game database. Your choices build the squad, not just a score.")
            )
            Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                AiDifficultyAr.indices.forEach { level ->
                    val selectedLevel = aiDifficulty == level
                    Card(Modifier.weight(1f).clickable { aiDifficulty = level }, colors = CardDefaults.cardColors(containerColor = if (selectedLevel) Gold else PanelColor), shape = RoundedCornerShape(10.dp)) {
                        Text(if (english) AiDifficultyEn[level] else AiDifficultyAr[level], color = if (selectedLevel) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                    }
                }
            }
        }
        Text(
            if (done) localizedText(english, "اكتملت الجولات الخمس", "All five rounds completed")
            else localizedText(english, "الجولة $round من 5", "Round $round of 5"),
            color = Cream
        )
        if (done) {
            Text(localizedText(english, "🏆 نتيجة Deal or No Deal", "🏆 Deal or No Deal result"), color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريقك", "Your team"), color = Cream)
                        Text("$userRating", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(localizedText(english, "فريق AI", "AI team"), color = Cream)
                        Text("$aiRating", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Text(saveStatus.ifBlank { localizedText(english, "جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp)
            Text(localizedText(english, "نتيجة المباراة المحاكاة", "Simulated match result"), color = Cream, fontWeight = FontWeight.Bold)
            Text(matchResult?.let { "${it.userGoals}  -  ${it.opponentGoals}" } ?: localizedText(english, "جاري المحاكاة…", "Simulating…"), color = Gold, fontSize = 35.sp, fontWeight = FontWeight.Black)
            Text(when {
                matchResult == null -> localizedText(english, "جاري تجهيز النتيجة", "Preparing result")
                matchResult!!.userWon -> localizedText(english, "👑 كسبت المباراة!", "👑 You won the match!")
                matchResult!!.opponentWon -> localizedText(english, "الذكاء الاصطناعي كسب المباراة", "The AI won the match")
                else -> localizedText(english, "المباراة انتهت بالتعادل", "The match ended in a draw")
            }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(localizedText(english, "تشكيلتك", "Your squad"), color = Cream, fontWeight = FontWeight.Bold)
            team.forEach { PlayerLine(it, "${it.rating} OVR") }
            Text(localizedText(english, "تشكيلة الخصم", "AI squad"), color = Cream, fontWeight = FontWeight.Bold)
            aiTeam.forEach { PlayerLine(it, "${it.rating} OVR") }
            Button(onClick = { round = 1; phase = "choose"; team = emptyList(); aiTeam = emptyList(); scoreSubmitted = false; saveStatus = ""; matchResult = null; first = null; second = null; firstBoxIndex = -1; secondBoxIndex = -1; boxes = PlayerDatabase.players.shuffled().take(4); status = ""; bankOffer = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) { Text(localizedText(english, "جولة جديدة", "New game")) }
        } else {
            Text(when (phase) { "choose" -> localizedText(english, "اختار صندوقًا من الأربعة", "Choose one of the four boxes"); "decision" -> localizedText(english, "تقبل اللاعب ولا تخاطر؟", "Deal or take a risk?"); else -> localizedText(english, "الصندوق الثاني إجباري", "The second box is mandatory") }, color = Cream, fontWeight = FontWeight.Bold)
            if (phase == "choose") {
                boxes.chunked(2).forEachIndexed { rowIndex, pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEachIndexed { itemIndex, _ ->
                            val index = rowIndex * 2 + itemIndex
                            Box(Modifier.weight(1f)) {
                                MysteryBoxCard(index = index + 1, label = localizedText(english, "الصندوق", "BOX")) {
                                    first = boxes[index]
                                    firstBoxIndex = index
                                    phase = "decision"
                                    status = ""
                                    bankOffer = Random.nextInt(100) < 28
                                    sound.play(Sfx.Click)
                                    sound.vibrate(18)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else if (phase == "decision") {
                first?.let { PlayerReveal(it, english) }
                PremiumAbilityCard(
                    symbol = "🤝",
                    title = "Deal",
                    description = localizedText(english, "احتفظ باللاعب المكشوف وابدأ الجولة التالية.", "Keep the revealed player and move to the next round."),
                    status = localizedText(english, "مضمون", "SAFE"),
                    enabled = true
                ) {
                    first?.let { chosen -> team = team + chosen; draftAiPlayer(team) }
                    round++
                    phase = "choose"
                    boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4)
                    first = null
                    second = null
                    firstBoxIndex = -1
                    secondBoxIndex = -1
                    sound.play(Sfx.Correct)
                }
                PremiumAbilityCard(
                    symbol = "🎲",
                    title = "No Deal",
                    description = localizedText(english, "ارفض اللاعب الحالي وافتح صندوقًا ثانيًا. بعده لازم تختار واحدًا من الاثنين.", "Reject this player and open a second box. Then you must keep one of the two."),
                    status = localizedText(english, "مخاطرة", "RISK"),
                    enabled = true
                ) { phase = "second" }
                if (bankOffer) {
                    Card(colors = CardDefaults.cardColors(containerColor = Gold), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(localizedText(english, "🏦 عرض البنك ظهر!", "🏦 The bank has an offer!"), color = DeepWine, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "اقبل وخد اللاعب المكشوف ولاعب الصندوق الثاني معًا، من غير ما تعرفه قبل الموافقة.", "Accept both the revealed player and one hidden second-box player."), color = DeepWine, fontSize = 12.sp)
                            Button(onClick = {
                                val hiddenIndex = boxes.indices.filter { it != firstBoxIndex }.randomOrNull()
                                val hidden = hiddenIndex?.let(boxes::getOrNull)
                                team = team + listOfNotNull(first, hidden)
                                draftAiPlayer(team)
                                round++
                                phase = "choose"
                                first = null
                                second = null
                                firstBoxIndex = -1
                                secondBoxIndex = -1
                                bankOffer = false
                                boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4)
                                status = localizedText(english, "قبلت عرض البنك وحصلت على لاعبين", "Bank deal accepted: two players added")
                                sound.play(Sfx.Correct)
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = DeepWine, contentColor = Gold)) {
                                Text(localizedText(english, "اقبل عرض البنك", "Accept bank deal"))
                            }
                        }
                    }
                } else {
                    Text(localizedText(english, "عرض البنك ممكن يظهر في بعض الأدوار", "The bank may make an offer in some rounds"), color = Muted, fontSize = 12.sp)
                }
            } else if (phase == "second") {
                Text(localizedText(english, "اختار صندوقًا ثانيًا، ولازم تاخد واحد من اللاعبين", "Choose a second box. You must keep one of the two players."), color = Muted)
                boxes.indices.filter { it != firstBoxIndex }.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { index ->
                            Box(Modifier.weight(1f)) {
                                MysteryBoxCard(index = index + 1, label = localizedText(english, "الصندوق", "BOX")) {
                                    second = boxes[index]
                                    secondBoxIndex = index
                                    phase = "select"
                                    sound.play(Sfx.Click)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            if (phase == "select") {
                first?.let { PlayerReveal(it, english) }
                second?.let { PlayerReveal(it, english) }
                Text(localizedText(english, "اختار اللاعب اللي هتحتفظ بيه", "Choose the player to keep"), color = Gold, fontWeight = FontWeight.Bold)
                listOfNotNull(first, second).forEach { player ->
                    PremiumPlayerChoiceCard(player = player, english = english) {
                        team = team + player
                        draftAiPlayer(team)
                        round++
                        phase = "choose"
                        first = null
                        second = null
                        firstBoxIndex = -1
                        secondBoxIndex = -1
                        boxes = PlayerDatabase.players.filter { p -> (team + aiTeam).none { it.nameEn == p.nameEn } }.shuffled().take(4)
                        status = localizedText(english, "تم ضم اللاعب لفريقك", "Player added to your team")
                    }
                }
            }
            if (status.isNotBlank()) Text(status, color = Gold)
            Text(localizedText(english, "فريقك: ${team.size} لاعب", "Your squad: ${team.size} players"), color = Cream)
            team.forEach { PlayerLine(it, "${it.rating} OVR") }
        }
    }
}

@Composable
private fun PlayerLine(player: PlayerCard, detail: String) {
    val english = LocalAppUiSettings.current.english
    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${player.rating}", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr} • ${player.position}", color = Muted, fontSize = 11.sp)
            }
            Text(detail, color = Gold, fontWeight = FontWeight.Black, fontSize = 12.sp, textAlign = TextAlign.End)
        }
    }
}

@Composable
private fun PlayerReveal(player: PlayerCard, english: Boolean) {
    PremiumPlayerCard(
        player = player,
        detail = localizedText(english, "اللاعب داخل الصندوق", "PLAYER REVEALED"),
        eyebrow = localizedText(english, "محتوى الصندوق", "BOX CONTENT")
    )
}
