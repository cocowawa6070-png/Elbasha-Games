package com.mostafabek.elbashagames

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Sfx { Correct, Wrong, Win, Tick, Click }
enum class Track { Menu, Tournament }

/**
 * Plays the original music loops and short effects (res/raw) and light vibration.
 * The sound toggle controls effects + vibration, the music toggle controls the loops.
 * Both choices are remembered between launches.
 */
class SoundManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("elbasha_audio", Context.MODE_PRIVATE)

    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set
    var musicOn by mutableStateOf(prefs.getBoolean("music", true))
        private set

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val loadedSounds = mutableSetOf<Int>()
    private val pendingSounds = mutableSetOf<Int>()
    private val effectIds: Map<Sfx, Int>

    init {
        // Register first: a short sample can finish loading immediately after load().
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
                if (pendingSounds.remove(sampleId) && soundOn) {
                    pool.play(sampleId, 1f, 1f, 1, 0, 1f)
                }
            }
        }
        effectIds = mapOf(
            Sfx.Correct to pool.load(app, R.raw.sfx_correct, 1),
            Sfx.Wrong to pool.load(app, R.raw.sfx_wrong, 1),
            Sfx.Win to pool.load(app, R.raw.sfx_win, 1),
            Sfx.Tick to pool.load(app, R.raw.sfx_tick, 1),
            Sfx.Click to pool.load(app, R.raw.sfx_click, 1)
        )
    }

    private var player: MediaPlayer? = null
    private var playingTrack: Track? = null
    private var desiredTrack: Track? = null
    private var activityPaused = false

    fun play(effect: Sfx) {
        if (!soundOn) return
        effectIds[effect]?.let { id ->
            if (id in loadedSounds) pool.play(id, 1f, 1f, 1, 0, 1f)
            else pendingSounds.add(id)
        }
    }

    @Suppress("DEPRECATION")
    fun vibrate(milliseconds: Long = 30L) {
        if (!soundOn) return
        val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(milliseconds)
        }
    }

    fun playMusic(track: Track) {
        desiredTrack = track
        refreshMusic()
    }

    /** Stops menu music while a game is active; effects remain available. */
    fun stopMusic() {
        desiredTrack = null
        refreshMusic()
    }

    fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound", soundOn).apply()
    }

    fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        refreshMusic()
    }

    fun onPause() {
        activityPaused = true
        refreshMusic()
    }

    fun onResume() {
        activityPaused = false
        refreshMusic()
    }

    fun release() {
        player?.release()
        player = null
        playingTrack = null
        pool.release()
    }

    private fun refreshMusic() {
        val wanted = desiredTrack
        if (!musicOn || activityPaused || wanted == null) {
            player?.takeIf { it.isPlaying }?.pause()
            return
        }
        if (playingTrack != wanted) {
            player?.release()
            val resource = if (wanted == Track.Menu) R.raw.music_menu else R.raw.music_tournament
            player = MediaPlayer.create(app, resource)?.apply {
                isLooping = true
                setVolume(0.45f, 0.45f)
            }
            playingTrack = wanted
        }
        player?.takeIf { !it.isPlaying }?.start()
    }
}

@Composable
fun SoundToggles(sound: SoundManager) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ToggleChip(if (sound.soundOn) "🔊" else "🔇") { sound.toggleSound() }
        ToggleChip(if (sound.musicOn) "🎵" else "🚫") { sound.toggleMusic() }
    }
}

@Composable
private fun ToggleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(PanelColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(label, fontSize = 16.sp) }
}
