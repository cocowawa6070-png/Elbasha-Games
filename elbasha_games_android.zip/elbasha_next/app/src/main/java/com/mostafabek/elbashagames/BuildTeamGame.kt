package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase

private const val SQUAD_BUDGET = 56

private data class DraftPlayer(
    val nameAr: String,
    val nameEn: String,
    val positionAr: String,
    val positionEn: String,
    val rating: Int,
    val price: Int,
    val noteAr: String,
    val noteEn: String,
    val flag: String,
    val nationalityAr: String,
    val nationalityEn: String
)

private data class DraftSlot(val titleAr: String, val titleEn: String, val players: List<DraftPlayer>)

private val DraftSlots = listOf(
    DraftSlot("حارس المرمى", "Goalkeeper", PlayerDatabase.players.filter { it.position == "GK" }.map { DraftPlayer(PlayerSearch.arabicName(it.nameEn, it.nameAr), it.nameEn, "حارس", "GK", it.rating, it.price, "", "", it.flag, it.nationalityAr, it.nationalityEn) }),
    DraftSlot("الدفاع", "Defender", PlayerDatabase.players.filter { it.position == "DF" }.map { DraftPlayer(PlayerSearch.arabicName(it.nameEn, it.nameAr), it.nameEn, "مدافع", "DF", it.rating, it.price, "", "", it.flag, it.nationalityAr, it.nationalityEn) }),
    DraftSlot("خط الوسط", "Midfielder", PlayerDatabase.players.filter { it.position == "MF" }.map { DraftPlayer(PlayerSearch.arabicName(it.nameEn, it.nameAr), it.nameEn, "وسط", "MF", it.rating, it.price, "", "", it.flag, it.nationalityAr, it.nationalityEn) }),
    DraftSlot("الجناح", "Winger", PlayerDatabase.players.filter { it.position == "WG" }.map { DraftPlayer(PlayerSearch.arabicName(it.nameEn, it.nameAr), it.nameEn, "جناح", "WG", it.rating, it.price, "", "", it.flag, it.nationalityAr, it.nationalityEn) }),
    DraftSlot("رأس الحربة", "Striker", PlayerDatabase.players.filter { it.position == "ST" }.map { DraftPlayer(PlayerSearch.arabicName(it.nameEn, it.nameAr), it.nameEn, "مهاجم", "ST", it.rating, it.price, "", "", it.flag, it.nationalityAr, it.nationalityEn) })
)

@Composable
fun BuildTeamScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    val selectedPlayers = remember { mutableStateListOf<DraftPlayer>() }
    var slotIndex by remember { mutableIntStateOf(0) }
    var targetTeamSize by remember { mutableIntStateOf(5) }
    val formationCodes = remember(targetTeamSize) {
        when (targetTeamSize) {
            4 -> listOf("GK", "DF", "MF", "ST")
            5 -> listOf("GK", "DF", "MF", "WG", "ST")
            6 -> listOf("GK", "DF", "DF", "MF", "WG", "ST")
            7 -> listOf("GK", "DF", "DF", "MF", "MF", "WG", "ST")
            8 -> listOf("GK", "DF", "DF", "MF", "MF", "WG", "WG", "ST")
            9 -> listOf("GK", "DF", "DF", "DF", "MF", "MF", "WG", "WG", "ST")
            10 -> listOf("GK", "DF", "DF", "DF", "MF", "MF", "MF", "WG", "WG", "ST")
            else -> listOf("GK", "DF", "DF", "DF", "MF", "MF", "MF", "WG", "WG", "ST", "ST")
        }
    }
    val teamSlots = remember(formationCodes) {
        formationCodes.map { code -> DraftSlots.first { it.players.first().positionEn == code } }
    }
    var remainingBudget by remember { mutableIntStateOf(SQUAD_BUDGET) }
    var completed by remember { mutableStateOf(false) }
    var saveStatus by remember { mutableStateOf("") }
    var playerSearch by remember { mutableStateOf("") }
    val totalRating = selectedPlayers.sumOf { it.rating }
    val score = (totalRating * 10 + remainingBudget * 5).coerceAtLeast(0)

    BackHandler { onExit() }

    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }

    LaunchedEffect(completed) {
        if (completed) {
            if (ElbashaAccess.isDeveloper(user.uid)) {
                saveStatus = uiText("حساب المطور خارج الترتيب التنافسي", "Developer account is excluded from competitive rankings")
            } else {
                ScoreRepository.submit(database, user, score) { saved ->
                    saveStatus = if (saved) {
                        if (english) "Squad score saved ✅" else "اتسجلت نقاط التشكيلة ✅"
                    } else {
                        if (english) "Could not save your score. Check Firebase." else "تعذر حفظ النقاط. راجع Firebase."
                    }
                }
            }
        }
    }

    if (completed) {
        Column(
            Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(uiText("👑 تشكيلتك", "👑 Your Dream Team"), color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Text("$totalRating / ${targetTeamSize * 99}", color = Gold, fontSize = 45.sp, fontWeight = FontWeight.Black)
            Text(uiText("إجمالي تقييم الفريق", "Combined squad rating"), color = Muted)
            Spacer(Modifier.height(14.dp))
            selectedPlayers.forEach { player ->
                Text("${player.flag}  ${if (english) player.nameEn else player.nameAr}  •  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.rating}", color = Cream)
            }
            Spacer(Modifier.height(12.dp))
            Text(uiText("الميزانية المتبقية: $remainingBudget", "Budget left: $remainingBudget"), color = Gold)
            Text(uiText("مكافأة التحدي: $score نقطة", "Challenge reward: $score points"), color = Cream, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(saveStatus.ifBlank { uiText("جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(
                onClick = {
                    selectedPlayers.clear()
                    slotIndex = 0
                    remainingBudget = SQUAD_BUDGET
                    targetTeamSize = 5
                    completed = false
                    saveStatus = ""
                    playerSearch = ""
                },
                modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
            ) { Text(uiText("ابنِ تشكيلة جديدة", "Build another squad")) }
            TextButton(onClick = onExit) { Text(uiText("الرجوع للألعاب", "Back to games"), color = Gold) }
        }
        return
    }

    val slot = teamSlots[slotIndex]
    Column(
        Modifier.fillMaxSize().background(DeepWine).verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(uiText("🧩 كون فريقك", "🧩 Build Your Team"), color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
        Text(uiText("اختار من 4 إلى 11 لاعبًا. الميزانية بتزيد حسب حجم الفريق.", "Choose 4 to 11 players. Your budget scales with squad size."), color = Muted, fontSize = 13.sp)
        if (selectedPlayers.isEmpty() && slotIndex == 0) {
            Text(uiText("عدد لاعبي فريقك", "Squad size"), color = Cream, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                (4..11).forEach { count ->
                    val selected = targetTeamSize == count
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (selected) Gold else PanelColor)
                            .clickable { targetTeamSize = count; remainingBudget = count * 11 + 1 }
                            .padding(vertical = 10.dp), contentAlignment = Alignment.Center
                    ) {
                        Text("$count", color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(uiText("المركز ${slotIndex + 1} من ${teamSlots.size}: ${slot.titleAr}", "Position ${slotIndex + 1} of ${teamSlots.size}: ${slot.titleEn}"), color = Cream, fontWeight = FontWeight.Bold)
            Text("💰 $remainingBudget", color = Gold, fontWeight = FontWeight.Black)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            teamSlots.forEachIndexed { index, item ->
                Box(
                    Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (index <= slotIndex) Gold else PanelColor)
                )
            }
        }
        selectedPlayers.forEachIndexed { index, player ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelColor).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${index + 1}.", color = Gold, fontWeight = FontWeight.Black)
                Text(" ${if (english) player.nameEn else player.nameAr}", color = Cream, modifier = Modifier.weight(1f))
                Text("${player.rating} OVR", color = Gold, fontWeight = FontWeight.Bold)
            }
        }
        OutlinedTextField(
            value = playerSearch,
            onValueChange = { playerSearch = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(uiText("ابحث عن لاعب", "Search players")) },
            placeholder = { Text(uiText("اكتب أول 3 حروف من الاسم", "Type the first 3 letters")) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Cream,
                unfocusedTextColor = Cream,
                focusedBorderColor = Gold,
                unfocusedBorderColor = Muted,
                focusedLabelColor = Gold,
                unfocusedLabelColor = Muted,
                cursorColor = Gold
            )
        )
        val normalizedQuery = PlayerSearch.normalize(playerSearch)
        val availablePlayers = slot.players.filterNot { candidate ->
            selectedPlayers.any { it.nameEn == candidate.nameEn }
        }
        val visiblePlayers = PlayerSearch.suggestionsBy(
            availablePlayers, playerSearch, limit = 8,
            nameEn = { it.nameEn }, nameAr = { it.nameAr }, rating = { it.rating }
        )
        if (normalizedQuery.length < 3) {
            Text(
                uiText("اكتب 3 حروف على الأقل لعرض اقتراحات اللاعبين.", "Type at least 3 characters to see player suggestions."),
                color = Muted, fontSize = 13.sp
            )
        } else if (visiblePlayers.isEmpty()) {
            Text(uiText("مفيش لاعب مطابق للاسم ده في المركز الحالي.", "No matching player in this position."), color = Muted, fontSize = 13.sp)
        }
        visiblePlayers.forEach { player ->
            val affordable = player.price <= remainingBudget
            Card(
                modifier = Modifier.fillMaxWidth().clickable(enabled = affordable) {
                    selectedPlayers.add(player)
                    remainingBudget -= player.price
                    playerSearch = ""
                    sound.play(Sfx.Click)
                    sound.vibrate(18)
                    if (slotIndex == teamSlots.lastIndex) completed = true else slotIndex++
                },
                colors = CardDefaults.cardColors(containerColor = if (affordable) PanelColor else LocalElbashaPalette.current.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${player.rating}", color = if (affordable) Gold else Muted, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("OVR", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(if (english) player.nameEn else player.nameAr, color = if (affordable) Cream else Muted, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr} • ${if (english) player.positionEn else player.positionAr}", color = Muted, fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${player.price}", color = if (affordable) Gold else Muted, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(uiText("تكلفة", "credits"), color = Muted, fontSize = 10.sp)
                        if (!affordable) Text(uiText("مش كفاية", "Too costly"), color = LocalElbashaPalette.current.bad, fontSize = 10.sp)
                    }
                }
            }
        }
        Text(uiText("فكّر قبل ما تصرف الميزانية. مش لازم تختار أعلى تقييم في كل مركز.", "Spend carefully. You cannot afford the highest-rated player in every position."), color = Muted, fontSize = 11.sp)
    }
}
