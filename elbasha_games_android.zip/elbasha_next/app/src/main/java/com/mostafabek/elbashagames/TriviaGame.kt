package com.mostafabek.elbashagames

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.delay

private const val QUESTIONS_PER_GAME = 10
private const val SECONDS_PER_QUESTION = 15
private const val NOT_ANSWERED = -1
private const val TIMED_OUT = -2
private val Panel: Color
    @Composable get() = PanelColor
private val RightGreen: Color
    @Composable get() = LocalElbashaPalette.current.good
private val WrongRed: Color
    @Composable get() = LocalElbashaPalette.current.bad

private data class GameSummary(val score: Int, val correct: Int, val total: Int, val bestStreak: Int)

private sealed interface TriviaPhase {
    data object Setup : TriviaPhase
    data class Playing(val round: List<Question>) : TriviaPhase
    data class Result(val summary: GameSummary) : TriviaPhase
}

@Composable
fun TriviaScreen(user: FirebaseUser, database: FirebaseDatabase?, sound: SoundManager, onExit: () -> Unit) {
    var phase by remember { mutableStateOf<TriviaPhase>(TriviaPhase.Setup) }
    var bank by remember { mutableStateOf(QuestionRepository.sample) }
    var usingRemoteBank by remember { mutableStateOf(false) }
    var difficulty by remember { mutableStateOf("all") }
    val english = LocalAppUiSettings.current.english

    BackHandler { onExit() }

    DisposableEffect(Unit) {
        sound.stopMusic()
        onDispose { sound.playMusic(Track.Menu) }
    }

    LaunchedEffect(Unit) {
        QuestionRepository.load(database) { remote ->
            if (remote.isNotEmpty()) {
                bank = (QuestionRepository.sample + remote).distinctBy { it.id }
                usingRemoteBank = true
            }
        }
    }

    fun startRound() {
        val filtered = bank.filter { difficulty == "all" || it.difficulty == difficulty }.ifEmpty { bank }
        val round = filtered.shuffled().take(QUESTIONS_PER_GAME).map { question ->
            question.copy(
                text = question.prompt(english),
                options = question.choices(english).shuffled(),
                answer = question.correctAnswer(english),
                explanation = question.explanationText(english)
            )
        }
        sound.play(Sfx.Click)
        phase = TriviaPhase.Playing(round)
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Wine, DeepWine)))) {
        AnimatedContent(
            targetState = phase,
            transitionSpec = { (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 12 }) togetherWith fadeOut(tween(180)) },
            label = "trivia-phase"
        ) { current ->
            when (current) {
                is TriviaPhase.Setup -> SetupScreen(
                    difficulty = difficulty,
                    english = english,
                    onDifficulty = { sound.play(Sfx.Click); difficulty = it },
                    usingRemoteBank = usingRemoteBank,
                    sound = sound,
                    onStart = { startRound() },
                    onExit = onExit
                )
                is TriviaPhase.Playing -> PlayScreen(
                    round = current.round,
                    sound = sound,
                    onFinish = { phase = TriviaPhase.Result(it) }
                )
                is TriviaPhase.Result -> ResultScreen(
                    summary = current.summary,
                    user = user,
                    database = database,
                    sound = sound,
                    english = english,
                    onAgain = { startRound() },
                    onExit = onExit
                )
            }
        }
    }
}

@Composable
private fun SetupScreen(
    difficulty: String,
    english: Boolean,
    onDifficulty: (String) -> Unit,
    usingRemoteBank: Boolean,
    sound: SoundManager,
    onStart: () -> Unit,
    onExit: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(uiText("→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(uiText("🧠 تحدي المعلومات", "🧠 Football Trivia"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text(
            if (english) "$QUESTIONS_PER_GAME questions, $SECONDS_PER_QUESTION seconds each. Faster answers earn more points, and correct streaks add bonuses." else "$QUESTIONS_PER_GAME أسئلة، $SECONDS_PER_QUESTION ثانية لكل سؤال. كل ما جاوبت أسرع كل ما نقاطك أكتر، وسلسلة الإجابات الصح بتديك بونص.",
            color = Muted, fontSize = 13.sp
        )
        Text(uiText("اختار المستوى", "Choose difficulty"), color = Cream, fontWeight = FontWeight.Bold)
        val difficultyOptions = if (english) {
            listOf("all" to "All", "easy" to "Easy", "medium" to "Medium", "hard" to "Hard")
        } else {
            listOf("all" to "الكل", "easy" to "سهل", "medium" to "متوسط", "hard" to "صعب")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            difficultyOptions.forEach { (key, label) ->
                val selected = key == difficulty
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                        .background(if (selected) Gold else Panel)
                        .clickable { onDifficulty(key) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
        }
        if (!usingRemoteBank) {
            Text(
                uiText("ملاحظة: دي مكتبة أسئلة مدمجة، وهيتم إضافة أسئلة Firebase ليها تلقائيًا.", "Built-in question bank is ready. Questions from Firebase are added automatically when available."),
                color = Muted, fontSize = 11.sp
            )
        }
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
        ) { Text(uiText("يلا نبدأ 🔥", "Start playing 🔥"), fontWeight = FontWeight.Black, fontSize = 17.sp) }
    }
}

@Composable
private fun PlayScreen(round: List<Question>, sound: SoundManager, onFinish: (GameSummary) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(NOT_ANSWERED) }
    var timeLeftMs by remember { mutableLongStateOf(SECONDS_PER_QUESTION * 1000L) }
    var score by remember { mutableIntStateOf(0) }
    var correct by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(0) }
    var bestStreak by remember { mutableIntStateOf(0) }
    val question = round[index]

    // Countdown for the current question.
    LaunchedEffect(index) {
        val totalMs = SECONDS_PER_QUESTION * 1000L
        val start = SystemClock.elapsedRealtime()
        var lastTickSecond = -1
        while (selected == NOT_ANSWERED) {
            val left = totalMs - (SystemClock.elapsedRealtime() - start)
            if (left <= 0L) {
                timeLeftMs = 0L
                selected = TIMED_OUT
                streak = 0
                sound.play(Sfx.Wrong)
                sound.vibrate(120)
                break
            }
            timeLeftMs = left
            val second = ((left + 999) / 1000).toInt()
            if (second <= 3 && second != lastTickSecond) {
                lastTickSecond = second
                sound.play(Sfx.Tick)
            }
            delay(50)
        }
    }

    // After an answer (or a timeout) show the result briefly, then move on.
    LaunchedEffect(selected) {
        if (selected != NOT_ANSWERED) {
            delay(1400)
            if (index + 1 >= round.size) {
                onFinish(GameSummary(score, correct, round.size, bestStreak))
            } else {
                index += 1
                selected = NOT_ANSWERED
                timeLeftMs = SECONDS_PER_QUESTION * 1000L
            }
        }
    }

    fun answer(optionIndex: Int) {
        if (selected != NOT_ANSWERED) return
        selected = optionIndex
        if (question.options[optionIndex] == question.answer) {
            streak += 1
            bestStreak = maxOf(bestStreak, streak)
            val timeBonus = (timeLeftMs / 1000).toInt() * 5
            val streakBonus = minOf(streak - 1, 5) * 10
            score += 100 + timeBonus + streakBonus
            correct += 1
            sound.play(Sfx.Correct)
            sound.vibrate(25)
        } else {
            streak = 0
            sound.play(Sfx.Wrong)
            sound.vibrate(120)
        }
    }

    val progress = timeLeftMs / (SECONDS_PER_QUESTION * 1000f)
    val barColor by animateColorAsState(
        if (timeLeftMs < 5000L) Color(0xFFE5484D) else Gold, tween(300), label = "timer-color"
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(uiText("سؤال ${index + 1}/${round.size}", "Question ${index + 1}/${round.size}"), color = Muted, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            if (streak >= 2) Text("🔥 $streak  ", color = Gold, fontWeight = FontWeight.Bold)
            Text("⭐ $score", color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),
            color = barColor,
            trackColor = Panel
        )
        Text(if (LocalAppUiSettings.current.english) "${(timeLeftMs + 999) / 1000}s" else "${(timeLeftMs + 999) / 1000} ث", color = barColor, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.End))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(20.dp)) {
            Text(question.text, color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        question.options.forEachIndexed { i, option ->
            OptionRow(
                text = option,
                state = when {
                    selected == NOT_ANSWERED -> OptionState.Idle
                    option == question.answer -> OptionState.Right
                    i == selected -> OptionState.Wrong
                    else -> OptionState.Dimmed
                },
                onClick = { answer(i) }
            )
        }
        if (selected == TIMED_OUT) Text(uiText("انتهى الوقت ⏰", "Time is up ⏰"), color = Color(0xFFFFA9A9), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        if (selected != NOT_ANSWERED && question.explanation.isNotBlank()) {
            Text(question.explanation, color = Muted, fontSize = 12.sp)
        }
    }
}

private enum class OptionState { Idle, Right, Wrong, Dimmed }

@Composable
private fun OptionRow(text: String, state: OptionState, onClick: () -> Unit) {
    val background by animateColorAsState(
        when (state) {
            OptionState.Idle -> Panel
            OptionState.Right -> RightGreen
            OptionState.Wrong -> WrongRed
            OptionState.Dimmed -> LocalElbashaPalette.current.surface
        },
        tween(250), label = "option-color"
    )
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(background)
            .clickable(enabled = state == OptionState.Idle, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        Text(text, color = if (state == OptionState.Dimmed) Muted else Cream, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ResultScreen(
    summary: GameSummary,
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    english: Boolean,
    onAgain: () -> Unit,
    onExit: () -> Unit
) {
    var status by remember { mutableStateOf("جاري حفظ نقاطك…") }

    LaunchedEffect(Unit) {
        if (summary.correct * 2 >= summary.total) sound.play(Sfx.Win)
        sound.vibrate(200)
        if (ElbashaAccess.isDeveloper(user.uid)) {
            status = if (english) "Developer account is excluded from competitive rankings" else "حساب المطور خارج الترتيب التنافسي"
        } else {
            ScoreRepository.submit(database, user, summary.score) { ok ->
                status = if (ok) {
                    if (english) "Your score was added to the leaderboard ✅" else "تم حفظ نقاطك في الترتيب ✅"
                } else {
                    if (english) "Could not save the score. Check internet and Firebase setup." else "تعذر حفظ النقاط، راجع الإنترنت وإعدادات Firebase"
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text(if (summary.correct * 2 >= summary.total) uiText("🏆 أداء ملكي!", "🏆 Royal performance!") else uiText("💪 حاول تاني", "💪 Keep training"), color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Panel).padding(22.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("${summary.score}", color = Gold, fontSize = 48.sp, fontWeight = FontWeight.Black)
                Text(uiText("نقطة", "points"), color = Muted)
                Spacer(Modifier.height(10.dp))
                Text(uiText("إجابات صح: ${summary.correct} من ${summary.total}", "Correct answers: ${summary.correct}/${summary.total}"), color = Cream)
                Text(uiText("أطول سلسلة: ${summary.bestStreak}", "Best streak: ${summary.bestStreak}"), color = Cream)
            }
        }
        Text(status, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        Button(
            onClick = onAgain,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
        ) { Text(uiText("العب تاني", "Play again"), fontWeight = FontWeight.Black) }
        TextButton(onClick = onExit) { Text(uiText("الرجوع للرئيسية", "Back to home"), color = Gold) }
    }
}

