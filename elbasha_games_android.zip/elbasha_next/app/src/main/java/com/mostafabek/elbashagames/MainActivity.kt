package com.mostafabek.elbashagames

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.Credential
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var sound: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sound = SoundManager(this)
        try {
            auth = FirebaseAuth.getInstance()
            setContent {
                ElbashaApp(
                    auth = auth,
                    sound = sound,
                    databaseUrl = getString(R.string.firebase_database_url),
                    onGoogleSignIn = { callback -> startGoogleSignIn(callback) }
                )
            }
        } catch (error: Exception) {
            setContent {
                SetupRequiredScreen(
                    message = "إعداد Firebase غير مكتمل. استبدل app/google-services.json بملف مشروعك ثم أعد البناء.\n\n${error.localizedMessage ?: "خطأ في التهيئة"}"
                )
            }
        }
    }

    override fun onPause() {
        super.onPause()
        sound.onPause()
    }

    override fun onResume() {
        super.onResume()
        sound.onResume()
        installDownloadedUpdateIfReady(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        sound.release()
    }

    private fun startGoogleSignIn(onResult: (String?) -> Unit) {
        val webClientId = getString(R.string.google_web_client_id).trim()
        if (webClientId.isBlank() || webClientId.startsWith("REPLACE")) {
            onResult("إعداد Google Sign-In غير مكتمل. راجع Web Client ID داخل strings.xml ثم أعد البناء.")
            return
        }

        lifecycleScope.launch {
            val credentialManager = CredentialManager.create(this@MainActivity)
            try {
                // First try the Credential Manager account sheet, including accounts
                // that have not previously authorized this app.
                val googleOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(webClientId)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleOption)
                    .build()

                val result = credentialManager.getCredential(this@MainActivity, request)
                completeGoogleSignIn(result.credential, onResult)
            } catch (error: NoCredentialException) {
                // If the account sheet has no credential to return, try the explicit
                // Sign in with Google button flow. This can show the account chooser
                // even when no saved/authorized credential is available.
                try {
                    val signInOption = GetSignInWithGoogleOption.Builder(webClientId).build()
                    val signInRequest = GetCredentialRequest.Builder()
                        .addCredentialOption(signInOption)
                        .build()
                    val result = credentialManager.getCredential(this@MainActivity, signInRequest)
                    completeGoogleSignIn(result.credential, onResult)
                } catch (fallbackError: Exception) {
                    onResult(googleSignInErrorMessage(fallbackError))
                }
            } catch (error: Exception) {
                onResult(googleSignInErrorMessage(error))
            }
        }
    }

    private fun completeGoogleSignIn(credential: Credential, onResult: (String?) -> Unit) {
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            onResult("Google رجّع نوع بيانات اعتماد غير متوقع: ${credential.type}")
            return
        }

        val googleToken = try {
            GoogleIdTokenCredential.createFrom(credential.data)
        } catch (error: GoogleIdTokenParsingException) {
            onResult("تعذر قراءة رمز Google: ${error.localizedMessage ?: error.javaClass.simpleName}")
            return
        }

        val firebaseCredential = GoogleAuthProvider.getCredential(googleToken.idToken, null)
        auth.signInWithCredential(firebaseCredential)
            .addOnCompleteListener { task ->
                onResult(
                    if (task.isSuccessful) null
                    else task.exception?.localizedMessage ?: "فشل تسجيل الدخول بحساب Google"
                )
            }
    }

    private fun googleSignInErrorMessage(error: Exception): String {
        val detail = error.localizedMessage ?: "لا توجد تفاصيل إضافية"
        return "تعذر إكمال تسجيل الدخول باستخدام Google.\nنوع الخطأ: ${error.javaClass.simpleName}\nالتفاصيل: $detail"
    }

}
