package com.mostafabek.elbashagames

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/** User-facing preferences shared by every screen. */
data class AppUiSettings(
    val english: Boolean = false,
    val darkTheme: Boolean = true
)

val LocalAppUiSettings = compositionLocalOf { AppUiSettings() }

/** Central palette so the light/dark switch changes the whole experience, not just Material buttons. */
data class ElbashaPalette(
    val wine: Color,
    val deepWine: Color,
    val gold: Color,
    val cream: Color,
    val muted: Color,
    val panel: Color,
    val panelAlt: Color,
    val surface: Color,
    val good: Color,
    val bad: Color
)

private val DarkPalette = ElbashaPalette(
    wine = Color(0xFF500014),
    deepWine = Color(0xFF210009),
    gold = Color(0xFFE8B64E),
    cream = Color(0xFFFFF0D2),
    muted = Color(0xFFCABBAA),
    panel = Color(0xFF35101B),
    panelAlt = Color(0xFF4A1B28),
    surface = Color(0xFF2B0C15),
    good = Color(0xFF1F6B3A),
    bad = Color(0xFF8B1E2B)
)

private val LightPalette = ElbashaPalette(
    wine = Color(0xFFE8D7C8),
    deepWine = Color(0xFFFFF8F1),
    gold = Color(0xFF9B5C0B),
    cream = Color(0xFF2D1B18),
    muted = Color(0xFF705D54),
    panel = Color(0xFFFFFFFF),
    panelAlt = Color(0xFFF1E5DA),
    surface = Color(0xFFFFFDFB),
    good = Color(0xFF1F7A46),
    bad = Color(0xFFB32635)
)

val LocalElbashaPalette = compositionLocalOf { DarkPalette }

@Composable
fun uiText(arabic: String, english: String): String =
    if (LocalAppUiSettings.current.english) english else arabic

val Wine: Color
    @Composable get() = LocalElbashaPalette.current.wine
val DeepWine: Color
    @Composable get() = LocalElbashaPalette.current.deepWine
val Gold: Color
    @Composable get() = LocalElbashaPalette.current.gold
val Cream: Color
    @Composable get() = LocalElbashaPalette.current.cream
val Muted: Color
    @Composable get() = LocalElbashaPalette.current.muted
val PanelColor: Color
    @Composable get() = LocalElbashaPalette.current.panel
val PanelAltColor: Color
    @Composable get() = LocalElbashaPalette.current.panelAlt

fun paletteFor(darkTheme: Boolean): ElbashaPalette = if (darkTheme) DarkPalette else LightPalette
