package com.mostafabek.elbashagames

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private data class ReleaseInfo(val versionCode: Int, val versionName: String, val apkUrl: String)

@Composable
fun AppUpdaterCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("تحقق من وجود تحديثات جديدة على GitHub.") }
    var busy by remember { mutableStateOf(false) }
    var release by remember { mutableStateOf<ReleaseInfo?>(null) }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(status, modifier = Modifier.padding(bottom = 8.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                busy = true; status = "جاري البحث عن آخر إصدار..."
                try {
                    val latest = withContext(Dispatchers.IO) { fetchLatestRelease() }
                    release = latest
                    status = if (latest.versionCode <= BuildConfig.VERSION_CODE) "أنت تستخدم أحدث إصدار (${BuildConfig.VERSION_NAME})." else "يتوفر إصدار ${latest.versionName}. اضغط تنزيل وتثبيت."
                } catch (e: Exception) { status = "تعذر التحقق من التحديث: ${e.localizedMessage ?: "خطأ اتصال"}" }
                finally { busy = false }
            }
        }) { Text(if (busy) "جاري التحقق..." else "التحقق من التحديثات") }
        val available = release
        if (available != null && available.versionCode > BuildConfig.VERSION_CODE) {
            Button(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !busy, onClick = {
                scope.launch {
                    busy = true; status = "جاري تجهيز تنزيل التحديث..."
                    try {
                        withContext(Dispatchers.IO) { enqueueUpdateDownload(context, available.apkUrl) }
                        status = "بدأ التنزيل. ستظهر نافذة التثبيت بعد اكتماله."
                    } catch (e: Exception) { status = "فشل تنزيل التحديث: ${e.localizedMessage ?: "خطأ"}" }
                    finally { busy = false }
                }
            }) { Text("تنزيل وتثبيت ${available.versionName}") }
        }
    }
}

private fun fetchLatestRelease(): ReleaseInfo {
    val c = URL("https://api.github.com/repos/cocowawa6070-png/Elbasha-Games/releases/latest").openConnection() as HttpURLConnection
    c.connectTimeout = 12000; c.readTimeout = 12000
    c.setRequestProperty("Accept", "application/vnd.github+json")
    try {
        if (c.responseCode !in 200..299) error("GitHub HTTP ${c.responseCode}")
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = j.optString("tag_name", "").removePrefix("v")
        val body = j.optString("body", "")
        val code = Regex("(?im)^versionCode\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull()
            ?: tag.split('.').lastOrNull()?.toIntOrNull() ?: error("بيانات versionCode غير موجودة")
        val assets = j.getJSONArray("assets")
        val apk = (0 until assets.length()).map { assets.getJSONObject(it) }.firstOrNull { it.optString("name").endsWith(".apk", true) }?.optString("browser_download_url")
            ?.takeIf { it.startsWith("https://") } ?: error("ملف APK غير موجود في GitHub Release")
        return ReleaseInfo(code, j.optString("tag_name", "v$code"), apk)
    } finally { c.disconnect() }
}

private fun enqueueUpdateDownload(context: Context, apkUrl: String) {
    val request = DownloadManager.Request(Uri.parse(apkUrl))
        .setTitle("ELBASHA GAMES Update")
        .setDescription("Downloading the latest version")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedOverMetered(true).setAllowedOverRoaming(false)
        .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "elbasha-update.apk")
    val id = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE).edit()
        .putLong("download_id", id).putBoolean("install_prompted", false).apply()
}

fun handleUpdateDownloadCompleted(context: Context, downloadId: Long) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    if (prefs.getLong("download_id", -1L) != downloadId) return
    installDownloadedUpdateIfReady(context)
}

fun installDownloadedUpdateIfReady(context: Context) {
    val prefs = context.getSharedPreferences("elbasha_updates", Context.MODE_PRIVATE)
    if (prefs.getBoolean("install_prompted", false)) return
    val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "elbasha-update.apk")
    if (!file.exists() || file.length() == 0L) return
    if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) return
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    prefs.edit().putBoolean("install_prompted", true).apply()
    context.startActivity(intent)
}
