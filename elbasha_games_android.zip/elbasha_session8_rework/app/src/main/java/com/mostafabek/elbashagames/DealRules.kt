package com.mostafabek.elbashagames

import kotlin.random.Random

/** Pure draft rules for Deal or No Deal. */
object DealRules {
    /** Build four unique boxes for a round from the required role, excluding both teams. */
    fun createRoundBoxes(
        players: List<PlayerCard>,
        slot: String,
        excludedNames: Set<String>,
        random: Random = Random.Default
    ): List<PlayerCard> = players
        .filter { ElbashaPositions.supports(it, slot) && it.nameEn !in excludedNames }
        .shuffled(random)
        .take(4)
        .map { it.copy(position = slot) }

    /** AI may not draft a player already owned OR shown in any of the current round's boxes. */
    fun eligibleAiPlayers(
        players: List<PlayerCard>,
        slot: String,
        userTeam: List<PlayerCard>,
        aiTeam: List<PlayerCard>,
        visibleBoxes: List<PlayerCard>
    ): List<PlayerCard> {
        val blocked = (userTeam + aiTeam + visibleBoxes).map { it.nameEn }.toSet()
        return players.filter { ElbashaPositions.supports(it, slot) && it.nameEn !in blocked }
    }

    /** Higher difficulty focuses its random choice on stronger eligible players. */
    fun chooseAiPlayer(
        players: List<PlayerCard>,
        slot: String,
        userTeam: List<PlayerCard>,
        aiTeam: List<PlayerCard>,
        visibleBoxes: List<PlayerCard>,
        difficulty: Int,
        random: Random = Random.Default
    ): PlayerCard? {
        val candidates = eligibleAiPlayers(players, slot, userTeam, aiTeam, visibleBoxes)
        if (candidates.isEmpty()) return null
        val aiIsBehind = aiTeam.sumOf { it.rating } < userTeam.sumOf { it.rating }
        val baseFocus = when (difficulty.coerceIn(0, 3)) {
            0 -> 0.78
            1 -> 0.60
            2 -> 0.40
            else -> 0.24
        }
        val focusRatio = (baseFocus + if (aiIsBehind) -0.10 else 0.08).coerceIn(0.15, 0.90)
        val focusSize = (candidates.size * focusRatio).toInt().coerceAtLeast(1)
        return candidates.sortedByDescending { it.rating }.take(focusSize).randomOrNull(random)
            ?.copy(position = slot)
    }

    /** The bank can only select an unopened box, never the first revealed box. */
    fun randomUnopenedBoxIndex(boxCount: Int, openedIndex: Int, random: Random = Random.Default): Int? {
        if (boxCount <= 1 || openedIndex !in 0 until boxCount) return null
        return (0 until boxCount).filter { it != openedIndex }.randomOrNull(random)
    }
}
