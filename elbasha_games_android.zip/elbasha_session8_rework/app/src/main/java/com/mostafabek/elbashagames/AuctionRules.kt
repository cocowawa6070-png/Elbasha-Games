package com.mostafabek.elbashagames

import kotlin.random.Random

/** Pure auction rules shared by the UI and smoke tests. All money values are in millions. */
enum class AuctionWinner { User, Ai, Unsold }

data class AuctionSettlement(val winner: AuctionWinner, val price: Int)

data class AuctionSwapResult(
    val updatedBought: List<Pair<PlayerCard, Int>>,
    val oldPlayer: PlayerCard,
    val newPlayer: PlayerCard
)

object AuctionRules {
    private val bidSteps = listOf(1, 5, 10)

    fun openingPrice(playerRating: Int): Int = (playerRating / 14).coerceAtLeast(5)

    /** Reserve the minimum opening price for every squad slot after the current lot. */
    fun spendLimit(remainingBudget: Int, remainingSlotsAfterCurrent: Int, minimumOpening: Int = 5): Int =
        (remainingBudget - remainingSlotsAfterCurrent.coerceAtLeast(0) * minimumOpening.coerceAtLeast(0)).coerceAtLeast(0)

    /** Reserve the actual opening prices of every queued lot, not a flat minimum estimate. */
    fun spendLimitForLots(remainingBudget: Int, upcomingLots: List<PlayerCard>): Int =
        (remainingBudget - upcomingLots.sumOf { openingPrice(it.rating) }).coerceAtLeast(0)

    /**
     * Budget the AI may spend on the current lot while preserving enough cash for every
     * queued lot's opening price. Returns zero when buying the current lot would break
     * that reserve, even if the raw wallet could pay for the current player alone.
     */
    fun availableBudgetForCurrentLot(
        totalBudget: Int,
        currentOpeningPrice: Int,
        upcomingLots: List<PlayerCard>
    ): Int {
        val reservedForUpcoming = upcomingLots.sumOf { openingPrice(it.rating) }
        val spendable = totalBudget - reservedForUpcoming
        return if (spendable >= currentOpeningPrice) spendable else 0
    }

    fun isValidUserBid(proposed: Int, currentBid: Int, openingPrice: Int, userBudget: Int): Boolean =
        proposed >= openingPrice && proposed > currentBid && proposed <= userBudget

    /** Minimum absolute value the user may submit on the current turn. */
    fun minimumNextUserBid(currentBid: Int, openingPrice: Int): Int =
        maxOf(openingPrice, currentBid + 1)

    /** Adjust the editable bid draft without committing it; decrement cannot cross the legal minimum. */
    fun adjustUserBidDraft(
        currentDraft: Int,
        delta: Int,
        minimumBid: Int,
        userBudget: Int
    ): Int? {
        val safeMinimum = minimumBid.coerceAtLeast(0)
        val proposed = (currentDraft.toLong() + delta.toLong())
            .coerceAtLeast(safeMinimum.toLong())
        if (proposed > userBudget.toLong()) return null
        return proposed.toInt()
    }

    /** Returns the AI's next absolute bid, or null when it must pass. */
    fun nextAiBid(
        currentBid: Int,
        aiCeiling: Int,
        aiBudget: Int,
        random: Random = Random.Default
    ): Int? = bidSteps
        .filter { currentBid + it <= aiCeiling && currentBid + it <= aiBudget }
        .randomOrNull(random)
        ?.let { currentBid + it }

    /** Wild Card applies only to the lot where it was activated, never below the opening price. */
    fun payablePrice(currentBid: Int, openingPrice: Int, wildCardActive: Boolean): Int =
        if (wildCardActive) (currentBid - 2).coerceAtLeast(openingPrice) else currentBid

    fun canBuyOpening(openingPrice: Int, aiCeiling: Int, aiBudget: Int): Boolean =
        aiCeiling >= openingPrice && aiBudget >= openingPrice

    /** AI price ceiling follows difficulty, player rating, remaining funds and squad need. */
    fun calculateAiBidCeiling(
        rating: Int,
        opening: Int,
        budget: Int,
        difficulty: Int,
        positionNeed: Int,
        random: Random = Random.Default
    ): Int {
        if (budget < opening || positionNeed <= 0) return 0
        val level = difficulty.coerceIn(0, 3)
        val passChance = when (level) { 0 -> 24; 1 -> 13; 2 -> 6; else -> 2 }
        if (rating < 93 && random.nextInt(100) < passChance) return 0
        val divisor = when (level) { 0 -> 18; 1 -> 15; 2 -> 13; else -> 11 }
        val randomRange = when (level) { 0 -> 2; 1 -> 3; 2 -> 4; else -> 5 }
        val needBonus = if (positionNeed >= 2) 3 else 0
        val strategicCeiling = opening + (rating / divisor) + random.nextInt(0, randomRange + 1) + needBonus
        return minOf(budget, strategicCeiling)
    }

    /** Settle a user bid when the AI cannot or chooses not to raise. */
    fun settleWhenAiPasses(currentBid: Int, openingPrice: Int, wildCardActive: Boolean): AuctionSettlement =
        AuctionSettlement(AuctionWinner.User, payablePrice(currentBid, openingPrice, wildCardActive))

    /** Resolve the first-pass rule. No player is granted a hidden reward when both sides pass. */
    fun settleWhenUserPasses(
        currentBid: Int,
        openingPrice: Int,
        aiIsLeading: Boolean,
        aiCeiling: Int,
        aiBudget: Int
    ): AuctionSettlement = when {
        aiIsLeading -> AuctionSettlement(AuctionWinner.Ai, currentBid)
        canBuyOpening(openingPrice, aiCeiling, aiBudget) -> AuctionSettlement(AuctionWinner.Ai, openingPrice)
        else -> AuctionSettlement(AuctionWinner.Unsold, 0)
    }

    /**
     * Replace one purchased player with an unused player from the same tactical role.
     * The paid amount and auction queue are intentionally untouched: a free squad swap
     * must not silently add or remove auction rounds.
     */
    fun randomSwap(
        bought: List<Pair<PlayerCard, Int>>,
        otherOwned: List<PlayerCard>,
        currentLot: PlayerCard?,
        remainingLots: List<PlayerCard>,
        random: Random = Random.Default
    ): AuctionSwapResult? {
        if (bought.isEmpty()) return null
        val usedNames = (bought.map { it.first } + otherOwned + listOfNotNull(currentLot) + remainingLots)
            .map { it.nameEn }.toSet()
        val options = bought.indices.flatMap { index ->
            val oldPlayer = bought[index].first
            PlayerDatabase.players
                .filter { candidate ->
                    ElbashaPositions.supports(candidate, oldPlayer.position) &&
                        candidate.nameEn !in usedNames
                }
                .map { replacement -> index to replacement.copy(position = oldPlayer.position) }
        }
        val (index, replacement) = options.randomOrNull(random) ?: return null
        val oldEntry = bought[index]
        val updated = bought.toMutableList().also { it[index] = replacement to oldEntry.second }
        return AuctionSwapResult(updated, oldEntry.first, replacement)
    }

    /**
     * A hidden reward must not later reappear as an auction lot. When it collides with a
     * queued lot, replace that lot with another unused player of the same slot so the
     * number of rounds does not silently shrink.
     */
    fun preserveQueueAfterHiddenReward(
        remainingLots: List<PlayerCard>,
        hiddenPlayer: PlayerCard,
        occupiedNames: Set<String>,
        random: Random = Random.Default
    ): List<PlayerCard> {
        val collisionIndex = remainingLots.indexOfFirst { it.nameEn == hiddenPlayer.nameEn }
        if (collisionIndex < 0) return remainingLots

        val replacedSlot = remainingLots[collisionIndex].position
        val queuedOthers = remainingLots.indices
            .filter { it != collisionIndex }
            .map { remainingLots[it].nameEn }
            .toSet()
        val blockedNames = occupiedNames + hiddenPlayer.nameEn + queuedOthers
        val replacement = PlayerDatabase.players
            .filter { ElbashaPositions.supports(it, replacedSlot) && it.nameEn !in blockedNames }
            .randomOrNull(random)
            ?.copy(position = replacedSlot)

        return if (replacement != null) {
            remainingLots.toMutableList().also { it[collisionIndex] = replacement }
        } else {
            // Defensive fallback: better to end with one fewer available lot than duplicate a player.
            remainingLots.filterIndexed { index, _ -> index != collisionIndex }
        }
    }
}
