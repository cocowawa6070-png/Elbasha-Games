package com.mostafabek.elbashagames

import kotlin.random.Random

/** Pure auction rules shared by the UI and smoke tests. All money values are in millions. */
object AuctionRules {
    private val bidSteps = listOf(1, 5, 10)

    fun openingPrice(playerRating: Int): Int = (playerRating / 14).coerceAtLeast(5)

    /** Reserve the minimum opening price for every squad slot after the current lot. */
    fun spendLimit(remainingBudget: Int, remainingSlotsAfterCurrent: Int, minimumOpening: Int = 5): Int =
        (remainingBudget - remainingSlotsAfterCurrent.coerceAtLeast(0) * minimumOpening.coerceAtLeast(0)).coerceAtLeast(0)

    fun isValidUserBid(proposed: Int, currentBid: Int, openingPrice: Int, userBudget: Int): Boolean =
        proposed >= openingPrice && proposed > currentBid && proposed <= userBudget

    /** Returns the AI's next absolute bid, or null when it must pass. */
    fun nextAiBid(
        currentBid: Int,
        aiCeiling: Int,
        aiBudget: Int,
        random: Random = Random.Default
    ): Int? = bidSteps
        .filter { currentBid + it <= aiCeiling && currentBid + it <= aiBudget }
        .randomOrNull(random)
        ?.let { currentBid + it }

    /** Wild Card applies only to the lot where it was activated, never below the opening price. */
    fun payablePrice(currentBid: Int, openingPrice: Int, wildCardActive: Boolean): Int =
        if (wildCardActive) (currentBid - 2).coerceAtLeast(openingPrice) else currentBid

    fun canBuyOpening(openingPrice: Int, aiCeiling: Int, aiBudget: Int): Boolean =
        aiCeiling >= openingPrice && aiBudget >= openingPrice
}
