package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase

private data class BuildSlot(
    val code: String,
    val titleAr: String,
    val titleEn: String
)

private data class NationalityChallenge(
    val nationalityAr: String,
    val nationalityEn: String,
    val positionCode: String,
    val positionAr: String,
    val positionEn: String
)

private enum class BuildPhase { Setup, Picking, Result }

private val BuildPositionLabels = mapOf(
    "GK" to ("حارس مرمى" to "Goalkeeper"),
    "RB" to ("ظهير أيمن" to "Right Back"),
    "CB" to ("قلب دفاع" to "Centre Back"),
    "LB" to ("ظهير أيسر" to "Left Back"),
    "CDM" to ("وسط دفاعي" to "Defensive Midfielder"),
    "CM" to ("وسط" to "Central Midfielder"),
    "CAM" to ("وسط هجومي" to "Attacking Midfielder"),
    "RW" to ("جناح أيمن" to "Right Winger"),
    "LW" to ("جناح أيسر" to "Left Winger"),
    "ST" to ("مهاجم" to "Striker")
)

private fun buildFormation(size: Int): List<BuildSlot> =
    ElbashaPositions.rosterOrder.take(size.coerceIn(4, 11)).map { code ->
        val labels = BuildPositionLabels.getValue(code)
        BuildSlot(code, labels.first, labels.second)
    }

private fun createNationalityChallenge(
    positionCode: String,
    excludedNames: Set<String>
): NationalityChallenge? {
    val remaining = PlayerDatabase.players.filter {
        ElbashaPositions.supports(it, positionCode) && it.nameEn !in excludedNames &&
            it.nationalityEn.isNotBlank() && it.nationalityAr.isNotBlank()
    }
    val groups = remaining.groupBy { it.nationalityEn }
        .filterValues { it.size >= 2 }
    val chosen = groups.entries.randomOrNull() ?: return null
    val sample = chosen.value.first()
    val labels = BuildPositionLabels.getValue(positionCode)
    return NationalityChallenge(
        nationalityAr = sample.nationalityAr,
        nationalityEn = chosen.key,
        positionCode = positionCode,
        positionAr = labels.first,
        positionEn = labels.second
    )
}

private fun chooseAiPlayer(candidates: List<PlayerCard>, difficulty: Int): PlayerCard? {
    if (candidates.isEmpty()) return null
    val ranked = candidates.sortedByDescending { it.rating }
    val poolSize = when (difficulty) {
        0 -> (ranked.size * 0.78).toInt().coerceAtLeast(1)
        1 -> (ranked.size * 0.60).toInt().coerceAtLeast(1)
        2 -> (ranked.size * 0.38).toInt().coerceAtLeast(1)
        else -> (ranked.size * 0.20).toInt().coerceAtLeast(1)
    }
    return ranked.take(poolSize).randomOrNull()
}

@Composable
fun BuildTeamScreen(
    user: FirebaseUser,
    database: FirebaseDatabase?,
    sound: SoundManager,
    onExit: () -> Unit
) {
    val english = LocalAppUiSettings.current.english
    var phase by remember { mutableStateOf(BuildPhase.Setup) }
    var teamSize by remember { mutableIntStateOf(5) }
    var aiDifficulty by remember { mutableIntStateOf(1) }
    var slotIndex by remember { mutableIntStateOf(0) }
    var currentChallenge by remember { mutableStateOf<NationalityChallenge?>(null) }
    var searchText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var saveStatus by remember { mutableStateOf("") }
    val playerTeam = remember { mutableStateListOf<PlayerCard>() }
    val aiTeam = remember { mutableStateListOf<PlayerCard>() }
    var scoreSubmitted by remember { mutableStateOf(false) }
    val formation = remember(teamSize) { buildFormation(teamSize) }
    val usedNames = (playerTeam + aiTeam).map { it.nameEn }.toSet()
    val challenge = currentChallenge
    val eligiblePlayers = if (challenge == null) emptyList() else PlayerDatabase.players.filter {
        ElbashaPositions.supports(it, challenge.positionCode) &&
            it.nationalityEn == challenge.nationalityEn &&
            it.nameEn !in usedNames
    }
    val suggestions = PlayerSearch.suggestions(eligiblePlayers, searchText, limit = 10)
    val userPoints = playerTeam.indices.count { index ->
        playerTeam[index].rating > (aiTeam.getOrNull(index)?.rating ?: 0)
    }
    val aiPoints = aiTeam.indices.count { index ->
        aiTeam[index].rating > (playerTeam.getOrNull(index)?.rating ?: 0)
    }
    val totalUserRating = playerTeam.sumOf { it.rating }
    val totalAiRating = aiTeam.sumOf { it.rating }

    fun startGame() {
        playerTeam.clear()
        aiTeam.clear()
        slotIndex = 0
        searchText = ""
        status = ""
        saveStatus = ""
        scoreSubmitted = false
        currentChallenge = createNationalityChallenge(formation.first().code, emptySet())
        if (currentChallenge == null) {
            status = if (english) "Not enough matching players in the database." else "قاعدة اللاعبين لا تحتوي على لاعبين كفاية لهذا التحدي."
            return
        }
        phase = BuildPhase.Picking
        sound.play(Sfx.Click)
    }

    fun choosePlayer(player: PlayerCard) {
        val active = currentChallenge ?: return
        if (player.nameEn in usedNames || player !in eligiblePlayers) return
        playerTeam.add(player.copy(position = active.positionCode))
        val aiCandidates = PlayerDatabase.players.filter {
            ElbashaPositions.supports(it, active.positionCode) &&
                it.nationalityEn == active.nationalityEn &&
                it.nameEn !in (playerTeam + aiTeam).map { picked -> picked.nameEn }.toSet()
        }
        val aiChoice = chooseAiPlayer(aiCandidates, aiDifficulty)
        if (aiChoice != null) aiTeam.add(aiChoice.copy(position = active.positionCode))
        searchText = ""
        sound.play(Sfx.Correct)
        sound.vibrate(22)
        if (slotIndex >= formation.lastIndex) {
            phase = BuildPhase.Result
        } else {
            slotIndex++
            val unavailable = (playerTeam + aiTeam).map { it.nameEn }.toSet()
            currentChallenge = createNationalityChallenge(formation[slotIndex].code, unavailable)
            if (currentChallenge == null) {
                // This is a defensive fallback for unusual player-pool edits.
                val fallback = PlayerDatabase.players.filter {
                    ElbashaPositions.supports(it, formation[slotIndex].code) && it.nameEn !in unavailable
                }
                val nation = fallback.groupBy { it.nationalityEn }.entries
                    .firstOrNull { it.value.size >= 2 }
                if (nation != null) {
                    val sample = nation.value.first()
                    val labels = BuildPositionLabels.getValue(formation[slotIndex].code)
                    currentChallenge = NationalityChallenge(sample.nationalityAr, nation.key, formation[slotIndex].code, labels.first, labels.second)
                } else {
                    status = if (english) "The player pool for this position is exhausted." else "خلصت اختيارات اللاعبين المتاحة للمركز ده."
                    phase = BuildPhase.Result
                }
            }
        }
    }

    BackHandler { onExit() }
LaunchedEffect(phase) {
        if (phase == BuildPhase.Result && !scoreSubmitted) {
            scoreSubmitted = true
            sound.play(if (userPoints >= aiPoints) Sfx.Win else Sfx.Loss)
            if (ElbashaAccess.isDeveloper(user.uid)) {
                saveStatus = localizedText(english, "حساب المطور مستبعد من الترتيب التنافسي", "Developer account is excluded from competitive rankings")
            } else {
                val score = (userPoints * 1000 + totalUserRating).coerceIn(0, 100_000)
                ScoreRepository.submit(database, user, score) { saved ->
                    saveStatus = if (saved) localizedText(english, "تم حفظ نقاط التحدي ✅", "Challenge score saved ✅")
                    else localizedText(english, "تعذر حفظ النتيجة. راجع اتصال Firebase.", "Could not save the result. Check Firebase.")
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(localizedText(english, "🧩 كون فريق", "🧩 Build a Team"), color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)

        when (phase) {
            BuildPhase.Setup -> {
                Text(localizedText(english, "اتحدى الذكاء الاصطناعي في بناء فريقك", "Challenge the AI to build a stronger team"), color = Cream, fontWeight = FontWeight.Bold)
                HowToPlayCard(
                    title = localizedText(english, "طريقة اللعب والتحكيم", "How to play and score"),
                    steps = if (english) listOf(
                        "Choose a squad size from 4 to 11 players and set the AI difficulty.",
                        "Each turn gives you a position and a nationality requirement.",
                        "Search the player database. Suggestions appear after at least 3 Arabic or English characters.",
                        "Pick one eligible player. The AI secretly picks a different player from the same group.",
                        "After all positions are filled, reveal both squads. The higher ELBASHA rating wins that position and earns one point."
                    ) else listOf(
                        "اختار حجم فريق من 4 إلى 11 لاعب، وحدد مستوى صعوبة الذكاء الاصطناعي.",
                        "في كل دور هيظهر مركز مطلوب وجنسية لازم اللاعب يكون منها.",
                        "ابحث في قاعدة اللاعبين. الاقتراحات بتظهر بعد كتابة 3 حروف على الأقل بالعربي أو الإنجليزي.",
                        "اختار لاعبًا مطابقًا للشرط. الـAI هيختار لاعبًا مختلفًا من نفس المجموعة بشكل سري.",
                        "بعد اكتمال المراكز، الفريقان هيظهروا. اللاعب الأعلى في تقييم ELBASHA يكسب نقطة المركز."
                    ),
                    note = localizedText(english, "الـAI لا يكشف اختياراته أثناء اللعب، ولا يمكن استخدام اللاعب نفسه مرتين.", "The AI keeps its picks hidden during the game, and the same player cannot be used twice.")
                )
                Text(localizedText(english, "عدد لاعبي الفريق", "Team size"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    (4..11).forEach { count ->
                        val selected = teamSize == count
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                                .background(if (selected) Gold else PanelColor)
                                .clickable { teamSize = count }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$count", color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 13.sp)
                        }
                    }
                }
                Text(localizedText(english, "مستوى الذكاء الاصطناعي", "AI difficulty"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("سهل" to "Easy", "متوازن" to "Balanced", "صعب" to "Hard", "صعب جدًا" to "Very hard").forEachIndexed { index, pair ->
                        val selected = aiDifficulty == index
                        Card(
                            Modifier.weight(1f).clickable { aiDifficulty = index },
                            colors = CardDefaults.cardColors(containerColor = if (selected) Gold else PanelColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (english) pair.second else pair.first, color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 12.dp), textAlign = TextAlign.Center, fontSize = 11.sp)
                        }
                    }
                }
                if (status.isNotBlank()) Text(status, color = LocalElbashaPalette.current.bad)
                Button(onClick = { startGame() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)) {
                    Text(localizedText(english, "ابدأ التحدي", "Start challenge"), fontWeight = FontWeight.Bold)
                }
            }

            BuildPhase.Picking -> {
                val slot = formation.getOrNull(slotIndex)
                Text(localizedText(english, "المركز ${slotIndex + 1} من ${formation.size}", "Position ${slotIndex + 1} of ${formation.size}"), color = Cream, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(
                    progress = { (slotIndex.toFloat() / formation.size).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor
                )
                if (slot != null && challenge != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(17.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(if (english) slot.titleEn else slot.titleAr, color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(localizedText(english, "الشرط: لاعب ${challenge.positionAr} من ${challenge.nationalityAr}", "Requirement: ${challenge.positionEn} from ${challenge.nationalityEn}"), color = Cream, fontWeight = FontWeight.Bold)
                            Text(localizedText(english, "الـAI بيختار في نفس الوقت، واختياره مش هيظهر غير في النتيجة.", "The AI is choosing at the same time. Its pick stays hidden until the results."), color = Muted, fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(localizedText(english, "ابحث عن لاعب مطابق", "Search for an eligible player")) },
                        placeholder = { Text(localizedText(english, "اكتب 3 حروف على الأقل", "Type at least 3 characters")) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Cream,
                            unfocusedTextColor = Cream,
                            focusedBorderColor = Gold,
                            unfocusedBorderColor = Muted,
                            focusedLabelColor = Gold,
                            unfocusedLabelColor = Muted,
                            cursorColor = Gold
                        )
                    )
                    if (PlayerSearch.normalize(searchText).length < 3) {
                        Text(localizedText(english, "اكتب 3 حروف عشان تظهر اقتراحات من قاعدة اللاعبين فقط.", "Enter 3 characters to see suggestions from the player database."), color = Muted, fontSize = 12.sp)
                    } else if (suggestions.isEmpty()) {
                        Text(localizedText(english, "مفيش لاعب مطابق للبحث والشرط الحالي.", "No player matches the search and current requirement."), color = Muted, fontSize = 12.sp)
                    }
                    suggestions.forEach { player ->
                        PremiumPlayerChoiceCard(player = player, english = english) { choosePlayer(player) }
                    }
                }
                Text(localizedText(english, "فريقك حتى الآن: ${playerTeam.size} لاعب", "Your team so far: ${playerTeam.size} players"), color = Cream, fontWeight = FontWeight.Bold)
                playerTeam.forEachIndexed { index, player ->
                    PremiumPlayerCard(
                        player = player,
                        detail = localizedText(english, "الاختيار رقم ${index + 1}", "Pick ${index + 1}"),
                        eyebrow = localizedText(english, "بطاقة تشكيلتك", "YOUR SQUAD CARD")
                    )
                }
            }

            BuildPhase.Result -> {
                Text(localizedText(english, "🏆 نتيجة التحدي", "🏆 Challenge results"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                        Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(localizedText(english, "فريقك", "Your team"), color = Cream)
                            Text("$userPoints", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "نقطة مركز", "position points"), color = Muted, fontSize = 10.sp)
                        }
                    }
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = PanelColor)) {
                        Column(Modifier.padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("AI", color = Cream)
                            Text("$aiPoints", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
                            Text(localizedText(english, "نقطة مركز", "position points"), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                Text(
                    when {
                        userPoints > aiPoints -> localizedText(english, "👑 كسبت التحدي!", "👑 You won the challenge!")
                        userPoints < aiPoints -> localizedText(english, "الـAI كسب التحدي المرة دي.", "The AI won this challenge.")
                        else -> localizedText(english, "تعادل! الفريقان متساويان في النقاط.", "Draw! Both teams earned the same points.")
                    }, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp
                )
                Text(localizedText(english, "التحكيم: كل مركز يُقارن بشكل منفصل، والأعلى في تقييم ELBASHA يحصل على نقطة.", "Judging: each position is compared separately; the higher ELBASHA rating earns one point."), color = Muted, fontSize = 12.sp)
                Text(saveStatus.ifBlank { localizedText(english, "جاري حفظ النتيجة…", "Saving result…") }, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                formation.forEachIndexed { index, slot ->
                    val mine = playerTeam.getOrNull(index)
                    val rival = aiTeam.getOrNull(index)
                    val winner = when {
                        mine == null -> localizedText(english, "لم يتم اختيار لاعب", "No player selected")
                        rival == null -> localizedText(english, "لا يوجد خصم متاح", "No AI player available")
                        mine.rating > rival.rating -> localizedText(english, "نقطتك ✅", "Your point ✅")
                        mine.rating < rival.rating -> localizedText(english, "نقطة AI", "AI point")
                        else -> localizedText(english, "تعادل", "Tie")
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(if (english) slot.titleEn else slot.titleAr, color = Gold, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    mine?.let { PlayerPortrait(it, Modifier.fillMaxWidth().height(82.dp), cornerRadius = 10) }
                                    Text(
                                        "${localizedText(english, "فريقك:", "You:")} ${mine?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) } ?: "-"}  •  ${mine?.rating ?: 0}",
                                        color = Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    rival?.let { PlayerPortrait(it, Modifier.fillMaxWidth().height(82.dp), cornerRadius = 10) }
                                    Text(
                                        "${localizedText(english, "AI:", "AI:")} ${rival?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) } ?: "-"}  •  ${rival?.rating ?: 0}",
                                        color = Cream, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(winner, color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Text(localizedText(english, "إجمالي تقييم فريقك: $totalUserRating", "Your squad rating total: $totalUserRating"), color = Cream)
                Text(localizedText(english, "إجمالي تقييم AI: $totalAiRating", "AI squad rating total: $totalAiRating"), color = Muted)
                Button(
                    onClick = { phase = BuildPhase.Setup; searchText = ""; playerTeam.clear(); aiTeam.clear(); currentChallenge = null },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "ابدأ تحديًا جديدًا", "Start a new challenge")) }
            }
        }
    }
}
