package com.mostafabek.elbashagames

/**
 * Shared ELBASHA player pool. Ratings represent each player's prime, not their current age/current form.
 * FC 27 Icon/Hero card OVR is preferred when an eligible special item exists; otherwise the
 * closest available peak standard FIFA/FC OVR is used as the historical reference.
 * The pool deliberately has no arbitrary 75 floor and no special 99 override for any player.
 */
data class PlayerCard(
    val nameEn: String, val nameAr: String, val position: String,
    val rating: Int, val price: Int, val flag: String,
    val nationalityAr: String = "", val nationalityEn: String = ""
)

object PlayerDatabase {
    val players: List<PlayerCard> = listOf(
        PlayerCard("Manuel Neuer", "مانويل نوير", "GK", 92, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Iker Casillas", "إيكر كاسياس", "GK", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Gianluigi Buffon", "جانلويجي بوفون", "GK", 92, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Petr Cech", "بيتر تشيك", "GK", 88, 8, "🇨🇿", "التشيك", "Czechia"),
        PlayerCard("Thibaut Courtois", "تيبو كورتوا", "GK", 92, 10, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Alisson Becker", "أليسون بيكر", "GK", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ederson", "إيدرسون", "GK", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jan Oblak", "يان أوبلاك", "GK", 91, 9, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Marc-Andre ter Stegen", "مارك أندريه تير شتيجن", "GK", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Emiliano Martinez", "إيميليانو مارتينيز", "GK", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("David de Gea", "دافيد دي خيا", "GK", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Keylor Navas", "كيلور نافاس", "GK", 90, 9, "🇨🇷", "كوستاريكا", "Costa Rica"),
        PlayerCard("Hugo Lloris", "هوجو لوريس", "GK", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Oliver Kahn", "أوليفر كان", "GK", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Peter Schmeichel", "بيتر شمايكل", "GK", 89, 9, "🇩🇰", "الدنمارك", "Denmark"),
        PlayerCard("Dida", "ديدا", "GK", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Jose Luis Chilavert", "خوسيه لويس تشيلافيرت", "GK", 88, 8, "🇵🇾", "باراغواي", "Paraguay"),
        PlayerCard("Rene Higuita", "رينيه هيجيتا", "GK", 87, 8, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("David Raya", "دافيد رايا", "GK", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Essam El Hadary", "عصام الحضري", "GK", 86, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Yassine Bounou", "ياسين بونو", "GK", 88, 8, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Mike Maignan", "مايك مانيان", "GK", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gianluigi Donnarumma", "جيانلويجي دوناروما", "GK", 92, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Unai Simon", "أوناي سيمون", "GK", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jordan Pickford", "جوردان بيكفورد", "GK", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Andre Onana", "أندريه أونانا", "GK", 87, 8, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Samir Handanovic", "سمير هاندانوفيتش", "GK", 91, 9, "🇸🇮", "سلوفينيا", "Slovenia"),
        PlayerCard("Edwin van der Sar", "إدوين فان دير سار", "GK", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Claudio Bravo", "كلاوديو برافو", "GK", 88, 8, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("Walter Zenga", "والتر زينجا", "GK", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jorge Campos", "خورخي كامبوس", "GK", 87, 8, "🇲🇽", "المكسيك", "Mexico"),
        PlayerCard("David Seaman", "ديفيد سيمان", "GK", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Victor Valdes", "فيكتور فالديس", "GK", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Shaka Hislop", "شاكا هيسلوب", "GK", 78, 5, "🇹🇹", "ترينيداد وتوباغو", "Trinidad and Tobago"),
        PlayerCard("Paolo Maldini", "باولو مالديني", "DF", 93, 10, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Sergio Ramos", "سيرخيو راموس", "DF", 93, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Virgil van Dijk", "فيرجيل فان دايك", "DF", 91, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franco Baresi", "فرانكو باريزي", "DF", 91, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Alessandro Nesta", "أليساندرو نيستا", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Fabio Cannavaro", "فابيو كانافارو", "DF", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Carles Puyol", "كارليس بويول", "DF", 89, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rio Ferdinand", "ريو فرديناند", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Nemanja Vidic", "نيمانيا فيديتش", "DF", 88, 8, "🇷🇸", "صربيا", "Serbia"),
        PlayerCard("John Terry", "جون تيري", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Gerard Pique", "جيرارد بيكيه", "DF", 91, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Thiago Silva", "تياغو سيلفا", "DF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ruben Dias", "روبن دياز", "DF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Antonio Rudiger", "أنطونيو روديجر", "DF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Achraf Hakimi", "أشرف حكيمي", "DF", 91, 9, "🇲🇦", "المغرب", "Morocco"),
        PlayerCard("Trent Alexander-Arnold", "ترنت ألكسندر أرنولد", "DF", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Dani Alves", "داني ألفيش", "DF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Cafu", "كافو", "DF", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Roberto Carlos", "روبرتو كارلوس", "DF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Marcelo", "مارسيلو", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ashley Cole", "آشلي كول", "DF", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Philipp Lahm", "فيليب لام", "DF", 89, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Javier Zanetti", "خافيير زانيتي", "DF", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Raphael Varane", "رافاييل فاران", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("William Saliba", "ويليام ساليبا", "DF", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Alessandro Bastoni", "أليساندرو باستوني", "DF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Kim Min-jae", "كيم مين جاي", "DF", 87, 8, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Ronald Araujo", "رونالد أراوخو", "DF", 89, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("John Stones", "جون ستونز", "DF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Kyle Walker", "كايل ووكر", "DF", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Theo Hernandez", "ثيو هيرنانديز", "DF", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andrew Robertson", "أندرو روبرتسون", "DF", 90, 9, "🇬🇧", "اسكتلندا", "Scotland"),
        PlayerCard("Giorgio Chiellini", "جورجيو كيليني", "DF", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Leonardo Bonucci", "ليوناردو بونوتشي", "DF", 90, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Jaap Stam", "ياب ستام", "DF", 87, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Nuno Mendes", "نونو مينديز", "DF", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Gabriel Magalhaes", "جابرييل ماجالهايس", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Willian Pacho", "ويليان باتشو", "DF", 88, 8, "🇪🇨", "الإكوادور", "Ecuador"),
        PlayerCard("Lilian Thuram", "ليليان تورام", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Marcel Desailly", "مارسيل ديسايي", "DF", 89, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sol Campbell", "سول كامبل", "DF", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Wael Gomaa", "وائل جمعة", "DF", 86, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Lucio", "لوسيو", "DF", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Carlos Alberto", "كارلوس ألبرتو", "DF", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Zinedine Zidane", "زين الدين زيدان", "MF", 94, 11, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Andres Iniesta", "أندريس إنييستا", "MF", 92, 10, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Xavi Hernandez", "تشافي هيرنانديز", "MF", 91, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Luka Modric", "لوكا مودريتش", "MF", 92, 10, "🇭🇷", "كرواتيا", "Croatia"),
        PlayerCard("Toni Kroos", "توني كروس", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Andrea Pirlo", "أندريا بيرلو", "MF", 91, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Steven Gerrard", "ستيفن جيرارد", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Frank Lampard", "فرانك لامبارد", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Paul Scholes", "بول سكولز", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Patrick Vieira", "باتريك فييرا", "MF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Claude Makelele", "كلود ماكيليلي", "MF", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Sergio Busquets", "سيرجيو بوسكيتس", "MF", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Rodri", "رودري", "MF", 91, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Kevin De Bruyne", "كيفن دي بروين", "MF", 94, 11, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Jude Bellingham", "جود بيلينجهام", "MF", 91, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Pedri", "بيدري", "MF", 91, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Jamal Musiala", "جمال موسيالا", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Federico Valverde", "فيديريكو فالفيردي", "MF", 90, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Declan Rice", "ديكلان رايس", "MF", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Bruno Fernandes", "برونو فيرنانديز", "MF", 91, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Yaya Toure", "يايا توريه", "MF", 88, 8, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Clarence Seedorf", "كلارنس سيدورف", "MF", 90, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Kaka", "كاكا", "MF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ronaldinho", "رونالدينيو", "MF", 93, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Rivaldo", "ريفالدو", "MF", 90, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Michel Platini", "ميشيل بلاتيني", "MF", 93, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Lothar Matthaus", "لوثار ماتيوس", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Roy Keane", "روي كين", "MF", 90, 9, "🇮🇪", "أيرلندا", "Ireland"),
        PlayerCard("Cesc Fabregas", "سيسك فابريجاس", "MF", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mesut Ozil", "مسعود أوزيل", "MF", 90, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("David Silva", "دافيد سيلفا", "MF", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bastian Schweinsteiger", "باستيان شفاينشتايجر", "MF", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Mohamed Aboutrika", "محمد أبو تريكة", "MF", 88, 8, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Xabi Alonso", "تشابي ألونسو", "MF", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bobby Charlton", "بوبي تشارلتون", "MF", 92, 10, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Vitinha", "فيتينيا", "MF", 90, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joao Neves", "جواو نيفيز", "MF", 88, 8, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Joshua Kimmich", "جوشوا كيميش", "MF", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Florian Wirtz", "فلوريان فيرتز", "MF", 91, 9, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Martin Odegaard", "مارتن أوديجارد", "MF", 90, 9, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Enzo Fernandez", "إنزو فيرنانديز", "MF", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Jay-Jay Okocha", "جاي جاي أوكوشا", "MF", 90, 9, "🇳🇬", "نيجيريا", "Nigeria"),
        PlayerCard("Michael Essien", "مايكل إيسيان", "MF", 88, 8, "🇬🇭", "غانا", "Ghana"),
        PlayerCard("N'Golo Kante", "نجولو كانتي", "MF", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gennaro Gattuso", "جينارو جاتوزو", "MF", 88, 8, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Park Ji-sung", "بارك جي سونغ", "MF", 87, 8, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Shinji Kagawa", "شينجي كاغاوا", "MF", 88, 8, "🇯🇵", "اليابان", "Japan"),
        PlayerCard("Frank Rijkaard", "فرانك ريكارد", "MF", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Lionel Messi", "ليونيل ميسي", "WG", 94, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Cristiano Ronaldo", "كريستيانو رونالدو", "WG", 94, 11, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Mohamed Salah", "محمد صلاح", "WG", 91, 9, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Neymar Jr", "نيمار", "WG", 93, 10, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Riyad Mahrez", "رياض محرز", "WG", 89, 9, "🇩🇿", "الجزائر", "Algeria"),
        PlayerCard("Kylian Mbappe", "كيليان مبابي", "WG", 93, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Vinicius Junior", "فينيسيوس جونيور", "WG", 91, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Lamine Yamal", "لامين يامال", "WG", 90, 9, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Bukayo Saka", "بوكايو ساكا", "WG", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Son Heung-min", "سون هيونج مين", "WG", 91, 9, "🇰🇷", "كوريا الجنوبية", "South Korea"),
        PlayerCard("Arjen Robben", "أريين روبن", "WG", 92, 10, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Franck Ribery", "فرانك ريبيري", "WG", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Gareth Bale", "جاريث بيل", "WG", 88, 8, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Eden Hazard", "إيدين هازارد", "WG", 91, 9, "🇧🇪", "بلجيكا", "Belgium"),
        PlayerCard("Luis Figo", "لويس فيجو", "WG", 90, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("George Best", "جورج بست", "WG", 90, 9, "🇬🇧", "أيرلندا الشمالية", "Northern Ireland"),
        PlayerCard("Ryan Giggs", "ريان جيجز", "WG", 90, 9, "🇬🇧", "ويلز", "Wales"),
        PlayerCard("Luis Suarez", "لويس سواريز", "WG", 92, 10, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Sadio Mane", "ساديو ماني", "WG", 91, 9, "🇸🇳", "السنغال", "Senegal"),
        PlayerCard("Raphinha", "رافينيا", "WG", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Ousmane Dembele", "عثمان ديمبيلي", "WG", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Khvicha Kvaratskhelia", "خفيتشا كفاراتسخيليا", "WG", 89, 9, "🇬🇪", "جورجيا", "Georgia"),
        PlayerCard("Angel Di Maria", "أنخيل دي ماريا", "WG", 90, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alexis Sanchez", "أليكسيس سانشيز", "WG", 89, 9, "🇨🇱", "تشيلي", "Chile"),
        PlayerCard("David Beckham", "ديفيد بيكهام", "WG", 88, 8, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Stanley Matthews", "ستانلي ماثيوز", "WG", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Hristo Stoichkov", "خريستو ستويتشكوف", "WG", 89, 9, "🇧🇬", "بلغاريا", "Bulgaria"),
        PlayerCard("Robert Pires", "روبير بيريس", "WG", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Pierre-Emerick Aubameyang", "بيير إيمريك أوباميانج", "WG", 90, 9, "🇬🇦", "الغابون", "Gabon"),
        PlayerCard("Raheem Sterling", "رحيم سترلينج", "WG", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Michael Olise", "مايكل أوليسيه", "WG", 90, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Luis Diaz", "لويس دياز", "WG", 89, 9, "🇨🇴", "كولومبيا", "Colombia"),
        PlayerCard("Rayan Cherki", "ريان شرقي", "WG", 88, 8, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Nani", "ناني", "WG", 89, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Pedro Rodriguez", "بيدرو رودريغيز", "WG", 88, 8, "🇪🇸", "إسبانيا", "Spain"),
        PlayerCard("Mohamed Zidan", "محمد زيدان", "WG", 86, 7, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Angel Correa", "أنخيل كوريا", "WG", 88, 8, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Pele", "بيليه", "ST", 95, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Diego Maradona", "دييجو مارادونا", "ST", 95, 11, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Ronaldo Nazario", "رونالدو نازاريو", "ST", 94, 11, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Thierry Henry", "تييري هنري", "ST", 91, 9, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Didier Drogba", "ديدييه دروجبا", "ST", 89, 9, "🇨🇮", "ساحل العاج", "Ivory Coast"),
        PlayerCard("Samuel Eto'o", "صامويل إيتو", "ST", 89, 9, "🇨🇲", "الكاميرون", "Cameroon"),
        PlayerCard("Robert Lewandowski", "روبرت ليفاندوفسكي", "ST", 92, 10, "🇵🇱", "بولندا", "Poland"),
        PlayerCard("Karim Benzema", "كريم بنزيما", "ST", 92, 10, "🇫🇷", "فرنسا", "France"),
        PlayerCard("Erling Haaland", "إيرلينج هالاند", "ST", 91, 9, "🇳🇴", "النرويج", "Norway"),
        PlayerCard("Harry Kane", "هاري كين", "ST", 91, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Zlatan Ibrahimovic", "زلاتان إبراهيموفيتش", "ST", 92, 10, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Wayne Rooney", "واين روني", "ST", 90, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Ruud van Nistelrooy", "رود فان نيستلروي", "ST", 89, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Marco van Basten", "ماركو فان باستن", "ST", 91, 9, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Gerd Muller", "جيرد مولر", "ST", 92, 10, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Eusebio", "يوزيبيو", "ST", 91, 9, "🇵🇹", "البرتغال", "Portugal"),
        PlayerCard("Ferenc Puskas", "فيرينتس بوشكاش", "ST", 92, 10, "🇭🇺", "المجر", "Hungary"),
        PlayerCard("Romario", "روماريو", "ST", 89, 9, "🇧🇷", "البرازيل", "Brazil"),
        PlayerCard("Gabriel Batistuta", "جابرييل باتيستوتا", "ST", 89, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Alan Shearer", "آلان شيرر", "ST", 89, 9, "🇬🇧", "المملكة المتحدة", "United Kingdom"),
        PlayerCard("Sergio Aguero", "سيرخيو أجويرو", "ST", 90, 9, "🇦🇷", "الأرجنتين", "Argentina"),
        PlayerCard("Viktor Gyokeres", "فيكتور جيوكيريس", "ST", 88, 8, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Alexander Isak", "ألكسندر إيزاك", "ST", 88, 8, "🇸🇪", "السويد", "Sweden"),
        PlayerCard("Hossam Hassan", "حسام حسن", "ST", 88, 8, "🇪🇬", "مصر", "Egypt"),
        PlayerCard("Miroslav Klose", "ميروسلاف كلوزه", "ST", 88, 8, "🇩🇪", "ألمانيا", "Germany"),
        PlayerCard("Robin van Persie", "روبن فان بيرسي", "ST", 88, 8, "🇳🇱", "هولندا", "Netherlands"),
        PlayerCard("Filippo Inzaghi", "فيليبو إنزاغي", "ST", 89, 9, "🇮🇹", "إيطاليا", "Italy"),
        PlayerCard("Edinson Cavani", "إدينسون كافاني", "ST", 90, 9, "🇺🇾", "أوروغواي", "Uruguay"),
        PlayerCard("Hernan Crespo", "هرنان كريسبو", "ST", 88, 8, "🇦🇷", "الأرجنتين", "Argentina"),
    )

    init {
        require(players.size == 192)
        require(players.all { it.rating in 1..99 })
        require(players.map { it.nameEn }.distinct().size == players.size)
    }
}


/** Canonical squad order shared by all player-picking games. */
object ElbashaPositions {
    val rosterOrder = listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "CAM", "RW", "LW", "ST")

    /** Legacy database roles are broad; map them to the requested tactical slot family. */
    fun poolRole(slot: String): String = when (slot) {
        "GK" -> "GK"
        "RB", "CB", "LB" -> "DF"
        "CDM", "CM", "CAM" -> "MF"
        "RW", "LW" -> "WG"
        "ST" -> "ST"
        else -> ""
    }

    fun supports(player: PlayerCard, slot: String): Boolean = player.position == poolRole(slot)

    /** Creates a position-ordered auction lot pool, without repeating a player. */
    fun auctionPool(size: Int, total: Int): List<PlayerCard> {
        val used = mutableSetOf<String>()
        val ordered = mutableListOf<PlayerCard>()
        rosterOrder.take(size.coerceIn(1, rosterOrder.size)).forEach { slot ->
            val candidates = PlayerDatabase.players
                .filter { supports(it, slot) && it.nameEn !in used }
                .shuffled()
                .take(1)
            candidates.forEach { player ->
                if (used.add(player.nameEn)) ordered.add(player.copy(position = slot))
            }
        }
        return ordered.take(minOf(size, total))
    }
}
