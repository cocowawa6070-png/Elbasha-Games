package com.mostafabek.elbashagames

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Player headshots are resolved from Wikipedia's free page-image metadata, then cached locally.
 * We deliberately show a neutral fallback when no suitable footballer image is returned.
 */
object PlayerImageRepository {
    private const val TAG = "PlayerImageRepository"
    private const val API = "https://en.wikipedia.org/w/api.php"
    private const val USER_AGENT = "ELBASHA-GAMES/0.3 (Android; player portrait lookup)"
    private const val URL_CACHE_MS = 30L * 24L * 60L * 60L * 1000L
    private const val NEGATIVE_CACHE_MS = 6L * 60L * 60L * 1000L
    private val memory = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount.coerceAtLeast(1)
    }
    private val aliases = mapOf(
        "Neymar Jr" to "Neymar",
        "Pele" to "Pelé",
        "Eusebio" to "Eusébio",
        "Ronaldo Nazario" to "Ronaldo (Brazilian footballer)",
        "Marc-Andre ter Stegen" to "Marc-André ter Stegen",
        "Jose Luis Chilavert" to "José Luis Chilavert",
        "Rene Higuita" to "René Higuita",
        "Gerd Muller" to "Gerd Müller",
        "Ferenc Puskas" to "Ferenc Puskás",
        "Kaka" to "Kaká",
        "Victor Valdes" to "Víctor Valdés",
        "N'Golo Kante" to "N'Golo Kanté",
        "Pedro Rodriguez" to "Pedro (footballer, born 1987)",
        "Hernan Crespo" to "Hernán Crespo",
        "David Raya" to "David Raya",
        "Lucio" to "Lúcio",
        "Carlos Alberto" to "Carlos Alberto Torres",
        "Xabi Alonso" to "Xabi Alonso",
        "Bobby Charlton" to "Bobby Charlton",
        "Frank Rijkaard" to "Frank Rijkaard",
        "Iker Casillas" to "Iker Casillas",
        "Gianluigi Buffon" to "Gianluigi Buffon",
        "Paolo Maldini" to "Paolo Maldini",
        "Franco Baresi" to "Franco Baresi",
        "Fabio Cannavaro" to "Fabio Cannavaro",
        "Lothar Matthaus" to "Lothar Matthäus",
        "Zinedine Zidane" to "Zinedine Zidane",
        "Andres Iniesta" to "Andrés Iniesta",
        "Xavi Hernandez" to "Xavi",
        "Diego Maradona" to "Diego Maradona",
        "Hristo Stoichkov" to "Hristo Stoichkov",
        "Jay-Jay Okocha" to "Jay-Jay Okocha"
    )

    suspend fun load(context: Context, playerName: String): Bitmap? = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val key = digest(playerName)
        memory.get(key)?.let { return@withContext it }
        val folder = File(appContext.cacheDir, "player_portraits").apply { mkdirs() }
        val imageFile = File(folder, "$key.jpg")
        if (imageFile.isFile && imageFile.length() > 2_000) {
            BitmapFactory.decodeFile(imageFile.absolutePath)?.let {
                memory.put(key, it)
                return@withContext it
            }
        }

        val prefs = appContext.getSharedPreferences("player_image_cache", Context.MODE_PRIVATE)
        val cacheKey = "image:$key"
        val cached = prefs.getString(cacheKey, null)
        val now = System.currentTimeMillis()
        val imageUrl = when {
            cached == null -> resolveImageUrl(playerName)
            cached.startsWith("none:") -> {
                val timestamp = cached.substringAfter(':').toLongOrNull() ?: 0L
                if (now - timestamp < NEGATIVE_CACHE_MS) return@withContext null
                resolveImageUrl(playerName)
            }
            cached.startsWith("url:") -> {
                val parts = cached.split(':', limit = 3)
                val timestamp = parts.getOrNull(1)?.toLongOrNull() ?: 0L
                if (now - timestamp < URL_CACHE_MS) parts.getOrNull(2) else resolveImageUrl(playerName)
            }
            else -> resolveImageUrl(playerName)
        }
        if (imageUrl.isNullOrBlank()) {
            prefs.edit().putString(cacheKey, "none:$now").apply()
            return@withContext null
        }
        prefs.edit().putString(cacheKey, "url:$now:$imageUrl").apply()
        val bytes = download(imageUrl)
        if (bytes == null) {
            prefs.edit().putString(cacheKey, "none:$now").apply()
            return@withContext null
        }
        runCatching { imageFile.writeBytes(bytes) }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bitmap != null) memory.put(key, bitmap) else imageFile.delete()
        bitmap
    }

    private fun resolveImageUrl(playerName: String): String? {
        val title = aliases[playerName] ?: playerName
        val exactUrl = buildString {
            append(API)
            append("?action=query&format=json&formatversion=2&redirects=1")
            append("&prop=pageimages%7Cpageterms&piprop=thumbnail&pithumbsize=512&pilicense=free")
            append("&wbptterms=description&titles=")
            append(URLEncoder.encode(title, "UTF-8"))
        }
        val exact = requestPageImage(exactUrl, playerName)
        if (exact != null) return exact

        // Search fallback is constrained to footballer descriptions to avoid unrelated namesakes.
        val search = URLEncoder.encode("\"$playerName\" footballer", "UTF-8")
        val searchUrl = "$API?action=query&format=json&formatversion=2&generator=search&gsrnamespace=0&gsrlimit=5&gsrsearch=$search&prop=pageimages%7Cpageterms&piprop=thumbnail&pithumbsize=512&pilicense=free&wbptterms=description"
        return requestPageImage(searchUrl, playerName)
    }

    private fun requestPageImage(endpoint: String, playerName: String): String? {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7_000
            readTimeout = 7_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (connection.responseCode !in 200..299) return null
            val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val pages = JSONObject(json).optJSONObject("query")?.optJSONArray("pages") ?: return null
            for (index in 0 until pages.length()) {
                val page = pages.optJSONObject(index) ?: continue
                if (page.has("missing")) continue
                val terms = page.optJSONObject("terms")
                val description = terms?.optJSONArray("description")?.optString(0).orEmpty()
                val normalizedDescription = description.lowercase()
                val pageTitle = page.optString("title").trim()
                val normalizedTitle = pageTitle.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
                val normalizedPlayer = playerName.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
                val exactPlayerPage = normalizedTitle == normalizedPlayer ||
                    normalizedTitle.startsWith("$normalizedPlayer ") ||
                    (aliases[playerName]?.lowercase()?.replace(Regex("[^a-z0-9]+"), " ")?.trim() == normalizedTitle)
                val isFootballer = exactPlayerPage || listOf(
                    "footballer", "football player", "association football", "goalkeeper",
                    "soccer player", "football manager", "football coach"
                ).any { normalizedDescription.contains(it) }
                if (!isFootballer) continue
                val source = page.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.startsWith("https://upload.wikimedia.org/") }
                if (source != null) return source
            }
            null
        } catch (error: Exception) {
            Log.w(TAG, "Could not resolve portrait for $playerName", error)
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun download(imageUrl: String): ByteArray? {
        val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            setRequestProperty("User-Agent", USER_AGENT)
            setRequestProperty("Accept", "image/*")
        }
        return try {
            if (connection.responseCode !in 200..299) return null
            val type = connection.contentType.orEmpty()
            if (!type.startsWith("image/")) return null
            connection.inputStream.use { input ->
                val bytes = input.readBytes()
                if (bytes.size !in 2_000..4_000_000) null else bytes
            }
        } catch (error: Exception) {
            Log.w(TAG, "Could not download player portrait", error)
            null
        } finally {
            connection.disconnect()
        }
    }

    fun cachedCount(context: Context): Int = File(context.applicationContext.cacheDir, "player_portraits")
        .listFiles()?.count { it.isFile && it.extension.equals("jpg", ignoreCase = true) } ?: 0

    fun cachedBytes(context: Context): Long = File(context.applicationContext.cacheDir, "player_portraits")
        .listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L

    fun clearCache(context: Context) {
        File(context.applicationContext.cacheDir, "player_portraits").deleteRecursively()
        context.applicationContext.getSharedPreferences("player_image_cache", Context.MODE_PRIVATE)
            .edit().clear().apply()
        memory.evictAll()
    }

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .take(12)
        .joinToString("") { "%02x".format(it) }
}

@Composable
fun PlayerPortrait(
    player: PlayerCard,
    modifier: Modifier = Modifier,
    cornerRadius: Int = 14
) {
    val context = LocalContext.current
    val palette = LocalElbashaPalette.current
    val bitmapState = produceState<Bitmap?>(initialValue = null, player.nameEn) {
        value = PlayerImageRepository.load(context, player.nameEn)
    }
    Box(
        modifier = modifier.clip(RoundedCornerShape(cornerRadius.dp))
            .background(Brush.verticalGradient(listOf(palette.gold.copy(alpha = 0.30f), palette.deepWine, palette.panelAlt))),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = bitmapState.value
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "${player.nameEn} portrait (Wikipedia)",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.align(Alignment.BottomEnd).background(Color.Black.copy(alpha = 0.58f))) {
                Text("WIKI", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            val initials = player.nameEn.split(" ").filter { it.isNotBlank() }.take(2).mapNotNull { it.firstOrNull()?.toString() }.joinToString("").uppercase()
            Text(initials.ifBlank { "⚽" }, color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
        }
    }
}
