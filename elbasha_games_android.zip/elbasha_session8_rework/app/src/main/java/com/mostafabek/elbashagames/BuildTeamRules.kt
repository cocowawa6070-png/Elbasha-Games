package com.mostafabek.elbashagames

import kotlin.random.Random

data class NationalityChallenge(
    val nationalityAr: String,
    val nationalityEn: String,
    val positionCode: String,
    val positionAr: String,
    val positionEn: String
)

/** Pure challenge and draft rules for Build Team, kept separate from Compose state. */
object BuildTeamRules {
    private val positionLabels = mapOf(
        "GK" to ("حارس مرمى" to "Goalkeeper"),
        "RB" to ("ظهير أيمن" to "Right Back"),
        "CB" to ("قلب دفاع" to "Centre Back"),
        "LB" to ("ظهير أيسر" to "Left Back"),
        "CDM" to ("وسط دفاعي" to "Defensive Midfielder"),
        "CM" to ("وسط" to "Central Midfielder"),
        "CAM" to ("وسط هجومي" to "Attacking Midfielder"),
        "RW" to ("جناح أيمن" to "Right Winger"),
        "LW" to ("جناح أيسر" to "Left Winger"),
        "ST" to ("مهاجم" to "Striker")
    )

    fun createNationalityChallenge(
        players: List<PlayerCard>,
        positionCode: String,
        excludedNames: Set<String>,
        random: Random = Random.Default
    ): NationalityChallenge? {
        val groups = players.filter {
            ElbashaPositions.supports(it, positionCode) && it.nameEn !in excludedNames &&
                it.nationalityEn.isNotBlank() && it.nationalityAr.isNotBlank()
        }.groupBy { it.nationalityEn }.filterValues { it.size >= 2 }
        val chosen = groups.entries.randomOrNull(random) ?: return null
        val labels = positionLabels[positionCode] ?: return null
        val sample = chosen.value.first()
        return NationalityChallenge(
            nationalityAr = sample.nationalityAr,
            nationalityEn = chosen.key,
            positionCode = positionCode,
            positionAr = labels.first,
            positionEn = labels.second
        )
    }

    fun eligiblePlayers(
        players: List<PlayerCard>,
        challenge: NationalityChallenge,
        excludedNames: Set<String>
    ): List<PlayerCard> = players.filter {
        ElbashaPositions.supports(it, challenge.positionCode) &&
            it.nationalityEn == challenge.nationalityEn &&
            it.nameEn !in excludedNames
    }

    /** Easy chooses from a wider rating band; higher difficulty concentrates near the top. */
    fun chooseAiPlayer(
        candidates: List<PlayerCard>,
        difficulty: Int,
        random: Random = Random.Default
    ): PlayerCard? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.sortedByDescending { it.rating }
        val poolRatio = when (difficulty.coerceIn(0, 3)) {
            0 -> 0.78
            1 -> 0.60
            2 -> 0.38
            else -> 0.20
        }
        val poolSize = (ranked.size * poolRatio).toInt().coerceAtLeast(1)
        return ranked.take(poolSize).randomOrNull(random)
    }
}
