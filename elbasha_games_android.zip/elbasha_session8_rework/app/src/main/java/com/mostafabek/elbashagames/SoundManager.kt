package com.mostafabek.elbashagames

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.io.File
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Sfx { Correct, Wrong, Win, Loss, Tick, Click, HiddenReveal }

/** Shared game effects plus developer-managed group music. */
class SoundManager(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("elbasha_audio", Context.MODE_PRIVATE)

    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set

    var musicOn by mutableStateOf(prefs.getBoolean("music", true))
        private set

    private var musicPlayer: MediaPlayer? = null
    private var musicPrepared = false
    private var musicPath: String? = null
    private var appInForeground = true

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(3)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val loadedSounds = mutableSetOf<Int>()
    private val pendingSounds = mutableSetOf<Int>()
    private val effectIds: Map<Sfx, Int>

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                loadedSounds.add(sampleId)
                if (pendingSounds.remove(sampleId) && soundOn) pool.play(sampleId, 1f, 1f, 1, 0, 1f)
            }
        }
        effectIds = mapOf(
            Sfx.Correct to pool.load(app, R.raw.sfx_correct, 1),
            Sfx.Wrong to pool.load(app, R.raw.sfx_wrong, 1),
            Sfx.Win to pool.load(app, R.raw.sfx_win, 1),
            Sfx.Loss to pool.load(app, R.raw.sfx_loss, 1),
            Sfx.Tick to pool.load(app, R.raw.sfx_tick, 1),
            Sfx.Click to pool.load(app, R.raw.sfx_click, 1),
            Sfx.HiddenReveal to pool.load(app, R.raw.sfx_hidden_reveal, 1)
        )
    }

    fun play(effect: Sfx) {
        if (!soundOn) return
        effectIds[effect]?.let { id ->
            if (id in loadedSounds) pool.play(id, 1f, 1f, 1, 0, 1f) else pendingSounds.add(id)
        }
    }

    @Suppress("DEPRECATION")
    fun vibrate(milliseconds: Long = 30L) {
        if (!soundOn) return
        val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else vibrator.vibrate(milliseconds)
    }

    fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound", soundOn).apply()
    }

    fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        val player = musicPlayer ?: return
        if (musicOn && musicPrepared && appInForeground) runCatching { if (!player.isPlaying) player.start() }
        else runCatching { if (player.isPlaying) player.pause() }
    }

    /** Plays the latest music file distributed through the shared Realtime Database node. */
    fun setSharedMusic(file: File) {
        if (!file.isFile || file.length() == 0L) return
        if (musicPath == file.absolutePath && musicPlayer != null) return
        runCatching { musicPlayer?.release() }
        musicPlayer = null
        musicPrepared = false
        musicPath = file.absolutePath
        val player = MediaPlayer()
        musicPlayer = player
        try {
            player.setDataSource(file.absolutePath)
            player.isLooping = true
            player.setOnPreparedListener { ready ->
                if (musicPlayer === ready) {
                    musicPrepared = true
                    if (musicOn && appInForeground) runCatching { ready.start() }
                }
            }
            player.setOnErrorListener { failed, _, _ ->
                if (musicPlayer === failed) musicPrepared = false
                true
            }
            player.prepareAsync()
        } catch (_: Exception) {
            runCatching { player.release() }
            if (musicPlayer === player) musicPlayer = null
            musicPrepared = false
        }
    }

    fun clearSharedMusic() {
        runCatching { musicPlayer?.release() }
        musicPlayer = null
        musicPrepared = false
        musicPath = null
    }

    @Suppress("DEPRECATION")
    fun onPause() {
        appInForeground = false
        pool.autoPause()
        pendingSounds.clear()
        val player = musicPlayer
        if (player != null) runCatching { if (player.isPlaying) player.pause() }
    }

    @Suppress("DEPRECATION")
    fun onResume() {
        appInForeground = true
        pool.autoResume()
        val player = musicPlayer
        if (musicOn && musicPrepared && player != null) runCatching { if (!player.isPlaying) player.start() }
    }

    fun release() {
        clearSharedMusic()
        pool.release()
    }
}

@Composable
fun SoundToggles(sound: SoundManager) {
    Row {
        ToggleChip(if (sound.soundOn) "🔊" else "🔕") { sound.toggleSound() }
        ToggleChip(if (sound.musicOn) "🎵" else "🚫🎵") { sound.toggleMusic() }
    }
}

@Composable
private fun ToggleChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(PanelColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(label, fontSize = 16.sp) }
}
