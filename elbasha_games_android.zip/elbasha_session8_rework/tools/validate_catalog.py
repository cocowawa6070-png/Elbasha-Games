#!/usr/bin/env python3
"""Fast source-level checks for the ELBASHA player catalog and MVP scope."""
from pathlib import Path
import json
import re
import random
import xml.etree.ElementTree as ET
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "app/src/main/java/com/mostafabek/elbashagames"
players_source = (BASE / "PlayerDatabase.kt").read_text(encoding="utf-8")
search_source = (BASE / "PlayerSearch.kt").read_text(encoding="utf-8")
build_source = (BASE / "BuildTeamGame.kt").read_text(encoding="utf-8")
ui_source = (BASE / "ElbashaUi.kt").read_text(encoding="utf-8")
questions_source = (BASE / "Questions.kt").read_text(encoding="utf-8")

players = re.findall(
    r'PlayerCard\("([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([A-Z]+)"\s*,\s*(\d+)\s*,\s*(\d+)\s*,',
    players_source,
)
if len(players) != 192:
    sys.exit(f"FAIL: expected 192 player records, found {len(players)}")

names = [p[0] for p in players]
if "🌍" in players_source:
    sys.exit("FAIL: player nationality flags still contain globe placeholders")
if len(re.findall(r'PlayerCard\("[^"]+"\s*,\s*"[^"]+"\s*,\s*"[A-Z]+"\s*,\s*\d+\s*,\s*\d+\s*,\s*"[^"]+"\s*,\s*"[^"]+"\s*,\s*"[^"]+"\)', players_source)) != 192:
    sys.exit("FAIL: all players must have bilingual nationality labels")
if len(names) != len(set(names)):
    sys.exit("FAIL: duplicate English player names")

arabic_names = [p[1] for p in players]
if len(arabic_names) != len(set(arabic_names)):
    sys.exit("FAIL: duplicate Arabic display names")
if any(not re.search(r"[\u0600-\u06FF]", name) for name in arabic_names):
    bad = [p[0] for p in players if not re.search(r"[\u0600-\u06FF]", p[1])]
    sys.exit(f"FAIL: players missing Arabic display names: {bad}")

positions = {position: sum(1 for p in players if p[2] == position)
             for position in {p[2] for p in players}}
if positions != {"GK": 34, "DF": 44, "MF": 48, "WG": 37, "ST": 29}:
    sys.exit(f"FAIL: unexpected position distribution: {positions}")

ratings = {name: int(rating) for name, _, _, rating, _ in players}
prices = {name: int(price) for name, _, _, _, price in players}
if any(rating < 1 or rating > 99 for rating in ratings.values()):
    sys.exit("FAIL: player rating must be within the supported 1..99 range")
if ratings.get("Lionel Messi") != 94 or ratings.get("Cristiano Ronaldo") != 94:
    sys.exit("FAIL: Messi and Cristiano must use their historical prime base OVR, not a hardcoded 99")
expected_prices = {name: max(5, min(11, 5 + ((rating - 80) * 6 + 7) // 15)) for name, rating in ratings.items()}
if prices != expected_prices:
    sys.exit("FAIL: player prices must scale consistently with the prime OVR economy")
if any(name in names for name in ["Mohamed El Shenawy", "Ahmed Hegazi", "Mohamed Hany", "Hossam Ghaly", "Mohamed Elneny", "Ahmed Hassan"]):
    sys.exit("FAIL: the Egyptian-league-heavy entries scheduled for replacement remain in the catalog")

alias_pairs = dict(re.findall(r'"([^"]+)"\s+to\s+"([^"]+)"', search_source))
missing_aliases = sorted(set(names) - set(alias_pairs))
if missing_aliases:
    sys.exit(f"FAIL: missing Arabic search aliases: {missing_aliases}")
alias_mismatches = sorted(
    name for name, arabic, _, _, _ in players if alias_pairs.get(name) != arabic
)
if alias_mismatches:
    sys.exit(f"FAIL: Arabic display/search aliases differ: {alias_mismatches}")

if "PlayerSearch.normalize(searchText).length < 3" not in build_source:
    sys.exit("FAIL: Build Team search must enforce the 3-character threshold")
if "fun createNationalityChallenge" not in build_source or "fun chooseAiPlayer" not in build_source:
    sys.exit("FAIL: Build Team must provide nationality-based challenges and an AI draft")
if "صعب جدًا" not in build_source or "0.20" not in build_source:
    sys.exit("FAIL: Build Team must include the Very Hard AI level")
launch_source_for_ai = (BASE / "LaunchGames.kt").read_text(encoding="utf-8")
if "private fun auctionAiBidCeiling" not in launch_source_for_ai or launch_source_for_ai.count("AiDifficultyAr.indices") < 2:
    sys.exit("FAIL: Auction and Deal or No Deal must expose four AI difficulty levels")
if "else -> 2" not in launch_source_for_ai or "else -> 0.24" not in launch_source_for_ai:
    sys.exit("FAIL: Very Hard AI strategy settings are missing")
if "BuildPhase.Result" not in build_source or "ScoreRepository.submit(database, user, score)" not in build_source:
    sys.exit("FAIL: Build Team must finish with a result and submit a score")
if "sharedMusic" not in ui_source or 'musicPicker.launch(arrayOf("audio/*"))' not in ui_source:
    sys.exit("FAIL: developer music upload and shared Firebase playback are missing")
if "fun setSharedMusic(file: File)" not in (BASE / "SoundManager.kt").read_text(encoding="utf-8"):
    sys.exit("FAIL: shared music playback manager is missing")
firebase_rules = json.loads((ROOT / "firebase/database.rules.json").read_text(encoding="utf-8"))
shared_music_rules = firebase_rules["rules"].get("sharedMusic", {}).get("current", {})
if shared_music_rules.get(".read") != "auth != null" or "1NZfGRNjIOcpz3SmdBDdg3auJs82" not in shared_music_rules.get(".write", ""):
    sys.exit("FAIL: shared music must be readable by signed-in players and writable only by the developer")
if "7000000" not in shared_music_rules.get("data", {}).get(".validate", ""):
    sys.exit("FAIL: shared music data size guard is missing")
for screen_file in ["ElbashaUi.kt", "ArcadeGames.kt", "BuildTeamGame.kt", "LaunchGames.kt", "PenaltyShootout.kt", "TriviaGame.kt"]:
    if "elbashaAtmosphere()" not in (BASE / screen_file).read_text(encoding="utf-8"):
        sys.exit(f"FAIL: stadium background is not applied in {screen_file}")
match_engine = (BASE / "MatchEngine.kt").read_text(encoding="utf-8")
if "fun simulate(" not in match_engine or "userExpectedGoals" not in match_engine:
    sys.exit("FAIL: first-release games must use the shared probability-based match simulator")
if "positionalFit(team) * 6.0" not in match_engine or "fun positionalFit(team: List<PlayerCard>)" not in match_engine:
    sys.exit("FAIL: match simulation must account for coverage of the approved positional formation")
if "fun <T> suggestionsBy" not in search_source:
    sys.exit("FAIL: shared generic player suggestion engine is missing")

# The current Build Team MVP uses real nationality metadata. Verify that its
# 4..11-player formations can generate a two-player matchup for every slot.
player_meta = re.findall(
    r'PlayerCard\("([^"]+)"\s*,\s*"[^"]+"\s*,\s*"([A-Z]+)"\s*,\s*\d+\s*,\s*\d+\s*,\s*"[^"]+"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\)',
    players_source,
)
canonical_families = ["GK", "DF", "DF", "DF", "DF", "MF", "MF", "MF", "WG", "WG", "ST"]
formations = {size: canonical_families[:size] for size in range(4, 12)}

if len(player_meta) != 192:
    sys.exit(f"FAIL: expected nationality metadata for 192 players, found {len(player_meta)}")
for size, formation in formations.items():
    for trial in range(300):
        used = set()
        for position in formation:
            groups = {}
            for name, player_position, nationality_ar, nationality_en in player_meta:
                if player_position == position and name not in used and nationality_ar and nationality_en:
                    groups.setdefault(nationality_en, []).append(name)
            eligible_groups = [names_in_group for names_in_group in groups.values() if len(names_in_group) >= 2]
            if not eligible_groups:
                sys.exit(f"FAIL: Build Team cannot form a two-player nationality challenge (size={size}, position={position})")
            chosen_group = random.choice(eligible_groups)
            used.update(random.sample(chosen_group, 2))


catalog = re.findall(r'GameItem\("(auction|deal|build)"', ui_source)
if catalog != ["auction", "deal", "build"]:
    sys.exit(f"FAIL: first-release game catalog is not exactly Auction/Deal/Build Team: {catalog}")




strings_root = ET.parse(ROOT / "app/src/main/res/values/strings.xml").getroot()
string_values = {node.attrib.get("name"): (node.text or "").strip() for node in strings_root.findall("string")}
google_config = json.loads((ROOT / "app/google-services.json").read_text(encoding="utf-8"))
expected_database_url = google_config.get("project_info", {}).get("firebase_url", "").strip()
configured_database_url = string_values.get("firebase_database_url", "")
if not expected_database_url or configured_database_url != expected_database_url:
    sys.exit("FAIL: firebase_database_url must match project_info.firebase_url in google-services.json")
gradle_app_config = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
package_match = re.search(r'applicationId\s*=\s*"([^"]+)"', gradle_app_config)
configured_package = package_match.group(1) if package_match else ""
google_packages = {
    client.get("client_info", {}).get("android_client_info", {}).get("package_name")
    for client in google_config.get("client", [])
}
if not configured_package or configured_package not in google_packages:
    sys.exit("FAIL: Android applicationId must match a package in google-services.json")
web_client_ids = {
    oauth.get("client_id")
    for client in google_config.get("client", [])
    for oauth in client.get("oauth_client", [])
    if oauth.get("client_type") == 3
}
if not string_values.get("google_web_client_id") or string_values["google_web_client_id"] not in web_client_ids:
    sys.exit("FAIL: google_web_client_id must match an OAuth client of type 3 in google-services.json")

release_workflow = (ROOT / ".github/workflows/release.yml").read_text(encoding="utf-8")
if "github.run_number + 2" in release_workflow or "GITHUB_RUN_NUMBER + 2" not in release_workflow:
    sys.exit("FAIL: release workflow version code must be calculated in shell, not GitHub expression arithmetic")
if "python3 tools/validate_catalog.py" not in release_workflow:
    sys.exit("FAIL: release workflow must run source validation before publishing")
if "workflow_dispatch" in release_workflow:
    sys.exit("FAIL: release publishing should only run from version tags, not a branch dispatch")
if "APP_VERSION_CODE" not in release_workflow or "${{ steps.version.outputs.version_code }}" not in release_workflow or "id: version" not in release_workflow:
    sys.exit("FAIL: release workflow must pass the calculated version code to Gradle and release notes")


updater_source = (BASE / "AppUpdater.kt").read_text(encoding="utf-8")
if "isUpdateDownloadSuccessful(context, prefs.getLong(\"download_id\", -1L))" not in updater_source:
    sys.exit("FAIL: updater must verify DownloadManager success before launching the installer")
if "destination.delete()" not in updater_source:
    sys.exit("FAIL: updater must clear an old APK before downloading a replacement")
receiver_source = (BASE / "UpdateDownloadReceiver.kt").read_text(encoding="utf-8")
if "if (!isUpdateDownloadSuccessful(context, id)) return" not in receiver_source:
    sys.exit("FAIL: updater receiver must ignore failed DownloadManager transfers")

launch_source = (BASE / "LaunchGames.kt").read_text(encoding="utf-8")
if "grantHiddenPlayer(lot.position, toUser = true)" not in launch_source or "grantHiddenPlayer(lot.position, toUser = false)" not in launch_source:
    sys.exit("FAIL: auction must grant a same-position hidden bonus player to the losing side")
if "userCount: Int = bought.size + hiddenPlayers.size" not in launch_source or "aiCount: Int = aiBought.size + aiHiddenPlayers.size" not in launch_source:
    sys.exit("FAIL: auction completion must count purchased and hidden bonus players for both squads")
if "(currentBid - 2).coerceAtLeast(opening)" not in launch_source:
    sys.exit("FAIL: Wild Card must reduce the final paid amount without invalidating the opening bid")
if "currentBid += step" not in launch_source or "AI passed! You won the lot" not in launch_source or "aiMaxForLot" not in launch_source:
    sys.exit("FAIL: Auction must alternate bids and end when the AI passes")
if "You passed! AI won the lot" not in launch_source or "Sfx.HiddenReveal" not in launch_source:
    sys.exit("FAIL: Passing must award the lot, reveal the losing side's hidden player, and play its reveal effect")
if "remainingLots = remainingLots.filterNot { it.nameEn == hidden.nameEn }" not in launch_source:
    sys.exit("FAIL: hidden bonus player must be removed from future auction lots")
if "val lot = remainingLots.firstOrNull()" not in launch_source:
    sys.exit("FAIL: auction must advance through the remaining-lot queue")
if "userSquad.size + 1" not in launch_source or "userSquad.size.toFloat() / targetCount" not in launch_source:
    sys.exit("FAIL: Auction progress must count hidden bonus players in the visible squad total")
if 'Text("${userSquad.size}/$targetCount"' not in launch_source or 'Text("${aiSquad.size}/$targetCount"' not in launch_source:
    sys.exit("FAIL: Auction result squad totals must include hidden bonus players")
if "val aiIsBehind = aiTeam.sumOf { it.rating } < team.sumOf { it.rating }" not in launch_source:
    sys.exit("FAIL: Deal or No Deal AI must adapt its draft choices to the user's current squad rating")
if "aiMaxForLot >= opening" not in launch_source or "opening.coerceAtMost(aiBudget)" not in launch_source:
    sys.exit("FAIL: AI must not buy a player below the opening bid when its budget is insufficient")
if "boxes.indices.filter { it != firstBoxIndex }.randomOrNull()" not in launch_source:
    sys.exit("FAIL: Deal bank offer must select randomly among the three unopened boxes")
if launch_source.count("MatchEngine.simulate(") < 2:
    sys.exit("FAIL: Auction and Deal or No Deal must both simulate a match")
if launch_source.count("ScoreRepository.submit(database, user,") != 2:
    sys.exit("FAIL: Auction and Deal or No Deal must both submit completed-game scores")
if "fun AuctionGameScreen(user: FirebaseUser" not in launch_source or "fun DealOrNoDealScreen(user: FirebaseUser" not in launch_source:
    sys.exit("FAIL: completed games are missing authenticated score context")


question_rows = re.findall(
    r'q\("(s\d+)",\s*"([^"]+)",\s*"([^"]+)",\s*listOf\(([^)]*)\),\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)",\s*listOf\(([^)]*)\)',
    questions_source,
)
if len(question_rows) != 140 or len({row[0] for row in question_rows}) != 140:
    sys.exit(f"FAIL: expected 140 unique built-in questions, found {len(question_rows)}")
if len({row[1] for row in question_rows}) != 140 or len({row[6] for row in question_rows}) != 140:
    sys.exit("FAIL: duplicate Arabic or English question prompts detected")
answer_leaks = [row[0] for row in question_rows if row[2].strip() and row[2].strip() in row[1]]
answer_leaks_en = [row[0] for row in question_rows if row[7].strip().casefold() in row[6].casefold()]
if answer_leaks or answer_leaks_en:
    sys.exit(f"FAIL: answers appear in prompt text (AR={answer_leaks}, EN={answer_leaks_en})")
invalid_options = []
for row in question_rows:
    wrong_ar = re.findall(r'"([^"]+)"', row[3])
    wrong_en = re.findall(r'"([^"]+)"', row[8])
    if len(wrong_ar) != 3 or len(set(wrong_ar)) != 3 or len(wrong_en) != 3 or len(set(wrong_en)) != 3 or row[2] in wrong_ar or row[7] in wrong_en:
        invalid_options.append(row[0])
if invalid_options:
    sys.exit(f"FAIL: questions must have three distinct wrong options: {invalid_options}")
invalid_difficulty = [row[0] for row in question_rows if row[4] not in {"easy", "medium", "hard"}]
if invalid_difficulty:
    sys.exit(f"FAIL: invalid question difficulty values: {invalid_difficulty}")
difficulty_counts = {level: sum(1 for row in question_rows if row[4] == level) for level in ("easy", "medium", "hard")}
if difficulty_counts != {"easy": 42, "medium": 48, "hard": 50}:
    sys.exit(f"FAIL: unexpected question difficulty distribution: {difficulty_counts}")

# Session 9 policy checks: ordered role slots, shared music, and developer diagnostics.
positions_source = players_source
expected_order = 'listOf("GK", "RB", "CB", "CB", "LB", "CDM", "CM", "CAM", "RW", "LW", "ST")'
if expected_order not in positions_source or "ordered.add(player.copy(position = slot))" not in positions_source:
    sys.exit("FAIL: shared canonical position order is missing from the player-pool helper")
if "ElbashaPositions.supports(it, position)" not in launch_source or "dealBoxesForRound(round" not in launch_source:
    sys.exit("FAIL: Auction and Deal or No Deal must assign players by the ordered role slot")
sound_source = (BASE / "SoundManager.kt").read_text(encoding="utf-8")
if "MediaPlayer" not in sound_source or "fun setSharedMusic(file: File)" not in sound_source:
    sys.exit("FAIL: shared group music playback is missing")
if "Sfx.Win to pool.load" not in sound_source or "Sfx.Loss to pool.load" not in sound_source or "Sfx.HiddenReveal to pool.load" not in sound_source or "effect !in setOf(Sfx.Win, Sfx.Loss, Sfx.HiddenReveal)" not in sound_source:
    sys.exit("FAIL: only win/loss and hidden-player reveal effects may be audible")
if not (ROOT / "app/src/main/res/raw/sfx_hidden_reveal.ogg").is_file():
    sys.exit("FAIL: hidden-player reveal drum effect is missing")
if "AnimatedVisibility" not in launch_source or "scaleIn(initialScale = 0.72f" not in launch_source:
    sys.exit("FAIL: hidden-player reveal must animate into view")
ui_source = (BASE / "ElbashaUi.kt").read_text(encoding="utf-8")
if ui_source.count("sound.clearSharedMusic()") != 3:
    sys.exit("FAIL: shared music cleanup must only belong to its own listener lifecycle")
raw_audio = ROOT / "app/src/main/res/raw"
if (raw_audio / "music_menu.ogg").exists() or (raw_audio / "music_tournament.ogg").exists():
    sys.exit("FAIL: bundled music resources must be removed")
ui_source_full = (BASE / "ElbashaUi.kt").read_text(encoding="utf-8")
if 'child(".info/connected")' not in ui_source_full or "BuildConfig.VERSION_NAME" not in ui_source_full:
    sys.exit("FAIL: developer diagnostics must include Firebase connection and app build information")
player_image_source = (BASE / "PlayerImage.kt").read_text(encoding="utf-8")
if "pilicense=free" not in player_image_source or "upload.wikimedia.org" not in player_image_source or "PlayerPortrait" not in player_image_source:
    sys.exit("FAIL: player portrait resolver must use free Wikimedia page-image results and a visible portrait component")
if "fun cachedCount(context: Context)" not in player_image_source or "fun clearCache(context: Context)" not in player_image_source:
    sys.exit("FAIL: local player portrait cache diagnostics and clearing are missing")
if "PlayerPortrait(player = player" not in (BASE / "PremiumGameUi.kt").read_text(encoding="utf-8") or "PlayerPortrait(player = player" not in launch_source:
    sys.exit("FAIL: player portraits must appear in selection, reveal, and squad cards")
if "Download all ${PlayerDatabase.players.size} player portraits" not in ui_source_full or "PlayerImageRepository.load(appContext, player.nameEn)" not in ui_source_full:
    sys.exit("FAIL: developer panel must offer progressive full-catalog photo preload")
if "isDeveloper = ElbashaAccess.isDeveloper(user.uid)" not in ui_source_full or 'child("admins")' in ui_source_full:
    sys.exit("FAIL: developer access must remain restricted to the configured developer UID")

print("PASS: 192 unique players with country flags and bilingual nationality labels")
print("PASS: all players have matching Arabic display names and search aliases")
print("PASS: position distribution is valid (GK 34 / DF 44 / MF 48 / WG 37 / ST 29)")
print("PASS: prime OVR range is open-ended; Messi and Cristiano use 94 historical base OVR")
print("PASS: player catalog uses the prime-era rating model")
print("PASS: player prices scale consistently with prime OVR")
print("PASS: shared 3-character player suggestions and Build Team AI challenge")
print("PASS: four AI difficulty levels in all three first-release games")
print("PASS: all 4..11-player formations follow the canonical GK-to-ST slot families")
print("PASS: shared match engine used by first-release games")
print("PASS: first-release catalog contains the three selected games")
print("PASS: Auction hidden-player reward, correct squad completion, Wild Card discount and AI opening-bid guard")
print("PASS: Deal bank offer picks a random unopened box")
print("PASS: both Auction and Deal or No Deal run a match simulation")
print("PASS: Auction and Deal or No Deal submit completed scores")
print("PASS: Deal or No Deal AI uses an adaptive rating-based draft")
print("PASS: release workflow calculates versionCode with shell arithmetic")
print("PASS: Firebase URL, Google web client ID and Android package match google-services.json")
print("PASS: updater verifies completed downloads and clears stale APKs")
print("PASS: 140 unique questions, 42 easy / 48 medium / 50 hard, four choices each, no answer leakage")
print("PASS: canonical GK-to-ST order is used across player-picking flows")
print("PASS: developer-only shared music, Realtime Database rules, and separate win/loss effects")
print("PASS: stadium-style backgrounds are applied across main and game screens")
print("PASS: developer panel exposes Firebase connection and build diagnostics")
print("PASS: free Wikimedia portrait resolver, local cache, squad-card integration and batch-preload control")
print("PASS: developer access is restricted to the configured UID")
