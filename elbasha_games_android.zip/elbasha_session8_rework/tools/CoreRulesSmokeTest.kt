import com.mostafabek.elbashagames.AuctionRules
import com.mostafabek.elbashagames.AuctionWinner
import com.mostafabek.elbashagames.DealRules
import com.mostafabek.elbashagames.BuildTeamRules
import com.mostafabek.elbashagames.PlayerDatabase
import com.mostafabek.elbashagames.PlayerCard
import com.mostafabek.elbashagames.ElbashaPositions
import com.mostafabek.elbashagames.MatchEngine
import kotlin.random.Random

/** Run with kotlinc PlayerDatabase.kt MatchEngine.kt AuctionRules.kt tools/CoreRulesSmokeTest.kt -include-runtime -d core-smoke.jar */
fun main() {
    check(AuctionRules.openingPrice(94) == 6)
    check(AuctionRules.openingPrice(70) == 5)
    check(AuctionRules.spendLimit(100, 4) == 80)
    check(AuctionRules.spendLimit(15, 3) == 0)
    check(AuctionRules.spendLimit(100, -2) == 100)
    check(AuctionRules.spendLimitForLots(100, listOf(
        PlayerCard("A", "أ", "ST", 92, 6, ""),
        PlayerCard("B", "ب", "GK", 84, 6, "")
    )) == 88)
    check(AuctionRules.spendLimitForLots(10, listOf(
        PlayerCard("A", "أ", "ST", 92, 6, ""),
        PlayerCard("B", "ب", "GK", 84, 6, "")
    )) == 0)
    check(AuctionRules.isValidUserBid(11, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(10, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(21, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(4, 0, 5, 20))
    check(AuctionRules.payablePrice(10, 6, true) == 8)
    check(AuctionRules.payablePrice(7, 6, true) == 6)
    check(AuctionRules.payablePrice(10, 6, false) == 10)
    check(AuctionRules.canBuyOpening(6, 8, 6))
    check(!AuctionRules.canBuyOpening(6, 8, 5))
    check(!AuctionRules.canBuyOpening(6, 5, 10))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 8, 20) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 6))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 6, 15) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 6))
    check(AuctionRules.settleWhenUserPasses(17, 6, true, 20, 20) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.Ai, 17))
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 5, 20).winner == AuctionWinner.Unsold)
    check(AuctionRules.settleWhenUserPasses(5, 6, false, 20, 5).winner == AuctionWinner.Unsold)
    check(AuctionRules.settleWhenAiPasses(7, 6, true) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.User, 6))
    check(AuctionRules.settleWhenAiPasses(10, 6, false) ==
        com.mostafabek.elbashagames.AuctionSettlement(AuctionWinner.User, 10))
    check(AuctionRules.calculateAiBidCeiling(92, 6, 4, 3, 1, Random(1)) == 0)
    check(AuctionRules.calculateAiBidCeiling(92, 6, 200, 3, 0, Random(1)) == 0)

    // The AI must reserve exact minimum opening costs for every future lot.
    for (size in 5..11) {
        val lots = ElbashaPositions.auctionPool(size, 42)
        for (index in lots.indices) {
            val queued = lots.drop(index + 1)
            val budget = 200
            val allowedCurrentSpend = AuctionRules.spendLimitForLots(budget, queued)
            check(allowedCurrentSpend + queued.sumOf { AuctionRules.openingPrice(it.rating) } <= budget)
            if (queued.isNotEmpty()) check(allowedCurrentSpend >= 0)
        }
    }

    // Difficulty must raise the AI's average ceiling without allowing it over budget.
    val auctionCeilingAverages = (0..3).map { difficulty ->
        (0 until 2_000).map { seed ->
            AuctionRules.calculateAiBidCeiling(90, 6, 100, difficulty, 1, Random(difficulty * 20_000 + seed))
        }.also { values -> values.forEach { check(it == 0 || it in 6..100) } }.filter { it > 0 }.average()
    }
    check(auctionCeilingAverages.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Auction AI difficulty should raise average bid ceilings: $auctionCeilingAverages"
    }
    repeat(10_000) { seed ->
        val budget = seed % 60
        val opening = 5 + seed % 8
        val ceiling = AuctionRules.calculateAiBidCeiling(70 + seed % 30, opening, budget, seed % 4, seed % 3, Random(seed))
        check(ceiling == 0 || (ceiling >= opening && ceiling <= budget))
    }

    // A hidden player that collides with a queued lot must replace it, not shorten the game.
    repeat(1_000) { seed ->
        val size = if (seed % 2 == 0) 5 else 11
        val lots = ElbashaPositions.auctionPool(size, 42)
        val collision = lots[seed % lots.size]
        val preserved = AuctionRules.preserveQueueAfterHiddenReward(
            remainingLots = lots,
            hiddenPlayer = collision,
            occupiedNames = emptySet(),
            random = Random(seed)
        )
        check(preserved.size == lots.size)
        check(preserved.map { it.nameEn }.distinct().size == preserved.size)
        check(preserved[seed % lots.size].nameEn != collision.nameEn)
        check(ElbashaPositions.poolRole(preserved[seed % lots.size].position) == ElbashaPositions.poolRole(collision.position))
    }
    val noCollisionPool = ElbashaPositions.auctionPool(5, 24)
    val unrelatedHidden = PlayerDatabase.players.first { it.nameEn !in noCollisionPool.map(PlayerCard::nameEn) }
    check(AuctionRules.preserveQueueAfterHiddenReward(noCollisionPool, unrelatedHidden, emptySet()) == noCollisionPool)

    repeat(10_000) { seed ->
        val current = seed % 40
        val ceiling = current + (seed % 12)
        val budget = current + (seed % 14)
        val next = AuctionRules.nextAiBid(current, ceiling, budget, Random(seed))
        if (next != null) {
            check(next > current && next <= ceiling && next <= budget)
            check(next - current in setOf(1, 5, 10))
        } else {
            check(listOf(1, 5, 10).none { current + it <= ceiling && current + it <= budget })
        }
    }

    for (size in 4..11) {
        val slots = ElbashaPositions.formationSlots(size)
        check(slots.size == size && slots.first() == "GK" && slots.last() == "ST")
        check(slots.any { it in setOf("CDM", "CM", "CAM") })
        check(slots.any { it in setOf("RB", "CB", "LB") })
        val pool = ElbashaPositions.auctionPool(size, 42)
        check(pool.size == size && pool.map { it.nameEn }.distinct().size == size)
        check(pool.zip(slots).all { (player, slot) -> player.position == slot })
    }

    val dealSlot = "GK"
    val visibleBoxes = PlayerDatabase.players.filter { it.position == dealSlot }.take(4)
    val userOwned = listOf(PlayerDatabase.players.first { it.position == dealSlot && it.nameEn !in visibleBoxes.map { p -> p.nameEn } })
    val eligibleDealAi = DealRules.eligibleAiPlayers(PlayerDatabase.players, dealSlot, userOwned, emptyList(), visibleBoxes)
    check(eligibleDealAi.none { it.nameEn in (visibleBoxes + userOwned).map { p -> p.nameEn } })
    check(eligibleDealAi.all { ElbashaPositions.supports(it, dealSlot) })
    repeat(2_000) { seed ->
        val selected = DealRules.chooseAiPlayer(PlayerDatabase.players, dealSlot, userOwned, emptyList(), visibleBoxes, seed % 4, Random(seed))
        check(selected != null && selected.nameEn !in (visibleBoxes + userOwned).map { it.nameEn })
        check(ElbashaPositions.supports(selected, dealSlot))
        val bankIndex = DealRules.randomUnopenedBoxIndex(4, seed % 4, Random(seed))
        check(bankIndex != null && bankIndex in 0..3 && bankIndex != seed % 4)
    }
    check(DealRules.randomUnopenedBoxIndex(1, 0, Random(1)) == null)
    for (boxCount in 2..10) {
        for (opened in 0 until boxCount) {
            repeat(20) { seed ->
                val index = DealRules.randomUnopenedBoxIndex(boxCount, opened, Random(seed * 17 + opened))
                check(index != null && index in 0 until boxCount && index != opened)
            }
        }
    }
    val allSlots = ElbashaPositions.formationSlots(11)
    repeat(1_000) { seed ->
        val slot = allSlots[seed % allSlots.size]
        val visible = PlayerDatabase.players.filter { ElbashaPositions.supports(it, slot) }
            .shuffled(Random(seed)).take(4)
        val chosen = visible.first()
        val ai = DealRules.chooseAiPlayer(
            PlayerDatabase.players, slot, listOf(chosen), emptyList(), visible, seed % 4, Random(seed * 13)
        )
        check(ai != null && ai.position == slot)
        check(ai.nameEn !in visible.map { it.nameEn })
    }
    repeat(250) { seed ->
        var userTeam = emptyList<com.mostafabek.elbashagames.PlayerCard>()
        var aiTeam = emptyList<com.mostafabek.elbashagames.PlayerCard>()
        for (round in 0 until 5) {
            val slot = ElbashaPositions.formationSlots(5)[round]
            val boxesForRound = PlayerDatabase.players
                .filter { ElbashaPositions.supports(it, slot) && it.nameEn !in (userTeam + aiTeam).map { p -> p.nameEn } }
                .shuffled(Random(seed * 31 + round))
                .take(4)
            check(boxesForRound.size == 4)
            val userPick = boxesForRound[seed % boxesForRound.size]
            userTeam = userTeam + userPick.copy(position = slot)
            val aiPick = DealRules.chooseAiPlayer(
                PlayerDatabase.players, slot, userTeam, aiTeam, boxesForRound, seed % 4,
                Random(seed * 101 + round)
            )
            check(aiPick != null && aiPick.nameEn !in (userTeam + aiTeam + boxesForRound).map { it.nameEn })
            aiTeam = aiTeam + aiPick
        }
        check(userTeam.size == 5 && aiTeam.size == 5)
        check((userTeam + aiTeam).map { it.nameEn }.distinct().size == 10)
    }

    // Real Deal box generation: four unique players of the required role on every round.
    val dealSlots = ElbashaPositions.formationSlots(5)
    repeat(500) { seed ->
        dealSlots.forEachIndexed { index, slot ->
            val boxes = DealRules.createRoundBoxes(PlayerDatabase.players, slot, emptySet(), Random(seed * 11 + index))
            check(boxes.size == 4)
            check(boxes.map { it.nameEn }.distinct().size == 4)
            check(boxes.all { it.position == slot })
        }
    }

    // Full Build Team drafts: both sides must select distinct players from the exact challenge.
    for (size in 4..11) {
        repeat(100) { seed ->
            val slots = ElbashaPositions.formationSlots(size)
            val userTeam = mutableListOf<PlayerCard>()
            val aiTeam = mutableListOf<PlayerCard>()
            for ((round, slot) in slots.withIndex()) {
                val excluded = (userTeam + aiTeam).map { it.nameEn }.toSet()
                val challenge = BuildTeamRules.createNationalityChallenge(
                    PlayerDatabase.players, slot, excluded, Random(seed * 31 + round)
                ) ?: error("No nationality challenge for size=$size slot=$slot seed=$seed")
                val userCandidates = BuildTeamRules.eligiblePlayers(PlayerDatabase.players, challenge, excluded)
                check(userCandidates.size >= 2)
                val userPick = userCandidates.random(Random(seed * 101 + round))
                val aiCandidates = BuildTeamRules.eligiblePlayers(
                    PlayerDatabase.players, challenge, excluded + userPick.nameEn
                )
                val aiPick = BuildTeamRules.chooseAiPlayer(aiCandidates, seed % 4, Random(seed * 211 + round))
                    ?: error("AI had no legal pick for $challenge")
                check(userPick.nameEn != aiPick.nameEn)
                check(userPick.nationalityEn == challenge.nationalityEn && aiPick.nationalityEn == challenge.nationalityEn)
                check(ElbashaPositions.supports(userPick, slot) && ElbashaPositions.supports(aiPick, slot))
                userTeam += userPick.copy(position = slot)
                aiTeam += aiPick.copy(position = slot)
            }
            check(userTeam.size == size && aiTeam.size == size)
            check((userTeam + aiTeam).map { it.nameEn }.distinct().size == size * 2)
        }
    }
    val buildCandidates = PlayerDatabase.players.filter { ElbashaPositions.supports(it, "DF") }
    val buildDifficultyAverages = (0..3).map { difficulty ->
        (0 until 1_000).map { seed ->
            BuildTeamRules.chooseAiPlayer(buildCandidates, difficulty, Random(difficulty * 10_000 + seed))!!.rating.toDouble()
        }.average()
    }
    check(buildDifficultyAverages.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Build Team AI difficulty should produce stronger average picks: $buildDifficultyAverages"
    }

    // Bank deals can leave the user with more than five players; only the best valid five are fielded.
    repeat(500) { seed ->
        val userTeam = mutableListOf<PlayerCard>()
        val aiTeam = mutableListOf<PlayerCard>()
        dealSlots.forEachIndexed { round, slot ->
            val excluded = (userTeam + aiTeam).map { it.nameEn }.toSet()
            val boxes = DealRules.createRoundBoxes(PlayerDatabase.players, slot, excluded, Random(seed * 17 + round))
            check(boxes.size == 4)
            val firstIndex = seed % boxes.size
            val secondIndex = DealRules.randomUnopenedBoxIndex(boxes.size, firstIndex, Random(seed + round))!!
            // Alternate ordinary choices and accepting a bank deal (two players).
            if ((seed + round) % 3 == 0) {
                userTeam += boxes[firstIndex]
                userTeam += boxes[secondIndex]
            } else {
                userTeam += boxes[firstIndex]
            }
            val aiPick = DealRules.chooseAiPlayer(
                PlayerDatabase.players, slot, userTeam, aiTeam, boxes, seed % 4, Random(seed * 43 + round)
            ) ?: error("Deal AI failed to find a legal player")
            aiTeam += aiPick
        }
        check(userTeam.map { it.nameEn }.distinct().size == userTeam.size)
        check(aiTeam.size == 5 && aiTeam.map { it.nameEn }.distinct().size == 5)
        check((userTeam + aiTeam).map { it.nameEn }.distinct().size == userTeam.size + aiTeam.size)
        val bestLineup = MatchEngine.selectBestLineup(userTeam, 5)
        check(bestLineup.size == 5)
        check(MatchEngine.positionalFit(bestLineup, 5) == 1.0)
    }

    val buildDifficulty = (0..3).map { difficulty ->
        (0 until 1_000).map { seed ->
            DealRules.chooseAiPlayer(
                PlayerDatabase.players.filter { ElbashaPositions.supports(it, "GK") },
                "GK", emptyList(), emptyList(), emptyList(), difficulty, Random(difficulty * 20_000 + seed)
            )!!.rating.toDouble()
        }.average()
    }
    check(buildDifficulty.zipWithNext().all { (easier, harder) -> harder > easier }) {
        "Deal AI difficulty should produce stronger average picks: $buildDifficulty"
    }

    val classic = ElbashaPositions.auctionPool(5, 24)
    repeat(1_000) {
        val result = MatchEngine.simulate(classic, ElbashaPositions.auctionPool(5, 24), targetSquadSize = 5)
        check(result.userGoals in 0..6 && result.opponentGoals in 0..6)
    }
    // A strong duplicate-role substitute must not create an invalid starting lineup.
    val extraGoalkeeper = PlayerDatabase.players.first { it.position == "GK" && it.nameEn !in classic.map { p -> p.nameEn } }
        .copy(position = "GK")
    val bankedSquad = listOf(extraGoalkeeper) + classic
    val bestFive = MatchEngine.selectBestLineup(bankedSquad, 5)
    check(bestFive.size == 5 && MatchEngine.positionalFit(bestFive, 5) == 1.0)
    repeat(1_000) { seed ->
        val result = MatchEngine.simulate(bankedSquad, classic, random = Random(seed), targetSquadSize = 5)
        check(result.userGoals in 0..6 && result.opponentGoals in 0..6)
    }
    println("PASS: Auction bids (10,000 randomized cases), hidden reward queue stability (1,000 cases), Deal AI and unopened boxes, full 4..11-player Build Team drafts (800 games), 2,500 generated Deal rounds, 500 bank-deal drafts with best-five selection, four-level AI strength ordering, and 2,000 match simulations")
}
