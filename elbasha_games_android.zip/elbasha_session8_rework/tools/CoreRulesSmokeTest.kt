import com.mostafabek.elbashagames.AuctionRules
import com.mostafabek.elbashagames.ElbashaPositions
import com.mostafabek.elbashagames.MatchEngine
import kotlin.random.Random

/** Run with kotlinc PlayerDatabase.kt MatchEngine.kt AuctionRules.kt tools/CoreRulesSmokeTest.kt -include-runtime -d core-smoke.jar */
fun main() {
    check(AuctionRules.openingPrice(94) == 6)
    check(AuctionRules.openingPrice(70) == 5)
    check(AuctionRules.spendLimit(100, 4) == 80)
    check(AuctionRules.spendLimit(15, 3) == 0)
    check(AuctionRules.spendLimit(100, -2) == 100)
    check(AuctionRules.isValidUserBid(11, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(10, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(21, 10, 5, 20))
    check(!AuctionRules.isValidUserBid(4, 0, 5, 20))
    check(AuctionRules.payablePrice(10, 6, true) == 8)
    check(AuctionRules.payablePrice(7, 6, true) == 6)
    check(AuctionRules.payablePrice(10, 6, false) == 10)
    check(AuctionRules.canBuyOpening(6, 8, 6))
    check(!AuctionRules.canBuyOpening(6, 8, 5))
    check(!AuctionRules.canBuyOpening(6, 5, 10))

    repeat(10_000) { seed ->
        val current = seed % 40
        val ceiling = current + (seed % 12)
        val budget = current + (seed % 14)
        val next = AuctionRules.nextAiBid(current, ceiling, budget, Random(seed))
        if (next != null) {
            check(next > current && next <= ceiling && next <= budget)
            check(next - current in setOf(1, 5, 10))
        } else {
            check(listOf(1, 5, 10).none { current + it <= ceiling && current + it <= budget })
        }
    }

    for (size in 4..11) {
        val slots = ElbashaPositions.formationSlots(size)
        check(slots.size == size && slots.first() == "GK" && slots.last() == "ST")
        check(slots.any { it in setOf("CDM", "CM", "CAM") })
        check(slots.any { it in setOf("RB", "CB", "LB") })
        val pool = ElbashaPositions.auctionPool(size, 42)
        check(pool.size == size && pool.map { it.nameEn }.distinct().size == size)
        check(pool.zip(slots).all { (player, slot) -> player.position == slot })
    }

    val classic = ElbashaPositions.auctionPool(5, 24)
    repeat(1_000) {
        val result = MatchEngine.simulate(classic, ElbashaPositions.auctionPool(5, 24))
        check(result.userGoals in 0..6 && result.opponentGoals in 0..6)
    }
    println("PASS: Auction rules (10,000 randomized cases), 4..11 balanced formations, and 1,000 match simulations")
}
