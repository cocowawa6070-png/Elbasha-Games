package com.mostafabek.elbashagames

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class LocalPhase { Setup, Handover, Picking, Result }

/**
 * Build a Team for 2-4 people on ONE phone, fully offline.
 * Every position all players pick a different footballer from the same requirement; the phone is
 * handed over between turns so nobody sees another player's squad until the final reveal.
 * Results are not written to the online leaderboard (local games only).
 */
@Composable
fun BuildTeamLocalScreen(sound: SoundManager, onExit: () -> Unit) {
    val english = LocalAppUiSettings.current.english
    var phase by remember { mutableStateOf(LocalPhase.Setup) }
    var playerCount by remember { mutableIntStateOf(2) }
    var teamSize by remember { mutableIntStateOf(5) }
    val nameInputs = remember { mutableStateListOf("", "", "", "") }
    var names by remember { mutableStateOf<List<String>>(emptyList()) }
    var slotIndex by remember { mutableIntStateOf(0) }
    var turnIndex by remember { mutableIntStateOf(0) }
    var challenge by remember { mutableStateOf<NationalityChallenge?>(null) }
    var searchText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var pickLocked by remember { mutableStateOf(false) }
    var resultSoundPlayed by remember { mutableStateOf(false) }
    val teams = remember { List(PassAndPlayRules.MAX_PLAYERS) { mutableStateListOf<PlayerCard>() } }
    val formation = remember(teamSize) { ElbashaPositions.formationSlots(teamSize) }

    val activeTeams = teams.take(names.size.coerceAtLeast(1)).map { it.toList() }
    val usedNames = teams.flatMap { it }.map { it.nameEn }.toSet()
    val order = if (names.isEmpty()) emptyList() else PassAndPlayRules.pickingOrder(names.size, slotIndex)
    val currentPlayer = order.getOrNull(turnIndex) ?: 0
    val currentName = names.getOrNull(currentPlayer).orEmpty()
    val activeChallenge = challenge
    val eligible = if (activeChallenge == null) emptyList()
    else PassAndPlayRules.eligiblePlayers(PlayerDatabase.players, activeChallenge, usedNames)
    val suggestions = PlayerSearch.suggestions(eligible, searchText, limit = 10)

    fun newChallengeFor(slot: Int): NationalityChallenge? =
        PassAndPlayRules.createChallenge(
            PlayerDatabase.players, formation[slot],
            teams.flatMap { it }.map { it.nameEn }.toSet(), names.size
        )

    fun startGame() {
        names = PassAndPlayRules.normalizeNames(nameInputs.toList(), playerCount) {
            if (english) "Player $it" else "لاعب $it"
        }
        teams.forEach { it.clear() }
        slotIndex = 0
        turnIndex = 0
        searchText = ""
        status = ""
        pickLocked = false
        resultSoundPlayed = false
        challenge = newChallengeFor(0)
        if (challenge == null) {
            status = localizedText(english, "قاعدة اللاعبين لا تكفي لهذا العدد.", "Not enough players in the database for this setup.")
            return
        }
        sound.play(Sfx.Click)
        phase = LocalPhase.Handover
    }

    fun choosePlayer(player: PlayerCard) {
        if (phase != LocalPhase.Picking || pickLocked) return
        val active = challenge ?: return
        if (player !in eligible) return
        // Lock synchronously so a double tap cannot draft twice.
        pickLocked = true
        teams[currentPlayer].add(player.copy(position = active.positionCode))
        searchText = ""
        sound.play(Sfx.Correct)
        sound.vibrate(22)
        if (turnIndex < names.size - 1) {
            turnIndex++
            phase = LocalPhase.Handover
        } else if (slotIndex < formation.lastIndex) {
            slotIndex++
            turnIndex = 0
            challenge = newChallengeFor(slotIndex)
            if (challenge == null) {
                status = localizedText(english, "خلصت اختيارات اللاعبين المتاحة للمركز ده.", "The player pool for this position is exhausted.")
                phase = LocalPhase.Result
            } else {
                phase = LocalPhase.Handover
            }
        } else {
            phase = LocalPhase.Result
        }
    }

    BackHandler { onExit() }
    LaunchedEffect(phase, slotIndex, turnIndex) {
        // Unlock only after the next turn has been rendered.
        if (phase == LocalPhase.Picking) pickLocked = false
    }

    val points = PassAndPlayRules.tally(activeTeams, formation.size)
    val totals = activeTeams.map { team -> team.sumOf { it.rating } }
    val winners = if (phase == LocalPhase.Result) PassAndPlayRules.winners(points, totals) else emptyList()
    LaunchedEffect(phase) {
        if (phase == LocalPhase.Result && !resultSoundPlayed) {
            resultSoundPlayed = true
            sound.play(Sfx.Win)
        }
    }

    Column(
        Modifier.fillMaxSize().elbashaAtmosphere().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onExit) { Text(localizedText(english, "→ رجوع", "← Back"), color = Gold) }
            Spacer(Modifier.weight(1f))
            SoundToggles(sound)
        }
        Text(localizedText(english, "📱 كون فريق — جهاز واحد", "📱 Build a Team — one phone"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)

        when (phase) {
            LocalPhase.Setup -> {
                HowToPlayCard(
                    title = localizedText(english, "طريقة اللعب", "How to play"),
                    steps = if (english) listOf(
                        "Choose 2 to 4 players and a squad size from 4 to 11.",
                        "Every position has the same requirement for everyone.",
                        "Each player picks a DIFFERENT footballer, one after another, passing the phone.",
                        "Picks stay hidden until the end. The highest rating at a position wins a point.",
                        "Ties at a position give no point. The final tie-break is the total squad rating."
                    ) else listOf(
                        "اختار من 2 لـ 4 لاعبين وحجم فريق من 4 لـ 11.",
                        "كل مركز له نفس الشرط لكل اللاعبين.",
                        "كل لاعب بيختار لاعب مختلف، واحد ورا التاني، وبتسلّموا الموبايل لبعض.",
                        "الاختيارات مخفية لحد النهاية. الأعلى تقييمًا في المركز بياخد نقطة.",
                        "التعادل في مركز مفيهوش نقطة. وفي النهاية بيتحسم بمجموع تقييم الفريق."
                    ),
                    note = localizedText(english, "اللعب هنا بدون إنترنت ونتيجته لا تُسجل في لوحة المتصدرين.", "Works offline; results are not added to the leaderboard.")
                )
                Text(localizedText(english, "عدد اللاعبين", "Players"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (PassAndPlayRules.MIN_PLAYERS..PassAndPlayRules.MAX_PLAYERS).forEach { count ->
                        val selected = playerCount == count
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Gold else PanelColor)
                                .clickable { playerCount = count }
                                .padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("$count", color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black) }
                    }
                }
                repeat(playerCount) { index ->
                    OutlinedTextField(
                        value = nameInputs[index],
                        onValueChange = { nameInputs[index] = it.take(20) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(localizedText(english, "اسم اللاعب ${index + 1}", "Player ${index + 1} name")) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Cream, unfocusedTextColor = Cream,
                            focusedBorderColor = Gold, unfocusedBorderColor = Muted,
                            focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold
                        )
                    )
                }
                Text(localizedText(english, "عدد لاعبي الفريق", "Squad size"), color = Cream, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    (4..11).forEach { count ->
                        val selected = teamSize == count
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                                .background(if (selected) Gold else PanelColor)
                                .clickable { teamSize = count }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("$count", color = if (selected) DeepWine else Cream, fontWeight = FontWeight.Black, fontSize = 13.sp) }
                    }
                }
                if (status.isNotBlank()) Text(status, color = LocalElbashaPalette.current.bad)
                Button(
                    onClick = { startGame() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "ابدأ اللعب", "Start game"), fontWeight = FontWeight.Bold) }
            }

            LocalPhase.Handover -> {
                val slotTitle = formation.getOrNull(slotIndex)?.let { BuildTeamRules.positionLabels[it] }
                Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(20.dp)) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("🤝", fontSize = 44.sp)
                        Text(localizedText(english, "سلّم الموبايل لـ", "Hand the phone to"), color = Muted)
                        Text(currentName, color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                        Text(
                            localizedText(english, "المركز ${slotIndex + 1} من ${formation.size}", "Position ${slotIndex + 1} of ${formation.size}") +
                                (slotTitle?.let { "  •  " + if (english) it.second else it.first } ?: ""),
                            color = Cream, fontSize = 13.sp
                        )
                        Text(localizedText(english, "باقي اللاعبين يبعدوا عينهم عن الشاشة.", "Everyone else, look away."), color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        Button(
                            onClick = { sound.play(Sfx.Click); phase = LocalPhase.Picking },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                        ) { Text(localizedText(english, "أنا $currentName — جاهز", "I'm $currentName — ready"), fontWeight = FontWeight.Bold) }
                    }
                }
            }

            LocalPhase.Picking -> {
                val slot = formation.getOrNull(slotIndex)?.let { BuildTeamRules.positionLabels[it] }
                Text(
                    localizedText(english, "دور $currentName", "$currentName's turn") + "  •  " +
                        localizedText(english, "المركز ${slotIndex + 1} من ${formation.size}", "Position ${slotIndex + 1} of ${formation.size}"),
                    color = Cream, fontWeight = FontWeight.Bold
                )
                LinearProgressIndicator(
                    progress = { ((slotIndex * names.size + turnIndex).toFloat() / (formation.size * names.size)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = PanelColor
                )
                if (slot != null && activeChallenge != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(17.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(if (english) slot.second else slot.first, color = Gold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(
                                if (activeChallenge.nationalityEn.isBlank())
                                    localizedText(english, "الشرط: لاعب ${activeChallenge.positionAr} من أي جنسية", "Requirement: ${activeChallenge.positionEn} of any nationality")
                                else
                                    localizedText(english, "الشرط: لاعب ${activeChallenge.positionAr} من ${activeChallenge.nationalityAr}", "Requirement: ${activeChallenge.positionEn} from ${activeChallenge.nationalityEn}"),
                                color = Cream, fontWeight = FontWeight.Bold
                            )
                            Text(localizedText(english, "اللاعب اللي اتاخد قبل كده مش هيظهر في الاقتراحات.", "Players already taken do not appear in the suggestions."), color = Muted, fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text(localizedText(english, "ابحث عن لاعب مطابق", "Search for an eligible player")) },
                        placeholder = { Text(localizedText(english, "اكتب 3 حروف على الأقل", "Type at least 3 characters")) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Cream, unfocusedTextColor = Cream,
                            focusedBorderColor = Gold, unfocusedBorderColor = Muted,
                            focusedLabelColor = Gold, unfocusedLabelColor = Muted, cursorColor = Gold
                        )
                    )
                    if (PlayerSearch.normalize(searchText).length < 3) {
                        Text(localizedText(english, "اكتب 3 حروف عشان تظهر اقتراحات من قاعدة اللاعبين فقط.", "Enter 3 characters to see suggestions from the player database."), color = Muted, fontSize = 12.sp)
                    } else if (suggestions.isEmpty()) {
                        Text(localizedText(english, "مفيش لاعب مطابق للبحث والشرط الحالي.", "No player matches the search and current requirement."), color = Muted, fontSize = 12.sp)
                    }
                    suggestions.forEach { player ->
                        PremiumPlayerChoiceCard(player = player, english = english) { choosePlayer(player) }
                    }
                }
                SquadFormationPitch(
                    title = localizedText(english, "تشكيلتك ($currentName)", "Your squad ($currentName)"),
                    players = teams[currentPlayer].toList(),
                    slotCount = teamSize,
                    detailFor = { "${it.rating} OVR" }
                )
            }

            LocalPhase.Result -> {
                val ranking = PassAndPlayRules.ranking(points, totals)
                Text(localizedText(english, "🏆 النتيجة النهائية", "🏆 Final result"), color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(
                    if (winners.size == 1) localizedText(english, "👑 الفايز: ${names[winners.first()]}", "👑 Winner: ${names[winners.first()]}")
                    else localizedText(english, "تعادل بين: ${winners.joinToString(" و ") { names[it] }}", "Draw between: ${winners.joinToString(" & ") { names[it] }}"),
                    color = Gold, fontWeight = FontWeight.Bold, fontSize = 19.sp
                )
                if (status.isNotBlank()) Text(status, color = Muted, fontSize = 12.sp)
                ranking.forEachIndexed { place, player ->
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${place + 1}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Spacer(Modifier.padding(horizontal = 6.dp))
                            Text(names[player], color = Cream, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(localizedText(english, "${points[player]} نقطة", "${points[player]} pts"), color = Gold, fontWeight = FontWeight.Black)
                                Text(localizedText(english, "مجموع التقييم ${totals[player]}", "Total rating ${totals[player]}"), color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
                formation.forEachIndexed { index, code ->
                    val label = BuildTeamRules.positionLabels[code]
                    val ratings = activeTeams.map { it.getOrNull(index)?.rating ?: 0 }
                    val winnerIndex = PassAndPlayRules.slotWinner(ratings)
                    Card(colors = CardDefaults.cardColors(containerColor = PanelColor), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(label?.let { if (english) it.second else it.first } ?: code, color = Gold, fontWeight = FontWeight.Bold)
                            names.forEachIndexed { player, name ->
                                val pick = activeTeams[player].getOrNull(index)
                                val pickName = pick?.let { if (english) it.nameEn else PlayerSearch.arabicName(it.nameEn, it.nameAr) } ?: "-"
                                Text(
                                    "$name: $pickName  •  ${pick?.rating ?: 0}" + if (winnerIndex == player) "  ✅" else "",
                                    color = if (winnerIndex == player) Gold else Cream, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (winnerIndex == null) Text(localizedText(english, "تعادل — بدون نقطة", "Tie — no point"), color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                names.forEachIndexed { player, name ->
                    SquadFormationPitch(
                        title = localizedText(english, "تشكيلة $name", "$name's squad"),
                        players = activeTeams[player],
                        slotCount = teamSize
                    )
                }
                Button(
                    onClick = { phase = LocalPhase.Setup; teams.forEach { it.clear() }; challenge = null; searchText = "" },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepWine)
                ) { Text(localizedText(english, "العب تاني", "Play again")) }
            }
        }
    }
}
