package com.mostafabek.elbashagames
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HowToPlayCard(
    title: String,
    steps: List<String>,
    note: String? = null
) {
    val palette = LocalElbashaPalette.current
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize().border(1.dp, palette.gold.copy(alpha = 0.38f), RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📜", fontSize = 20.sp)
                Text(title, color = palette.gold, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(start = 8.dp))
            }
            steps.forEachIndexed { index, step ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier.size(25.dp).clip(RoundedCornerShape(9.dp))
                            .background(palette.gold.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${index + 1}", color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                    Text(step, color = palette.cream, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
                }
            }
            if (!note.isNullOrBlank()) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(palette.panelAlt).padding(11.dp)) {
                    Text(note, color = palette.muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
fun PremiumPlayerCard(
    player: PlayerCard,
    detail: String,
    eyebrow: String = "ELBASHA PLAYER"
) {
    val palette = LocalElbashaPalette.current
    val english = LocalAppUiSettings.current.english
    AnimatedVisibility(
        visible = true,
        enter = fadeIn(tween(320)) + slideInVertically(initialOffsetY = { it / 10 }, animationSpec = tween(320))
    ) {
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize().border(1.dp, palette.gold.copy(alpha = 0.58f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(palette.panelAlt, palette.panel, palette.deepWine))
            ).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PlayerPortrait(player = player, modifier = Modifier.size(width = 74.dp, height = 88.dp), cornerRadius = 15)
            Column(
                Modifier.size(width = 58.dp, height = 66.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.verticalGradient(listOf(palette.gold, Color(0xFF9C6421))))
                    .padding(5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("${player.rating}", color = palette.deepWine, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = palette.deepWine, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(eyebrow, color = palette.gold, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text(
                    if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr),
                    color = palette.cream, fontSize = 17.sp, fontWeight = FontWeight.Black
                )
                Text(
                    "${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.position}",
                    color = palette.muted, fontSize = 11.sp
                )
                Text(detail, color = palette.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text("♛", color = palette.gold, fontSize = 19.sp)
        }
    }
    }
}

@Composable
fun PremiumAbilityCard(
    symbol: String,
    title: String,
    description: String,
    status: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().animateContentSize().border(
            1.dp,
            if (enabled) palette.gold.copy(alpha = 0.65f) else palette.muted.copy(alpha = 0.25f),
            RoundedCornerShape(17.dp)
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) palette.panelAlt else palette.surface,
            disabledContainerColor = palette.surface
        ),
        shape = RoundedCornerShape(17.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp))
                    .background(if (enabled) palette.gold.copy(alpha = 0.19f) else palette.muted.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) { Text(symbol, fontSize = 23.sp) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = if (enabled) palette.cream else palette.muted, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Text(description, color = palette.muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
            Text(status, color = if (enabled) palette.gold else palette.muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
        }
    }
}

@Composable
fun MysteryBoxCard(
    index: Int,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.55f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(palette.panelAlt, palette.panel))).padding(vertical = 17.dp, horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text("🎁", fontSize = 34.sp)
            Text("${label.uppercase()}  $index", color = palette.gold, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("✦  ?  ✦", color = palette.cream, fontSize = 17.sp, fontWeight = FontWeight.Black)
            Text(if (LocalAppUiSettings.current.english) "TAP TO REVEAL" else "اضغط للكشف", color = palette.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PremiumPlayerChoiceCard(
    player: PlayerCard,
    english: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalElbashaPalette.current
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.35f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            PlayerPortrait(player = player, modifier = Modifier.size(width = 54.dp, height = 62.dp), cornerRadius = 12)
            Column(
                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(palette.gold.copy(alpha = 0.16f)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("${player.rating}", color = palette.gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("OVR", color = palette.muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr), color = palette.cream, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text("${player.flag}  ${if (english) player.nationalityEn else player.nationalityAr}  •  ${player.position}", color = palette.muted, fontSize = 10.sp)
            }
            Text(if (english) "PICK  ›" else "اختار  ›", color = palette.gold, fontWeight = FontWeight.Black, fontSize = 10.sp)
        }
    }
}


/** Visual squad board shared by Auction, Deal or No Deal, and Build Team. */
@Composable
fun SquadFormationPitch(
    title: String,
    players: List<PlayerCard>,
    slotCount: Int,
    detailFor: (PlayerCard) -> String = { "${it.rating} OVR" }
) {
    val palette = LocalElbashaPalette.current
    val english = LocalAppUiSettings.current.english
    val slots = ElbashaPositions.formationSlots(slotCount.coerceIn(4, 11))
    val playersByRole = players.groupBy { ElbashaPositions.poolRole(it.position) }
    val rows = listOf("ST", "WG", "MF", "DF", "GK").mapNotNull { role ->
        val roleSlots = slots.filter { ElbashaPositions.poolRole(it) == role }
        if (roleSlots.isEmpty()) null else {
            roleSlots.mapIndexed { index, slot -> slot to playersByRole[role]?.getOrNull(index) }
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, palette.gold.copy(alpha = 0.48f), RoundedCornerShape(22.dp)),
        colors = CardDefaults.cardColors(containerColor = palette.panel),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("${players.size}/${slotCount.coerceIn(4, 11)}", color = palette.cream, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier.fillMaxWidth().height(286.dp).clip(RoundedCornerShape(17.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF075437), Color(0xFF063B2D), Color(0xFF075437))))
                    .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(17.dp))
            ) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.22f)).align(Alignment.Center))
                Box(Modifier.size(68.dp).border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape).align(Alignment.Center))
                Box(Modifier.fillMaxWidth(0.42f).height(24.dp).border(1.dp, Color.White.copy(alpha = 0.20f)).align(Alignment.TopCenter))
                Box(Modifier.fillMaxWidth(0.42f).height(24.dp).border(1.dp, Color.White.copy(alpha = 0.20f)).align(Alignment.BottomCenter))
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    rows.forEach { line ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            line.forEach { (slot, player) ->
                                Column(Modifier.width(70.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    if (player != null) {
                                        PlayerPortrait(player, Modifier.width(43.dp).height(49.dp), cornerRadius = 8)
                                        Text(
                                            if (english) player.nameEn else PlayerSearch.arabicName(player.nameEn, player.nameAr),
                                            color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                                        )
                                        Text(detailFor(player), color = palette.gold, fontSize = 8.sp, fontWeight = FontWeight.Black, maxLines = 1)
                                    } else {
                                        Box(
                                            Modifier.size(39.dp).border(1.dp, Color.White.copy(alpha = 0.48f), CircleShape)
                                                .background(Color.Black.copy(alpha = 0.12f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(slot, color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp, fontWeight = FontWeight.Black)
                                        }
                                        Text(if (english) "Open slot" else "مركز فارغ", color = Color.White.copy(alpha = 0.65f), fontSize = 8.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
